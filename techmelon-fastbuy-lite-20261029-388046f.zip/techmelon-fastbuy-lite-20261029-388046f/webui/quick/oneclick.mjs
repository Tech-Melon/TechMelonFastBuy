/**
 * 一键买入：用户对「整笔计划 + 上限」确认一次，服务端自动依次 preview → execute → 等上链 → 重新报价 → 下一步。
 *
 * 安全边界（docs/AUTOMATION_RULES.md 硬性规则 3 的「一键买入」例外）：确认时锁定上限，之后每一步都要在上限内，否则立即停止：
 * - 步骤类型只能是确认时出现过的（不会凭空多出一次换币）；总步数 ≤ 确认时步数；
 * - 所有步骤附带的 BNB 合计 ≤ 确认时的合计（即「扣取 X BNB」）；
 * - 授权只能是确认时出现过的「同一代币 → 同一 spender」，额度 ≤ 确认时额度；
 * - 交互合约只能是确认时出现过的合约；
 * - 重新报价后的「最少收到」不低于确认时的 99.5%（0.5% 只容纳手续费取整差），否则停止；
 * - 每一步都必须 preview 模拟通过；整体 3 分钟截止（以 Date.now() 为准）。
 * 中途停止时已完成的步骤不会回滚（例如已换到的报价币留在钱包），状态里会写明。
 */
import { randomBytes } from 'node:crypto';
import { decodeFunctionData, parseAbi } from 'viem';
import { rpcFor } from '../config.mjs';
import { journal } from '../journal.mjs';

const BUNDLE_TTL_MS = 2 * 60 * 1000;
const JOB_DEADLINE_MS = 3 * 60 * 1000;
const RECEIPT_POLL_MS = 700; // BSC 约 0.75s 出块
const MIN_FLOOR_BPS = 9950n;
const erc20Abi = parseAbi(['function approve(address,uint256) returns (bool)', 'function transfer(address,uint256) returns (bool)']);
const lc = (a) => String(a || '').toLowerCase();

const bundles = new Map(); // bundleId → 确认前的计划快照
const jobs = new Map(); // bundleId → 执行状态

function approveOf(step) {
  try {
    const d = decodeFunctionData({ abi: erc20Abi, data: step.inputData });
    if (d.functionName === 'approve') return { token: lc(step.to), spender: lc(d.args[0]), amount: BigInt(d.args[1]) };
  } catch { /* 不是 approve */ }
  return null;
}

function transferOf(step) {
  try {
    const d = decodeFunctionData({ abi: erc20Abi, data: step.inputData });
    if (d.functionName === 'transfer') return { token: lc(step.to), to: lc(d.args[0]), amount: BigInt(d.args[1]) };
  } catch { /* 不是 transfer */ }
  return null;
}

/** 从计划里提取上限（确认框展示的就是这些） */
export function boundsOf(plan, steps) {
  const approvals = steps.map(approveOf).filter(Boolean);
  return {
    kinds: [...new Set(steps.map((s) => s.kind))],
    maxSteps: steps.length,
    maxValueWei: steps.reduce((a, s) => a + BigInt(s.value || '0'), 0n),
    targets: [...new Set(steps.map((s) => lc(s.to)))],
    pairs: [...new Set(steps.map((s) => `${s.kind}|${lc(s.to)}`))], // 步骤类型与交互合约成对出现过才算在范围内
    approvals,
    transfers: steps.map(transferOf).filter(Boolean),
    minOutRaw: plan.receive?.minRaw != null ? BigInt(plan.receive.minRaw) : null,
  };
}

/** 重新报价后的步骤是否仍在确认时的上限内；不在则返回原因 */
export function checkStep(step, bounds, spentWei, newMinRaw) {
  if (!bounds.kinds.includes(step.kind)) return `出现了确认时没有的步骤类型「${step.kind}」`;
  if (!bounds.targets.includes(lc(step.to))) return `交互合约 ${step.to} 不在确认范围内`;
  if (spentWei + BigInt(step.value || '0') > bounds.maxValueWei) return 'BNB 合计会超过确认时的扣取金额';
  if (bounds.pairs && !bounds.pairs.includes(`${step.kind}|${lc(step.to)}`)) return `「${step.kind}」→ ${step.to} 不是确认时出现过的组合`;
  // 不依赖 kind（它来自 label 推断）：凡是 calldata 解码出来是 approve 的，一律按确认时的授权上限复核
  const a = approveOf(step);
  if (a || step.kind === 'approve') {
    const ok = a && bounds.approvals.some((b) => b.token === a.token && b.spender === a.spender && a.amount <= b.amount);
    if (!ok) return '授权的代币 / 对象 / 额度超出确认范围';
  }
  // 转账同理：解码出 transfer 的，代币 / 收款人必须与确认时一致，数量不能更多
  const t = transferOf(step);
  if (t || step.kind === 'transfer') {
    const ok = t && (bounds.transfers || []).some((b) => b.token === t.token && b.to === t.to && t.amount <= b.amount);
    if (!ok) return '转账的代币 / 收款地址 / 数量超出确认范围';
  }
  if (bounds.minOutRaw != null && newMinRaw != null && newMinRaw * 10000n < bounds.minOutRaw * MIN_FLOOR_BPS) {
    return '价格变动：重新报价后的最少收到低于确认值，已停止（不按更差的价格成交）';
  }
  return null;
}

export function rememberBundle({ walletId, from, req, plan, steps }) {
  const now = Date.now();
  for (const [k, v] of bundles) if (now - v.at > BUNDLE_TTL_MS) bundles.delete(k);
  const id = randomBytes(12).toString('hex');
  const bounds = boundsOf(plan, steps);
  bundles.set(id, { id, walletId, from, req, plan, steps, bounds, at: now });
  return { id, bounds };
}

export function publicBounds(b) {
  return {
    maxSteps: b.maxSteps,
    maxValueWei: b.maxValueWei.toString(),
    kinds: b.kinds,
    approvals: b.approvals.map((a) => ({ token: a.token, spender: a.spender, amount: a.amount.toString() })),
    transfers: (b.transfers || []).map((t) => ({ token: t.token, to: t.to, amount: t.amount.toString() })),
    minOutRaw: b.minOutRaw == null ? null : b.minOutRaw.toString(),
  };
}

async function waitReceipt(hash, deadline) {
  while (Date.now() < deadline) {
    const r = await rpcFor('56', 'eth_getTransactionReceipt', [hash]).catch(() => null);
    if (r) return r.status === '0x1' ? 'success' : 'failed';
    await new Promise((res) => setTimeout(res, Math.min(RECEIPT_POLL_MS, Math.max(0, deadline - Date.now()))));
  }
  return 'timeout';
}

/**
 * 启动一键执行。deps：{ preview(walletId, step) → {preview, ok, error, ms}, execute(walletId, requestId) → {result, ms},
 * replan(req) → { plan, steps }（steps 为扁平结构，已带 kind/to/value/inputData/replan/next） }
 */
export function startJob(bundleId, walletId, deps) {
  const b = bundles.get(bundleId);
  if (!b) throw new Error('一键买入的计划已过期或不存在，请重新生成（计划有效期 2 分钟）');
  if (b.walletId !== walletId) throw new Error('计划不属于该钱包');
  if (Date.now() - b.at > BUNDLE_TTL_MS) { bundles.delete(bundleId); throw new Error('计划已过期，请重新生成'); }
  bundles.delete(bundleId); // 一次性
  const job = { id: bundleId, state: 'running', startedAt: Date.now(), steps: [], error: null, note: null, totalMs: null };
  jobs.set(bundleId, job);
  journal('oneclick.start', {
    jobId: job.id, walletId, token: b.req.address, platform: b.plan.platform, side: b.req.side || null, planToken: b.plan.token || null, amount: b.req.amount,
    maxValueWei: b.bounds.maxValueWei.toString(), steps: b.steps.map((s) => s.kind),
  });
  run(job, b, deps)
    .catch((err) => { job.state = 'failed'; job.error = err.message; })
    .finally(() => {
      job.totalMs = Date.now() - job.startedAt;
      journal('oneclick.end', { jobId: job.id, state: job.state, error: job.error, totalMs: job.totalMs, txs: job.steps.map((s) => s.txHash) });
      // 任务结束回调（买入后自动授权等）：只读 job / 计划，出错不影响任务本身
      if (deps.onDone) Promise.resolve().then(() => deps.onDone(job, { walletId: b.walletId, from: b.from, req: b.req, plan: b.plan })).catch((err) => console.warn(`[oneclick] onDone：${err.message}`));
    });
  return job;
}

export function jobStatus(id) {
  const j = jobs.get(id);
  if (!j) throw new Error('未知的一键买入任务');
  return j;
}

/**
 * 流水线：当前步骤需要「上链后重新报价」、下一步是授权时，授权不依赖当前步骤的结果（额度在计划里已经确定），
 * 所以当前步骤一广播就接着预览并广播授权，两笔一起等上链，省掉一次「等上链 + 重新报价」。
 * 授权同样经过 checkStep 上限复核。QUICK_PIPELINE=0 可关闭。
 */
const PIPELINE = process.env.QUICK_PIPELINE !== '0';

async function run(job, b, deps) {
  const deadline = job.startedAt + JOB_DEADLINE_MS;
  let steps = b.steps;
  let req = b.req;
  let spent = 0n;
  let firstPreview = steps[0].preview && steps[0].ok ? steps[0] : null;
  let n = 0;

  /** 预览 + 广播一步（不等上链） */
  const send = async (step, minOutRaw) => {
    const rec = { kind: step.kind, label: step.label, previewMs: null, executeMs: null, confirmMs: null, replanMs: null, txHash: null, status: 'preview', pipelined: false };
    job.steps.push(rec);
    n += 1;
    if (n > b.bounds.maxSteps) throw new Error(`步骤数超过确认时的 ${b.bounds.maxSteps} 步，已停止`);
    const why = checkStep(step, b.bounds, spent, minOutRaw);
    if (why) throw new Error(why);
    let pv = firstPreview;
    firstPreview = null;
    if (pv) {
      rec.previewMs = 0; // 生成计划时已经预览过
    } else {
      const t = Date.now();
      pv = await deps.preview(b.walletId, step);
      rec.previewMs = Date.now() - t;
    }
    if (!pv.ok || !pv.preview?.requestId) throw new Error(`第 ${n} 步模拟失败：${pv.error || '未返回 requestId'}`);
    rec.status = 'execute';
    const t = Date.now();
    const ex = await deps.execute(b.walletId, pv.preview.requestId);
    rec.executeMs = Date.now() - t;
    rec.txHash = ex.result?.txHash || null;
    spent += BigInt(step.value || '0');
    journal('oneclick.step', { jobId: job.id, kind: step.kind, to: step.to, value: step.value, txHash: rec.txHash, status: 'sent' });
    if (!rec.txHash) {
      rec.status = 'app-confirm';
      job.needsAppConfirm = true;
      throw new Error(`第 ${n} 步（${step.kind === 'approve' ? '授权' : step.kind}）被币安风控挂起，要在币安 App → Agentic Wallet 里确认。`
        + '确认或拒绝之前，这个钱包的所有新交易（包括狙击、卖出）都会被币安拒绝，不要反复重试。'
        + (step.kind === 'approve' ? '在 App 确认授权并上链后，再点一次卖出即可（不会重复授权）' : '确认上链后再重新下单'));
    }
    rec.status = 'confirm';
    rec.sentAt = Date.now();
    return rec;
  };

  /** 等一步上链 */
  const confirm = async (rec) => {
    const st = await waitReceipt(rec.txHash, deadline);
    rec.confirmMs = Date.now() - rec.sentAt;
    journal('oneclick.step', { jobId: job.id, kind: rec.kind, txHash: rec.txHash, status: st });
    if (st !== 'success') throw new Error(st === 'failed' ? `「${rec.kind}」交易链上失败，已停止` : `「${rec.kind}」等待上链超时，已停止`);
    rec.status = 'done';
  };

  for (;;) {
    if (Date.now() > deadline) throw new Error('超过 3 分钟仍未完成，已停止');
    const step = steps[0];
    const rec = await send(step, n === 0 ? null : step.minOutRaw ?? null);
    const pending = [rec];
    let used = 1;
    let pendingApprove = null;
    // 流水线：下一步是授权 → 立即发出授权，一起等上链（授权额度在计划里已定，不依赖当前步的结果）
    if (PIPELINE && step.kind !== 'approve' && steps[1]?.kind === 'approve') {
      const r2 = await send(steps[1], null);
      r2.pipelined = true;
      pending.push(r2);
      used = 2;
      pendingApprove = approveOf(steps[1])?.amount ?? null;
    }
    const lastStep = steps[used - 1];
    const needReplan = lastStep.replan || step.replan;
    const nextReq = { ...req, ...(step.next || {}), ...(lastStep.next || {}) };

    let replanned = null;
    if (needReplan && pendingApprove != null) {
      // 重新报价只依赖当前步（换币）上链后的余额，不依赖授权：换币一上链就开始报价，与等授权上链并行。
      // 报价里把「已广播待上链」的授权额度当作已授权；之后的买入步骤仍在授权上链后才预览（预览不过即停止）
      try {
        await confirm(pending[0]);
      } catch (err) {
        const ap = approveOf(steps[1]);
        throw new Error(`${err.message}。注意：并行发出的授权（${ap ? `${ap.amount} 给 ${ap.spender}` : '本次数量'}）可能已经生效，只授权了本次数量，如需收回可在报价币库存里点「撤销」或用合约调用把额度设为 0`);
      }
      const last = pending[1];
      const t = Date.now();
      const [r] = await Promise.all([deps.replan({ ...nextReq, pendingApprove: pendingApprove.toString() }), confirm(last)]);
      last.replanMs = Date.now() - t; // 与等上链重叠的部分不额外耗时
      last.overlap = true;
      replanned = r;
    } else {
      for (const p of pending) await confirm(p);
    }

    const last = pending[pending.length - 1];
    if (steps.length <= used && !needReplan) { job.state = 'done'; return; }
    if (needReplan) {
      let r = replanned;
      if (!r) {
        last.status = 'replan';
        const t = Date.now();
        r = await deps.replan(nextReq);
        last.replanMs = Date.now() - t;
      }
      last.status = 'done';
      req = nextReq;
      steps = r.steps.map((s) => ({ ...s, minOutRaw: r.plan.receive?.minRaw != null ? BigInt(r.plan.receive.minRaw) : null }));
      if (!steps.length) throw new Error('重新报价后没有可执行的步骤');
    } else {
      steps = steps.slice(used);
    }
  }
}
