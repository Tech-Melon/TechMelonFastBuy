# 技术瓜内盘快买（Tech Melon FastBuy）· 部署与配置说明

两个版本：**技术瓜内盘快买 Pro**（全量版，含狙击 / 打新）与 **技术瓜内盘快买**（轻量版，不含狙击 / 打新）；包根目录的 `EDITION.txt` 写着是哪一个。
配套浏览器插件「技术瓜内盘快买 · 一键买卖」单独一个包。

本地 Web 控制台，用来操作 **Binance Agentic Wallet**（币安官方 `@binance/agentic-wallet` CLI）：多钱包隔离、
快捷交易（Four / gang / Flap 内盘 + Pancake 外盘自动识别）、gang V2 / V3 内盘狙击、Four 狙击、自动打新、
报价币库存与授权、GMGN 持仓、一键转移、兑换 / 转账 / 合约调用 / AI 执行。

- 服务只监听 `127.0.0.1`，默认只能本机浏览器访问；
- 发布包**不含**任何密钥、登录会话、钱包列表、执行日志或个人配置，部署后需要你自己登录钱包、填写配置；
- 所有交易最终都由币安钱包服务签名广播，控制台不接触私钥 / 助记词。

**版本**：包根目录的 `EDITION.txt` 写明是哪个版本。
- **全量版**：全部功能。
- **轻量版**：不含 gang V2 / V3 内盘狙击、Four 狙击、打新 / 自动打新、新部署发现（这些文件不在包里，页面上也没有入口）。
  快捷交易（Four / gang V2 / V3 / Flap 内盘与 Pancake 外盘）、一键 / 直接买入、持仓、一键转移、发射后自动转移、报价币库存、路由记录、
  Flap 曲线、兑换 / 转账 / 合约调用 / AI 执行、浏览器插件都有。gang V3 使用内置的官方主网部署，不需要在页面上启用。
  文中提到狙击 / 打新的章节对轻量版不适用。

> ⚠️ 风险提示：内盘狙击、自动打新等功能面向高风险的新币，合约可能未审计、可能被抢先或归零。
> 请只用你能承受损失的资金，先用小额度验证，自动化功能一律设置单笔 / 每日上限。

---

## 目录

1. [环境要求](#1-环境要求)
2. [解压与目录结构](#2-解压与目录结构)
3. [安装依赖](#3-安装依赖)
4. [启动](#4-启动)
5. [添加并登录钱包（必做）](#5-添加并登录钱包必做)
6. [必须 / 建议配置的内容（总表）](#6-必须--建议配置的内容总表)
7. [设置页：RPC / WSS / AI](#7-设置页rpc--wss--ai)
8. [资金与授权：买入上限、直接买入、重启恢复、报价币库存](#8-资金与授权)
9. [各功能的前置条件](#9-各功能的前置条件)
10. [config.json 字段说明](#10-configjson-字段说明)
11. [环境变量](#11-环境变量)
12. [公网部署（可选，进阶）](#12-公网部署可选进阶)
13. [私人数据文件（不要外发）](#13-私人数据文件不要外发)
14. [验证安装](#14-验证安装)
15. [手动调用 CLI](#15-手动调用-cli)
16. [升级 / 迁移 / 卸载](#16-升级--迁移--卸载)
17. [常见问题](#17-常见问题)

---

## 1. 环境要求

| 项 | 要求 |
|---|---|
| 系统 | Windows 10/11（`.cmd` 入口按 Windows 编写）；macOS / Linux 可用 `node` 直接启动（见第 4、15 节） |
| Node.js | **18 或更高**（推荐 22 LTS），自带 npm |
| 网络 | 能访问 `registry.npmjs.org`（安装依赖）、BSC RPC、币安钱包服务 |
| 币安 App | 已开通 **Agentic Wallet**；需要合约调用的功能（内盘买卖、授权、狙击）要在 App 里打开 **Developer Mode** |
| 浏览器 | Chrome / Edge 新版（狙中提示音、系统通知依赖浏览器权限） |

```powershell
node -v
npm -v
```

## 2. 解压与目录结构

把 zip 解压到**只有你自己能访问**的目录，例如 `D:\wallet-console`：

```
README.md               从这里开始：产品介绍、两个版本对比、快速开始、文档地图
DEPLOY.md               本文档
EDITION.txt             你拿到的是 Pro（full）还是轻量版（lite）
extension/              浏览器插件「技术瓜内盘快买 · 一键买卖」（加载已解压的扩展程序）
webui/                  控制台（服务端 + 前端）
  config.example.json   配置样例（可选，复制成 config.json 后编辑）
  start.cmd             启动脚本（崩溃自动重启）
  eval/                 回归评测与离线单测
profiles/               每个钱包一个会话子目录（首次为空）
deploy/baw-cli/         币安 CLI 的锁定版本清单（package.json + package-lock.json）
scripts/setup.mjs       安装脚本（带数字菜单）
docs/                   使用说明与各功能手册：
  USAGE.md              控制台各页面的使用说明与常用流程
  ARCHITECTURE.md       项目架构：模块、一笔交易怎么走完、缓存、RPC 分层、数据文件
  QUICK_TRADE.md        快捷交易、报价币库存、gang 内盘狙击、一键转移
  FOUR_SNIPER.md        Four 狙击架构与开盘复盘（仅 Pro）
  GANG_LAUNCH.md        gang V3 / 打新上线的发现与启用流程（仅 Pro）
  AUTOMATION_RULES.md   哪些操作必须逐笔确认、各自动化功能的预授权边界
  SECURITY_MODEL.md     安全模型；KNOWN_LIMITATIONS.md 已知限制；COMMANDS.md CLI 命令清单
baw-wallet.cmd          手动调用某个钱包 CLI 的入口
MANIFEST.txt            全部文件的 sha256
```

可选：校验文件完整性（任何一行 `False` 说明文件被改动过）：

```powershell
Get-Content MANIFEST.txt | ForEach-Object {
  $h, $s, $f = $_ -split '  ', 3
  if ($f) { "{0}  {1}" -f ((Get-FileHash $f -Algorithm SHA256).Hash.ToLower() -eq $h), $f }
}
```

## 3. 安装依赖

在解压目录执行：

```powershell
node scripts/setup.mjs
```

菜单选 **1（完整安装）**。脚本会：

1. 在 `webui/` 按 `package-lock.json` 执行 `npm ci`（只有 `viem`、`qrcode` 两个依赖，版本与哈希锁定）；
2. 在 `.tmp/baw-cli` 安装币安官方 `@binance/agentic-wallet`，版本锁定为发布时验证过的版本；
3. 把 CLI 里的 `@github/keytar` 改名为 `keytar.disabled`；
4. 做一次环境检查。

> **为什么要禁用 keytar**：CLI 默认把登录凭据写进系统钥匙串的同一个全局槽位，多个钱包会互相覆盖（串号）。
> 禁用后，会话加密保存在各自的 `profiles/<钱包目录>/`，钱包才真正隔离。
> **以后升级 CLI 必须重新运行 `node scripts/setup.mjs` 并选 2**，否则隔离失效。

无人值守安装：`$env:SETUP_CHOICE='1'; node scripts/setup.mjs`。

## 4. 启动

```powershell
webui\start.cmd          # 推荐：服务崩溃会在 3 秒后自动重启
# 或
node webui\server.mjs
```

浏览器打开 <http://127.0.0.1:8790>。改端口：`$env:PORT=8899; node webui\server.mjs`。

首次启动会生成：

- `webui/wallets.json`：钱包列表（初始为空）；
- `webui/.api-token`：本次运行的随机 API 令牌（每次启动更换，页面自动获取）。

页面布局：交易台（默认页）/ 狙击 ▾（gang 内盘 V2·V3 + 狙击看板、Four 狙击、自动打新）/ 持仓 / 资金与授权 /
发射台 ▾（gang V3·打新、Flap）/ 工具 ▾（兑换、转账、合约调用、AI 执行、模块）/ 系统 ▾（概览、钱包、交易历史、设置）。
顶部「钱包」下拉框是**操作钱包**，交易台、资金与授权、持仓都对它生效。

## 5. 添加并登录钱包（必做）

1. 打开「系统 ▾ → 钱包」，在「钱包管理」输入名称，点「添加钱包」。每个钱包会得到一个独立目录 `profiles/wallet-N`；
2. 在该钱包上点「登录」，页面出现二维码；
3. 用**币安 App** 扫码，**核对 App 里显示的配对码与页面一致**后确认；
4. 状态变成「已连接」即可。会话有效期约 **48 小时**，过期后重新登录（自动化功能会因此失败，见第 17 节）。

建议：

- 在币安 App 的 Agentic Wallet 设置里打开 **Developer Mode**（合约调用 / 授权 / 内盘交易都需要）；
- 给控制台用的钱包只放计划使用的资金；
- 需要多个钱包（例如狙击多开）就重复添加，每个钱包分别扫码登录。**不要复制 `profiles/` 下的目录**，两个进程也不要共用一个目录；
- 删除钱包只删本机会话目录，不影响币安账户与链上资产。

## 6. 必须 / 建议配置的内容（总表）

| 配置 | 在哪里配 | 是否必需 | 不配会怎样 |
|---|---|---|---|
| 钱包登录 | 系统 → 钱包 | **必需** | 无法查询余额、无法交易 |
| Developer Mode | 币安 App | 交易类功能必需 | 合约调用预览失败 |
| 买入上限（单笔 / 每日） | 资金与授权 → 买入上限 | **自动化功能必需**（都要 > 0） | 直接买入、gang 狙击、自动打新无法预授权 |
| BSC RPC（付费节点） | 设置 → RPC 节点 | 强烈建议（狙击 / 快捷交易） | 用公共节点，限流时报价 / 模拟变慢或失败 |
| BSC WSS 节点 | 设置 → RPC 节点 | **Four 狙击必需**；gang 狙击、V3 / 打新发现、自动转移强烈建议 | Four 狙击无法开始；gang 狙击退回 3 秒 HTTP 轮询，明显变慢 |
| Agent ID | 币安 Agentic Wallet 账户 | gang V2 内盘买卖、Four Agent ID 模式、部分 Flap 市场必需 | 合约拒绝（`NotAgent` / 无买入资格） |
| 报价币库存 + 授权 | 资金与授权 → 报价币库存 | gang 非 BNB 底池的极速狙击需要 | 「没库存，跳过」或临时换币（慢 2~3 秒） |
| gang V3 / 打新启用 | 发射台 → gang V3 / 打新 | 使用 V3 狙击、打新时必需 | V3 狙击 / 自动打新只能「待命」 |
| GMGN API Key | 持仓 → GMGN API 设置 | 可选 | 「钱包持仓」面板没有数据 |
| 转账白名单 | 持仓 → 一键转移 | 用一键转移 / 发射后自动转移时必需 | 无法转出 |
| AI Key | 设置 → AI 模型 | 可选 | AI 执行用规则解析，只支持标准写法 |

## 7. 设置页：RPC / WSS / AI

「系统 ▾ → 设置」。保存到 `webui/config.json`，页面只显示脱敏后的地址，明文不会回传前端。

### 7.1 RPC 节点

| 链 | 说明 |
|---|---|
| BSC（56） | **主要链**。留空用 publicnode 公共节点。狙击 / 快捷交易建议填付费节点（QuickNode、NodeReal、Alchemy 等的 https 地址） |
| Ethereum（1） | 可选，Uniswap 兑换用 |
| Base（8453） | 可选 |
| Robinhood（4663） | 可选，默认未配置 |

- 只接受 `https://`（`http://` 只允许 `127.0.0.1`），不允许在 URL 里嵌账号密码；
- 每条都可以「测试」延迟，「加为备用」组成节点池：主节点网络失败 / 限流时自动切到备用；
- 后台类请求（库存、持仓、看板、图标等）会优先走免费公共节点，节省付费节点额度；交易相关的读请求（模拟、报价、回执）走你配置的节点。

### 7.2 BSC WebSocket（wss）

例：`wss://xxx.bsc.quiknode.pro/<token>/`。用途：

- **Four 狙击**：订阅 OpenFour 新币事件（必需）；
- **gang V2 / V3 狙击**：新币创建事件推送（没有时退回 3 秒 HTTP 轮询）；
- **gang V3 / 打新部署发现**、**发射后自动转移**（V2 毕业事件）。

全项目共用一条 WSS 连接，断线自动重连。填好后点「测试」确认能连上。

### 7.3 AI 模型（可选）

| 字段 | 默认值 | 说明 |
|---|---|---|
| Base URL | `https://api.deepseek.com` | OpenAI 兼容接口均可 |
| 模型 | `deepseek-chat` | |
| API Key | 空 | 留空 = 规则解析（毫秒级，只认标准写法）；填写后「AI 执行」可以处理口语化指令 |

AI 只负责把提示词解析成计划，所有交易仍要预览 + 你确认。建议给控制台单独申请一个有额度上限的 Key。

## 8. 资金与授权

「资金与授权」页，对顶部的**操作钱包**生效。

### 8.1 买入上限（自动化前必须设置）

| 字段 | 说明 |
|---|---|
| 单笔最多（BNB） | 每一笔买入（按 BNB 等值）不能超过它。0 = 不限 |
| 每日最多（BNB） | 每个钱包每天买入合计上限（按本机日期分天，重启后从执行日志重建）。0 = 不限 |

**直接买入、gang 狙击、自动打新的预授权要求这两项都 > 0**。修改上限会立即解除所有依赖它的预授权。

### 8.2 直接买入（可选）

确认一次策略（钱包、当时的上限、最大滑点、有效期默认 4 小时、最长 24 小时）后，交易台点金额直接买入，不再逐笔弹确认框。
每笔仍走完整链路：计划 → 币安预览 → 上限复核 → 广播前每日上限检查。只用于买入。

### 8.3 服务重启后自动恢复预授权

默认开启。只恢复没到期（不顺延）、上限和参数都没改过的预授权；已花预算一起恢复。关闭后重启即全部失效。

### 8.4 报价币库存（gang 非 BNB 底池需要）

gang 的币可能用 GANG、USDT 等报价币计价。提前「备货 + 授权」后，狙击 / 快捷交易一笔就能买完。

- 表格按「报价币 × 平台（gang V2 / gang V3 / Four）」显示授权状态，点格子操作；
- 「备货并授权」：用 BNB 换成该报价币，授权额度 = 库存；「同步授权」：不花 BNB，只把额度对齐到现有库存；
- 每种报价币库存有上限（默认 1 BNB 等值，可改）；
- 「批量预授权（无上限）」只授权给白名单合约、只限已知报价币。gang V3 合约未审计，**优先用同步授权，不要无上限授权**；
- Flap 的授权对象是每个市场，不做常驻授权。

### 8.5 Four bStock 预授权

BNCB / NVDAB 计价的 Four 币，买入前要授权 Four Core，在此页一次完成。

## 9. 各功能的前置条件

| 功能 | 位置 | 前置条件 | 手册 |
|---|---|---|---|
| 快捷交易（粘贴 CA 买卖） | 交易台 | 钱包已登录；内盘需 Developer Mode / Agent ID | `docs/QUICK_TRADE.md` |
| gang V2 内盘狙击 | 狙击 → gang 内盘 | 买入上限 > 0；建议 WSS；钱包有 Agent ID；非 BNB 底池需库存 | `docs/QUICK_TRADE.md`（gang 内盘狙击） |
| gang V3 狙击 | 同上，发射台选 V3 | 先在「发射台 → gang V3」链上核验并**确认启用**；单笔上限 0.1 BNB（未审计） | 同上 |
| 狙击看板 | 狙击 → gang 内盘（下方卡片） | 有过狙击记录即可，只读 | — |
| Four 狙击 | 狙击 → Four 狙击 | **必须配置 BSC WSS**；钱包有 Agent ID | `docs/FOUR_SNIPER.md` |
| 自动打新 | 狙击 → 自动打新 | 先在「发射台 → gang 打新」核验并启用；买入上限 > 0 | `docs/GANG_LAUNCH.md` |
| GMGN 持仓 | 持仓 | GMGN API Key + 签名密钥（见下） | — |
| 一键转移 / 发射后自动转移 | 持仓 | 先添加转账白名单地址（会检查是否本机钱包、合约、疑似投毒地址） | `docs/QUICK_TRADE.md` |
| Flap 曲线 | 发射台 → Flap | 部分市场要求 Agent ID 或指定 NFT | — |
| AI 执行 / 模块 | 工具 | 可选 AI Key | `docs/USAGE.md` |
| 浏览器插件（网页上一键买卖） | Chrome 加载 `extension/` | 在「设置 → 浏览器插件」生成配对密钥填到插件里；免确认买入需要先开启「直接买入」 | `extension/README.md` |

### GMGN API 设置（可选）

「持仓 → GMGN API 设置」：

1. 点「生成签名密钥」，复制显示的**公钥**；
2. 打开 <https://gmgn.ai/ai>，上传公钥、创建 API Key；
3. 把 API Key 填回控制台保存。

API Key 和签名私钥只保存在本机 `config.json`、只在后端使用。查询时钱包地址会发给 GMGN；不要把交易钱包绑定到这个 Key。

### 自动化功能的共同规则

所有自动执行（直接买入、gang 狙击、Four 自动狙击、自动打新、发射后自动转移）都必须你先确认一份「预授权」策略
（钱包、预算、上限、滑点、有效期 ≤ 24 小时，自动转移 ≤ 7 天）。改任意参数、到期、手动解除、修改买入上限都会立即失效。
顶部状态条的「⛔ 全部解除」可一键关闭所有自动化。每种自动化的具体边界见 `docs/AUTOMATION_RULES.md`。

## 10. config.json 字段说明

位置 `webui/config.json`。一般**不需要手改**，设置页 / 各功能页会自动写入；手改前先停服务。
`config.example.json` 是最小样例，复制改名即可。

| 字段 | 类型 | 由谁写入 | 说明 |
|---|---|---|---|
| `rpcs` | `{ "56": url, "1": url, "8453": url, "4663": url }` | 设置页 | 各链主 RPC；空 = 公共节点 |
| `wss` | `{ "56": url }` | 设置页 | BSC WebSocket |
| `pools` | `{ "rpc:56": [url...], "wss:56": [url...] }` | 设置页 | 备用节点池 |
| `wssDual` | `true / false`（默认 false） | 设置页 | 双节点订阅：节点池里第一条非主节点的 wss 同时订阅日志，先到先用（eth_call 仍只走主节点） |
| `bgRpcs` | `{ "56": url }` | 手改（可选） | 后台 / 非即时请求（预热、发射检查、持仓、补查等）用的节点。不填时自动用备用节点池里的 NodeReal 地址；都没有就走免费公共节点。交易相关请求始终走 `rpcs` 主节点 |
| `ai` | `{ baseUrl, model, apiKey }` | 设置页 | AI 模型（可选） |
| `limits` | `{ maxBuyBnb, dailyBnb }`（字符串） | 资金与授权 | 买入上限，`"0"` = 不限 |
| `resumeArms` | bool，默认 true | 资金与授权 | 重启后恢复预授权 |
| `bawDirect` | bool，默认 true | 手改 | true = 服务进程内直连币安下单（更快）；false = 每次调用 CLI |
| `inventory` | `{ capBnb, tokens }` | 资金与授权 | 报价币库存上限与登记的报价币 |
| `gmgn` | `{ apiKey, privateKeyPem, publicKeyPem }` | 持仓 | GMGN OpenAPI 凭据 |
| `transferTargets` | 数组 | 持仓 | 转账白名单 |
| `gangV3` / `fairMint` | 对象 | 发射台 | 已核验启用的 V3 / 打新部署地址。**不要手写**，必须经链上核验后在页面确认启用 |
| `discovery` | 对象 | 发射台 | 新部署发现开关 |
| `extension` | `{ key, origins }` | 设置页 | 浏览器插件的配对密钥和插件 ID。密钥等同快捷交易权限，不要外发 |
| `gangSnipe` / `gangSnipeV3` | 对象 | 狙击页 | 狙击参数（预授权时保存） |

`config.json` 明文保存 Key 和节点令牌，**不要提交、不要发给别人**。

## 11. 环境变量

全部可选，启动前设置（PowerShell：`$env:名字='值'`）。

| 变量 | 默认 | 说明 |
|---|---|---|
| `PORT` | 8790 | 监听端口（只监听 127.0.0.1） |
| `RPC_<链ID>` / `WSS_<链ID>` | — | 设置页没填时的兜底节点，例 `RPC_56`、`WSS_56` |
| `PUBLIC_RPC_56` | 内置公共节点列表 | 后台只读请求用的公共节点（逗号分隔）；`off` 关闭分流 |
| `PUBLIC_LOGS_RPC_56` | publicnode | 后台 `eth_getLogs` 用的公共节点 |
| `RPC_MAX_CONCURRENCY` | 8 | 付费节点最大并发 |
| `BG_RPC_RATE_PER_SEC` | 25 | 后台节点（非即时请求，见 `config.json` 的 `bgRpcs`）每秒上限，用满的请求让给公共节点 |
| `RPC_RATE_PER_SEC` | 45 | 付费节点每秒请求上限（按你的套餐调整） |
| `QUICK_MAX_IMPACT_BPS` | 1000（10%） | 快捷交易外盘价格冲击上限（基点），超过拒绝生成交易 |
| `QUICK_GANG_V3_MAX_BNB` | 0.1 | gang V3 单笔买入上限（未审计合约） |
| `MAX_SLIPPAGE_BPS` | 5000（50%） | 全局最大滑点（基点，只能调低） |
| `SETUP_CHOICE` | — | 安装脚本无人值守选项 |
| `PUBLIC_ORIGIN` 等 | — | 公网部署，见第 12 节 |

## 12. 公网部署（可选，进阶）

默认只在本机使用，**不需要这一节**。如果要放在自己的服务器上用浏览器远程访问：

- 服务仍只监听 `127.0.0.1`，必须在同一台机器上用 Nginx 等反向代理提供 HTTPS；
- 设置 `PUBLIC_ORIGIN` 后才启用登录闸门，请求依次过：IP 白名单 → 登录会话（7 天）→ 原有 API 令牌校验；
- 同一 IP 10 分钟内密码错 3 次封禁 1 小时。

| 变量 | 说明 |
|---|---|
| `PUBLIC_ORIGIN` | 你的站点，例 `https://wallet.example.com`（必须 https、不带路径） |
| `ADMIN_PASSWORD_HASH` | 登录密码的 scrypt 哈希（格式 `scrypt:N:r:p:<salt>:<hash>`，生成方法见下） |
| `ALLOWED_CLIENT_IPS` | 允许访问的客户端 IP / 网段，逗号分隔。**为空时全部拒绝** |
| `ALLOWED_CLIENT_IPS_FILE` | 同上，从文件读取（每行一个） |
| `TRUSTED_PROXY_IPS` | 信任哪些代理的 `X-Real-IP`，默认 `127.0.0.1/32,::1/128` |

生成密码哈希（把 `你的密码` 换掉，输出整行就是 `ADMIN_PASSWORD_HASH` 的值）：

```powershell
node -e "const c=require('crypto');const s=c.randomBytes(16);const N=16384;const h=c.scryptSync(process.argv[1],s,32,{N,r:8,p:1,maxmem:256*N*8});console.log(['scrypt',N,8,1,s.toString('base64'),h.toString('base64')].join(':'))" "你的密码"
```

反向代理需要把 `X-Real-IP` 设为真实客户端 IP，并保留 `Host`。公网部署意味着能访问页面的人就能操作你的钱包：
务必同时启用 IP 白名单和强密码，并只在你信任的服务器上运行。

## 13. 私人数据文件（不要外发）

以下文件都是你的私人数据，已在 `.gitignore` 中，**不要发给别人**：

| 文件 | 内容 |
|---|---|
| `profiles/*/` | 各钱包的登录会话（凭据） |
| `webui/config.json` | RPC / WSS 令牌、AI Key、GMGN 凭据、上限、白名单 |
| `webui/wallets.json` | 钱包列表与地址 |
| `webui/addressbook.json`、`modules.json` | 地址簿、保存的提示词模块 |
| `webui/journal*.jsonl` | 执行日志（每笔交易记录，用于每日上限与复盘） |
| `webui/arms.json` | 落盘的预授权（重启恢复用） |
| `webui/sniper.json` | Four 狙击记录 |
| `webui/metrics.json`、`sessions.json`、`.api-token` | 统计、公网登录会话、本次 API 令牌 |
| `webui/positions.json`、`routes.json`、`detect-cache.json` | 本系统买过的币、路由记录、CA 识别缓存（删掉会自动重建） |

## 14. 验证安装

```powershell
node webui\eval\custom-args.mjs        # 离线单测，不连链
node webui\eval\quick.mjs              # 快捷交易识别与计划（只读）
node webui\eval\gangsnipe.mjs          # 狙击策略与过滤（只读链上数据，不发交易；仅 Pro）
```

都显示全部通过（例如 `14/14 passed`、`28 passed, 0 failed`）即安装正常。然后打开页面，按 `README.md` 的「快速开始」登录钱包、试一笔小额交易。

## 15. 手动调用 CLI

```powershell
.\baw-wallet.cmd wallet-1 wallet status --json
.\baw-wallet.cmd wallet-1 wallet balance --json
```

第一个参数是 `profiles/` 下的钱包目录名（在「钱包」页可以看到，例如 `wallet-1`）。
**不要直接运行全局 `baw`**：它读写 `%USERPROFILE%\.baw`，与控制台里的钱包无关。完整命令见 `docs/COMMANDS.md`。

macOS / Linux：设置 `BINANCE_BAW_DIR=profiles/<钱包目录>` 后运行
`node .tmp/baw-cli/node_modules/@binance/agentic-wallet/dist/index.js <命令>`。

## 16. 升级 / 迁移 / 卸载

- **升级控制台**：先在页面点「⛔ 全部解除」、停止服务；解压新版本到新目录，把旧目录的 `profiles/` 和
  `webui/{config,wallets,addressbook,modules}.json` 复制过去，再运行 `node scripts/setup.mjs`（选 1）。
- **升级币安 CLI**：只能通过新发布包里的 `deploy/baw-cli` 锁文件；装完运行 `node scripts/setup.mjs` 选 2（重新禁用 keytar）。
- **迁移到另一台电脑**：建议在新电脑重新扫码登录，不要复制 `profiles/`（会话凭据不应在多台机器间流转）。
- **卸载**：先在「钱包」页逐个退出，再删除整个目录。

## 17. 常见问题

| 现象 | 处理 |
|---|---|
| `missing or invalid api token` | 服务重启导致令牌更换；页面会自动恢复，仍出现就刷新 |
| `host not allowed` | 只能用 `127.0.0.1:端口` 或 `localhost:端口` 访问（公网模式用 `PUBLIC_ORIGIN`） |
| 钱包显示未连接 / 自动化全部失败 | 会话过期（约 48 小时），到「钱包」页重新登录 |
| 合约调用预览失败、提示 Developer Mode | 在币安 App 的 Agentic Wallet 设置里打开 Developer Mode |
| 下单提示钱包被锁定（`API_351716`） | 有一笔交易被币安风控挂起，去币安 App 确认或拒绝后再操作 |
| gang 买卖报 `NotAgent` | 该钱包没有 Agent ID，gang V2 内盘需要 Agent 身份 |
| 狙击日志「没库存，跳过」 | 到「资金与授权 → 报价币库存」为该报价币备货并同步授权，或关闭「没库存直接跳过」 |
| 无法预授权自动化 | 先设置买入上限（单笔、每日都 > 0） |
| Four 狙击无法开始 | 设置页没配置 BSC WSS |
| 两个钱包地址 / 余额一样（串号） | keytar 没禁用：`node scripts/setup.mjs` 选 2，然后两个钱包都重新登录 |
| 狙中没有提示音 | 浏览器要求页面被点过一次才能出声：点顶部「试听」；后台标签页可能被浏览器降频 |
| `npm ci` 报锁文件不一致 | 不要手改 `deploy/baw-cli`；重新解压发布包 |
| 端口被占用 | `$env:PORT=8899; node webui\server.mjs` |

更多：安全模型 `docs/SECURITY_MODEL.md`，已知限制 `docs/KNOWN_LIMITATIONS.md`，使用说明 `docs/USAGE.md`。
