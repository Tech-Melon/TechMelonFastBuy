// 发射后自动转移评测：node eval/autoxfer.mjs
// 1) 策略校验越界必须被拒；2) 用链上真实的已毕业 gang V2 代币跑一遍完整流程（只读链 + 假的预览 / 广播，绝不发交易）：
//    识别平台 → 已发射 → 按比例算数量 → 以钱包身份模拟 transfer → 复核 calldata → 「广播」→ 每个钱包每个币只转一次。
import os from 'node:os';
import path from 'node:path';
import { rmSync } from 'node:fs';
import { decodeFunctionData, parseAbi, encodeFunctionData, decodeFunctionResult } from 'viem';
import { rpcFor } from '../config.mjs';

process.env.ARMS_FILE = path.join(os.tmpdir(), `walletui-arms-autoxfer-${process.pid}.json`); // 不碰真实 arms.json
const JDIR = path.join(os.tmpdir(), `walletui-journal-autoxfer-${process.pid}`);
(await import('node:fs')).mkdirSync(JDIR, { recursive: true });
process.env.JOURNAL_FILE = path.join(JDIR, 'journal.jsonl'); // 不碰真实执行日志
const { parseXferConfig, armXfer, disarmXfer, xferStatus, GRADUATED_TOPIC_V2 } = await import('../quick/autoxfer.mjs');
const { journal } = await import('../journal.mjs');

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };
const rejects = (name, fn, inc) => { try { fn(); ok(name, false, '应当拒绝'); } catch (e) { ok(`${name} → ${e.message}`, e.message.includes(inc), e.message); } };

const TID = '11111111-2222-3333-4444-555555555555';
const good = { walletIds: ['w1'], targetId: TID, platforms: { v2: { enabled: true, percent: 100 } }, hours: 168 };
ok('合法策略通过', parseXferConfig(good).hours === 168);
ok('打新默认只转超出出局线的部分', parseXferConfig({ ...good, platforms: { fair: { enabled: true } } }).platforms.fair.keepHold === true);
ok('自动加入默认开', parseXferConfig(good).autoAdd === true);
rejects('有效期超过 7 天', () => parseXferConfig({ ...good, hours: 169 }), '7 天');
rejects('没选平台', () => parseXferConfig({ ...good, platforms: {} }), '平台');
rejects('比例 0', () => parseXferConfig({ ...good, platforms: { v2: { enabled: true, percent: 0 } } }), '比例');
rejects('比例 101', () => parseXferConfig({ ...good, platforms: { v2: { enabled: true, percent: 101 } } }), '比例');
rejects('没选钱包', () => parseXferConfig({ ...good, walletIds: [] }), '钱包');
rejects('超过 5 个钱包', () => parseXferConfig({ ...good, walletIds: ['a', 'b', 'c', 'd', 'e', 'f'] }), '最多');
rejects('收款地址 id 无效', () => parseXferConfig({ ...good, targetId: 'x' }), '白名单');
ok('毕业事件 topic 与链上核对过的一致', GRADUATED_TOPIC_V2 === '0x6da2ac486174425e3bbc9aab3a6fd9ee8fb4d1c1e769a02af4a159b37c52eea9');

// ---- 链上真实数据：2026-10-27 毕业的 gang V2 代币，用它的 Pancake 交易对当「钱包」（持有大量该代币） ----
const TOKEN = '0x4b1f0b4ac6d634f223cea6379ce855f372ffac65';
const HOLDER = '0x0e4B409b244AFB8528D311B157f3Df9D444B7425';
const TARGET = '0x000000000000000000000000000000000000dead'; // 只在模拟里当收款地址（小写，下面按小写比较），不发交易
const erc = parseAbi(['function balanceOf(address) view returns (uint256)', 'function transfer(address,uint256) returns (bool)']);
const bal = decodeFunctionResult({ abi: erc, functionName: 'balanceOf', data: await rpcFor('56', 'eth_call', [{ to: TOKEN, data: encodeFunctionData({ abi: erc, functionName: 'balanceOf', args: [HOLDER] }) }, 'latest']) });
const sent = [];
const deps = {
  walletEvm: async () => HOLDER,
  listTargets: async () => [{ id: TID, name: '评测目标', address: TARGET }],
  preview: async (walletId, from, step) => ({ ok: true, preview: { requestId: `eval-${sent.length}` }, step }),
  execute: async (walletId, requestId) => { sent.push({ walletId, requestId }); return { result: { txHash: `0x${'ab'.repeat(32)}` } }; },
};
// 拦截 preview 记录 calldata
const calls = [];
const origPreview = deps.preview;
deps.preview = async (walletId, from, step) => { calls.push(step.tx); return origPreview(walletId, from, step); };

try {
  await armXfer({ walletIds: ['eval-w'], targetId: TID, platforms: { v2: { enabled: true, percent: 50 } }, autoAdd: false, hours: 1 }, deps, { tokens: [{ token: TOKEN }] });
  // 等首轮扫描完成（按绝对时间截止）
  const until = Date.now() + 60000;
  while (Date.now() < until && !sent.length) await new Promise((r) => setTimeout(r, 300));
  const s = xferStatus();
  ok('已毕业代币被识别为 gang V2', s.tokens[0]?.platform === 'v2', JSON.stringify(s.tokens[0]));
  ok('发射后自动「广播」了一笔', sent.length === 1, `sent=${sent.length} events=${s.events.map((e) => e.text).slice(0, 3).join(' | ')}`);
  if (calls[0]) {
    const d = decodeFunctionData({ abi: erc, data: calls[0].inputData });
    ok('交易目标是该代币合约', calls[0].to.toLowerCase() === TOKEN);
    ok('函数是 transfer、收款人是白名单地址', d.functionName === 'transfer' && d.args[0].toLowerCase() === TARGET);
    ok('数量 = 余额 × 50%', BigInt(d.args[1]) === (bal * 50n) / 100n, `${d.args[1]} vs ${(bal * 50n) / 100n}`);
    ok('不带 BNB', BigInt(calls[0].value) === 0n);
  }
  ok('状态显示已全部转走', /已全部转走/.test(xferStatus().tokens[0]?.status || ''), xferStatus().tokens[0]?.status);
  // 再扫一次：不会重复转
  await new Promise((r) => setTimeout(r, 16000));
  ok('同一个钱包同一个币只转一次', sent.length === 1, `sent=${sent.length}`);
  disarmXfer('manual');

  // 买入即加入：开「买入即加入」后，执行日志一写入买入就进监控（不等轮询、不等发射）
  await armXfer({ walletIds: ['eval-w'], targetId: TID, platforms: { v2: { enabled: true, percent: 100 } }, autoAdd: true, hours: 1 }, deps, { tokens: [] });
  const NEW = '0x1111111111111111111111111111111111111111';
  const before = xferStatus().tokens.length;
  journal('gangsnipe.buy', { walletId: 'eval-w', token: NEW, spendWei: '1' });
  ok('买入写进日志的同一时刻就加入监控', xferStatus().tokens.some((t) => t.token === NEW && t.source === 'auto'), `before=${before} after=${xferStatus().tokens.length}`);
  journal('gangsnipe.buy', { walletId: 'other-wallet', token: '0x2222222222222222222222222222222222222222', spendWei: '1' });
  ok('别的钱包买的不加入', !xferStatus().tokens.some((t) => t.token === '0x2222222222222222222222222222222222222222'));
  journal('gangsnipe3.buy', { walletId: 'eval-w', token: '0x3333333333333333333333333333333333333333', spendWei: '1' });
  ok('没勾选的平台（V3）不加入', !xferStatus().tokens.some((t) => t.token === '0x3333333333333333333333333333333333333333'));
} finally {
  disarmXfer('manual');
  rmSync(process.env.ARMS_FILE, { force: true });
  await new Promise((r) => setTimeout(r, 200));
  rmSync(JDIR, { recursive: true, force: true });
}

// ---- 静态资源版本号（对齐 gmgn-toolkit static_cache.py）----
{
  const { injectCacheBusters } = await import('../static_cache.mjs');
  const { writeFileSync, mkdirSync, utimesSync } = await import('node:fs');
  const dir = path.join(os.tmpdir(), `walletui-static-${process.pid}`);
  mkdirSync(dir, { recursive: true });
  writeFileSync(path.join(dir, 'app.js'), 'console.log(1)');
  const html = '<link href="/styles.css"><script src="/app.js?v=old"></script><img src="/x.png">';
  const h1 = await injectCacheBusters(html, dir);
  const v1 = h1.match(/app\.js\?v=([0-9a-f]{8})"/)?.[1];
  ok('JS 注入内容哈希版本号（替换旧的 ?v=）', Boolean(v1) && !h1.includes('v=old'), h1);
  ok('不存在的文件保持原样', h1.includes('href="/styles.css"'));
  ok('非 JS / CSS 不改', h1.includes('src="/x.png"'));
  writeFileSync(path.join(dir, 'app.js'), 'console.log(2)');
  utimesSync(path.join(dir, 'app.js'), new Date(), new Date(Date.now() + 5000));
  const v2 = (await injectCacheBusters(html, dir)).match(/app\.js\?v=([0-9a-f]{8})"/)?.[1];
  ok('文件内容一变，版本号自动变', v2 && v2 !== v1, `${v1} → ${v2}`);
  rmSync(dir, { recursive: true, force: true });
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
