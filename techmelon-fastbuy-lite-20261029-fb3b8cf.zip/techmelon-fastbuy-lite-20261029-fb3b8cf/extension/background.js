/*
 * 插件后台（service worker）：所有对控制台的请求都从这里发（网页里的 content script 不直接请求，避免页面的 CORS / CSP 限制，
 * 也不把配对密钥暴露给网页）。另外负责读剪贴板（offscreen 文档）和工具栏按钮。
 *
 * 请求头：x-ext-key = 控制台「设置 → 浏览器插件」生成的配对密钥。服务端只放行快捷交易相关接口。
 */
const DEFAULTS = { baseUrl: 'http://127.0.0.1:8790', extKey: '' };
const TIMEOUT_MS = 60000;

async function settings() {
  const s = await chrome.storage.local.get(['baseUrl', 'extKey']);
  return { ...DEFAULTS, ...s };
}

/** 调控制台接口，返回 { ok, data } 或 { ok:false, error }（不抛异常，content script 那边好处理） */
async function callApi({ path, method = 'GET', body }) {
  if (typeof path !== 'string' || !path.startsWith('/api/')) return { ok: false, error: '无效的接口路径' };
  const { baseUrl, extKey } = await settings();
  if (!extKey) return { ok: false, error: '还没配对：打开插件设置页，填控制台地址和配对密钥', needSetup: true };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const headers = { 'x-ext-key': extKey };
    if (method === 'POST') headers['content-type'] = 'application/json';
    const res = await fetch(baseUrl.replace(/\/+$/, '') + path, {
      method, headers, body: method === 'POST' ? JSON.stringify(body || {}) : undefined, signal: ctrl.signal, credentials: 'omit',
    });
    const payload = await res.json().catch(() => null);
    if (!payload) return { ok: false, error: `控制台返回了非 JSON（HTTP ${res.status}）：地址填对了吗？` };
    if (!res.ok || !payload.ok) return { ok: false, error: payload.error || `HTTP ${res.status}`, status: res.status };
    return { ok: true, data: payload.data };
  } catch (err) {
    return { ok: false, error: err.name === 'AbortError' ? '控制台 60 秒没有响应' : `连不上控制台（${baseUrl}）：${err.message}` };
  } finally {
    clearTimeout(timer);
  }
}

/* ---- 剪贴板：MV3 的 service worker 没有 DOM，借一个 offscreen 文档读 ---- */
let creating = null;
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: 'offscreen.html', reasons: ['CLIPBOARD'], justification: '读取刚复制的合约地址（只在你复制 / 点击之后读一次）',
    }).finally(() => { creating = null; });
  }
  await creating;
}
async function readClipboard() {
  try {
    await ensureOffscreen();
    const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'readClipboard' });
    return { ok: true, text: String(r?.text || '').slice(0, 2000) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.target === 'offscreen') return false; // 发给 offscreen 文档的，不在这里处理
  if (msg?.type === 'api') { callApi(msg).then(reply); return true; }
  if (msg?.type === 'readClipboard') { readClipboard().then(reply); return true; }
  if (msg?.type === 'openOptions') { chrome.runtime.openOptionsPage(); reply({ ok: true }); return false; }
  return false;
});

// 第一次安装：打开设置页（复制插件 ID、填配对密钥）
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === 'install') chrome.runtime.openOptionsPage(); });

// 工具栏按钮：显示 / 隐藏当前页的交易窗口
chrome.action.onClicked.addListener((tab) => {
  if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'togglePanel' }).catch(() => {});
});
