/*
 * 网页里的一键买卖窗口（参考 meme 交易平台的快捷交易弹窗）：
 *   - 识别 CA：地址栏里的 0x 地址（单页应用换页也会跟着变）；刚复制的 CA（复制事件 / 点了复制按钮后读一次剪贴板）。
 *   - 窗口：拖标题栏移动，拖右下角调整大小；窗口够高时显示两排金额按钮。
 *   - 买入 P1 / P2 / P3、卖出 P1 / P2 / P3：每组 8 个金额 / 比例 + 各自的滑点，点 ✎ 编辑。
 *   - 多钱包：勾选几个钱包，点一次金额每个钱包各买一笔（并行）；卖出同样对勾选的钱包各卖一笔。
 *   - 买入：钱包在控制台开了「直接买入」且金额 / 滑点在范围内时直接买，否则先弹一次确认（多钱包合并成一个确认框）。
 *   - 卖出：设置页「卖出免确认」打开时（默认开）直接卖，关掉时先确认。
 * 设置（预设 / 钱包 / 窗口位置）存在 chrome.storage.local，所有标签页实时同步（storage.onChanged）：
 * 以前每个标签页各自在打开时读一次，之后改了预设，别的标签页还是旧的，甚至会把旧值写回去覆盖掉（2026-10-28 修）。
 * 界面放在 Shadow DOM 里，不受网页样式影响；所有动态文字都用 textContent 写入，不拼 HTML。
 */
(() => {
  if (window.top !== window || window.__awQuickPanel) return;
  window.__awQuickPanel = true;

  const CA_RE = /0x[a-fA-F0-9]{40}(?![a-fA-F0-9])/g;
  const ONE_CA = /^\s*(0x[a-fA-F0-9]{40})\s*$/;
  const EXPLORER = 'https://bscscan.com/tx/';
  const MIN_W = 280;
  const MIN_H = 250;
  const TALL_H = 430; // 高于这个显示两排按钮
  const MAX_WALLETS = 5;
  const DEFAULT_PRESETS = {
    buyP: 0,
    sellP: 0,
    buy: [
      { amounts: ['0.01', '0.02', '0.05', '0.1', '0.2', '0.3', '0.5', '1'], slipBps: 1500 },
      { amounts: ['0.01', '0.02', '0.05', '0.1', '0.2', '0.3', '0.5', '1'], slipBps: 2500 },
      { amounts: ['0.05', '0.1', '0.2', '0.5', '1', '2', '3', '5'], slipBps: 4000 },
    ],
    sell: [
      { amounts: ['20', '35', '50', '100', '10', '25', '75', '90'], slipBps: 1500 },
      { amounts: ['20', '35', '50', '100', '10', '25', '75', '90'], slipBps: 2500 },
      { amounts: ['20', '35', '50', '100', '10', '25', '75', '90'], slipBps: 4000 },
    ],
  };
  const DEFAULT_PANEL = { x: null, y: 120, w: 340, h: 390, open: false };
  const STEP_TEXT = {
    preview: '币安模拟中', execute: '广播中', confirm: '等上链', replan: '重新报价', done: '完成', 'app-confirm': '等币安 App 确认',
  };
  const KIND_TEXT = { approve: '授权', swap: '兑换', buy: '买入', sell: '卖出', wrap: '包装 BNB', unwrap: '解包 WBNB', transfer: '转账' };

  const st = {
    settings: { autoOpen: true, watchClipboard: true, sellNoConfirm: true },
    presets: structuredClone(DEFAULT_PRESETS),
    panel: { ...DEFAULT_PANEL },
    walletIds: [], // 勾选的下单钱包
    ca: null, // { address, source }
    info: null, // 识别结果
    wallets: [],
    walletError: null, // 拿钱包列表失败的原因（连不上控制台 / 没配对），信息行会显示
    arms: new Map(), // walletId → 直接买入预授权状态
    pos: null, // 当前代币持仓（后端 /api/quick/position）；null = 还没读到
    managed: { tokens: new Set(), addrs: new Set(), at: 0, key: '' }, // 本系统买过的币 / 自己的钱包地址（本地判断用）
    posState: 'idle', // idle / loading / error
    posError: null,
    posAt: 0,
    posOpen: false,
    busy: false,
    editing: false,
    walletMenu: false,
    dismissed: new Set(),
    lastClip: '',
  };

  /* ---------- 小工具 ---------- */
  // 插件被重新加载 / 更新后，旧页面里的脚本还活着，但 sendMessage 会同步抛「Extension context invalidated」
  // （不是返回 rejected promise，.catch 接不住）：必须 try 住，否则调用方永远等不到结果
  const STALE_MSG = '插件已重新加载或更新：请刷新这个网页';
  const isStale = (err) => /context invalidated/i.test(String(err?.message || err));
  const api = (path, method = 'GET', body) => {
    try {
      return chrome.runtime.sendMessage({ type: 'api', path, method, body })
        .then((r) => r || { ok: false, error: '插件后台没有响应' })
        .catch((err) => ({ ok: false, error: isStale(err) ? STALE_MSG : err.message, stale: isStale(err) }));
    } catch (err) {
      return Promise.resolve({ ok: false, error: isStale(err) ? STALE_MSG : String(err?.message || err), stale: isStale(err) });
    }
  };
  // 产品头像：插件内的资源不受网页 CSP 的 img-src 限制（data: 图片会被部分网站拦掉）；use_dynamic_url 防网页按固定 URL 探测插件
  const LOGO = (() => { try { return chrome.runtime.getURL('icons/icon48.png'); } catch { return ''; } })();
  const short = (a) => (a ? `${a.slice(0, 6)}…${a.slice(-4)}` : '');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const weiToBnb = (w) => { try { const n = BigInt(w); const s = n.toString().padStart(19, '0'); return `${s.slice(0, -18)}.${s.slice(-18).replace(/0+$/, '')}`.replace(/\.$/, ''); } catch { return String(w); } };
  const compact = (v) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return String(v);
    return n >= 1e9 ? `${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(2)}K` : String(Number(n.toPrecision(4)));
  };
  function el(tag, attrs = {}, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  }
  // 三类设置分开存：改预设只写预设，拖窗口只写窗口，互不覆盖
  const savePresets = () => chrome.storage.local.set({ quickPresets: st.presets }).catch(() => {});
  const savePanel = () => chrome.storage.local.set({ quickPanel: st.panel }).catch(() => {});
  const saveWallets = () => chrome.storage.local.set({ quickWallets: st.walletIds }).catch(() => {});
  const walletName = (id) => st.wallets.find((w) => w.id === id)?.name || id;
  const armedFor = (id, amount, slipBps) => {
    const a = st.arms.get(id);
    return Boolean(a?.armed && Date.now() < Date.parse(a.expiresAt) && (amount == null || Number(amount) <= Number(a.maxBuyBnb)) && (slipBps == null || slipBps <= a.maxSlippageBps));
  };

  /** 读出来的预设做一次校验，坏数据退回默认 */
  function normPresets(p) {
    const d = structuredClone(DEFAULT_PRESETS);
    if (!p || typeof p !== 'object') return d;
    for (const k of ['buy', 'sell']) {
      if (Array.isArray(p[k]) && p[k].length === 3) {
        d[k] = p[k].map((g, i) => ({
          amounts: Array.isArray(g?.amounts) ? g.amounts.slice(0, 8).map((x) => String(x ?? '')).concat(Array(8).fill('')).slice(0, 8) : d[k][i].amounts,
          slipBps: Number.isInteger(g?.slipBps) && g.slipBps >= 1 && g.slipBps <= 5000 ? g.slipBps : d[k][i].slipBps,
        }));
      }
    }
    d.buyP = [0, 1, 2].includes(p.buyP) ? p.buyP : 0;
    d.sellP = [0, 1, 2].includes(p.sellP) ? p.sellP : 0;
    return d;
  }

  /* ---------- 窗口骨架（Shadow DOM） ---------- */
  const host = el('div', { id: 'aw-quick-host' });
  host.style.cssText = 'all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0;';
  const root = host.attachShadow({ mode: 'closed' });
  root.append(el('style', { text: CSS() }));
  const panel = el('div', { class: 'panel', role: 'dialog', 'aria-label': '技术瓜内盘快买' });
  const bubble = el('button', { class: 'bubble', type: 'button', title: '打开技术瓜内盘快买', onclick: () => openPanel(true) },
    el('img', { class: 'logo', src: LOGO, alt: '' }), '内盘快买');
  root.append(panel, bubble);

  // 标题栏
  const titleSym = el('b', { class: 'sym', text: '未识别 CA' });
  const titleCa = el('span', { class: 'ca', title: '点击复制完整地址' });
  const titleSrc = el('span', { class: 'src' });
  const walletBtn = el('button', { class: 'wallet', type: 'button', title: '下单钱包（可多选：每个钱包各买 / 卖一笔）', 'aria-haspopup': 'true', onclick: () => toggleWalletMenu() });
  const walletMenu = el('div', { class: 'wallet-menu', role: 'menu', hidden: true });
  const head = el('div', { class: 'head' },
    el('img', { class: 'logo', src: LOGO, alt: '', title: '技术瓜内盘快买（拖动移动窗口）' }),
    el('div', { class: 'title' }, titleSym, titleCa, titleSrc),
    walletBtn,
    el('button', { class: 'icon', type: 'button', title: '编辑金额和滑点', 'aria-label': '编辑', text: '✎', onclick: () => toggleEdit() }),
    el('button', { class: 'icon', type: 'button', title: '插件设置', 'aria-label': '设置', text: '⚙', onclick: () => chrome.runtime.sendMessage({ type: 'openOptions' }) }),
    el('button', { class: 'icon', type: 'button', title: '收起', 'aria-label': '收起', text: '—', onclick: () => openPanel(false) }),
  );
  const infoLine = el('div', { class: 'info' });
  // 持仓条：当前代币的持仓（链上余额，价值 / 盈亏来自后端的 GMGN 数据），多钱包时点开看每个钱包
  const posBar = el('button', { type: 'button', class: 'pos', title: '点击展开 / 收起每个钱包的持仓', onclick: () => { st.posOpen = !st.posOpen; renderPos(); } });
  const posDetail = el('div', { class: 'pos-detail', hidden: true });
  const buySec = el('section', { class: 'side buy' });
  const sellSec = el('section', { class: 'side sell' });
  const statusBar = el('div', { class: 'status', role: 'status', 'aria-live': 'polite' });
  const overlay = el('div', { class: 'overlay', hidden: true });
  panel.append(head, walletMenu, infoLine, posBar, posDetail, buySec, sellSec, statusBar, overlay);

  titleCa.addEventListener('click', async () => {
    if (!st.ca) return;
    try { await navigator.clipboard.writeText(st.ca.address); flash('地址已复制'); } catch { /* 网页不允许写剪贴板 */ }
  });

  /* ---------- 多钱包选择 ---------- */
  function renderWalletBtn() {
    const ids = st.walletIds.filter((id) => st.wallets.some((w) => w.id === id));
    walletBtn.textContent = !st.wallets.length ? '未连接' : !ids.length ? '选钱包 ▾' : `${walletName(ids[0])}${ids.length > 1 ? ` +${ids.length - 1}` : ''} ▾`;
  }
  function renderWalletMenu() {
    walletMenu.replaceChildren(
      el('div', { class: 'wm-tip', text: `勾选的钱包都会下单（每个钱包各一笔，最多 ${MAX_WALLETS} 个）` }),
      ...st.wallets.map((w) => {
        const on = st.walletIds.includes(w.id);
        const cb = el('input', { type: 'checkbox', checked: on });
        cb.addEventListener('change', () => {
          if (cb.checked && st.walletIds.length >= MAX_WALLETS) { cb.checked = false; flash(`最多勾选 ${MAX_WALLETS} 个钱包`, 'err'); return; }
          st.walletIds = cb.checked ? [...st.walletIds, w.id] : st.walletIds.filter((x) => x !== w.id);
          saveWallets();
          renderWalletBtn();
          refreshWalletState();
        });
        return el('label', { class: 'wm-row' }, cb, ` ${w.name}`, armedFor(w.id) ? el('span', { class: 'badge ok', text: '免确认' }) : null);
      }),
    );
  }
  function toggleWalletMenu(force) {
    st.walletMenu = force ?? !st.walletMenu;
    walletMenu.hidden = !st.walletMenu;
    if (st.walletMenu) renderWalletMenu();
  }
  panel.addEventListener('pointerdown', (e) => { if (st.walletMenu && !e.composedPath().some((n) => n === walletMenu || n === walletBtn)) toggleWalletMenu(false); });
  const activeWallets = () => st.walletIds.filter((id) => st.wallets.some((w) => w.id === id));

  /* ---------- 拖动 / 调大小 ---------- */
  function applyGeometry() {
    const p = st.panel;
    const w = Math.max(MIN_W, Math.min(p.w || 340, window.innerWidth - 16));
    const hgt = Math.max(MIN_H, Math.min(p.h || 390, window.innerHeight - 16));
    const x = p.x == null ? window.innerWidth - w - 20 : Math.max(8, Math.min(p.x, window.innerWidth - w - 8));
    const y = Math.max(8, Math.min(p.y ?? 120, window.innerHeight - 60));
    Object.assign(panel.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${hgt}px` });
    panel.classList.toggle('tall', hgt >= TALL_H);
  }
  head.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button, select')) return;
    const r = panel.getBoundingClientRect();
    const dx = e.clientX - r.left;
    const dy = e.clientY - r.top;
    head.setPointerCapture(e.pointerId);
    const move = (ev) => {
      st.panel.x = Math.round(ev.clientX - dx);
      st.panel.y = Math.round(ev.clientY - dy);
      applyGeometry();
    };
    const up = () => { head.removeEventListener('pointermove', move); head.removeEventListener('pointerup', up); savePanel(); };
    head.addEventListener('pointermove', move);
    head.addEventListener('pointerup', up);
  });
  let resizeTimer = null;
  new ResizeObserver(() => {
    if (panel.hidden) return;
    const r = panel.getBoundingClientRect();
    panel.classList.toggle('tall', r.height >= TALL_H);
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (Math.abs(st.panel.w - r.width) < 2 && Math.abs(st.panel.h - r.height) < 2) return;
      st.panel.w = Math.round(r.width); st.panel.h = Math.round(r.height); savePanel();
    }, 300);
  }).observe(panel);
  window.addEventListener('resize', () => { if (!panel.hidden) applyGeometry(); });

  function openPanel(open, { persist = true } = {}) {
    st.panel.open = open;
    panel.hidden = !open;
    bubble.hidden = open || !st.ca;
    if (open) {
      applyGeometry();
      // 识别不等钱包列表：先用上次保存的钱包 ID 发出去（列表回来发现它已删除会重新识别）
      if (st.ca && (!st.info || st.info.error)) detect(st.ca.address);
      refreshWallets();
    } else if (st.ca) st.dismissed.add(st.ca.address.toLowerCase());
    if (persist) savePanel();
  }

  /* ---------- 买入 / 卖出区 ---------- */
  function sideHtml(side) {
    const sec = side === 'buy' ? buySec : sellSec;
    const group = st.presets[side];
    const idx = side === 'buy' ? st.presets.buyP : st.presets.sellP;
    const g = group[idx];
    const tabs = group.map((_, i) => el('button', {
      type: 'button', class: `tab${i === idx ? ' on' : ''}`, text: `P${i + 1}`, title: `预设 ${i + 1}（滑点 ${group[i].slipBps / 100}%）`,
      onclick: () => { if (side === 'buy') st.presets.buyP = i; else st.presets.sellP = i; savePresets(); renderSides(); },
    }));
    const right = side === 'buy' ? armBadge() : sellBadge();
    const top = el('div', { class: 'side-head' }, el('span', { class: 'side-title', text: side === 'buy' ? '买入' : '卖出' }), ...tabs, el('span', { class: 'grow' }), right);
    let grid;
    if (st.editing) {
      grid = el('div', { class: 'grid' }, g.amounts.map((v, i) => el('input', {
        class: 'amt-edit', value: v, inputmode: 'decimal', 'aria-label': `${side === 'buy' ? '买入金额' : '卖出比例'} ${i + 1}`,
        oninput: (e) => { g.amounts[i] = e.target.value.trim(); },
      })));
    } else {
      grid = el('div', { class: 'grid' }, g.amounts.map((v, i) => {
        const valid = side === 'buy' ? /^\d+(\.\d+)?$/.test(v) && Number(v) > 0 : /^\d{1,3}(\.\d{1,2})?$/.test(v) && Number(v) > 0 && Number(v) <= 100;
        const n = activeWallets().length;
        const noPos = side === 'sell' && posEmpty();
        const noPlat = noPlatform();
        // st.pos 可能是 { managed:false }（本系统没买过，没有 total）：只有真读到余额才估算
        const bal = st.pos?.total?.balance;
        const sellAmt = side === 'sell' && valid && bal != null && !noPos ? ` ≈ ${compact(Number(bal) * Number(v) / 100)} ${st.pos.symbol || ''}` : '';
        return el('button', {
          type: 'button', class: `amt${i >= 4 ? ' row2' : ''}`, disabled: !valid || st.busy || !st.ca || !n || noPos || noPlat,
          text: valid ? (side === 'buy' ? v : `${v}%`) : '—',
          title: !valid ? '点 ✎ 设置' : noPlat ? '没有可交易的平台（点信息行可重新识别）' : noPos ? '所选钱包没有这个代币' : side === 'buy' ? `${n > 1 ? `${n} 个钱包各` : ''}买入 ${v} BNB` : `${n > 1 ? `${n} 个钱包各` : ''}卖出持仓的 ${v}%${sellAmt}`,
          onclick: () => (side === 'buy' ? doBuy(v, g.slipBps) : doSell(v, g.slipBps)),
        });
      }));
    }
    const slip = st.editing
      ? el('label', { class: 'foot' }, '滑点 ', el('input', {
        class: 'slip-edit', value: String(g.slipBps / 100), inputmode: 'decimal', 'aria-label': '滑点百分比',
        oninput: (e) => { const n = Math.round(Number(e.target.value) * 100); if (n >= 1 && n <= 5000) g.slipBps = n; },
      }), ' %')
      : el('div', { class: 'foot', text: `滑点 ${g.slipBps / 100}%${side === 'buy' ? ` · 单位 BNB${bnbText()}` : ' · 按每个钱包当前持仓的比例'}` });
    sec.replaceChildren(top, grid, slip);
  }
  function renderSides() { sideHtml('buy'); sideHtml('sell'); renderPos(); }

  /* ---------- 持仓条 ---------- */
  // 所选钱包都确定没有这个币：本系统买过的钱包余额都是 0，且没有「没在本系统买过」的钱包（那些可能在别处买过，余额未知）
  const posEmpty = () => Boolean(st.pos?.managed && st.pos.total?.raw === '0' && !st.pos.unmanaged?.length);
  /** 这个钱包当前代币余额：'0' / 数字串 = 已读到；null = 不知道（没在本系统买过 / 读取失败） */
  // 只信「当前代币 + 当前钱包组合」且 60 秒内读到的数据：太旧的（可能在别处刚买 / 刚转入）当作不知道，交给后端判断
  const POS_TRUST_MS = 60000;
  const posRow = (id) => {
    if (!st.ca || !st.pos?.rows || Date.now() - st.posAt > POS_TRUST_MS) return null;
    if (st.pos.key !== `${st.ca.address.toLowerCase()}|${activeWallets().join(',')}`) return null;
    return st.pos.rows.find((r) => r.walletId === id) || null;
  };
  const tokenRawOf = (id) => posRow(id)?.raw ?? null;
  const bnbOf = (id) => posRow(id)?.bnb ?? null;
  /** 识别已完成且确定没有可交易平台（识别出错不算：那时让后端下单时自己再识别） */
  const noPlatform = () => Boolean(st.info && !st.info.error && !tradableOf(st.info));
  const usd = (v) => (v == null ? null : `$${Math.abs(v) >= 1000 ? compact(v) : Number(v).toFixed(2)}`);
  const signed = (v) => (v == null ? '' : `${v >= 0 ? '+' : '-'}${usd(Math.abs(v))}`);
  const pct = (p) => (p == null ? '' : `（${p >= 0 ? '+' : ''}${(p * 100).toFixed(1)}%）`);
  function bnbText() {
    const rows = st.pos?.rows?.filter((r) => r.bnb != null) || [];
    if (!rows.length) return '';
    const total = rows.reduce((a, r) => a + Number(r.bnb), 0);
    return ` · 可用 ${Number(total.toPrecision(4))} BNB${rows.length > 1 ? `（${rows.length} 个钱包合计）` : ''}`;
  }
  function renderPos() {
    const multi = activeWallets().length > 1;
    posBar.hidden = !st.ca;
    posDetail.hidden = !st.ca || !st.posOpen || !st.pos?.rows?.length;
    if (!st.ca) return;
    const p = st.pos;
    let cls = 'pos';
    let parts;
    if (!p) {
      parts = [st.posState === 'error' ? `持仓读取失败：${st.posError || ''}` : !st.wallets.length ? (st.walletError ? '没连上控制台' : '读取钱包中…') : !activeWallets().length ? '先选钱包' : '持仓读取中…'];
      cls += st.posState === 'error' ? ' err' : ' none';
    } else if (p.managed === false || !p.total) {
      parts = ['本系统没买过（狙击 / 一键买入的才显示）'];
      cls += ' none';
    } else if (posEmpty()) {
      parts = ['已清仓（本系统买过，现在余额为 0）'];
      cls += ' none';
    } else {
      const t = p.total;
      const pnl = t.totalProfit ?? t.unrealized;
      // 百分比与 GMGN 一致（盈亏 / GMGN 的成本基数）；多钱包按各自基数合计（基数 = 盈亏 ÷ 百分比）
      const held = p.rows.filter((r) => r.raw && r.raw !== '0' && r.totalProfit != null && r.totalPnl);
      const basis = held.reduce((a, r) => a + r.totalProfit / r.totalPnl, 0);
      const pnlPct = held.length === 1 ? held[0].totalPnl : basis ? held.reduce((a, r) => a + r.totalProfit, 0) / basis : null;
      parts = [
        el('b', { text: `${compact(t.balance)} ${p.symbol || ''}` }),
        t.usdValue != null ? ` ≈ ${usd(t.usdValue)}` : '',
        pnl != null ? el('span', { class: pnl >= 0 ? 'up' : 'down', text: ` · 盈亏 ${signed(pnl)}${pct(pnlPct)}` }) : '',
        multi ? ` · ${t.held}/${activeWallets().length} 个钱包有仓` : '',
        !multi && p.rows[0]?.source ? el('span', { class: 'dim', text: ` · ${p.rows[0].source}` }) : '',
        !p.gmgn ? el('span', { class: 'dim', text: ' · 无 GMGN 估值' }) : '',
      ];
      cls += ' has';
    }
    posBar.className = cls;
    // 原生 replaceChildren 会把 null 转成文字 "null"：先过滤
    posBar.replaceChildren(...[el('span', { class: 'pos-k', text: '持仓' }), ...parts,
      el('span', { class: 'grow' }), st.posState === 'loading' && p ? el('span', { class: 'dim', text: '↻' }) : null, p && multi ? el('span', { class: 'dim', text: st.posOpen ? '▴' : '▾' }) : null].filter(Boolean));
    if (!posDetail.hidden) {
      posDetail.replaceChildren(...p.rows.map((r) => el('div', { class: 'pos-row', title: r.source ? `来源：${r.source}（买入 ${r.buys} 次）` : '' },
        el('span', { class: 'pos-w', text: walletName(r.walletId) }),
        el('span', { text: r.raw == null ? '读取失败' : r.raw === '0' ? '—' : `${compact(r.balance)}${r.usdValue != null ? ` ≈ ${usd(r.usdValue)}` : ''}` }),
        r.totalProfit != null && r.raw !== '0' ? el('span', { class: r.totalProfit >= 0 ? 'up' : 'down', text: `${signed(r.totalProfit)}${pct(r.totalPnl)}` }) : el('span'),
        el('span', { class: 'dim', text: r.bnb != null ? `${Number(Number(r.bnb).toPrecision(4))} BNB` : '' }))));
    }
  }

  function armBadge() {
    const ids = activeWallets();
    const on = ids.filter((id) => armedFor(id));
    const all = ids.length && on.length === ids.length;
    return el('span', {
      class: `badge ${all ? 'ok' : 'warn'}`,
      text: all ? '免确认' : on.length ? `${on.length}/${ids.length} 免确认` : '需确认',
      title: ids.map((id) => {
        const a = st.arms.get(id);
        return armedFor(id) ? `${walletName(id)}：直接买入已开启（单笔 ≤ ${a.maxBuyBnb} BNB、滑点 ≤ ${a.maxSlippageBps / 100}%）` : `${walletName(id)}：没开启直接买入，买入先确认`;
      }).join('\n') || '先选钱包',
    });
  }
  function sellBadge() {
    return el('span', {
      class: `badge ${st.settings.sellNoConfirm ? 'ok' : 'warn'}`, text: st.settings.sellNoConfirm ? '直接卖' : '需确认',
      title: st.settings.sellNoConfirm ? '插件设置里开了「卖出免确认」：点比例直接卖（仍经币安模拟、最少收到按滑点算）' : '每次卖出先确认（插件设置里可改）',
    });
  }

  function toggleEdit() {
    if (st.editing) {
      for (const g of [...st.presets.buy, ...st.presets.sell]) g.amounts = g.amounts.map((v) => String(v || '').replace(/%$/, '').trim()).slice(0, 8);
      savePresets();
      flash('预设已保存（所有网页同步生效）');
    }
    st.editing = !st.editing;
    renderSides();
  }

  /* ---------- 状态栏 ---------- */
  let flashTimer = null;
  function flash(text, cls = '') {
    statusBar.className = `status ${cls}`;
    statusBar.replaceChildren(text);
    clearTimeout(flashTimer);
    if (!cls) flashTimer = setTimeout(() => { if (!st.busy) statusBar.replaceChildren(); }, 4000);
  }
  /** 多钱包进度：每个钱包一行 */
  function showRuns(runs, verb, startedAt) {
    const sec = ((Date.now() - startedAt) / 1000).toFixed(1);
    const running = runs.some((r) => !r.end);
    const act = runs.filter((r) => r.end !== 'skipped'); // 本地就跳过的钱包（没持仓 / 余额不够）不算失败
    const ok = act.filter((r) => r.end === 'done').length;
    const skipped = runs.length - act.length;
    statusBar.className = `status ${running ? '' : ok === act.length ? 'ok' : ok ? '' : 'err'}`;
    statusBar.replaceChildren(
      el('div', { class: 'job-head', text: running ? `⏳ ${verb}中… ${sec} 秒` : `${ok === act.length ? '✅' : ok ? '⚠' : '⛔'} ${verb}完成 ${ok}/${act.length}${skipped ? ` · 跳过 ${skipped}` : ''} · ${sec} 秒` }),
      ...runs.map((r) => {
        const last = [...(r.job?.steps || [])].reverse().find((s) => s.txHash);
        const steps = (r.job?.steps || []).map((s) => `${KIND_TEXT[s.kind] || s.kind} ${STEP_TEXT[s.status] || s.status}`).join(' → ');
        return el('div', { class: `step ${r.end === 'done' ? 'ok' : r.end === 'skipped' ? 'dim' : r.error ? 'err' : ''}` },
          runs.length > 1 ? el('b', { text: `${walletName(r.walletId)}：` }) : null,
          r.end === 'skipped' ? `跳过：${r.note}` : r.error ? r.error : (steps || r.note || '准备中…'), ' ',
          last ? el('a', { href: EXPLORER + last.txHash, target: '_blank', rel: 'noopener noreferrer', text: '查看交易 ↗' }) : null);
      }),
    );
  }

  /* ---------- 确认框（需要确认的买入、关掉「卖出免确认」时的卖出） ---------- */
  function confirmBox(title, rows, note, okText) {
    return new Promise((resolve) => {
      const done = (v) => { overlay.hidden = true; overlay.replaceChildren(); document.removeEventListener('keydown', key, true); resolve(v); };
      const key = (e) => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
      const okBtn = el('button', { type: 'button', class: 'ok-btn', text: okText, onclick: () => done(true) });
      overlay.replaceChildren(el('div', { class: 'confirm' },
        el('div', { class: 'c-title', text: title }),
        el('div', { class: 'c-rows' }, rows.map(([k, v]) => el('div', { class: `c-row${k.startsWith('—') ? ' sep' : ''}` }, el('span', { class: 'k', text: k }), el('span', { class: 'v', text: v })))),
        note ? el('p', { class: 'c-note', text: note }) : null,
        el('div', { class: 'c-act' }, el('button', { type: 'button', class: 'cancel-btn', text: '取消', onclick: () => done(false) }), okBtn)));
      overlay.hidden = false;
      document.addEventListener('keydown', key, true);
      okBtn.focus();
    });
  }
  /** 一个钱包的计划明细（与控制台一键执行确认框一致：每一步、BNB 合计上限、授权上限、最少收到） */
  function planRows(r, sell, multi) {
    const p = r.plan;
    const oc = r.oneClick;
    const pre = multi ? `${walletName(r.walletId)} · ` : '';
    const rows = [];
    if (multi) rows.push([`— ${walletName(r.walletId)}`, r.from]);
    else rows.push(['钱包', `${walletName(r.walletId)} · ${r.from}`]);
    if (!multi) rows.push(['方向', sell ? '卖出' : '买入'], ['代币', `${p.symbol || '?'}  ${p.token}`], ['平台', p.platformLabel || p.platform]);
    rows.push([`${pre}扣取`, p.pay?.text || '—'], [`${pre}预计收到`, `${p.receive?.expected} ${p.receive?.symbol}`], [`${pre}最少收到`, `${p.receive?.min} ${p.receive?.symbol}`]);
    if (!multi) rows.push(['路由', p.route || '—']);
    if (p.impactBps != null || p.lossBps != null) rows.push([`${pre}冲击 / 税`, [p.impactBps != null ? `价格冲击 ${(p.impactBps / 100).toFixed(2)}%` : '', p.lossBps != null ? `税/损耗 ${(p.lossBps / 100).toFixed(2)}%` : ''].filter(Boolean).join(' · ')]);
    r.steps.forEach((s, i) => rows.push([`${pre}第 ${i + 1} 步`, `${KIND_TEXT[s.kind] || s.kind} · ${s.label}`]));
    rows.push([`${pre}上限 · BNB 合计`, `${weiToBnb(oc.bounds.maxValueWei)} BNB`]);
    for (const a of oc.bounds.approvals || []) {
      let unl = false;
      try { unl = BigInt(a.amount) >= 2n ** 255n; } catch { /* 当有限额 */ }
      const step = r.steps.find((s) => s.kind === 'approve' && String(s.to).toLowerCase() === String(a.token).toLowerCase());
      rows.push([`${pre}上限 · 授权`, `${unl ? '无上限' : step?.label || '只授权本次数量'}（授权给 ${a.spender}）`]);
    }
    for (const w of p.warnings || []) rows.push([`${pre}⚠ 注意`, typeof w === 'string' ? w : (w.text || w.message || JSON.stringify(w))]);
    if (r.steps[0]?.preview?.requireConfirmation === true) rows.unshift([`${pre}⚠ 币安风控`, '第 1 步币安预判要在 App 里确认，确认之前这个钱包的所有交易都会被拒绝']);
    return rows;
  }

  /* ---------- 下单 ---------- */
  function preflight() {
    if (st.busy) { flash('上一笔还在执行'); return null; }
    if (!st.ca) { flash('还没识别到 CA', 'err'); return null; }
    const ids = activeWallets();
    if (!ids.length) { flash('先在标题栏勾选下单钱包（读不到钱包时检查插件设置）', 'err'); toggleWalletMenu(true); return null; }
    return { ids, address: st.ca.address };
  }

  /** 跟踪一个一键任务直到结束（按绝对时间截止） */
  async function follow(run, onTick) {
    const started = Date.now();
    while (run.job?.state === 'running' && Date.now() - started < 200000) {
      onTick();
      await sleep(700);
      const r = await api(`/api/quick/oneclick/${run.job.id}`);
      if (r.ok) run.job = r.data;
    }
    run.end = run.job?.state || 'failed';
    if (run.job?.error) run.error = run.job.error;
    onTick();
  }

  async function exclusive(verb, fn) {
    st.busy = true;
    renderSides();
    try { await fn(); } catch (err) { flash(`${verb}失败：${err.message}`, 'err'); } finally {
      st.busy = false;
      renderSides();
      // 一键任务结束时已上链：先刷新「本系统买过的币」（刚买的币要加进来），再直接读链上新余额
      setTimeout(() => refreshHold({ fresh: true, managedFirst: true }), 1500);
      refreshArms();
    }
  }

  async function doBuy(amount, slipBps) {
    const t = preflight();
    if (!t) return;
    await exclusive('买入', async () => {
      const startedAt = Date.now();
      await refreshArms();
      // 本地已知 BNB 余额（持仓条读到的）不够这笔的钱包直接跳过，不发请求；不知道余额的照常交给后端判断
      const runs = t.ids.map((walletId) => {
        const bnb = bnbOf(walletId);
        if (bnb != null && Number(bnb) < Number(amount)) return { walletId, end: 'skipped', note: `BNB 不够（可用 ${Number(Number(bnb).toPrecision(4))}，要 ${amount}）` };
        return { walletId, direct: armedFor(walletId, amount, slipBps), note: '报价中…' };
      });
      const tick = () => showRuns(runs, '买入', startedAt);
      tick();
      if (runs.every((r) => r.end === 'skipped')) return;
      const body = (walletId) => ({ address: t.address, walletId, platform: 'auto', slippageBps: slipBps, amount });
      // 1) 已开启直接买入、且在范围内的钱包：直接买（服务端按预授权复核）
      // 2) 其它钱包：并行报价 + 币安模拟，合并成一个确认框
      await Promise.all(runs.filter((r) => !r.end).map(async (run) => {
        if (run.direct) {
          const r = await api('/api/quick/autobuy', 'POST', body(run.walletId));
          if (!r.ok) { run.error = r.error; run.end = 'failed'; return; }
          run.job = r.data.job;
          return;
        }
        const r = await api('/api/quick/plan', 'POST', { ...body(run.walletId), side: 'buy' });
        if (!r.ok) { run.error = r.error; run.end = 'failed'; return; }
        if (!r.data.oneClick) { run.error = r.data.steps?.[0]?.error || '第一步模拟没通过'; run.end = 'failed'; return; }
        run.plan = r.data;
        run.note = '等确认';
      }));
      tick();
      const need = runs.filter((r) => r.plan && !r.job);
      if (need.length) {
        const multi = need.length > 1;
        const rows = multi
          ? [['代币', `${need[0].plan.plan.symbol || '?'}  ${need[0].plan.plan.token}`], ['平台', need[0].plan.plan.platformLabel || need[0].plan.plan.platform], ...need.flatMap((r) => planRows(r.plan, false, true))]
          : planRows(need[0].plan, false, false);
        const why = need.map((r) => r.walletId).some((id) => st.arms.get(id)?.armed) ? '部分钱包超出直接买入的范围（单笔上限或滑点），这几笔需要确认。' : '';
        const ok = await confirmBox(multi ? `确认买入（${need.length} 个钱包，每个 ${amount} BNB）` : '确认买入', rows,
          `${why}确认后每个钱包自动依次执行各自的步骤（每步都经币安模拟），任何一步超出上限或模拟失败立即停止。计划 2 分钟内有效。`,
          multi ? `确认 ${need.length} 个钱包买入` : `确认买入 ${amount} BNB`);
        await Promise.all(need.map(async (run) => {
          if (!ok) { run.error = '已取消'; run.end = 'failed'; return; }
          const j = await api('/api/quick/oneclick', 'POST', { walletId: run.walletId, bundleId: run.plan.oneClick.bundleId, confirm: 'ONECLICK' });
          if (!j.ok) { run.error = j.error; run.end = 'failed'; return; }
          run.job = j.data;
        }));
      }
      await Promise.all(runs.filter((r) => r.job).map((r) => follow(r, tick)));
      tick();
    });
  }

  async function doSell(percent, slipBps) {
    const t = preflight();
    if (!t) return;
    await exclusive('卖出', async () => {
      const startedAt = Date.now();
      // 本地已确定余额为 0 的钱包直接跳过（不发报价请求）；余额未知（没在本系统买过 / 读取失败）的交给后端判断
      const runs = t.ids.map((walletId) => (tokenRawOf(walletId) === '0'
        ? { walletId, end: 'skipped', note: '没有这个币' }
        : { walletId, note: '报价中…' }));
      const tick = () => showRuns(runs, '卖出', startedAt);
      tick();
      if (runs.every((r) => r.end === 'skipped')) return;
      const plan = async (run) => {
        const r = await api('/api/quick/plan', 'POST', { address: t.address, walletId: run.walletId, platform: 'auto', slippageBps: slipBps, side: 'sell', percent });
        if (!r.ok) { run.error = r.error; run.end = 'failed'; return false; }
        if (!r.data.oneClick) { run.error = r.data.steps?.[0]?.error || '第一步模拟没通过'; run.end = 'failed'; return false; }
        run.plan = r.data;
        return true;
      };
      await Promise.all(runs.filter((r) => !r.end).map(plan));
      tick();
      const ready = runs.filter((r) => r.plan);
      if (!ready.length) return;
      if (!st.settings.sellNoConfirm) {
        const multi = ready.length > 1;
        const rows = multi ? ready.flatMap((r) => planRows(r.plan, true, true)) : planRows(ready[0].plan, true, false);
        const ok = await confirmBox(multi ? `确认卖出（${ready.length} 个钱包，各 ${percent}%）` : '确认卖出', rows,
          '确认后自动依次执行（授权本次数量 → 卖出 → 解包），已完成的步骤不会回滚。计划 2 分钟内有效。', `确认卖出 ${percent}%`);
        if (!ok) { for (const r of ready) { r.error = '已取消'; r.end = 'failed'; } return; }
      }
      const go = async (run) => {
        const j = await api('/api/quick/oneclick', 'POST', { walletId: run.walletId, bundleId: run.plan.oneClick.bundleId, confirm: 'ONECLICK' });
        if (!j.ok) { run.error = j.error; run.end = 'failed'; return; }
        run.job = j.data;
        run.end = null;
        await follow(run, tick);
        // 少数代币没法在授权前模拟卖出，计划里只有「授权」一步：授权上链后自动再卖一次（同样经币安模拟）
        const onlyApprove = run.plan.steps.length === 1 && run.plan.steps[0].kind === 'approve';
        if (run.end === 'done' && onlyApprove && !run.retried) {
          run.retried = true;
          run.note = '授权已上链，重新报价卖出…';
          run.end = null;
          run.job = null;
          tick();
          if (await plan(run)) { run.error = null; await go(run); }
        }
      };
      await Promise.all(ready.map(go));
      tick();
    });
  }

  /* ---------- 钱包 / 预授权 / 持仓 ---------- */
  async function refreshWallets() {
    const r = await api('/api/wallets');
    if (!r.ok) {
      st.wallets = [];
      st.walletError = r.needSetup ? '还没配对：点 ⚙ 打开设置，填控制台地址和配对密钥' : r.error;
      renderWalletBtn();
      renderTitle(); // 信息行显示为什么没法识别（不再一直停在「识别平台中…」）
      flash(st.walletError, 'err');
      return;
    }
    st.walletError = null;
    st.wallets = r.data;
    const valid = st.walletIds.filter((id) => r.data.some((w) => w.id === id));
    if (!valid.length && r.data[0]) { st.walletIds = [r.data[0].id]; saveWallets(); } else if (valid.length !== st.walletIds.length) { st.walletIds = valid; saveWallets(); }
    renderWalletBtn();
    /*
     * 拿到钱包后三路互不依赖，并行：
     *   识别（只要一个钱包 ID）｜ 持仓（「本系统买过的币」列表 → 买过才读余额，与平台识别无关）｜ 预授权状态。
     * 自己的钱包地址被当成 CA 的情况由 refreshManaged 拿到地址后撤掉（顶多多一次识别请求，不再为此串行等待）。
     */
    const staleWallet = detecting && !activeWallets().includes(detectingWallet); // 在途的识别用的是已删除的旧钱包
    if (st.ca && (!st.info || st.info.error || staleWallet)) detect(st.ca.address, { force: staleWallet });
    refreshWalletState();
  }
  function refreshWalletState() { refreshArms(); refreshHold(); }
  async function refreshArms() {
    const ids = activeWallets();
    await Promise.all(ids.map(async (id) => {
      const r = await api(`/api/quick/arm?walletId=${encodeURIComponent(id)}`);
      st.arms.set(id, r.ok ? r.data : null);
    }));
    renderSides();
    if (st.walletMenu) renderWalletMenu();
  }
  /*
   * 持仓刷新：只向自己的后端要（/api/quick/position：链上余额 + GMGN 估值都由后端去取）。
   * 触发：换 CA / 换钱包 / 打开窗口 / 成交后（跳过后端链上缓存）/ 切回这个标签页；
   * 窗口开着且标签页在前台时每 POS_REFRESH_MS 刷新一次（价值和盈亏会随价格变），后台标签页、窗口收起时不刷新。
   */
  const POS_REFRESH_MS = 20000;
  const MANAGED_REFRESH_MS = 2 * 60 * 1000;
  /** 本系统买过的币 + 自己的钱包地址（一次请求，本地判断用）；换钱包 / 成交后 / 超过 2 分钟时刷新 */
  async function refreshManaged() {
    const ids = activeWallets();
    if (!ids.length) return;
    const r = await withTimeout(api(`/api/quick/positions?walletIds=${ids.map(encodeURIComponent).join(',')}`), POS_TIMEOUT_MS, '控制台没返回持仓列表');
    if (!r.ok) return r.error || '读不到本系统持仓列表';
    st.managed = { tokens: new Set(r.data.tokens), addrs: new Set(r.data.walletAddresses || []), at: Date.now(), key: ids.join(',') };
    chrome.storage.local.set({ ownAddrs: [...st.managed.addrs] }).catch(() => {});
    // 钱包地址是后来才拿到的：之前识别成 CA 的如果是自己的钱包，撤掉
    if (st.ca && st.managed.addrs.has(st.ca.address.toLowerCase())) {
      flash(`忽略 ${short(st.ca.address)}：这是你自己的钱包地址`);
      st.ca = null; st.info = null; st.pos = null; detectSeq += 1; detecting = null;
      renderTitle(); renderSides(); bubble.hidden = true;
    }
    return null;
  }
  /*
   * 持仓刷新的并发规则（2026-10-29 修：后端慢于 5 秒时，定时器每 5 秒发一个新请求把上一个作废，永远「持仓读取中…」）：
   *   - 定时 / 切回标签页这类「顺便刷新」：有请求在途就跳过，不叠加；间隔从「发出请求」算起；
   *   - 换 CA / 换钱包 / 成交后这类「必须刷新」：照常发，用 posSeq 作废旧请求（旧结果可能是别的代币）；
   *   - 单次最多等 POS_TIMEOUT_MS，超时进入「读取失败」，按正常间隔再试。
   */
  const POS_TIMEOUT_MS = 20000;
  let posInflight = false;
  let posSeq = 0;
  async function refreshHold({ fresh = false, managedFirst = false } = {}) {
    const ids = activeWallets();
    const seq = ++posSeq;
    posInflight = false; // 旧请求已作废（下面提前返回的分支也不能让它一直占着「在途」）
    if (!ids.length || !st.ca) { st.pos = null; st.posState = 'idle'; renderSides(); return; }
    const want = `${st.ca.address.toLowerCase()}|${ids.join(',')}`;
    if (st.pos && st.pos.key !== want) st.pos = null; // 换了代币 / 钱包：旧数据不能留着误导
    // 持仓与平台识别无关，不等识别：本系统没买过这个币 → 本地直接显示，不发余额请求；买过才读
    st.posAt = Date.now(); // 间隔从发出请求算起：请求在途期间定时器不会再触发
    posInflight = true;
    try {
      await loadHold(seq, ids, want, fresh, managedFirst);
    } finally {
      if (seq === posSeq) posInflight = false;
    }
  }
  async function loadHold(seq, ids, want, fresh, managedFirst) {
    const key = ids.join(',');
    if (managedFirst || st.managed.key !== key || Date.now() - st.managed.at > MANAGED_REFRESH_MS) {
      const err = await refreshManaged();
      if (seq !== posSeq) return;
      // 列表一次都没拿到（或钱包换了）：不知道买没买过，不能显示「本系统没买过」
      if (err && st.managed.key !== key) {
        st.pos = null; st.posState = 'error'; st.posError = err; st.posAt = Date.now();
        renderSides();
        return;
      }
    }
    if (seq !== posSeq || !st.ca) return; // refreshManaged 可能刚把 CA 撤掉（是自己的钱包地址）
    if (!st.managed.tokens.has(st.ca.address.toLowerCase())) {
      st.pos = { managed: false, key: want, rows: [] };
      st.posState = 'idle';
      st.posAt = Date.now();
      renderSides();
      return;
    }
    st.posState = 'loading';
    renderPos();
    const r = await withTimeout(
      api(`/api/quick/position?address=${st.ca.address}&walletIds=${ids.map(encodeURIComponent).join(',')}${fresh ? '&fresh=1' : ''}`),
      POS_TIMEOUT_MS, `控制台 ${POS_TIMEOUT_MS / 1000} 秒没返回持仓`,
    );
    if (seq !== posSeq) return;
    st.posAt = Date.now();
    if (r.ok) { st.pos = { ...r.data, key: want }; st.posState = 'idle'; st.posError = null; } else { st.posState = 'error'; st.posError = r.error; if (st.pos?.key !== want) st.pos = null; }
    renderSides();
  }
  /** 顺便刷新（定时 / 切回标签页）：请求在途就不叠加 */
  const idleRefreshHold = (gapMs) => {
    if (posInflight || panel.hidden || document.hidden || !st.ca || st.busy) return;
    if (Date.now() - st.posAt >= gapMs) refreshHold();
  };
  setInterval(() => idleRefreshHold(POS_REFRESH_MS), 5000);
  document.addEventListener('visibilitychange', () => idleRefreshHold(5000));

  /* ---------- CA 识别 ---------- */
  function setCa(address, source) {
    const lc = address.toLowerCase();
    const why = notToken(address);
    if (why) { if (!panel.hidden) flash(`忽略 ${short(address)}：${why}`); return; } // 本地就能判断，不发请求
    if (st.ca?.address.toLowerCase() === lc) { if (st.ca.source !== source && source === '剪贴板') st.ca.source = source; renderTitle(); return; }
    st.ca = { address, source };
    st.info = null;
    renderTitle();
    renderSides();
    st.pos = null;
    // 窗口收起时不识别、不读持仓：打开窗口时由 openPanel → refreshWallets 补。
    // 窗口开着：识别和持仓并行（钱包列表还没回来时识别先用上次保存的钱包 ID，列表回来发现它已删除会重新识别）
    if (!panel.hidden) { detect(address); refreshHold(); }
    if (st.settings.autoOpen && panel.hidden && !st.dismissed.has(lc)) openPanel(true);
    else bubble.hidden = !panel.hidden; // 窗口收起时留一个小按钮
  }
  function renderTitle() {
    titleSym.textContent = !st.ca ? '未识别 CA' : !st.info ? '识别中…' : st.info.error ? '识别失败' : (st.info.symbol || '未知代币');
    titleCa.textContent = st.ca ? short(st.ca.address) : '';
    titleCa.title = st.ca ? `${st.ca.address}（点击复制）` : '';
    titleSrc.textContent = st.ca ? `来自${st.ca.source}` : '';
    const c = st.info?.candidates?.find((x) => x.id === st.info.recommended);
    const errs = st.info?.errors?.length ? `部分平台查询出错（${st.info.errors.slice(0, 2).join('；')}）` : '';
    infoLine.textContent = !st.ca ? '打开带 CA 的页面，或复制一个 CA'
      : !st.info ? (!st.wallets.length && st.walletError ? `没法识别：${st.walletError}` : '识别平台中…')
        : st.info.error ? `识别失败：${st.info.error}${st.info.stale ? '' : ' · 点击重试'}`
          : c ? [`⭐ ${c.label}`, c.phase, c.payUnit && c.payUnit !== 'BNB' ? `付 ${c.payUnit}` : '', ...(c.notes || []).slice(0, 1)].filter(Boolean).join(' · ')
            : errs ? `${errs} · 点击重试`
              : `没有可交易的平台（不是 Four / gang / Flap 内盘，Pancake 上也没有池子）${st.info.cached ? ' · 缓存结果，点击重新识别' : ''}`;
    infoLine.title = infoLine.textContent;
    infoLine.className = `info${(st.info && !c) || (!st.info && st.walletError) ? ' err' : ''}`;
  }
  /*
   * 识别结果本地缓存（chrome.storage.local 的 detectCache2，所有标签页共用；键 = CA|钱包，Agent 门槛按钱包不同）：
   *   - 可交易：5 分钟内直接用，不问后端；5 分钟 ~ 24 小时先显示缓存、后台再问一次（内盘可能毕业换平台），
   *     后台这次失败就继续显示缓存，不变成「识别失败」；超过 24 小时当没缓存。
   *     下单不依赖这份缓存：后端报价时会按链上实时状态重新识别，缓存旧了顶多显示的阶段晚几分钟。
   *   - 不可交易（没有平台 / 不是合约）：30 分钟内不再问，点信息行可以强制重新识别；
   *   - 出错 / 部分平台查询出错的不缓存；最多 DETECT_MAX 条，超出按最近使用淘汰。
   * 服务端另有「平台归属」缓存（quick/detectcache.mjs）：问到后端时只查归属平台 + 外盘。
   */
  const DETECT_FRESH_MS = 5 * 60 * 1000;
  const DETECT_STALE_MS = 24 * 3600 * 1000;
  const DETECT_NEG_MS = 30 * 60 * 1000;
  const DETECT_MAX = 500;
  const DETECT_KEY = 'detectCache2';
  const tradableOf = (info) => Boolean(info && !info.error && info.candidates?.some((c) => c.id === info.recommended && c.tradable !== false));
  chrome.storage.local.remove('detectCache').catch(() => {}); // 旧版（按 CA 不分钱包）的缓存不再用
  /** → null | { info, fresh }：fresh=false 表示先用着、需要后台再问一次 */
  async function cachedDetect(key) {
    const { [DETECT_KEY]: cache = {} } = await chrome.storage.local.get(DETECT_KEY).catch(() => ({}));
    const hit = cache[key];
    if (!hit) return null;
    const age = Date.now() - hit.at;
    if (!hit.tradable) return age < DETECT_NEG_MS ? { info: hit.info, fresh: true } : null;
    return age < DETECT_FRESH_MS ? { info: hit.info, fresh: true } : age < DETECT_STALE_MS ? { info: hit.info, fresh: false } : null;
  }
  async function saveDetect(key, info) {
    // 网络 / 后端出错不缓存；后端返回了但有平台查询出错（RPC 抖动）也不缓存，否则会被当成「不可交易」记 30 分钟
    if (info?.error || info?.errors?.length) return;
    const { [DETECT_KEY]: cache = {} } = await chrome.storage.local.get(DETECT_KEY).catch(() => ({}));
    delete cache[key]; // 重新插入：对象键顺序 = 写入顺序，淘汰时从最早的删
    cache[key] = { at: Date.now(), tradable: tradableOf(info), info };
    const keys = Object.keys(cache);
    for (const k of keys.slice(0, Math.max(0, keys.length - DETECT_MAX))) delete cache[k];
    await chrome.storage.local.set({ [DETECT_KEY]: cache }).catch(() => {});
  }
  let detectSeq = 0;
  let detecting = null; // 正在识别的 CA（小写）：同一个 CA 不重复发请求
  let detectingWallet = null; // 这次识别用的钱包 ID
  const DETECT_TIMEOUT_MS = 25000; // 比后台的 60 秒短：识别慢到这个程度直接提示，可点重试
  const withTimeout = (p, ms, error) => Promise.race([p, new Promise((r) => setTimeout(() => r({ ok: false, error }), ms))]);
  /** 无论成功 / 失败 / 超时 / 异常，结束时 st.info 一定有值（不会一直停在「识别中…」） */
  async function detect(address, { force = false } = {}) {
    const lc = address.toLowerCase();
    if (!force && detecting === lc) return;
    const seq = ++detectSeq;
    detecting = lc;
    const done = (info) => {
      if (seq !== detectSeq) return;
      detecting = null;
      st.info = info;
      renderTitle();
      afterDetect();
    };
    try {
      // 钱包列表回来之前先用上次保存的钱包 ID（识别只用它判断 Agent 准入等，不下单）；列表回来后发现它已删除会重新识别
      const walletId = activeWallets()[0] || (st.wallets.length ? null : st.walletIds[0]);
      if (!walletId) {
        if (!st.wallets.length && !st.walletError) { if (seq === detectSeq) detecting = null; return; } // 第一次用、列表还没回来：refreshWallets 回来后会识别
        done({ error: st.wallets.length ? '先在标题栏勾选下单钱包' : (st.walletError || '还没读到钱包列表') });
        return;
      }
      detectingWallet = walletId;
      const key = `${lc}|${walletId}`;
      const hit = force ? null : await cachedDetect(key);
      if (seq !== detectSeq) return;
      if (hit?.fresh) { done({ ...hit.info, cached: true }); return; }
      if (hit) { // 旧缓存：先显示，后台再问（detecting 保持，期间不重复发）
        st.info = { ...hit.info, cached: true };
        renderTitle();
        afterDetect();
      }
      const r = await withTimeout(api('/api/quick/warm', 'POST', { address, platform: 'auto', walletId }), DETECT_TIMEOUT_MS, `控制台 ${DETECT_TIMEOUT_MS / 1000} 秒没返回识别结果`);
      if (seq !== detectSeq) return;
      const info = r.ok ? (r.data?.detect || { symbol: null, candidates: [] }) : { error: r.error, stale: r.stale };
      saveDetect(key, info);
      // 后台复查失败：继续显示旧缓存（插件已重新加载这种必须提示的除外）
      if (hit && info.error && !info.stale) { if (seq === detectSeq) detecting = null; return; }
      done(info);
    } catch (err) {
      done({ error: isStale(err) ? STALE_MSG : String(err?.message || err), stale: isStale(err) });
    }
  }
  /** 识别完成后只重画买卖区（按钮是否可用取决于有没有可交易平台）；持仓不依赖识别，各读各的 */
  function afterDetect() { renderSides(); }
  infoLine.addEventListener('click', () => {
    if (!st.ca) return;
    if (!st.wallets.length) { refreshWallets(); return; } // 连不上控制台：先重拿钱包，拿到后会自动识别
    if (st.info && !tradableOf(st.info) && !st.info.stale) { st.info = null; renderTitle(); detect(st.ca.address, { force: true }); }
  });

  /*
   * 地址栏：本地先按网址结构判断这个 0x 地址是不是代币，明显不是的（钱包 / 交易 / 区块页、?address=、自己的钱包、销毁地址）
   * 直接忽略，不向后端发任何请求。路径里的 CA 优先，其次 query / hash；单页应用换页时跟着变。
   */
  const NON_TOKEN_SEG = /^(address(es)?|accounts?|wallets?|txs?|transactions?|blocks?|profile|users?|traders?|makers?|holders?|portfolio|dev|creators?|owners?|validators?|swaps?)$/i;
  const NON_TOKEN_KEY = /^(address|wallet|account|maker|trader|user|owner|creator|dev|ref|referrer|inviter|from|to)$/i;
  const BURN = new Set(['0x0000000000000000000000000000000000000000', '0x000000000000000000000000000000000000dead']);
  /** 本地能判断「不是代币」的地址：返回原因；可能是代币返回 null */
  function notToken(address) {
    const lc = address.toLowerCase();
    if (BURN.has(lc)) return '销毁 / 零地址';
    if (st.managed.addrs.has(lc)) return '这是你自己的钱包地址';
    return null;
  }
  function urlCa() {
    let u;
    try { u = new URL(location.href); } catch { return null; }
    // 路径段：网址路径 + hash 路由（#/token/0x…）
    const segs = `${u.pathname}/${u.hash.replace(/^#/, '').split('?')[0]}`.split('/').map((s) => { try { return decodeURIComponent(s); } catch { return s; } });
    for (let i = 0; i < segs.length; i += 1) {
      const m = segs[i].match(/^(0x[a-fA-F0-9]{40})$/) || segs[i].match(/(?:^|[^a-fA-F0-9x])(0x[a-fA-F0-9]{40})(?![a-fA-F0-9])/);
      if (!m) continue;
      if (NON_TOKEN_SEG.test(segs[i - 1] || '')) continue; // /address/0x…、/tx/0x… 之类：钱包 / 交易页
      return m[1];
    }
    for (const [k, v] of [...u.searchParams, ...new URLSearchParams(u.hash.replace(/^#\/?/, '').split('?').pop())]) {
      const m = String(v).match(/^(0x[a-fA-F0-9]{40})$/);
      if (m && !NON_TOKEN_KEY.test(k)) return m[1];
    }
    return null;
  }
  let lastUrl = '';
  function scanUrl() {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    const ca = urlCa();
    if (ca) setCa(ca, '地址栏');
  }
  setInterval(scanUrl, 800);
  window.addEventListener('popstate', scanUrl);
  window.addEventListener('hashchange', scanUrl);

  /** 剪贴板：只在复制动作之后读一次（复制事件、Ctrl/⌘+C、点了「复制」按钮），不常驻轮询 */
  function fromText(text) {
    const s = String(text || '');
    const one = s.match(ONE_CA);
    if (one) return one[1];
    if (s.length > 300) return null;
    const all = [...new Set((s.match(CA_RE) || []).map((x) => x.toLowerCase()))];
    return all.length === 1 ? s.match(CA_RE)[0] : null;
  }
  async function checkClipboard() {
    if (!st.settings.watchClipboard) return;
    const r = await chrome.runtime.sendMessage({ type: 'readClipboard' }).catch(() => null);
    if (!r?.ok || r.text === st.lastClip) return;
    st.lastClip = r.text;
    const ca = fromText(r.text);
    if (ca) setCa(ca, '剪贴板');
  }
  let clipTimer = null;
  const soon = () => { clearTimeout(clipTimer); clipTimer = setTimeout(checkClipboard, 200); };
  document.addEventListener('copy', () => {
    const sel = fromText(String(window.getSelection?.() || ''));
    if (sel) { setCa(sel, '剪贴板'); return; }
    soon();
  }, true);
  document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'C')) soon(); }, true);
  document.addEventListener('click', (e) => {
    if (host.contains(e.target)) return;
    const t = e.target.closest?.('button, [role="button"], a, svg, span, div, i');
    if (!t) return;
    const hint = `${t.getAttribute?.('aria-label') || ''} ${t.getAttribute?.('title') || ''} ${t.className?.baseVal ?? t.className ?? ''} ${t.dataset ? Object.keys(t.dataset).join(' ') : ''}`;
    if (/copy|复制|clipboard/i.test(hint)) soon();
  }, true);

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'togglePanel') openPanel(panel.hidden);
  });

  /* ---------- 跨标签页同步：任何一个页面改了预设 / 钱包 / 设置，其它页面立刻跟着变 ---------- */
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.quickPresets && !st.editing) { st.presets = normPresets(changes.quickPresets.newValue); renderSides(); }
    if (changes.quickWallets) { st.walletIds = Array.isArray(changes.quickWallets.newValue) ? changes.quickWallets.newValue : []; renderWalletBtn(); refreshWalletState(); }
    if (changes.quickPanel?.newValue) {
      // 窗口位置 / 大小同步；开关状态每个页面自己管（在这个页面收起不影响别的页面）
      const { open, ...geo } = changes.quickPanel.newValue;
      void open;
      Object.assign(st.panel, geo);
      if (!panel.hidden) applyGeometry();
    }
    for (const k of ['autoOpen', 'watchClipboard', 'sellNoConfirm']) {
      if (changes[k]) { st.settings[k] = changes[k].newValue !== false; if (k === 'sellNoConfirm') renderSides(); }
    }
  });

  /* ---------- 启动 ---------- */
  (async () => {
    const s = await chrome.storage.local.get(['quickPresets', 'quickPanel', 'quickWallets', 'quickPrefs', 'autoOpen', 'watchClipboard', 'sellNoConfirm', 'ownAddrs']).catch(() => ({}));
    if (Array.isArray(s.ownAddrs)) st.managed.addrs = new Set(s.ownAddrs.map((a) => String(a).toLowerCase()));
    st.settings.autoOpen = s.autoOpen !== false;
    st.settings.watchClipboard = s.watchClipboard !== false;
    st.settings.sellNoConfirm = s.sellNoConfirm !== false;
    // 旧版本把预设 / 窗口 / 钱包都存在 quickPrefs 一个键里：迁移一次
    const old = s.quickPrefs;
    st.presets = normPresets(s.quickPresets || old);
    st.panel = { ...DEFAULT_PANEL, ...(s.quickPanel || old?.panel || {}) };
    st.walletIds = Array.isArray(s.quickWallets) ? s.quickWallets : (old?.walletId ? [old.walletId] : []);
    if (old && !s.quickPresets) {
      await chrome.storage.local.set({ quickPresets: st.presets, quickPanel: st.panel, quickWallets: st.walletIds }).catch(() => {});
      await chrome.storage.local.remove('quickPrefs').catch(() => {});
    }
    panel.hidden = true;
    bubble.hidden = true;
    renderTitle();
    renderWalletBtn();
    renderSides();
    (document.body || document.documentElement).append(host);
    if (st.panel.open) openPanel(true, { persist: false });
    scanUrl();
  })();

  function CSS() {
    return `
:host { all: initial; }
* { box-sizing: border-box; }
.panel {
  position: fixed; display: flex; flex-direction: column; gap: 8px; padding: 0 10px 10px;
  background: #15171c; color: #eaecef; border: 1px solid #2b2f38; border-radius: 12px;
  box-shadow: 0 12px 40px rgba(0,0,0,.55); font: 12.5px/1.45 system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  resize: both; overflow: hidden; min-width: ${MIN_W}px; min-height: ${MIN_H}px; container-type: inline-size;
}
.panel[hidden], .bubble[hidden], .overlay[hidden], .wallet-menu[hidden] { display: none !important; }
.head { display: flex; align-items: center; gap: 6px; height: 38px; margin: 0 -10px; padding: 0 8px; border-bottom: 1px solid #23262e; cursor: move; user-select: none; touch-action: none; }
.grip { color: #5e6673; }
.title { display: flex; align-items: baseline; gap: 6px; min-width: 0; flex: 1; overflow: hidden; white-space: nowrap; }
.sym { font-size: 14px; overflow: hidden; text-overflow: ellipsis; max-width: 48%; flex-shrink: 0; }
@container (max-width: 380px) { .src { display: none; } .wallet { max-width: 30%; } }
.ca { font: 11.5px ui-monospace, Consolas, monospace; color: #b7bdc6; cursor: pointer; }
.ca:hover { color: #f0b90b; }
.src { font-size: 11px; color: #848e9c; }
.wallet { max-width: 38%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; background: #1e2128; color: #eaecef; border: 1px solid #2b2f38; border-radius: 6px; padding: 3px 6px; font-size: 12px; cursor: pointer; }
.wallet-menu { position: absolute; top: 40px; right: 8px; z-index: 5; min-width: 200px; background: #1b1e25; border: 1px solid #2b2f38; border-radius: 10px; padding: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.5); display: flex; flex-direction: column; gap: 4px; }
.wm-tip { color: #848e9c; font-size: 11.5px; margin-bottom: 2px; }
.wm-row { display: flex; align-items: center; gap: 6px; padding: 3px 2px; cursor: pointer; }
.wm-row .badge { margin-left: auto; }
.icon { background: none; border: 0; color: #b7bdc6; font-size: 15px; width: 26px; height: 26px; border-radius: 6px; cursor: pointer; }
.icon:hover { background: #23262e; color: #fff; }
.info { color: #b7bdc6; font-size: 12px; min-height: 18px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.info.err { color: #f6465d; }
.pos { display: flex; align-items: center; gap: 4px; width: 100%; text-align: left; background: #191c22; border: 1px solid #2b2f38; border-radius: 8px; padding: 5px 8px; color: #b7bdc6; font: inherit; font-size: 12.5px; cursor: pointer; white-space: nowrap; overflow: hidden; }
.pos[hidden], .pos-detail[hidden] { display: none !important; }
.pos.has { border-color: #f0b90b66; color: #eaecef; }
.pos.has b { color: #f0b90b; font-size: 13.5px; }
.pos.none { color: #848e9c; }
.pos.err { color: #f6465d; }
.pos-k { color: #848e9c; margin-right: 4px; }
.pos .up, .pos-row .up { color: #2ebd85; }
.pos .down, .pos-row .down { color: #f6465d; }
.dim { color: #5e6673; }
.pos-detail { display: flex; flex-direction: column; gap: 2px; margin-top: -4px; padding: 4px 8px; background: #111318; border: 1px solid #23262e; border-radius: 8px; font-size: 11.5px; }
.pos-row { display: grid; grid-template-columns: minmax(60px, 1fr) 1.4fr 1.2fr auto; gap: 6px; white-space: nowrap; }
.pos-w { overflow: hidden; text-overflow: ellipsis; color: #b7bdc6; }
.side { display: flex; flex-direction: column; gap: 6px; flex: 1; min-height: 0; }
.side.sell { border-top: 1px solid #23262e; padding-top: 8px; }
.side-head { display: flex; align-items: center; gap: 6px; }
.side-title { font-weight: 700; font-size: 13.5px; margin-right: 2px; }
.buy .side-title { color: #2ebd85; }
.sell .side-title { color: #f6465d; }
.tab { background: none; border: 0; color: #848e9c; font-weight: 600; cursor: pointer; padding: 1px 4px; border-radius: 4px; }
.tab.on { color: #eaecef; background: #23262e; }
.grow { flex: 1; }
.badge { font-size: 11px; padding: 1px 7px; border-radius: 999px; cursor: help; white-space: nowrap; }
.badge.ok { background: #2ebd8522; color: #2ebd85; border: 1px solid #2ebd8555; }
.badge.warn { background: #f0b90b1a; color: #f0b90b; border: 1px solid #f0b90b55; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: 1fr; gap: 6px; flex: 1; min-height: 34px; }
.panel:not(.tall) .amt.row2 { display: none; }
.amt {
  border-radius: 8px; background: #191c22; font-weight: 700; cursor: pointer; min-height: 30px;
  font-size: clamp(12px, 4.2cqi, 22px); transition: background .12s, transform .05s;
}
.buy .amt { border: 1px solid #2ebd85aa; color: #2ebd85; }
.sell .amt { border: 1px solid #f6465daa; color: #f6465d; }
.buy .amt:hover:not(:disabled) { background: #2ebd8522; }
.sell .amt:hover:not(:disabled) { background: #f6465d22; }
.amt:active:not(:disabled) { transform: scale(.97); }
.amt:disabled { opacity: .4; cursor: not-allowed; }
.amt:focus-visible, .tab:focus-visible, .icon:focus-visible, button:focus-visible { outline: 2px solid #f0b90b; outline-offset: 1px; }
.amt-edit, .slip-edit { width: 100%; background: #0f1115; color: #eaecef; border: 1px dashed #5e6673; border-radius: 8px; text-align: center; font: 600 13px ui-monospace, Consolas, monospace; }
.slip-edit { width: 56px; padding: 2px; }
.foot { color: #848e9c; font-size: 11.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.status { font-size: 12px; color: #b7bdc6; max-height: 38%; overflow: auto; }
.status:empty { display: none; }
.status.ok .job-head { color: #2ebd85; }
.status.err, .status.err .job-head { color: #f6465d; }
.job-head { font-weight: 600; }
.step.ok { color: #2ebd85; }
.step.err { color: #f6465d; }
.step a { color: #f0b90b; text-decoration: none; }
.overlay { position: absolute; inset: 0; background: rgba(10,11,14,.88); display: flex; align-items: stretch; padding: 10px; z-index: 6; }
.confirm { display: flex; flex-direction: column; gap: 8px; width: 100%; background: #1b1e25; border: 1px solid #2b2f38; border-radius: 10px; padding: 10px; }
.c-title { font-size: 14px; font-weight: 700; }
.c-rows { flex: 1; overflow: auto; display: flex; flex-direction: column; gap: 4px; }
.c-row { display: grid; grid-template-columns: 110px 1fr; gap: 8px; }
.c-row.sep { margin-top: 6px; padding-top: 6px; border-top: 1px solid #2b2f38; font-weight: 600; }
.c-row .k { color: #848e9c; }
.c-row .v { word-break: break-all; }
.c-note { margin: 0; color: #f0b90b; font-size: 11.5px; }
.c-act { display: flex; gap: 8px; justify-content: flex-end; }
.cancel-btn, .ok-btn { border-radius: 8px; padding: 7px 14px; font-weight: 600; cursor: pointer; }
.cancel-btn { background: #23262e; color: #eaecef; border: 1px solid #2b2f38; }
.ok-btn { background: #f0b90b; color: #111; border: 1px solid #f0b90b; }
.bubble { position: fixed; right: 18px; bottom: 18px; display: flex; align-items: center; gap: 6px; padding: 5px 12px 5px 5px; border-radius: 999px; border: 1px solid #f0b90b; background: #15171c; color: #f0b90b; font: 600 13px system-ui, sans-serif; cursor: pointer; box-shadow: 0 6px 20px rgba(0,0,0,.4); }
.logo { width: 22px; height: 22px; border-radius: 6px; flex-shrink: 0; pointer-events: none; }
.head .logo { margin-left: 2px; }
`;
  }
})();
