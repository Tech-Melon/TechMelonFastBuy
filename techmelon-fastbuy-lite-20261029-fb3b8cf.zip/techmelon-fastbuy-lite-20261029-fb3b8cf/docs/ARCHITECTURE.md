# 架构

技术瓜内盘快买 = 一个本地（或自建服务器上的）Node 服务 + 原生前端 + Chrome 插件，操作币安 Agentic Wallet。
**签名和广播都在币安钱包服务完成**；本项目只负责：识别平台、生成交易、链上预检、上限复核，
再经币安「模拟（preview）→ 执行（execute）」两步提交。不保存、不接触私钥。

## 总览

```
 浏览器页面（webui/public）        Chrome 插件（extension/）
        │  API 令牌 / 登录                 │  配对密钥（只能调快捷交易相关接口）
        └──────────────┬──────────────────┘
                       ▼
             webui/server.mjs（唯一的 HTTP 服务，默认只听 127.0.0.1）
   访问闸门 → 路由 → 识别 / 计划 → 上限复核 → preview / execute 受控路径 → 执行日志
                       │                                   │
        ┌──────────────┴──────────┐               ┌────────┴─────────┐
        ▼                         ▼               ▼                  ▼
   BSC RPC / WSS             GMGN OpenAPI     币安钱包服务        profiles/<钱包>/
（读链、模拟、回执、事件）   （持仓估值，只读）  （preview / execute，  （每个钱包一份登录会话）
                                                签名并广播）
```

## 目录与模块

```
webui/
  server.mjs          HTTP 服务：访问闸门、API 路由、静态页面、preview / execute 受控路径、预授权恢复
  config.mjs          读写 config.json；RPC 三层分流与限速；Multicall 合并只读调用
  bawdirect.mjs       进程内直连币安 preview / execute（常驻长连接）；config.bawDirect=false 时改为每次调用 CLI
  wallets.mjs         钱包注册表（每个钱包一个会话目录，CLI 用 BINANCE_BAW_DIR 指向它）
  limits.mjs          单笔 / 每日买入上限（所有功能共用；每次广播前复核每日上限）
  journal.mjs         只追加的执行日志：每笔 preview / execute、一键任务状态；重启后用于对账和「未完成任务」
  arms.mjs            预授权落盘与重启恢复
  auth.mjs            公网部署时的登录 + IP 白名单；本机运行时直接放行
  wsshub.mjs          全项目共享一条 BSC WSS（订阅登记、断线重连、重连后补查）
  gmgn.mjs            GMGN 持仓（只读，签名请求，带限速与在途合并）；tokens.mjs / logos.mjs 代币目录与图标
  edition.mjs         页面按版本（Pro / 轻量）裁剪
  quick/              快捷交易（交易台和插件共用）
    registry.mjs        平台注册表：识别（detectAll）与计划（planQuick）入口
    platforms/          four、gang（LaunchpadV2）、gangv3、flap、flaptax、dex（Pancake 外盘）
    detectcache.mjs     CA 平台归属缓存（落盘 detect-cache.json）
    router.mjs          Pancake SmartRouter 智能路由：池子发现（带缓存与在途合并）、选路、模拟、冲击检查、calldata 复核
    warm.mjs            粘贴 CA 后预热池子；服务启动后预热中转币与报价币
    oneclick.mjs        一键执行：确认一次计划后逐步执行，每一步复核上限
    armed.mjs           直接买入预授权
    inventory.mjs       报价币库存与授权；transfer.mjs 一键转移；autoxfer.mjs 发射后自动转移
    positions.mjs       本系统买入过的持仓（插件持仓条用）；routebook.mjs 路由记录与固定路由
    gangv3.mjs          gang V3 部署核验（内置官方部署，每 10 分钟复核）与交易计划
    gangsnipe.mjs 等    （仅 Pro）gang 内盘狙击、狙击看板、打新、自动打新、新部署发现
  features/snipe.mjs  （仅 Pro）狙击 / 打新功能包：server 找不到它就按轻量版运行
  four/               OpenFour 协议、手动买卖；sniper.mjs（仅 Pro）
  agent/              AI 执行：提示词 → 协议与参数 → 适配器生成计划（LLM 不生成 calldata）；guard.mjs 输入防护
  public/             原生 HTML / CSS / JS（无构建步骤）
  eval/               回归评测与离线单测
extension/            Chrome MV3 插件：content.js（网页里的交易窗口，Shadow DOM）、background.js（转发请求，带配对密钥）
scripts/setup.mjs     安装向导（依赖、币安 CLI、禁用 keytar、环境检查）
deploy/baw-cli/       币安 CLI 的锁定版本
profiles/             每个钱包一个会话目录
```

## 一笔买入是怎么走完的

```
1. 识别   CA → detectAll：并行问各内盘平台 + 外盘 → 推荐平台（可交易的内盘优先，毕业了走外盘）
2. 计划   平台.plan：链上只读预检（余额、阶段、Agent ID、税率、池子）→ steps[]（换报价币 / 授权 / 买入…）
          外盘：发现池子 → 选路（最多 3 跳）→ 以钱包身份模拟前几条路径 → 冲击 > 10% / 损耗 > 20% 拒绝
3. 上限   单笔上限检查 → 第一步交给币安 preview（模拟），记下 requestId
4. 确认   用户在确认框里核对全部步骤与上限；或在已确认的预授权范围内（直接买入 / 狙击…）
5. 执行   oneclick 逐步：preview → 复核（步骤类型、交互合约、BNB 合计、授权对象和额度、最少收到）
          → 广播前每日上限 → execute → 等回执 → 需要时重新报价下一步
6. 记录   执行日志、路由记录、持仓记录；插件 / 页面刷新持仓
```

手动、一键、直接买入、狙击、自动转移、插件全部走同一条 preview / execute 受控路径，没有绕过复核的下单入口。
`execute` 只接受本服务 10 分钟内为同一钱包生成、没用过的 preview。

## 缓存（减少重复请求）

| 层 | 位置 | 内容 | 有效期 |
|---|---|---|---|
| 识别结果 | 服务端内存 | 完整识别结果（按 CA + 钱包） | 20 秒；有平台出错不缓存 |
| 平台归属 | `webui/detect-cache.json` | 这个 CA 属于哪个内盘、报价币、symbol | 内盘 7 天 / 非内盘 10 分钟；最多 3000 条 |
| 池子地址 | 服务端内存 | Pancake 池子地址 / 储备 | 中转币之间 30 分钟、含目标币 5 分钟；储备 15 秒 |
| 插件识别 | 浏览器 `chrome.storage.local` | 识别结果（按 CA + 钱包） | 可交易 5 分钟直接用、24 小时内先显示再复查；不可交易 30 分钟；最多 500 条 |

会变的状态（曲线中 / 已毕业、能不能交易、池子储备）每次下单前都重新读链，缓存只用来少问、快显示。

## RPC 分三层

| 层 | 用途 | 配置 |
|---|---|---|
| 主节点 | 交易、报价、模拟、等回执（要快、要准） | 设置页 BSC RPC（`config.rpcs['56']`），可加备用节点池 |
| 后台节点 | 预热、核验、持仓、补查等非即时请求 | `config.bgRpcs['56']`；不填用备用池里的 NodeReal |
| 免费公共节点 | 后台节点满了或失败时 | 内置列表（`PUBLIC_RPC_56` 可改） |

非即时请求都经 `runBackground()` 走后两层，只在都失败时才回落主节点；多个只读调用用 Multicall3 合并成一次。
没有自动化在跑、10 分钟内没人用时，保活和预热降频或暂停。

## 浏览器插件

```
网页（content.js，Shadow DOM 窗口）──消息──▶ background.js ──HTTPS + x-ext-key──▶ server.mjs（EXT_ROUTES 白名单）
```

- 识别 CA：地址栏（单页应用换页跟着变）或刚复制的内容；钱包页 / 交易页的地址、自己的钱包、零地址在本地直接忽略，不发请求。
- 取数并行：识别、钱包列表、预授权状态、持仓互不等待；持仓刷新有请求在途就不叠加。
- 插件只能调用识别、报价、买入、卖出、钱包、上限、持仓这几类接口；配对、预授权、改上限、转账、库存授权、狙击都不在白名单里。

## 两个版本

狙击 / 打新整块放在可选的功能包（`features/snipe.mjs` 及相关文件）里：轻量版不含这些文件，服务端找不到功能包就按轻量版运行，
页面按 `<!-- edition:full|lite -->` 区块裁剪。其余代码两个版本完全相同。

## 数据存在哪

| 文件 | 内容 | 能否外发 |
|---|---|---|
| `webui/config.json` | 节点地址与令牌、AI / GMGN Key、上限、白名单、插件配对密钥 | **不能** |
| `profiles/*/` | 各钱包的登录会话 | **不能** |
| `webui/wallets.json` | 钱包列表与地址 | 不要 |
| `webui/journal*.jsonl` | 执行日志（每笔交易） | 不要 |
| `webui/arms.json` | 落盘的预授权 | 不要 |
| `webui/positions.json`、`routes.json`、`detect-cache.json` | 本系统买过的币、路由记录、识别缓存 | 不要（可删，会重建） |
| `webui/.api-token` | 本次运行的 API 令牌（每次启动更换） | 不能 |

## 关键设计

- **LLM 不生成 calldata**：只选协议与参数；calldata 由 viem + 代码内 ABI 生成，广播前再解码复核。
- **预检失败即停**：余额、授权、阶段、Agent ID、是否毕业任一不满足就报原因，不生成交易。
- **自动执行必须预授权**：确认一次策略（钱包、上限、滑点、有效期…），改参数 / 到期 / 改上限立即失效，见 `docs/AUTOMATION_RULES.md`。
- **execute 不重试**：请求已发出就按「可能已广播」计入每日上限，避免重复下单。
- **金额精度**：链上金额全用 BigInt / 字符串，只有展示层用 Number。
- **会话隔离**：每个钱包一个目录；服务端只读会话、不写入、不打印凭据。
- **本地 API 闸门**：Host 白名单 → 令牌 / 登录 / 插件配对密钥 → Origin / Sec-Fetch-Site → 只收 JSON，全部在路由之前执行。
