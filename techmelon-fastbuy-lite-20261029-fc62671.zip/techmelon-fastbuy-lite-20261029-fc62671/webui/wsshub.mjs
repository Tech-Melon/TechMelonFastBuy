/**
 * BSC WSS 共享连接（全项目只开一条，按需连接）：Four 狙击、gang V3 / 打新发现、自动打新、gang 内盘狙击、
 * 发射后自动转移都在这条连接上订阅；第一个订阅时连上，最后一个订阅取消时断开。
 * - 订阅登记在 hub 里：节点 URL 变更（设置页保存）时整体迁移到新连接；断线重连由 WsRpc 自动恢复订阅。
 * - onHubReconnect：每次（重新）连上时回调，各模块用 HTTP 补查断线期间漏掉的日志。
 * - 设置页「测试 WSS」仍是一次性的临时连接，不影响这里。
 */
import { WsRpc } from './four/wss.mjs';
import { getConfig, chainWssUrl } from './config.mjs';

const hub = {
  ws: null, url: '', status: { state: 'idle', detail: '' }, lastBlock: 0,
  subs: new Set(), // { params, handler, unsub }
  reconnect: new Set(),
};

function attach(s) {
  s.unsub = hub.ws ? hub.ws.subscribe(s.params, s.handler) : null;
}

/** 按当前配置建立 / 迁移连接；没配置 WSS 时返回 null */
export async function ensureHub() {
  const url = chainWssUrl(56, await getConfig());
  if (!url) {
    if (hub.ws) { hub.ws.stop(); hub.ws = null; }
    hub.url = '';
    hub.status = { state: 'off', detail: '未配置 BSC WSS 节点（设置页填写）' };
    return null;
  }
  if (hub.ws && hub.url === url && !hub.ws.closed) return hub.ws;
  if (hub.ws) hub.ws.stop();
  hub.url = url;
  // 只让当前连接更新状态 / 触发补查：已 stop 的旧连接异步发来的 closed 不能覆盖新状态
  const ws = new WsRpc(url, {
    onStatus: (st) => { if (hub.ws === ws) hub.status = { state: st.state, detail: st.detail }; },
    onReconnect: () => { if (hub.ws === ws) for (const fn of hub.reconnect) Promise.resolve().then(fn).catch(() => {}); },
  });
  hub.ws = ws;
  for (const s of hub.subs) attach(s); // 迁移已有订阅（连上后 WsRpc 统一发 eth_subscribe）
  hub.ws.start();
  return hub.ws;
}

/**
 * 没有任何订阅时关掉连接（按需连接）：QuickNode 按连接时长 / 推送计费，空连着没意义。
 * 下一次 hubSubscribe 会自动重新连上；hubRequest 没连接时抛错，调用方退回 HTTP。
 */
function closeIfIdle() {
  if (hub.subs.size || !hub.ws) return;
  hub.ws.stop();
  hub.ws = null;
  hub.status = { state: 'idle', detail: '没有功能在订阅，连接已关闭（有订阅时自动连上）' };
}

/** 设置页修改了 WSS 节点后调用：有订阅才（迁移到新节点）连接，没有订阅不连 */
export async function reloadHub() {
  if (!hub.subs.size) { closeIfIdle(); return null; }
  return ensureHub();
}

/** 订阅（params 例如 ['logs', { address, topics }] / ['newHeads']）。返回取消函数 */
export async function hubSubscribe(params, handler, label = '') {
  await ensureHub();
  const s = { params, handler, unsub: null, label, since: new Date().toISOString() };
  hub.subs.add(s);
  attach(s);
  return () => {
    s.unsub?.();
    hub.subs.delete(s);
    closeIfIdle();
  };
}

/** 每次（重新）连上时回调（用于 HTTP 补查）。返回取消函数 */
export function onHubReconnect(fn) {
  hub.reconnect.add(fn);
  return () => hub.reconnect.delete(fn);
}

export const hubConnected = () => Boolean(hub.ws?.connected);

/**
 * 在共享 WSS 连接上发一次 JSON-RPC 请求（比如 eth_call）。推送新币日志的就是这个节点，
 * 读到的状态和日志同步（HTTP 节点可能还落后 1~3 个块）。没连上时抛错，由调用方退回 HTTP。
 */
export async function hubRequest(method, params = []) {
  if (!hub.ws?.connected) throw new Error('WSS 未连接');
  return hub.ws.request(method, params);
}

export function hubStatus() {
  return {
    ...hub.status,
    connected: hubConnected(),
    rttMs: hub.ws?.lastRttMs ?? null,
    subscriptions: hub.subs.size,
    url: hub.ws?.masked || '',
  };
}

/** 当前所有订阅（后台任务清单用）：谁订的、订什么 */
export function hubSubscriptions() {
  return [...hub.subs].map((s) => {
    const [kind, f] = s.params;
    return {
      label: s.label || '（未标注）', kind, since: s.since,
      address: f?.address || null,
      topics: Array.isArray(f?.topics) ? f.topics.flat().filter(Boolean).length : 0,
    };
  });
}
