/**
 * 报价币库存 + 常驻授权：提前把 BNB 换成内盘的报价币（gang 的 SPCXB / oANT / WBNB…、Four 的 BNCB / NVDAB），
 * 并把授权额度设成「等于库存」。之后买入直接用库存，一笔完成（省掉换币 + 授权两笔）。
 *
 * 安全边界（用户 2026-10-27 确认）：
 * - 授权对象只能是硬编码的官方合约：gang LaunchpadV2（不可升级）、Four Core（UUPS 可升级，owner 为合约）。
 *   Flap 的授权对象是每个 market，常驻授权没有意义，不支持。
 * - 每种报价币库存上限 = capBnb（默认 1 BNB 等值）：备货时「现有库存折合 BNB + 本次备货 BNB」不得超过上限；
 *   授权额度 = min(备货后库存, 上限折合的报价币数量)。不做无上限授权：出事时最多损失这份库存。
 * - 备货 / 同步授权 / 撤销都是状态变更：生成计划 → 前端展示明细 → 用户确认 → 走一键执行（每步币安预览）。
 * - 备货的换币带 BNB，照常计入每日上限；之后用库存买入计入单笔上限（按折合 BNB），不重复计入每日上限。
 */
import { encodeFunctionData, decodeFunctionResult, parseAbi, getAddress } from 'viem';
import { rpc, getConfig, saveConfig, runBackground } from '../config.mjs';
import { gangInfo, LAUNCHPAD_V2 } from '../agent/gang.mjs';
import { toEventSelector } from 'viem';
import { readCoreBrief, isNativeQuote, QUOTES, OPENFOUR } from '../four/openfour.mjs';
import { routeSwap, estimateOut, tokenMeta, WBNB, pretty } from './router.mjs';
import { activeDeployment, curveOf, mainnetCtx } from './gangv3.mjs';

/*
 * gang V3 的授权对象 = 当前已启用且核验通过的 LaunchpadV3（地址不写死，换部署时跟着变；没启用时 gangv3 不可用）。
 * 用到 SPENDERS 的入口先 await refreshV3()。
 */
let v3Pad = null;
async function refreshV3() { v3Pad = (await activeDeployment().catch(() => null))?.pad || null; }

export const SPENDERS = {
  gang: { address: LAUNCHPAD_V2, label: 'gang LaunchpadV2', upgradeable: false },
  four: { address: OPENFOUR.core, label: 'Four Core', upgradeable: true },
  get gangv3() { return v3Pad ? { address: v3Pad, label: 'gang LaunchpadV3（未审计）', upgradeable: false } : undefined; },
};
const noSpender = (platform) => (platform === 'gangv3' ? 'gang V3 没有启用（或部署复核没通过）：先在「发射台」启用' : `不支持的平台：${platform}`);

const DEFAULT_CAP_BNB = '1';
const UNLIMITED = 2n ** 255n; // 额度 ≥ 这个值就算「无上限」
const MAX_UINT = 2n ** 256n - 1n;
// LaunchpadV2 Created 事件（与 quick/gangsnipe.mjs 的 CREATED_TOPIC 相同；这里单独算，避免循环引用）
const GANG_CREATED_TOPIC = toEventSelector(parseAbi(['event Created(address indexed token, address indexed creator, string name, string symbol, string logoURI, bool taxed, address indexed quote, address refPair, uint256 gradAmt)'])[0]);
// LaunchpadV3 Created 事件（同上，与 quick/gangsnipe.mjs 的 CREATED_TOPIC_V3 相同）
const V3_CREATED_TOPIC = toEventSelector(parseAbi(['event Created(address indexed token, address indexed creator, string name, string symbol, string logoURI, address indexed quote, address refPair, uint256 gradAmt)'])[0]);
const QUOTE_SCAN_DAYS = 3;
const BLOCKS_PER_DAY = 192000; // BSC 0.45s 出块
const SCAN_SPAN = 9000;
const SCAN_PARALLEL = 6;
const INDEX_TTL_MS = 30 * 60 * 1000;
const INDEX_RETRY_MS = 30 * 1000;
const MAX_APPROVE_ITEMS = 40;
const WEI = 10n ** 18n;
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
]);
const wbnbAbi = parseAbi(['function deposit() payable']);
const lc = (a) => String(a || '').toLowerCase();

function toWei(s) {
  const v = String(s ?? '').trim();
  if (!/^\d{1,9}(\.\d{1,18})?$/.test(v)) throw new Error('BNB 数量格式不对（最多 18 位小数）');
  const [w, f = ''] = v.split('.');
  return BigInt(w) * WEI + BigInt((f + '0'.repeat(18)).slice(0, 18) || '0');
}

async function read(to, functionName, args) {
  const raw = await rpc('eth_call', [{ to, data: encodeFunctionData({ abi: erc20Abi, functionName, args }) }, 'latest']);
  return decodeFunctionResult({ abi: erc20Abi, functionName, data: raw });
}

/** 默认登记 Four 的两种 ERC20 计价币；gang 的报价币按代币 CA 添加 */
const DEFAULT_TOKENS = Object.values(QUOTES).filter((q) => !q.native).map((q) => ({ platform: 'four', token: getAddress(q.addr) }));

export async function inventoryConfig() {
  const inv = (await getConfig()).inventory || {};
  const capBnb = String(inv.capBnb ?? DEFAULT_CAP_BNB);
  const tokens = Array.isArray(inv.tokens) ? inv.tokens : DEFAULT_TOKENS;
  return { capBnb, tokens };
}

async function saveTokens(tokens) {
  const { capBnb } = await inventoryConfig();
  await saveConfig({ inventory: { capBnb, tokens } });
}

export async function setCap(capBnb) {
  const v = String(capBnb ?? '').trim();
  if (toWei(v) <= 0n) throw new Error('库存上限必须大于 0');
  const { tokens } = await inventoryConfig();
  await saveConfig({ inventory: { capBnb: v, tokens } });
  return inventoryConfig();
}

function findEntry(tokens, platform, token) {
  const e = tokens.find((t) => t.platform === platform && lc(t.token) === lc(token));
  if (!e) throw new Error('该报价币不在库存列表里（先用代币 CA 添加）');
  if (!SPENDERS[platform]) throw new Error(noSpender(platform));
  return e;
}

/**
 * 备货 / 同步授权 / 撤销用的条目：已登记的照旧；gang V3 在已启用 LaunchpadV3 当过报价币的（库存总览自动列出的行），
 * 没登记也可以直接操作（授权对象仍是 SPENDERS 里的官方 V3 合约，WBNB 不用授权）。
 */
function resolveEntry(tokens, platform, token, v3idx) {
  if (platform === 'gangv3' && SPENDERS.gangv3 && lc(token) !== lc(WBNB) && v3idx.has(lc(token))
    && !tokens.some((t) => t.platform === platform && lc(t.token) === lc(token))) {
    return { platform, token: getAddress(token), auto: true };
  }
  return findEntry(tokens, platform, token);
}

/*
 * gang 报价币索引：LaunchpadV2 没有「报价币白名单」的只读函数（2026-10-27 逐个试过 quotes / isQuote / quoteConfigs…
 * 都不存在），所以用最近 QUOTE_SCAN_DAYS 天的 Created 事件统计谁被当作报价币。事件来源地址固定是 LaunchpadV2，
 * 伪造不了：出现在这里的就是 gang 真实在用的报价币。之后每次只增量扫新块。
 */
const newQuoteIdx = () => ({ counts: new Map(), seen: new Set(), lastBlock: 0, at: 0, loading: null, key: '' });
const quoteIdx = newQuoteIdx();
// 换部署时整个换成新对象（不原地重置）：还在跑的旧扫描只会写进它自己持有的旧对象，不会污染新 pad 的索引
let v3QuoteIdx = newQuoteIdx();

/** 扫某个发射台合约的 Created 日志，统计谁被当作报价币（Created 的第 3 个 indexed 参数 = 报价币）。来源地址固定，伪造不了 */
async function loadQuoteIndex(idx, address, topic) {
  // 扫成功后 30 分钟内直接用缓存；上一轮有区间失败（lastBlock 没更新）则 30 秒后再试，避免被每 4 秒一次的预热反复触发整段重扫
  if (idx.at && Date.now() - idx.at < (idx.lastBlock ? INDEX_TTL_MS : INDEX_RETRY_MS) && !idx.loading) return idx.counts;
  if (!idx.loading) {
    // 扫最近几天的 Created 日志：非即时，走公共节点（publicnode 支持按地址的 getLogs）
    idx.loading = runBackground(async () => {
      const head = Number(await rpc('eth_blockNumber', []));
      const from = idx.lastBlock ? idx.lastBlock + 1 : head - QUOTE_SCAN_DAYS * BLOCKS_PER_DAY;
      const ranges = [];
      for (let s = from; s <= head; s += SCAN_SPAN) ranges.push([s, Math.min(head, s + SCAN_SPAN - 1)]);
      let failed = 0;
      for (let i = 0; i < ranges.length; i += SCAN_PARALLEL) {
        await Promise.all(ranges.slice(i, i + SCAN_PARALLEL).map(async ([a, b]) => {
          try {
            const logs = await rpc('eth_getLogs', [{ address, topics: [topic], fromBlock: `0x${a.toString(16)}`, toBlock: `0x${b.toString(16)}` }]);
            for (const l of logs) {
              const id = `${l.transactionHash}:${l.logIndex}`;
              if (idx.seen.has(id)) continue;
              idx.seen.add(id);
              const q = lc(`0x${l.topics[3].slice(26)}`);
              idx.counts.set(q, (idx.counts.get(q) || 0) + 1);
            }
          } catch { failed += 1; }
        }));
      }
      if (!failed) idx.lastBlock = head; // 有失败的区间就下次重扫（seen 去重，不会重复计数）
      idx.at = Date.now();
    }).finally(() => { idx.loading = null; });
  }
  await idx.loading;
  return idx.counts;
}

export const gangQuoteIndex = () => loadQuoteIndex(quoteIdx, LAUNCHPAD_V2, GANG_CREATED_TOPIC);

/** gang V3 的报价币索引：只看当前已启用的 LaunchpadV3 发出的 Created（换了部署就重扫）。没启用返回空表。pad 参数给评测用 */
export async function v3QuoteIndex(pad = v3Pad) {
  if (!pad) return new Map();
  if (v3QuoteIdx.key !== lc(pad)) v3QuoteIdx = { ...newQuoteIdx(), key: lc(pad) };
  return loadQuoteIndex(v3QuoteIdx, pad, V3_CREATED_TOPIC);
}

/**
 * 按代币 CA 添加它的报价币：报价币来自官方合约登记（gang：LaunchpadV2.curves；Four：Core.tokens），
 * 也可以直接填报价币本身的地址：Four 的 BNCB / NVDAB，或最近在 gang 被当作报价币用过的代币（GANG、WBNB…）。
 * 其它随意填写的地址一律拒绝，避免把假币当报价币备货 / 授权。
 */
export async function addFromCa(ca) {
  const address = getAddress(ca);
  await refreshV3();
  let entry = null;
  // 某个地址是不是 gang V3 在用的报价币（出现在已启用 LaunchpadV3 的 Created 里，且不是 WBNB）；要用到才扫，索引缓存
  let v3idx = null;
  const isV3Quote = async (a = address) => {
    if (!v3Pad || lc(a) === lc(WBNB)) return false;
    v3idx ??= await v3QuoteIndex().catch(() => new Map());
    return v3idx.has(lc(a));
  };
  const four = Object.values(QUOTES).find((q) => !q.native && lc(q.addr) === lc(address));
  if (four) entry = { platform: 'four', token: getAddress(four.addr) };
  if (!entry) {
    const g = await gangInfo(address).catch(() => null);
    if (g) entry = { platform: 'gang', token: getAddress(g.quote) };
  }
  if (!entry && v3Pad) {
    // gang V3 代币：报价币来自已启用 LaunchpadV3 的登记（WBNB 底池直接付 BNB，不需要库存）
    const c = await curveOf(mainnetCtx, v3Pad, address).catch(() => null);
    if (c) {
      if (lc(c.quote) === lc(WBNB)) throw new Error('这个 gang V3 代币是 WBNB 底池：买入直接付 BNB（GangRouter 一笔完成），不需要库存');
      entry = { platform: 'gangv3', token: getAddress(c.quote) };
    }
  }
  if (!entry) {
    const idx = await gangQuoteIndex().catch(() => new Map());
    if (idx.has(lc(address))) entry = { platform: 'gang', token: address }; // 本身就是 gang 报价币（如 GANG 0x0c63…）
  }
  if (!entry && (await isV3Quote())) entry = { platform: 'gangv3', token: address }; // 只在 V3 当过报价币
  if (!entry) {
    const b = await readCoreBrief(address).catch(() => null);
    if (b?.exists) {
      if (isNativeQuote(b.quoteAsset)) throw new Error('这个 Four 代币用 BNB 计价，买入本来就是一笔，不需要库存');
      entry = { platform: 'four', token: getAddress(b.quoteAsset) };
    }
  }
  if (!entry) throw new Error(`识别不到：支持 gang / Four 内盘代币的 CA，或报价币本身的地址（Four 的 BNCB / NVDAB；最近 ${QUOTE_SCAN_DAYS} 天在 gang 当过报价币的，如 GANG / WBNB）。Flap 的授权对象是每个 market，不做常驻授权`);
  // GANG 这类报价币 V2 和 V3 都在用，授权对象不同（LaunchpadV2 / LaunchpadV3）：同时登记 gang V3，库存里各一行
  const entries = [entry];
  // 按识别出的报价币（entry.token）判断，不按输入的地址：粘贴的是 V2 代币 CA 时，要看的是它的报价币
  if (entry.platform === 'gang' && (await isV3Quote(entry.token))) entries.push({ platform: 'gangv3', token: entry.token });
  const { tokens } = await inventoryConfig();
  const fresh = entries.filter((e) => !tokens.some((t) => t.platform === e.platform && lc(t.token) === lc(e.token)));
  if (fresh.length) await saveTokens([...tokens, ...fresh]);
  const meta = await tokenMeta(entry.token).catch(() => ({ symbol: '?' }));
  return { ...entry, symbol: meta.symbol, platforms: entries.map((e) => e.platform) };
}

/**
 * 从列表移除。任何本机钱包对它仍有授权时拒绝：移除后这笔常驻授权就不在总览里显示了，容易被遗忘。
 * wallets：本机钱包的 EVM 地址列表（调用方提供）。
 */
export async function removeToken(platform, token, wallets = []) {
  await refreshV3();
  const { tokens } = await inventoryConfig();
  findEntry(tokens, platform, token);
  const sp = SPENDERS[platform];
  for (const w of wallets) {
    const allowance = await read(token, 'allowance', [w, sp.address]);
    if (allowance > 0n) throw new Error(`钱包 ${w} 对 ${sp.label} 仍有 ${pretty(allowance)} 的授权：请先点「撤销」把授权设为 0，再移除`);
  }
  await saveTokens(tokens.filter((t) => !(t.platform === platform && lc(t.token) === lc(token))));
  return inventoryConfig();
}

/** 报价币数量折合 BNB（WBNB 1:1）；没有路由返回 null */
async function valueInBnb(token, amount) {
  if (amount === 0n) return 0n;
  const v = await estimateOut(token, WBNB, amount).catch(() => 0n);
  return v > 0n ? v : null;
}

/** 库存总览：余额、折合 BNB、授权额度与风险标记（展示用，走公共节点） */
export function inventoryStatus(wallet) {
  return runBackground(() => inventoryStatusNow(wallet));
}

async function inventoryStatusNow(wallet) {
  await refreshV3();
  const { capBnb, tokens } = await inventoryConfig();
  const v3idx = await v3QuoteIndex().catch(() => new Map());
  // 已登记的 + gang V3 用过的非 WBNB 报价币（自动列出，auto=true，不用手动添加；授权对象是 LaunchpadV3，和 V2 是两笔不同的授权）
  const pairs = tokens.map((t) => ({ ...t, auto: false }));
  if (SPENDERS.gangv3) {
    for (const [q] of v3idx) {
      if (q !== lc(WBNB) && !tokens.some((t) => t.platform === 'gangv3' && lc(t.token) === q)) pairs.push({ platform: 'gangv3', token: getAddress(q), auto: true });
    }
  }
  const rows = await Promise.all(pairs.map(async (t) => {
    const sp = SPENDERS[t.platform];
    if (!sp) return { platform: t.platform, token: t.token, symbol: '?', error: noSpender(t.platform), spender: null, spenderLabel: t.platform, flags: [], auto: t.auto };
    try {
      const [meta, balance, allowance] = await Promise.all([
        tokenMeta(t.token),
        read(t.token, 'balanceOf', [wallet]),
        read(t.token, 'allowance', [wallet, sp.address]),
      ]);
      const value = await valueInBnb(t.token, balance);
      const flags = [];
      // 无上限授权是用户主动选择的（批量预授权）：不再提示收回
      if (allowance < UNLIMITED && balance > 0n && allowance < balance) flags.push('授权少于库存：库存买入时会多一笔授权，可点「同步授权」或「批量预授权」');
      return {
        platform: t.platform, token: t.token, symbol: meta.symbol, decimals: meta.decimals,
        spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable,
        balance: balance.toString(), balanceText: pretty(balance, meta.decimals),
        allowance: allowance.toString(), allowanceText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals),
        valueBnb: value == null ? null : pretty(value), flags, auto: t.auto,
        uses: t.platform === 'gangv3' ? (v3idx.get(lc(t.token)) || 0) : null,
      };
    } catch (err) {
      return { platform: t.platform, token: t.token, symbol: '?', error: err.message, spender: sp.address, spenderLabel: sp.label, flags: [], auto: t.auto };
    }
  }));
  // 前端画「报价币 × 平台」授权矩阵用：当前有授权对象的平台
  const spenders = ['gang', 'gangv3', 'four'].filter((p) => SPENDERS[p]).map((p) => ({ platform: p, label: SPENDERS[p].label, address: SPENDERS[p].address, upgradeable: SPENDERS[p].upgradeable }));
  return { capBnb, rows, spenders };
}

/** 引擎预热用（同步、不触发扫描）：已扫到的 gang V3 报价币地址（小写，含 WBNB，调用方自己过滤） */
export function v3QuotesCached() { return [...v3QuoteIdx.counts.keys()]; }

function approveStep(token, symbol, spender, spenderLabel, amount) {
  return {
    kind: 'approve',
    label: amount === 0n ? `撤销 ${symbol} 对 ${spenderLabel} 的授权（额度设为 0）` : `授权 ${pretty(amount)} ${symbol} 给 ${spenderLabel}（常驻授权 = 库存量）`,
    tx: { to: getAddress(token), value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [getAddress(spender), amount] }) },
  };
}

/**
 * 备货计划：BNB → 报价币（WBNB 直接包装），并把授权额度设成备货后的库存量（不超过上限）。
 * amountBnb 为 0 时只「同步授权」（把授权额度对齐到现有库存）。
 */
export async function planStock({ wallet, platform, token, amountBnb, slippageBps }) {
  await refreshV3();
  const { capBnb, tokens } = await inventoryConfig();
  const v3idx = await v3QuoteIndex().catch(() => new Map());
  const e = resolveEntry(tokens, platform, token, v3idx);
  const sp = SPENDERS[platform];
  const isWbnb = lc(e.token) === lc(WBNB);
  if (platform === 'gangv3' && isWbnb) throw new Error('gang V3 的 WBNB 底池直接付 BNB（GangRouter 一笔完成），不需要 WBNB 库存');
  const bnbWei = toWei(amountBnb || '0');
  const capWei = toWei(capBnb);
  const [meta, balance, allowance] = await Promise.all([
    tokenMeta(e.token), read(e.token, 'balanceOf', [wallet]), read(e.token, 'allowance', [wallet, sp.address]),
  ]);
  const valueNow = await valueInBnb(e.token, balance);
  if (valueNow == null) throw new Error(`估不出 ${meta.symbol} 折合多少 BNB（PancakeSwap 上没有可用池子），无法检查库存上限`);
  if (valueNow + bnbWei > capWei) {
    throw new Error(`超过库存上限：现有 ${meta.symbol} 约 ${pretty(valueNow)} BNB，本次备货 ${pretty(bnbWei)} BNB，上限 ${capBnb} BNB 等值`);
  }

  const steps = [];
  const checks = [
    { name: '授权对象', ok: true, detail: `${sp.label} ${sp.address}${sp.upgradeable ? '（可升级合约）' : '（不可升级）'}` },
    { name: '现有库存', ok: true, detail: `${pretty(balance, meta.decimals)} ${meta.symbol} ≈ ${pretty(valueNow)} BNB` },
  ];
  const warnings = [];
  let addMin = 0n;
  let addExpected = 0n;
  let fill = null;
  if (bnbWei > 0n) {
    if (isWbnb) {
      addMin = bnbWei;
      addExpected = bnbWei;
      fill = { kind: 'wrap', label: `包装 ${pretty(bnbWei)} BNB → WBNB`, tx: { to: WBNB, value: bnbWei.toString(), inputData: encodeFunctionData({ abi: wbnbAbi, functionName: 'deposit' }) } };
    } else {
      const r = await routeSwap({ wallet, tokenIn: WBNB, tokenOut: e.token, amountIn: bnbWei, slippageBps, nativeIn: true, extras: [e.token] });
      addMin = r.minOut;
      addExpected = r.expected;
      warnings.push(...r.warnings);
      checks.push(...r.checks);
      fill = { kind: 'swap', label: `兑换 ${pretty(bnbWei)} BNB → ${meta.symbol}（${r.route}）`, tx: r.tx, route: r.route, impactBps: r.impactBps, lossBps: r.lossBps };
    }
  }
  // 授权额度 = 备货后的保底库存，且不超过上限折合的报价币数量
  const capQuote = isWbnb ? capWei : await estimateOut(WBNB, e.token, capWei).catch(() => 0n);
  if (capQuote <= 0n) throw new Error(`估不出 ${capBnb} BNB 值多少 ${meta.symbol}，无法确定授权上限`);
  let target = balance + addMin;
  if (target > capQuote) target = capQuote;
  if (target === 0n) throw new Error('库存为 0：请填写要备货的 BNB 数量');
  // 已经是无上限授权（批量预授权）时保持不动，不把它缩回库存量
  if (target !== allowance && allowance < UNLIMITED) steps.push(approveStep(e.token, meta.symbol, sp.address, sp.label, target));
  if (fill) steps.push(fill);
  if (!steps.length) throw new Error('授权额度已经等于库存，无需操作');
  // 自动列出的 V3 行（没登记）：生成计划时就登记进库存列表（与批量预授权一致）。V3 报价币索引只在内存里、重启只回扫 3 天，
  // 不登记的话这笔授权可能从总览里消失、也撤销不了。登记范围仍受 resolveEntry 约束（gangv3 + 官方 pad 日志里的币 + 非 WBNB）
  if (e.auto) await saveTokens([...tokens, { platform: e.platform, token: e.token }]);

  return {
    platform: 'inventory', side: 'stock', token: e.token, symbol: meta.symbol,
    pay: { text: bnbWei > 0n ? `${pretty(bnbWei)} BNB` : '不花 BNB（只调整授权）' },
    receive: { expected: pretty(balance + addExpected, meta.decimals), min: pretty(balance + addMin, meta.decimals), minRaw: null, symbol: meta.symbol },
    route: fill?.route || (isWbnb && fill ? 'WBNB.deposit（1:1）' : '—'),
    impactBps: fill?.impactBps ?? null, lossBps: fill?.lossBps ?? null,
    approve: { spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable, amount: target.toString(), amountText: pretty(target, meta.decimals), before: allowance.toString(), beforeText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals) },
    capBnb, checks, warnings, note: null,
    steps: steps.map(({ route: _r, impactBps: _i, lossBps: _l, ...s }) => s),
  };
}

/**
 * 批量预授权的候选：gang 最近在用的报价币（按出现次数排序）+ 库存列表里的报价币（含 Four 的 BNCB / NVDAB）。
 * 授权不需要先持有这个代币；但买入时付的是这个代币，没有库存仍要先换币（只是省掉授权那一笔）。
 */
export function approvalCandidates(wallet) {
  return runBackground(() => approvalCandidatesNow(wallet)); // 展示用，走公共节点
}

async function approvalCandidatesNow(wallet) {
  await refreshV3();
  const idx = await gangQuoteIndex().catch(() => new Map());
  const v3idx = await v3QuoteIndex().catch(() => new Map()); // V3 没启用时是空表
  const { tokens } = await inventoryConfig();
  const list = new Map();
  const put = (platform, token, uses) => { const k = `${platform}:${lc(token)}`; if (!list.has(k)) list.set(k, { platform, token: getAddress(token), uses }); };
  // 顺序决定截断（最多 MAX_APPROVE_ITEMS 个）时保留谁：已登记的排最前（所有授权路径都会登记，批量撤销靠它列全），
  // 然后是 gang V3 用过的非 WBNB 报价币（WBNB 底池直接付 BNB，不需要授权；授权对象是 LaunchpadV3，和 V2 是两笔不同的授权），最后是 V2 索引
  for (const t of tokens) {
    put(t.platform, t.token, t.platform === 'gang' ? (idx.get(lc(t.token)) || 0) : t.platform === 'gangv3' ? (v3idx.get(lc(t.token)) || 0) : null);
  }
  for (const [q, n] of [...v3idx].sort((a, b) => b[1] - a[1])) if (q !== lc(WBNB)) put('gangv3', q, n);
  for (const [q, n] of [...idx].sort((a, b) => b[1] - a[1])) put('gang', q, n);
  const rows = await Promise.all([...list.values()].filter((x) => SPENDERS[x.platform]).slice(0, MAX_APPROVE_ITEMS).map(async (x) => {
    const sp = SPENDERS[x.platform];
    try {
      const [meta, balance, allowance] = await Promise.all([tokenMeta(x.token), read(x.token, 'balanceOf', [wallet]), read(x.token, 'allowance', [wallet, sp.address])]);
      return {
        ...x, symbol: meta.symbol, decimals: meta.decimals, spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable,
        balance: balance.toString(), balanceText: pretty(balance, meta.decimals),
        allowance: allowance.toString(), allowanceText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals), unlimited: allowance >= UNLIMITED,
      };
    } catch (err) {
      return { ...x, symbol: '?', error: err.message, spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable };
    }
  }));
  return { scanDays: QUOTE_SCAN_DAYS, rows };
}

/**
 * 批量预授权（无上限）计划：每个选中的报价币 approve(spender, 2^256-1)。spender 只能是 SPENDERS 里的官方合约，
 * 代币只能是「gang 最近在用的报价币 / 库存列表里的 / Four 的 BNCB、NVDAB」。已经无上限的跳过。选中的会自动加进库存列表。
 */
export async function planUnlimited({ wallet, items }) {
  if (!Array.isArray(items) || !items.length) throw new Error('请至少选择一个报价币');
  if (items.length > MAX_APPROVE_ITEMS) throw new Error(`一次最多 ${MAX_APPROVE_ITEMS} 个`);
  await refreshV3();
  const idx = await gangQuoteIndex().catch(() => new Map());
  const v3idx = await v3QuoteIndex().catch(() => new Map());
  const { tokens } = await inventoryConfig();
  const steps = [];
  const approvals = [];
  const added = [];
  const seen = new Set();
  for (const it of items) {
    const platform = String(it?.platform || '');
    const sp = SPENDERS[platform];
    if (!sp) throw new Error(noSpender(platform));
    const token = getAddress(String(it?.token || ''));
    const k = `${platform}:${lc(token)}`;
    if (seen.has(k)) continue;
    seen.add(k);
    if (!isKnownQuote(platform, token, { idx, v3idx, tokens })) throw new Error(`${token} 不是 ${platform} 在用的报价币，拒绝授权`);
    const [meta, allowance] = await Promise.all([tokenMeta(token), read(token, 'allowance', [wallet, sp.address])]);
    if (allowance >= UNLIMITED) continue;
    steps.push({
      kind: 'approve',
      label: `授权 ${meta.symbol} 给 ${sp.label}（无上限）`,
      tx: { to: token, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [getAddress(sp.address), MAX_UINT] }) },
    });
    approvals.push({ platform, token, symbol: meta.symbol, spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable, beforeText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals) });
    if (!tokens.some((t) => t.platform === platform && lc(t.token) === lc(token))) added.push({ platform, token });
  }
  if (!steps.length) throw new Error('所选报价币都已经是无上限授权，无需操作');
  if (added.length) await saveTokens([...tokens, ...added]); // 显示在库存列表里，便于之后备货 / 撤销
  return {
    platform: 'inventory', side: 'approve-all', token: approvals[0].token, symbol: `${approvals.length} 种报价币`,
    pay: { text: '不花 BNB（只授权，每笔只有很少的 gas）' },
    receive: { expected: '—', min: '—', minRaw: null, symbol: '' },
    route: '—', approvals, checks: [], warnings: [], note: null,
    steps,
  };
}

/**
 * 这个代币能不能作为 platform 的报价币做授权 / 撤销：gang = 最近在 LaunchpadV2 当过报价币或已在库存列表；
 * gang V3 = 在已启用 LaunchpadV3 当过报价币或已在库存列表（WBNB 不用授权）；Four = BNCB / NVDAB 或已在库存列表。
 * 其它随意填写的地址一律拒绝。
 */
function isKnownQuote(platform, token, { idx, v3idx, tokens }) {
  const t = lc(token);
  const listed = tokens.some((x) => x.platform === platform && lc(x.token) === t);
  if (platform === 'gang') return idx.has(t) || listed;
  if (platform === 'gangv3') return (v3idx.has(t) || listed) && t !== lc(WBNB);
  return Object.values(QUOTES).some((q) => !q.native && lc(q.addr) === t) || listed;
}

/**
 * 批量撤销计划：每个选中的报价币 approve(spender, 0)。spender 只能是 SPENDERS 里的官方合约，代币范围与批量预授权相同。
 * 额度已经是 0 的跳过；全部都是 0 时报错。撤销只会降低风险，库存留在钱包里。不会改动库存列表。
 */
export async function planRevokeMany({ wallet, items }) {
  if (!Array.isArray(items) || !items.length) throw new Error('请至少选择一个报价币');
  if (items.length > MAX_APPROVE_ITEMS) throw new Error(`一次最多 ${MAX_APPROVE_ITEMS} 个`);
  await refreshV3();
  const idx = await gangQuoteIndex().catch(() => new Map());
  const v3idx = await v3QuoteIndex().catch(() => new Map());
  const { tokens } = await inventoryConfig();
  const steps = [];
  const approvals = [];
  const seen = new Set();
  for (const it of items) {
    const platform = String(it?.platform || '');
    const sp = SPENDERS[platform];
    if (!sp) throw new Error(noSpender(platform));
    const token = getAddress(String(it?.token || ''));
    const k = `${platform}:${lc(token)}`;
    if (seen.has(k)) continue;
    seen.add(k);
    if (!isKnownQuote(platform, token, { idx, v3idx, tokens })) throw new Error(`${token} 不是 ${platform} 在用的报价币，拒绝处理`);
    const [meta, allowance] = await Promise.all([tokenMeta(token), read(token, 'allowance', [wallet, sp.address])]);
    if (allowance === 0n) continue;
    steps.push(approveStep(token, meta.symbol, sp.address, sp.label, 0n));
    approvals.push({ platform, token, symbol: meta.symbol, spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable, beforeText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals) });
  }
  if (!steps.length) throw new Error('所选报价币的授权额度都已经是 0，无需撤销');
  return {
    platform: 'inventory', side: 'revoke-all', token: approvals[0].token, symbol: `${approvals.length} 种报价币`,
    pay: { text: '不花 BNB（只撤销授权，每笔只有很少的 gas）' },
    receive: { expected: '—', min: '—', minRaw: null, symbol: '' },
    route: '—', approvals, checks: [], warnings: [], note: null,
    steps,
  };
}

/** 撤销授权：额度设为 0（库存留在钱包，可在快捷交易里把报价币卖回 BNB） */
export async function planRevoke({ wallet, platform, token }) {
  await refreshV3();
  const { tokens } = await inventoryConfig();
  const v3idx = await v3QuoteIndex().catch(() => new Map());
  const e = resolveEntry(tokens, platform, token, v3idx);
  const sp = SPENDERS[platform];
  const [meta, allowance] = await Promise.all([tokenMeta(e.token), read(e.token, 'allowance', [wallet, sp.address])]);
  if (allowance === 0n) throw new Error('当前授权额度已经是 0');
  return {
    platform: 'inventory', side: 'revoke', token: e.token, symbol: meta.symbol,
    pay: { text: '不花 BNB' }, receive: { expected: '—', min: '—', minRaw: null, symbol: '' }, route: '—',
    approve: { spender: sp.address, spenderLabel: sp.label, upgradeable: sp.upgradeable, amount: '0', amountText: '0', before: allowance.toString(), beforeText: allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals) },
    checks: [], warnings: [], note: null,
    steps: [approveStep(e.token, meta.symbol, sp.address, sp.label, 0n)],
  };
}
