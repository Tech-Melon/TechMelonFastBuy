// 预热（后台、低优先级）：
// - 服务启动后：中转币之间的池子地址（约 50 个只读请求），让第一次快捷报价少等几秒
// - 服务启动后 + 每 20 分钟：报价币库存里的报价币（SPCXB / BNCB…）与中转币之间的池子，缓存一直保持热
// - 用户粘贴 CA 后：提前识别平台、发现该代币（及其报价币）的池子；点「买入」时只剩报价 + 模拟
import { runBackground } from '../config.mjs';
import { discoverPools, markLongCache, HUBS, WBNB } from './router.mjs';
import { inventoryConfig } from './inventory.mjs';

const QUOTE_REFRESH_MS = 20 * 60 * 1000; // 小于池子地址缓存的 30 分钟：到期前就刷新

/** 预热一个报价币：币集合与 routeSwap(WBNB → 报价币, extras=[报价币]) 相同，命中同一份缓存 */
function warmQuote(token, refresh) {
  return discoverPools([WBNB, token, ...Object.values(HUBS), token], { refresh, ends: [WBNB, token] });
}

/** 报价币库存里的所有报价币（refresh=true 时忽略缓存重新发现） */
export async function warmInventoryQuotes(refresh = false) {
  const { tokens } = await inventoryConfig();
  const list = [...new Set(tokens.map((t) => t.token))].filter((a) => a.toLowerCase() !== WBNB.toLowerCase());
  markLongCache(list);
  for (const t of list) {
    await runBackground(() => warmQuote(t, refresh)).catch((err) => console.warn(`[quick] 报价币预热失败 ${t}：${err.message}`));
  }
}

/** isBusy：服务闲置时跳过定时刷新（缓存过期后，下次有人报价时按需重新发现） */
export function warmQuickRouter(isBusy = () => true) {
  setTimeout(async () => {
    await runBackground(() => discoverPools(Object.values(HUBS))).catch((err) => console.warn(`[quick] 路由预热失败：${err.message}`));
    await warmInventoryQuotes().catch(() => null);
  }, 3000).unref?.();
  setInterval(() => { if (isBusy()) warmInventoryQuotes(true).catch(() => null); }, QUOTE_REFRESH_MS).unref?.();
}

/*
 * 粘贴 CA 后 2 分钟内保持储备缓存是热的：储备只缓存 15 秒，用户粘贴后隔一会儿才点买入时要重读一遍
 * （实测约 0.9 秒）。每 10 秒在后台重读一次（每次十几个只读请求），只保留最近粘贴的那一个代币。
 */
const HOT_MS = 2 * 60 * 1000;
const HOT_EVERY_MS = 10000;
let hotTimer = null;
let warmSeq = 0;
function keepHot(sets) {
  clearInterval(hotTimer);
  if (!sets.length) return;
  const until = Date.now() + HOT_MS;
  hotTimer = setInterval(() => {
    if (Date.now() > until) { clearInterval(hotTimer); return; }
    for (const [tokens, ends] of sets) runBackground(() => discoverPools(tokens, { ends, refreshLive: true })).catch(() => null);
  }, HOT_EVERY_MS);
  hotTimer.unref?.();
}

/**
 * 粘贴 CA 后的预热：识别结果进缓存（20 秒），池子地址进缓存（报价币 30 分钟 / 其它 5 分钟）。
 * 只读、不 preview、不产生任何 requestId。detect 由调用方传入（避免循环依赖）。
 */
export async function warmToken({ address, platform, wallet, detectAll, detectOne }) {
  // 用户刚粘贴 CA、马上就要下单：按前台优先级跑（后台补查此时可能还在进行，不能排在它后面）
  return (async () => {
    const t = Date.now();
    const det = platform === 'auto' ? await detectAll(address, { wallet }) : await detectOne(platform, address, wallet);
    // 只预热真正下单会走的路由：内盘（曲线）只需要 BNB → 报价币；外盘才需要 BNB → 代币。
    // 内盘代币多拉一组「代币 × 全部中转币」的池子既用不上，还会占满 RPC 限速窗口，拖慢紧接着的报价。
    // 币集合与 routeSwap 调用时一致（同一个缓存键），否则预热命中不了。
    const extras = det.extras || [];
    markLongCache(extras); // 报价币来自平台合约登记（gang curves / Four Core），池子地址可长缓存
    const viaDex = det.recommended === 'dex';
    const targets = (viaDex ? [address] : extras).filter((a) => a.toLowerCase() !== WBNB.toLowerCase());
    const sets = targets.map((t2) => [[WBNB, t2, ...Object.values(HUBS), ...(viaDex ? extras : [t2])], [WBNB, t2]]);
    // 池子发现不阻塞识别结果（实测要 1~2 秒）：先把识别返回给页面 / 插件，池子在后面继续跑；
    // 期间点了买入，报价的 discoverPools 会复用这次正在进行的发现（router.mjs 的 POOLS_INFLIGHT）
    const mine = ++warmSeq;
    // 只给最近一次粘贴的代币保温：旧代币的发现晚跑完时不能覆盖新代币
    Promise.all(sets.map(([tokens, ends]) => discoverPools(tokens, { ends }).catch(() => null))).then(() => { if (mine === warmSeq) keepHot(sets); });
    // 识别结果一并返回（已在缓存里，不多花时间）：交易台粘贴 CA 后直接显示「识别：xx」一行
    const detect = { address, symbol: det.symbol ?? null, candidates: det.candidates || [], recommended: det.recommended ?? null, errors: det.errors || [] };
    return { recommended: det.recommended, ms: Date.now() - t, detect };
  })();
}
