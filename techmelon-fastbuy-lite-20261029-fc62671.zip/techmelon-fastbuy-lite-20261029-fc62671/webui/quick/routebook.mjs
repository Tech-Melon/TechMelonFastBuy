/**
 * 路由记录与固定路由（webui/routes.json，权限 600，已 gitignore，不随代码同步：每台服务器记自己的）。
 *
 * 记录：每笔经 Pancake SmartRouter 的兑换（外盘买卖、gang / V3 换报价币、报价币库存备货）广播后等回执，
 *   按「币对（输入 → 输出）+ 池子路径」累计成功 / 失败次数。历史记录可从执行日志导入（按交易哈希读链上 calldata 还原路径）。
 * 固定：用户把某个币对的一条已成功过的路径设为固定后，routeSwap 不再做完整搜索（省几十个 RPC、快 1~3 秒），
 *   只沿固定路径重读储备 + 报价 + 模拟；模拟不过 / 池子没流动性 / 报价为 0 时这一次自动改用完整搜索，
 *   连续 PIN_MAX_FAILS 次不通就暂停固定（例：某个池子被撤流动性、报价服务下线），页面上显示原因，可一键恢复。
 *   固定期间每 PIN_RECHECK_MS 在后台完整搜索一次，有明显更好的路径时在页面上提示（不自动换）。
 * 安全：只能固定「记录里成功过」的路径（池子来自官方工厂、走过白名单校验）；使用时仍要求路径上的代币都在
 *   本次交易的白名单内，calldata 照常经过 assertRouterTx 复核。固定只改选路，不放宽任何上限。
 */
import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { rpcFor, runBackground } from '../config.mjs';
import { journal } from '../journal.mjs';

const FILE = process.env.ROUTES_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'routes.json');
export const PIN_MAX_FAILS = 3;
export const PIN_RECHECK_MS = 60 * 60 * 1000;
const SUGGEST_MIN_OK = 3; // 同一路径成功这么多次、没失败过、且占该币对成功次数的 80% 以上 → 建议固定
const RECEIPT_WAIT_MS = 90000;
const RECEIPT_POLL_MS = 1500;
const PENDING_TTL_MS = 10 * 60 * 1000;
const SEEN_MAX = 3000;

const lc = (a) => String(a || '').toLowerCase();
export const pairKey = (a, b) => `${lc(a)}>${lc(b)}`;
export const pathKeyOf = (hops) => hops.map((h) => lc(h.pool)).join('>');

let book = { version: 1, importedAt: null, pairs: {}, seen: [] };
try {
  const d = JSON.parse(readFileSync(FILE, 'utf8'));
  if (d && typeof d.pairs === 'object') book = { ...book, ...d, seen: Array.isArray(d.seen) ? d.seen : [] };
} catch { /* 没有文件 = 还没有记录 */ }
const seen = new Set(book.seen);

let chain = Promise.resolve();
let flushTimer = null;
function flush(now = false) {
  const write = () => {
    flushTimer = null;
    book.seen = [...seen].slice(-SEEN_MAX);
    const body = JSON.stringify({ ...book, savedAt: new Date().toISOString() }, null, 2);
    chain = chain.then(async () => {
      const tmp = `${FILE}.${process.pid}.tmp`;
      try {
        await writeFile(tmp, body, { encoding: 'utf8', mode: 0o600 });
        await rename(tmp, FILE);
      } catch (err) {
        console.warn(`[routes] 保存路由记录失败：${err.message}`);
      }
    });
    return chain;
  };
  if (now) { clearTimeout(flushTimer); return write(); }
  if (!flushTimer) flushTimer = setTimeout(write, 2000);
  return chain;
}

/** 可落盘的路径（去掉储备等临时字段）。a / b 是池子的两个币（V2 本地报价要按它判断方向） */
export function serialHops(hops) {
  return hops.map((h) => ({
    kind: h.kind, fee: h.kind === 'v3' ? Number(h.fee) : null, pool: h.pool,
    tokenIn: h.tokenIn, tokenOut: h.tokenOut, a: h.p?.a ?? h.a ?? h.tokenIn, b: h.p?.b ?? h.b ?? h.tokenOut,
  }));
}

function pairOf(tokenIn, tokenOut, create = true) {
  const k = pairKey(tokenIn, tokenOut);
  if (!book.pairs[k] && create) book.pairs[k] = { tokenIn, tokenOut, routes: {}, pin: null };
  return book.pairs[k] || null;
}

/** 记一笔结果（实时或导入）。txHash 去重 */
export function recordResult({ tokenIn, tokenOut, hops, text, ok, error = null, platform = null, txHash = null, at = null, source = 'live', inSym = null, outSym = null }) {
  if (!hops?.length) return;
  if (txHash) {
    if (seen.has(lc(txHash))) return;
    seen.add(lc(txHash));
  }
  const p = pairOf(tokenIn, tokenOut);
  if (inSym) p.inSym = inSym;
  if (outSym) p.outSym = outSym;
  const key = pathKeyOf(hops);
  const r = p.routes[key] || (p.routes[key] = { hops: serialHops(hops), text, ok: 0, fail: 0, platforms: {}, firstAt: null, lastOkAt: null, lastFailAt: null, lastError: null, lastTx: null });
  if (text) r.text = text;
  const when = at || new Date().toISOString();
  r.firstAt = r.firstAt && r.firstAt < when ? r.firstAt : when;
  if (ok) { r.ok += 1; if (!r.lastOkAt || when > r.lastOkAt) r.lastOkAt = when; } else { r.fail += 1; r.lastFailAt = when; r.lastError = error; }
  if (platform) r.platforms[platform] = (r.platforms[platform] || 0) + 1;
  if (txHash) r.lastTx = txHash;
  if (ok && p.pin?.pathKey === key && !p.pin.suspended) { p.pin.fails = 0; p.pin.lastOkAt = when; }
  if (source === 'live') journal('route.result', { tokenIn, tokenOut, path: key, ok, platform, txHash });
  flush();
}

/* ---- 广播后等回执再记账（按 calldata 对应到计划时的路径）---- */
const pending = new Map(); // inputData → { meta, at, platform }

/** routeSwap 生成交易时登记路径 */
export function rememberTx(inputData, meta) {
  const now = Date.now();
  for (const [k, v] of pending) if (now - v.at > PENDING_TTL_MS) pending.delete(k);
  if (pending.size > 300) pending.delete(pending.keys().next().value);
  pending.set(String(inputData), { meta, at: now, platform: null });
}

/** 计划生成后标记平台（dex / gang / gangv3 / inventory …），只用于统计展示 */
export function tagPlatform(inputData, platform) {
  const p = pending.get(String(inputData));
  if (p && platform) p.platform = platform;
}

/** execute 拿到 txHash 后调用：后台等回执，记成功 / 失败 */
export function noteSent(inputData, txHash) {
  const p = pending.get(String(inputData));
  if (!p || !txHash) return;
  pending.delete(String(inputData));
  const until = Date.now() + RECEIPT_WAIT_MS;
  const tick = async () => {
    const rc = await runBackground(() => rpcFor('56', 'eth_getTransactionReceipt', [txHash])).catch(() => null);
    if (rc) {
      recordResult({ ...p.meta, ok: rc.status === '0x1', error: rc.status === '0x1' ? null : '链上执行失败', platform: p.platform, txHash });
      return;
    }
    if (Date.now() < until) setTimeout(tick, RECEIPT_POLL_MS).unref?.();
  };
  setTimeout(tick, RECEIPT_POLL_MS).unref?.();
}

/* ---- 固定路由 ---- */

/** 该币对生效中的固定路由（暂停的不返回） */
export function getPin(tokenIn, tokenOut) {
  const p = pairOf(tokenIn, tokenOut, false);
  return p?.pin && !p.pin.suspended ? p.pin : null;
}

/** 固定路由这一次走不通：累计；连续 PIN_MAX_FAILS 次就暂停 */
export function pinFailed(tokenIn, tokenOut, reason) {
  const pin = pairOf(tokenIn, tokenOut, false)?.pin;
  if (!pin) return;
  pin.fails = (pin.fails || 0) + 1;
  pin.lastError = String(reason).slice(0, 300);
  pin.lastFailAt = new Date().toISOString();
  if (pin.fails >= PIN_MAX_FAILS && !pin.suspended) {
    pin.suspended = true;
    pin.suspendedAt = pin.lastFailAt;
    journal('route.pin.suspended', { pair: pairKey(tokenIn, tokenOut), path: pin.pathKey, reason: pin.lastError });
    console.warn(`[routes] 固定路由连续 ${pin.fails} 次不通，已暂停：${pin.text}（${pin.lastError}）`);
  }
  flush();
}

/** 固定路由这一次可用：清零失败计数（只有状态变化或间隔够久才写盘） */
export function pinOk(tokenIn, tokenOut) {
  const pin = pairOf(tokenIn, tokenOut, false)?.pin;
  if (!pin) return;
  const stale = !pin.lastOkAt || Date.now() - Date.parse(pin.lastOkAt) > 10 * 60 * 1000;
  if (!pin.fails && !stale) return;
  pin.fails = 0;
  pin.lastOkAt = new Date().toISOString();
  flush();
}

export const pinNeedsRecheck = (pin) => Date.now() - Date.parse(pin.checkedAt || 0) > PIN_RECHECK_MS;

/** 后台复查结果：better = { text, bps } 或 null */
export function pinChecked(tokenIn, tokenOut, better) {
  const pin = pairOf(tokenIn, tokenOut, false)?.pin;
  if (!pin) return;
  pin.checkedAt = new Date().toISOString();
  pin.better = better ? { ...better, at: pin.checkedAt } : null;
  flush();
}

export function pinRoute(pair, pathKey) {
  const p = book.pairs[lc(pair)];
  if (!p) throw new Error('没有这个币对的路由记录');
  const r = p.routes[lc(pathKey)];
  if (!r) throw new Error('只能固定记录里出现过的路径');
  if (!r.ok) throw new Error('这条路径还没有成功过，不能固定');
  p.pin = { pathKey: lc(pathKey), hops: r.hops, text: r.text, pinnedAt: new Date().toISOString(), fails: 0, suspended: false, lastError: null, checkedAt: new Date().toISOString(), better: null };
  journal('route.pin', { pair: lc(pair), path: lc(pathKey), text: r.text });
  flush(true);
  return publicPair(lc(pair), p);
}

export function unpinRoute(pair) {
  const p = book.pairs[lc(pair)];
  if (!p?.pin) throw new Error('这个币对没有固定路由');
  journal('route.unpin', { pair: lc(pair), path: p.pin.pathKey });
  p.pin = null;
  flush(true);
  return publicPair(lc(pair), p);
}

/** 暂停的固定路由恢复使用（失败计数清零） */
export function resumePin(pair) {
  const p = book.pairs[lc(pair)];
  if (!p?.pin) throw new Error('这个币对没有固定路由');
  Object.assign(p.pin, { suspended: false, suspendedAt: null, fails: 0 });
  journal('route.pin.resume', { pair: lc(pair), path: p.pin.pathKey });
  flush(true);
  return publicPair(lc(pair), p);
}

function suggestOf(p) {
  const rows = Object.entries(p.routes);
  const totalOk = rows.reduce((a, [, r]) => a + r.ok, 0);
  const best = rows.filter(([, r]) => r.ok >= SUGGEST_MIN_OK && r.fail === 0).sort((a, b) => b[1].ok - a[1].ok)[0];
  if (!best || best[1].ok * 10 < totalOk * 8) return null;
  if (p.pin?.pathKey === best[0] && !p.pin.suspended) return null;
  return best[0];
}

function publicPair(key, p) {
  const routes = Object.entries(p.routes)
    .map(([k, r]) => ({ pathKey: k, text: r.text, ok: r.ok, fail: r.fail, platforms: r.platforms, lastOkAt: r.lastOkAt, lastFailAt: r.lastFailAt, lastError: r.lastError, lastTx: r.lastTx, hops: r.hops.length, kinds: r.hops.map((h) => (h.kind === 'v2' ? 'V2' : `V3 ${h.fee / 10000}%`)) }))
    .sort((a, b) => b.ok - a.ok || (b.lastOkAt || '').localeCompare(a.lastOkAt || ''));
  const last = routes.reduce((a, r) => [a, r.lastOkAt || '', r.lastFailAt || ''].sort().pop(), '');
  return {
    pair: key, tokenIn: p.tokenIn, tokenOut: p.tokenOut, inSym: p.inSym || null, outSym: p.outSym || null,
    routes, pin: p.pin ? { ...p.pin, hops: undefined } : null, suggest: suggestOf(p), lastAt: last || null,
  };
}

export function listRoutes() {
  return {
    importedAt: book.importedAt,
    pinMaxFails: PIN_MAX_FAILS,
    pairs: Object.entries(book.pairs).map(([k, p]) => publicPair(k, p)).sort((a, b) => (b.lastAt || '').localeCompare(a.lastAt || '')),
  };
}

/** 币对的 symbol（展示用，导入 / 实时记录时补上） */
export function setPairSymbols(tokenIn, tokenOut, inSym, outSym) {
  const p = pairOf(tokenIn, tokenOut, false);
  if (p && (p.inSym !== inSym || p.outSym !== outSym)) { p.inSym = inSym; p.outSym = outSym; flush(); }
}

/* ---- 从执行日志导入历史成交 ---- */

function parseV3PathFull(pathHex) {
  const hex = pathHex.slice(2);
  const tokens = [`0x${hex.slice(0, 40)}`];
  const fees = [];
  for (let i = 40; i < hex.length; i += 46) {
    fees.push(parseInt(hex.slice(i, i + 6), 16));
    tokens.push(`0x${hex.slice(i + 6, i + 46)}`);
  }
  return { tokens, fees };
}

/**
 * 读执行日志里所有发往 SmartRouter 的已广播交易（execute.done 带 txHash），按哈希取链上 calldata 还原路径，
 * 用回执判断成败，一键任务的平台从 oneclick.start 对上。已导入过的哈希跳过。返回统计。
 */
export async function importHistory() {
  const { readJournal } = await import('../journal.mjs');
  const { PANCAKE, routerAbi, routeText, tokenMeta, WBNB } = await import('./router.mjs');
  const { decodeFunctionData, encodeFunctionData, parseAbi, getAddress } = await import('viem');
  const factoryV2 = parseAbi(['function getPair(address,address) view returns (address)']);
  const factoryV3 = parseAbi(['function getPool(address,address,uint24) view returns (address)']);
  const rows = await readJournal(Infinity, { withRotated: true });
  const jobPlatform = new Map();
  const txPlatform = new Map();
  for (const r of rows) {
    if (r.type === 'oneclick.start') jobPlatform.set(r.jobId, r.platform);
    else if (r.type === 'oneclick.step' && r.txHash && jobPlatform.has(r.jobId)) txPlatform.set(lc(r.txHash), jobPlatform.get(r.jobId));
  }
  const txs = rows.filter((r) => r.type === 'execute.done' && r.txHash && lc(r.to) === lc(PANCAKE.smartRouter) && !seen.has(lc(r.txHash)));
  const stat = { scanned: txs.length, imported: 0, failed: 0, skipped: 0 };
  const poolCache = new Map();
  const poolOf = async (kind, a, b, fee) => {
    const k = `${kind}:${[lc(a), lc(b)].sort().join(':')}:${fee ?? ''}`;
    if (poolCache.has(k)) return poolCache.get(k);
    const data = kind === 'v2'
      ? encodeFunctionData({ abi: factoryV2, functionName: 'getPair', args: [a, b] })
      : encodeFunctionData({ abi: factoryV3, functionName: 'getPool', args: [a, b, fee] });
    const raw = await rpcFor('56', 'eth_call', [{ to: kind === 'v2' ? PANCAKE.v2Factory : PANCAKE.v3Factory, data }, 'latest']);
    const addr = getAddress(`0x${String(raw).slice(-40)}`);
    poolCache.set(k, addr);
    return addr;
  };
  for (const r of txs) {
    try {
      await runBackground(async () => {
        const [tx, rc] = await Promise.all([
          rpcFor('56', 'eth_getTransactionByHash', [r.txHash]),
          rpcFor('56', 'eth_getTransactionReceipt', [r.txHash]),
        ]);
        if (!tx?.input || !rc) { stat.skipped += 1; return; }
        const outer = decodeFunctionData({ abi: routerAbi, data: tx.input });
        if (outer.functionName !== 'multicall') { stat.skipped += 1; return; }
        const hops = [];
        let nativeOut = false;
        for (const d of outer.args[1]) {
          const c = decodeFunctionData({ abi: routerAbi, data: d });
          if (c.functionName === 'swapExactTokensForTokens') {
            const p = c.args[2];
            for (let i = 0; i + 1 < p.length; i += 1) hops.push({ kind: 'v2', fee: null, tokenIn: getAddress(p[i]), tokenOut: getAddress(p[i + 1]) });
          } else if (c.functionName === 'exactInput') {
            const { tokens, fees } = parseV3PathFull(c.args[0].path);
            for (let i = 0; i + 1 < tokens.length; i += 1) hops.push({ kind: 'v3', fee: fees[i], tokenIn: getAddress(tokens[i]), tokenOut: getAddress(tokens[i + 1]) });
          } else if (c.functionName === 'unwrapWETH9') {
            nativeOut = true;
          }
        }
        if (!hops.length) { stat.skipped += 1; return; }
        for (const h of hops) {
          h.pool = await poolOf(h.kind, h.tokenIn, h.tokenOut, h.fee);
          h.a = h.tokenIn;
          h.b = h.tokenOut;
        }
        const nativeIn = BigInt(tx.value || '0') > 0n;
        const text = await routeText(hops, { nativeIn, nativeOut }).catch(() => hops.map((h) => h.tokenOut).join(' → '));
        const tokenIn = hops[0].tokenIn;
        const tokenOut = hops[hops.length - 1].tokenOut;
        const ok = rc.status === '0x1';
        recordResult({ tokenIn, tokenOut, hops, text, ok, error: ok ? null : '链上执行失败', platform: txPlatform.get(lc(r.txHash)) || null, txHash: r.txHash, at: r.at, source: 'import' });
        const [mi, mo] = await Promise.all([tokenMeta(tokenIn).catch(() => null), tokenMeta(tokenOut).catch(() => null)]);
        const sym = (m, a) => (lc(a) === lc(WBNB) ? 'BNB' : m?.symbol || '?');
        setPairSymbols(tokenIn, tokenOut, sym(mi, tokenIn), sym(mo, tokenOut));
        stat.imported += 1;
        if (!ok) stat.failed += 1;
      });
    } catch (err) {
      stat.skipped += 1;
      console.warn(`[routes] 导入 ${r.txHash} 失败：${err.message}`);
    }
  }
  book.importedAt = new Date().toISOString();
  await flush(true);
  journal('route.import', stat);
  return stat;
}
