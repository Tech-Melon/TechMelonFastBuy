/**
 * 持仓面板的代币头像来源（登记到 tokens.mjs 的 registerLogo，由 /api/token-logo 统一代理、校验、缓存）：
 *   1. 币安钱包公开持仓接口的 icon（官方 skill query-address-info，免鉴权）：覆盖主流币和币安收录的币；
 *   2. gang 代币：创建时写在 LaunchpadV2 Created 事件里的 logoURI（cdn.gang.fun），用到时才查链上事件。
 * gmgn.ai 自己的图片有 Cloudflare 校验，服务端取不到，所以不用 GMGN 返回的 logo 字段。
 */
import { decodeEventLog, parseAbi } from 'viem';
import { rpcFor, runBackground } from './config.mjs';
import { cacheGet, cacheSet } from './cache.mjs';
import { registerLogo } from './tokens.mjs';
import { LAUNCHPAD_V2, CREATED_TOPIC } from './agent/gang.mjs';

const BINANCE_POSITIONS = 'https://web3.binance.com/bapi/defi/v3/public/wallet-direct/buw/wallet/address/pnl/active-position-list/ai';
const ICON_HOST = 'https://bin.bnbstatic.com';
const ADDR = /^0x[0-9a-fA-F]{40}$/;
const createdAbi = parseAbi(['event Created(address indexed token, address indexed creator, string name, string symbol, string logoURI, bool taxed, address indexed quote, address refPair, uint256 gradAmt)']);

/** 登记这个钱包在币安持仓接口里能拿到的图标（10 分钟内同一钱包只查一次） */
export async function registerBinanceIcons(wallet) {
  const key = `bnicons:${wallet.toLowerCase()}`;
  if (cacheGet(key)) return;
  cacheSet(key, true, 10 * 60 * 1000);
  const url = `${BINANCE_POSITIONS}?address=${wallet}&chainId=56&offset=0`;
  const r = await fetch(url, {
    headers: { 'Accept-Encoding': 'identity', 'User-Agent': 'binance-web3/2.0 (Skill)', clienttype: 'web', clientversion: '1.2.0' },
    signal: AbortSignal.timeout(6000),
  });
  const j = await r.json();
  for (const x of j?.data?.list || []) {
    if (!ADDR.test(String(x.contractAddress)) || typeof x.icon !== 'string' || !x.icon.startsWith('/images/')) continue;
    registerLogo('56', x.contractAddress, `${ICON_HOST}${x.icon}`);
  }
}

/** gang 代币：按创建时间估出区块范围，查 Created 事件里的 logoURI（找不到返回 ''） */
async function gangLogoUri(token, createdAt) {
  const head = await rpcFor('56', 'eth_getBlockByNumber', ['latest', false]);
  const headNo = Number(head.number);
  const blockSec = 0.45; // BSC 当前出块间隔；估不准时靠下面的窗口兜住
  const est = headNo - Math.round((Number(head.timestamp) - createdAt) / blockSec);
  const topic = `0x${token.slice(2).toLowerCase().padStart(64, '0')}`;
  for (const span of [3000, 40000]) {
    const from = Math.max(0, est - span);
    const to = Math.min(headNo, est + span);
    const logs = await rpcFor('56', 'eth_getLogs', [{ address: LAUNCHPAD_V2, topics: [CREATED_TOPIC, topic], fromBlock: `0x${from.toString(16)}`, toBlock: `0x${to.toString(16)}` }]).catch(() => []);
    if (Array.isArray(logs) && logs[0]) {
      const ev = decodeEventLog({ abi: createdAbi, data: logs[0].data, topics: logs[0].topics });
      return String(ev.args.logoURI || '');
    }
  }
  return '';
}

/** 持仓行回调：gang 代币登记「用到时查链上 logoURI」 */
export function registerHoldingLogo(row) {
  if (!ADDR.test(String(row.token || ''))) return;
  // 图标是展示用的：查链走公共节点（runBackground）
  if (row.launchpad === 'gang' && row.createdAt > 0) registerLogo('56', row.token, () => runBackground(() => gangLogoUri(row.token, row.createdAt)));
}
