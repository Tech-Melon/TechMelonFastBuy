import http from 'node:http';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseAbi, encodeFunctionData, decodeFunctionResult } from 'viem';
import { planFlap } from './flap.mjs';
import { parsePrompt } from './prompt.mjs';
import { planMint, decodeMintReceipt } from './tasks.mjs';
import { analyzePrompt } from './agent/analyze.mjs';
import { listModules, createModule, removeModule, getModule } from './modules.mjs';
import { metricsSnapshot, recordCli } from './metrics.mjs';
import { listAddresses, addAddress, removeAddress } from './addressbook.mjs';
import { cacheGet, cacheSet, cacheInvalidate } from './cache.mjs';
import { tokenCatalog, tokenLogo, isVerified } from './tokens.mjs';
import { getConfig, saveConfig, publicConfig, assertRpcUrl, assertServiceUrl, assertWssUrl, chainRpcUrl, chainWssUrl, nodeList, rpcFor, rpcBatch, runBackground, publicRpcStats } from './config.mjs';
import { testWss } from './four/wss.mjs';
import { QUOTES, OPENFOUR, buildApproveTx, decodeAgentError, tokensToWei } from './four/openfour.mjs';
import { inspectToken, planBuy, planSell, listHoldings } from './four/trade.mjs';
import { listPlatforms, detectAll, detectOne, planQuick } from './quick/registry.mjs';
import { warmQuickRouter, warmToken, warmInventoryQuotes } from './quick/warm.mjs';
import { inventoryStatus, addFromCa, removeToken, setCap, planStock, planRevoke, planRevokeMany, planUnlimited, approvalCandidates, gangQuoteIndex } from './quick/inventory.mjs';
import { estimateOut, tokenMeta, WBNB as WBNB_ADDR } from './quick/router.mjs';
import { xferStatus, armXfer, disarmXfer, resumeXfer, setXferToken, clearXferTokens } from './quick/autoxfer.mjs';
import { reloadHub, hubStatus } from './wsshub.mjs';
import { gmgnStatus, setApiKey, generateSigner, walletHoldings, walletActivity, walletStats } from './gmgn.mjs';
import { listTargets, checkAddress, addTarget, removeTarget, listTransferable, planTransfer } from './quick/transfer.mjs';

/** 本机所有钱包的 EVM 地址（白名单地址检查：是不是自己 / 是否疑似投毒） */
async function ownEvmAddresses() {
  return (await listWallets()).map((w) => w.evm).filter((a) => ADDR_RE.test(String(a || '')));
}
import { journal, unfinishedJobs, orphanExecutes, readJournal, PROCESS_STARTED } from './journal.mjs';
import { getLimits, setLimits, spentToday, assertBuyLimit, reserveDaily, fromWei } from './limits.mjs';
import { arm, disarm, disarmAll, armStatus, assertArmed, resumeDirect, anyArmed as anyDirectArmed, armedWalletIds as directWalletIds } from './quick/armed.mjs';
import { startPositions, addFourTargets, managed as managedPosition, managedTokens, sourceText } from './quick/positions.mjs';
import { afterBuy, autoApproveStatus } from './quick/autoapprove.mjs';
import {
  noteSent as noteRouteSent, tagPlatform as tagRoutePlatform, listRoutes, pinRoute, unpinRoute, resumePin, importHistory as importRouteHistory,
} from './quick/routebook.mjs';
import { savedArms, clearArm } from './arms.mjs';
import { rememberBundle, publicBounds, startJob, jobStatus } from './quick/oneclick.mjs';
import { gangV3Status, verifyDeployment, enableGangV3, disableGangV3, checkForMainnet, mainnetCtx, pushGangAlert, discoveryCfg, syncChainWatch, v3Config } from './quick/gangv3.mjs';
import { hubSubscriptions } from './wsshub.mjs';
import { listWallets, getWallet, createWallet, deleteWallet, setWalletAddresses, setLastStatus, CLI_ENTRY } from './wallets.mjs';
import { directCall, keepWarm as keepBinanceWarm, warmSockets, MAX_WARM_SOCKETS } from './bawdirect.mjs';
import { authEnabled, authGate, publicHost, publicOrigin, extraSecurityHeaders } from './auth.mjs';
import { injectCacheBusters } from './static_cache.mjs';
import { stripEditionBlocks } from './edition.mjs';
import { registerBinanceIcons, registerHoldingLogo } from './logos.mjs';
import QRCode from 'qrcode';
import { MAX_SLIPPAGE_BPS, assertSlippageBps } from './agent/guard.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT || 8790);
const HOST = '127.0.0.1';

// ---- 本地 API 访问控制（防 CSRF / DNS 重绑定）----
// 每次启动生成随机令牌：页面通过 index.html 的 <meta> 拿到，同机脚本读 .api-token 文件。
// 跨源网页既读不到 index.html（无 CORS），也无法自定义请求头而不触发预检。
const API_TOKEN = randomBytes(32).toString('hex');
const API_TOKEN_BUF = Buffer.from(API_TOKEN);
const TOKEN_FILE = path.join(__dirname, '.api-token');
const LOCAL_HOSTS = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);
// 公网部署（PUBLIC_ORIGIN，见 auth.mjs）时额外允许该域名；本机运行不受影响
const ALLOWED_HOSTS = new Set([...LOCAL_HOSTS, ...(publicHost ? [publicHost] : [])]);
const ALLOWED_ORIGINS = new Set([...[...LOCAL_HOSTS].map((h) => `http://${h}`), ...(publicOrigin ? [publicOrigin] : [])]);
const TOKEN_PLACEHOLDER = '__API_TOKEN__';

const SECURITY_HEADERS = {
  ...extraSecurityHeaders,
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
  'content-security-policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    // blob: 用于代币图标（前端带令牌取回后转成 object URL）
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'none'",
    "frame-ancestors 'none'",
  ].join('; '),
};

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function tokenMatches(value) {
  if (typeof value !== 'string') return false;
  const buf = Buffer.from(value);
  return buf.length === API_TOKEN_BUF.length && timingSafeEqual(buf, API_TOKEN_BUF);
}

/*
 * ---- 浏览器插件（extension/）----
 * 插件的 service worker 带 Origin: chrome-extension://<id> 直接请求本服务。它拿不到页面里的随机 API 令牌（每次启动都换），
 * 所以用一把单独的「配对密钥」（控制台设置页生成，存 config.json extension.key，只显示一次）：
 *   - 只认已配对的插件 Origin（extension.origins）+ 配对密钥（x-ext-key，常量时间比较）；
 *   - 只放行快捷交易需要的接口（EXT_ROUTES），配对 / 预授权 / 改上限 / 转账 / 设置等一律不行；
 *   - 下单仍走同一套链路：买入在「直接买入」已预授权时直接买，否则插件弹确认框（列出全部步骤与上限）后一键执行；卖出一律先确认。
 * 公网模式下插件请求也要过 IP 白名单（auth.mjs），只是不用登录 cookie（插件发不了 SameSite=Strict 的 cookie）。
 */
const EXT_ORIGIN_RE = /^chrome-extension:\/\/[a-p]{32}$/;
const ext = { key: null, keyBuf: null, origins: new Set() };
function setExtensionConfig(c) {
  ext.key = typeof c?.key === 'string' && /^[0-9a-f]{64}$/.test(c.key) ? c.key : null;
  ext.keyBuf = ext.key ? Buffer.from(ext.key) : null;
  ext.origins = new Set((Array.isArray(c?.origins) ? c.origins : []).filter((o) => EXT_ORIGIN_RE.test(String(o))));
}
const EXT_ROUTES = [
  ['GET', /^\/api\/wallets$/],
  ['GET', /^\/api\/quick\/arm$/],
  ['GET', /^\/api\/limits$/],
  ['GET', /^\/api\/gmgn\/holdings$/],
  ['GET', /^\/api\/quick\/positions?$/],
  ['GET', /^\/api\/w\/[^/]+\/lock$/],
  ['GET', /^\/api\/quick\/oneclick\/[0-9a-f]{24}$/],
  ['POST', /^\/api\/quick\/(?:detect|warm|plan|autobuy|oneclick)$/],
];
const isExtOrigin = (req) => EXT_ORIGIN_RE.test(String(req.headers.origin || ''));
getConfig().then((c) => setExtensionConfig(c.extension)).catch(() => {});
/**
 * 插件请求检查：带了 x-ext-key 的才算插件请求（返回 null = 不是插件请求，走原来的令牌 / 登录逻辑）。
 * 2026-10-28 实测：Chrome 插件后台发的 GET 不带 Origin 头（POST 才带），所以 Origin 只在「带了」时核对必须是已配对的插件；
 * 真正的凭据是配对密钥（网页带不了自定义头而不触发预检，预检在这里一律 405）。
 * 返回 { ok, why }：why 是给插件看的具体原因（不再笼统地回「登录已过期」）。
 */
function extensionCheck(req, url) {
  const k = req.headers['x-ext-key'];
  if (k == null) return null;
  if (!ext.keyBuf) return { ok: false, why: '控制台还没有配对插件（设置 → 浏览器插件 → 生成配对密钥）' };
  const origin = req.headers.origin;
  if (origin && !(isExtOrigin(req) && ext.origins.has(origin))) {
    return { ok: false, why: `插件 ID 和配对时填的不一致（请求来自 ${String(origin).slice(0, 60)}，配对的是 ${[...ext.origins].join('、')}）` };
  }
  if (typeof k !== 'string' || k.length !== ext.keyBuf.length || !timingSafeEqual(Buffer.from(k), ext.keyBuf)) {
    return { ok: false, why: '配对密钥不对（可能重新生成过）：在控制台重新生成后填到插件设置页' };
  }
  if (!EXT_ROUTES.some(([m, re]) => m === req.method && re.test(url.pathname))) return { ok: false, why: '插件不能调用这个接口' };
  return { ok: true, why: null };
}
const extensionAllowed = (req, url) => extensionCheck(req, url)?.ok === true;

/** 所有 /api 请求的统一闸门；不通过直接抛 HttpError */
function assertApiRequest(req, url) {
  const origin = req.headers.origin;
  const e = extensionCheck(req, url);
  if (e || isExtOrigin(req)) {
    if (!e) throw new HttpError(403, '插件请求缺少配对密钥');
    if (!e.ok) throw new HttpError(403, e.why);
    if (req.method === 'POST' && String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase() !== 'application/json') {
      throw new HttpError(415, 'content-type must be application/json');
    }
    return;
  }
  if (origin && !ALLOWED_ORIGINS.has(origin)) throw new HttpError(403, 'origin not allowed');
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin' && site !== 'none') throw new HttpError(403, 'cross-site request blocked');
  if (!tokenMatches(req.headers['x-api-token'])) throw new HttpError(401, 'missing or invalid api token');
  if (req.method === 'POST') {
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (type !== 'application/json') throw new HttpError(415, 'content-type must be application/json');
  }
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
};

const queues = new Map();

/** 非 JSON 响应（代币图标）：路由返回它时按原始字节输出 */
class BinaryReply {
  constructor(type, body) {
    this.type = type;
    this.body = body;
  }
}

/** 钱包全链余额（默认 8 秒缓存；后台预热用更长 TTL），概览、代币选择器共用 */
const balanceAskedAt = new Map(); // walletId → 页面最近一次要余额的时间（后台预热只给最近有人看的钱包刷余额）
async function walletBalance(id, ttlMs = 8000, { prewarm = false } = {}) {
  if (!prewarm) balanceAskedAt.set(id, Date.now());
  const key = `balance:${id}`;
  const cached = cacheGet(key);
  if (cached) return cached;
  const r = await bawJson(id, ['wallet', 'balance', '--json']);
  const payload = { tokens: Array.isArray(r.data) ? r.data : [], ms: r.ms };
  cacheSet(key, payload, ttlMs);
  return payload;
}

// ---- 后台预热：定期把已登录钱包的 status/summary/balance 刷进缓存，前端请求几乎总命中缓存，首屏秒开 ----
const PREWARM_INTERVAL_MS = Number(process.env.PREWARM_INTERVAL_MS || 30000);
const PREWARM_TTL_MS = 90000; // 比预热间隔长，保证两次预热之间缓存不过期
const IDLE_PREWARM_MS = 5 * 60 * 1000;
let lastIdlePrewarm = 0;

/*
 * 服务是不是「在用」：有任何自动化在跑（预授权 / 监听），或者最近 ACTIVE_MS 内页面 / 插件调过接口。
 * 闲置时：币安保活不发、钱包状态 5 分钟查一次、报价币池子预热跳过。交易相关的读请求不受影响（本来就是有人点了才发）。
 */
const ACTIVE_MS = 10 * 60 * 1000;
let lastUserApiAt = Date.now();
const PASSIVE_API = new Set(['/api/automation', '/api/gangv3/status', '/api/metrics', '/api/version', '/api/system/background', '/api/sniper/state']);
function serviceBusy() {
  if (Date.now() - lastUserApiAt < ACTIVE_MS) return true;
  try {
    return Boolean(xferStatus().armed || anyDirectArmed() || features.busy?.());
  } catch { return true; }
}
/**
 * 到币安要保持几条热连接（bawdirect.keepWarm 每轮调用）：
 *   - 自动化会自己下单的钱包数（狙击 / 自动打新 / Four 自动 / 直接买入）：同一个新币各钱包并行预览，每个钱包占一条；
 *   - 最近 10 分钟有人在用页面 / 插件：插件多钱包一键买卖会同时发每个钱包的请求，按已配置的钱包总数算；
 *   - 再多留 1 条：并行处理的另一个新币、保活请求本身不跟下单抢连接。
 * 最少 1 条，最多 MAX_WARM_SOCKETS（6）条。发射后转移不算（不抢时间）。
 */
async function binanceSocketsWanted() {
  const ids = new Set(directWalletIds());
  for (const id of features.walletIds?.() || []) ids.add(id);
  let n = ids.size;
  if (Date.now() - lastUserApiAt < ACTIVE_MS) n = Math.max(n, (await listWallets()).length);
  return Math.min(MAX_WARM_SOCKETS, Math.max(1, n + (n ? 1 : 0)));
}
const BALANCE_PREWARM_MS = 10 * 60 * 1000;
let prewarming = false;

/** 预热单个钱包：状态始终刷新；仅已登录（CONNECTED）才刷余额，避免对未登录钱包空跑 */
async function prewarmWallet(id) {
  try {
    const wallet = await getWallet(id);
    let addresses = wallet?.addresses || [];
    const r = await bawJson(id, ['wallet', 'status', '--json']);
    const status = r.data.status;
    // 登录账号核对：刚变成已登录（可能是在 wrapper 里重登的）/ 启动后第一次 / 每 10 分钟一次
    const due = !addresses.length || wallet?.lastStatus?.status !== 'CONNECTED'
      || Date.now() - (identityCheckedAt.get(id) || 0) > IDENTITY_CHECK_MS;
    if (status === 'CONNECTED' && due) {
      try {
        await checkWalletIdentity(id);
        addresses = (await getWallet(id))?.addresses || addresses;
      } catch { /* 地址取不到不致命，下一轮再查 */ }
    }
    cacheSet(`status:${id}`, { status }, PREWARM_TTL_MS);
    cacheSet(`summary:${id}`, { status, addresses }, PREWARM_TTL_MS);
    await setLastStatus(id, status);
    // 余额只是展示用：最近 10 分钟有人看过这个钱包的余额才预热（没人看就不每 30 秒 spawn 一次 CLI），之后打开页面现查
    if (status === 'CONNECTED' && Date.now() - (balanceAskedAt.get(id) || 0) < BALANCE_PREWARM_MS) {
      await walletBalance(id, PREWARM_TTL_MS, { prewarm: true });
    }
  } catch { /* 未登录 / 离线：本轮跳过，不污染日志 */ }
}

/** 逐个钱包预热（串行，避免同时 spawn 多个 baw），带并发保护 */
async function prewarmAll() {
  if (prewarming) return;
  prewarming = true;
  try {
    const list = await listWallets();
    for (const w of list) await prewarmWallet(w.id);
  } catch { /* 忽略 */ } finally {
    prewarming = false;
  }
}

// ---- 登录账号核对：防止扫错码（2026-10-27 币安升级后重登，两个钱包登反，狙击全部 351808） ----
const IDENTITY_CHECK_MS = 10 * 60 * 1000;
const identityCheckedAt = new Map(); // walletId → 上次核对时间

/**
 * 读会话实际的地址，和 wallets.json 里缓存的 EVM 地址比对。
 * 不一致：以会话为准更新地址、解除全部自动化预授权（它们是按旧地址确认的）、写日志并推网页告警。
 * 返回变化明细；没变化返回 null。
 */
async function checkWalletIdentity(id) {
  const wallet = await getWallet(id);
  if (!wallet) return null;
  const before = wallet.evm || null;
  const r = await bawJson(id, ['wallet', 'address', '--json']);
  await setWalletAddresses(id, r.data.addresses);
  identityCheckedAt.set(id, Date.now());
  const after = (await getWallet(id))?.evm || null;
  invalidateWalletCache(id);
  if (!before || !after || before.toLowerCase() === after.toLowerCase()) return null;
  const twin = (await listWallets()).find((w) => w.id !== id && w.evm && w.evm.toLowerCase() === after.toLowerCase());
  const change = { walletId: id, name: wallet.name, from: before, to: after, sameAs: twin?.id || null };
  disarmEverything('identity-changed');
  journal('wallet.identity-changed', change);
  const text = `「${wallet.name}」登录的币安账号变了：原地址 ${before}，现在是 ${after}`
    + `${twin ? `（和「${twin.name}」是同一个账号，很可能扫错了码）` : ''}。已解除全部自动化预授权，核对无误后需要重新开启`;
  pushGangAlert('identity', text, { kind: 'wallet', walletId: id });
  console.warn(`[identity] ${text}`);
  return change;
}

/** 解除全部自动化预授权（总开关 / 登录账号变更共用） */
function disarmEverything(reason) {
  // 每一项单独兜住：任何一个引擎出错都不能让后面的漏解除（总开关 / 账号变更必须全部执行完）
  const errors = [];
  for (const [name, fn] of [['direct', () => disarmAll(reason)], ['autoxfer', () => disarmXfer(reason)], ['features', () => features.disarm?.(reason)]]) {
    try { fn(); } catch (err) { errors.push(`${name}: ${err.message}`); }
  }
  journal('automation.disarm-all', { reason, ...(errors.length ? { errors } : {}) });
  if (errors.length) console.error(`[disarm-all] 部分解除出错：${errors.join('；')}`);
}

function invalidateWalletCache(id) {
  for (const prefix of ['summary', 'settings', 'balance', 'status']) cacheInvalidate(`${prefix}:${id}`);
}

async function runBaw(walletId, args, timeoutMs = 120000) {
  const wallet = await getWallet(walletId);
  if (!wallet) throw new Error(`unknown wallet: ${walletId}`);

  const previous = queues.get(walletId) ?? Promise.resolve();
  const task = previous.then(() => new Promise((resolve, reject) => {
    const started = Date.now();
    const child = spawn(process.execPath, [CLI_ENTRY, ...args], {
      cwd: ROOT,
      windowsHide: true,
      env: { ...process.env, BINANCE_BAW_DIR: path.join(ROOT, wallet.dir) },
    });

    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error(`timeout after ${timeoutMs}ms: ${args.join(' ')}`));
    }, timeoutMs);

    child.stdout.on('data', (d) => { stdout += d; });
    child.stderr.on('data', (d) => { stderr += d; });
    child.on('error', (err) => { clearTimeout(timer); reject(err); });
    child.on('close', (code) => {
      clearTimeout(timer);
      recordCli(args.slice(0, 2).join(' '), Date.now() - started, code === 0);
      let parsed = null;
      try { parsed = JSON.parse(stdout); } catch { /* keep raw */ }
      resolve({
        code,
        ms: Date.now() - started,
        json: parsed,
        stdout: parsed ? undefined : stdout.trim(),
        stderr: stderr.trim() || undefined,
      });
    });
  }));

  queues.set(walletId, task.catch(() => {}));
  return task;
}

/**
 * contract-call preview / execute：默认直连币安（bawdirect.mjs，常驻长连接，每次省约 0.5~0.7 秒），
 * config.json 里 bawDirect=false 时一律走 CLI。
 * 退回 CLI 的规则：
 *   - 请求还没发出去（stage=local：会话读不到 / 解密失败）→ preview 和 execute 都退回 CLI；
 *   - 请求可能已到币安（stage=network）→ 只有 preview 退回 CLI；execute 绝不重发，按「可能已广播」抛给 doExecute；
 *   - 币安明确答复了错误（stage=api）→ 直接抛出，不重试。
 */
const execLocks = new Map(); // walletId -> 队尾 Promise：同一钱包的直连 execute 串行（与 CLI 路径的按钱包排队一致；preview 仍并行）

async function contractCall(walletId, kind, body, cliArgs, timeoutMs, cliTimeoutMs = 180000) {
  if ((await getConfig()).bawDirect !== false) {
    const wallet = await getWallet(walletId);
    if (!wallet) throw new Error(`unknown wallet: ${walletId}`);
    let unlock = () => {};
    if (kind === 'execute') {
      const prev = execLocks.get(walletId) || Promise.resolve();
      const mine = new Promise((r) => { unlock = r; });
      const tail = prev.then(() => mine);
      execLocks.set(walletId, tail);
      await prev;
      const done = unlock;
      unlock = () => { done(); if (execLocks.get(walletId) === tail) execLocks.delete(walletId); };
    }
    try {
      const r = await directCall(path.join(ROOT, wallet.dir), kind, body, { timeoutMs });
      recordCli(`direct ${kind}`, r.ms, true);
      return r;
    } catch (err) {
      recordCli(`direct ${kind}`, err.ms ?? 0, false);
      const fallback = err.stage === 'local' || (kind === 'preview' && err.stage === 'network');
      if (!fallback) throw err;
      journal('direct.fallback', { walletId, kind, stage: err.stage, error: err.message });
    } finally {
      unlock(); // 退回 CLI 后由 runBaw 的按钱包队列继续保证串行
    }
  }
  return bawJson(walletId, cliArgs, cliTimeoutMs);
}

async function bawJson(walletId, args, timeoutMs) {
  const result = await runBaw(walletId, args, timeoutMs);
  if (!result.json) {
    throw new Error(`baw did not return JSON (exit ${result.code}): ${result.stderr || result.stdout || 'no output'}`);
  }
  if (!result.json.success) {
    const e = result.json.error || {};
    throw new Error(`[${e.name || 'ERROR'}] ${e.message || JSON.stringify(result.json)}`);
  }
  return { data: result.json.data, ms: result.ms };
}

function json(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  });
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 1e6) {
        reject(new HttpError(413, 'body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (err) { reject(new Error('invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

const CHAINS = new Set(['56', '1', '8453', '42161', '137']);
const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;

// ---- 传给 baw CLI 的参数一律严格白名单校验，杜绝 `--xxx` 形式的参数注入 ----
function assertAddress(value, field) {
  if (typeof value !== 'string' || !ADDR_RE.test(value)) throw new Error(`invalid ${field}: 需要 0x + 40 位 hex`);
  return value;
}

/** 十进制金额字符串（不接受科学计数法 / 负数 / NaN），原样传给 CLI，避免 Number 精度丢失 */
function assertAmount(value, field = 'amount') {
  const s = typeof value === 'number' ? String(value) : String(value ?? '').trim();
  if (!/^\d{1,30}(\.\d{1,30})?$/.test(s) || !/[1-9]/.test(s)) throw new Error(`invalid ${field}: 需要大于 0 的十进制数`);
  return s;
}

function assertWei(value, field = 'value') {
  const s = String(value ?? '0').trim();
  if (!/^\d{1,78}$/.test(s)) throw new Error(`invalid ${field}: 需要整数 wei`);
  return s;
}

function assertHexData(value, field = 'inputData') {
  if (typeof value !== 'string' || !/^0x([0-9a-fA-F]{2}){0,10000}$/.test(value)) throw new Error(`invalid ${field}: 需要 0x 开头的偶数位 hex`);
  return value;
}

function assertToken(value, field) {
  // 首字符必须是字母数字：不可能被 CLI 解析成 `--flag`
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/.test(value)) throw new Error(`invalid ${field}`);
  return value;
}

const ORDER_POLL_MS = 1500;
const ORDER_WAIT_MS = 20000;

/**
 * 轮询市价单直到出现 txHash 或终态（FINISHED / FAILED）。
 * 以 Date.now() 截止时间为准（不累计 sleep），超时返回最后一次查询结果（可能仍是 PENDING）。
 */
async function waitMarketOrder(walletId, orderId) {
  const deadline = Date.now() + ORDER_WAIT_MS;
  let last = null;
  while (Date.now() < deadline) {
    try {
      const r = await bawJson(walletId, ['market-order', 'list', '--orderId', orderId, '--json'], 15000);
      last = r.data?.list?.find((o) => String(o.orderId) === orderId) || last;
    } catch (err) {
      console.warn(`[swap] 查询订单 ${orderId} 失败：${err.message}`);
    }
    if (last && (last.status === 'FAILED' || (last.status === 'FINISHED' && last.txHash))) return last;
    const wait = Math.min(ORDER_POLL_MS, deadline - Date.now());
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  }
  return last;
}

/** 兑换滑点：百分比，必须显式给出，且不超过护栏上限 */
function assertSwapSlippage(value) {
  const s = String(value ?? '').trim();
  if (!/^\d+(\.\d+)?$/.test(s) || Number(s) <= 0) throw new Error('请显式选择滑点（不提供 auto / 默认值）');
  if (Number(s) * 100 > MAX_SLIPPAGE_BPS) throw new Error(`滑点 ${s}% 超过安全上限 ${MAX_SLIPPAGE_BPS / 100}%`);
  return s;
}

// ---- preview 记录：execute 只能执行本服务为该钱包生成、未过期、未使用过的 preview ----
const PREVIEW_TTL_MS = 10 * 60 * 1000;
const previews = new Map();

function rememberPreview(requestId, record) {
  const now = Date.now();
  for (const [k, v] of previews) if (now - v.at > PREVIEW_TTL_MS) previews.delete(k);
  previews.set(requestId, { ...record, at: now });
}

function takePreview(requestId, walletId) {
  const rec = previews.get(requestId);
  if (!rec) throw new Error('未知的 requestId：请先在本控制台 preview');
  if (rec.walletId !== walletId) throw new Error('requestId 不属于该钱包');
  if (Date.now() - rec.at > PREVIEW_TTL_MS) {
    previews.delete(requestId);
    throw new Error('preview 已过期，请重新预览');
  }
  previews.delete(requestId); // 一次性
  return rec;
}

/** 钱包的 EVM 地址（以 baw CLI 返回为准，缓存在 wallets.json） */
async function walletEvm(walletId) {
  let wallet = await getWallet(walletId);
  if (!wallet) throw new Error(`unknown wallet: ${walletId}`);
  if (!wallet.evm) {
    const r = await bawJson(walletId, ['wallet', 'address', '--json']);
    await setWalletAddresses(walletId, r.data.addresses);
    wallet = await getWallet(walletId);
  }
  if (!wallet?.evm || !ADDR_RE.test(wallet.evm)) throw new Error('无法确定该钱包的 EVM 地址');
  return wallet.evm;
}

/** 规划接口里的 wallet 地址必须属于本机某个钱包：它会被写进 calldata 作为收款人 */
async function assertOwnAddress(value) {
  const address = assertAddress(value, 'wallet');
  const list = await listWallets();
  const own = list.some((w) => (w.evm && w.evm.toLowerCase() === address.toLowerCase())
    || (w.addresses || []).some((a) => String(a.address || '').toLowerCase() === address.toLowerCase()));
  if (!own) throw new Error('wallet 地址不属于本机任何钱包（请先在控制台加载该钱包）');
  return address;
}

function assertString(value, field, max = 200) {
  if (typeof value !== 'string' || !value || value.length > max) {
    throw new Error(`invalid ${field}`);
  }
  return value;
}

/*
 * 版本（edition）：全量版带 webui/features/snipe.mjs（狙击 / 打新 / 新部署发现），轻量版发布包里没有这个文件。
 * 找不到就是轻量版：features 只剩空钩子，其余功能（快捷交易、V2 / V3 / Four / Flap 手动买卖、持仓、转移、发射后转移…）不受影响。
 * 只在「文件不存在」时降级；文件在但加载出错照常抛出（不能悄悄变成轻量版）。
 */
const LITE_FEATURES = { edition: 'lite', routes: [] };
let features = LITE_FEATURES;
async function loadFeatures() {
  if (process.env.AIBOT_EDITION === 'lite') return features; // 开发时在完整仓库里试轻量版
  try {
    const mod = await import('./features/snipe.mjs');
    features = await mod.install({
      walletEvm, listWallets, doPreview, doExecute, previewStep, buildQuickPlan, startQuickJob, jobStatus,
      flatQuickSteps, rememberBundle, publicBounds, assertAddress, assertString,
    });
  } catch (err) {
    // 只认「功能包文件本身不存在」；功能包在、但它依赖的文件缺了（打包出错）要报错，不能悄悄变成轻量版
    if (err?.code !== 'ERR_MODULE_NOT_FOUND' || !/features[\\/]snipe\.mjs'? imported from/.test(String(err.message))) throw err;
    features = LITE_FEATURES;
  }
  return features;
}
const EDITION = () => features.edition;

/**
 * 后台任务清单（只读）：WSS 订阅取自 wsshub 的实时登记；HTTP 定时请求按代码里的固定间隔列出，active 表示现在是否在跑。
 * 新增定时任务时在这里补一行，方便判断哪些可以停。
 */
async function backgroundTasks() {
  const xfer = xferStatus();
  const wallets = await listWallets();
  const busy = serviceBusy();
  const v3 = await v3Config().catch(() => null);
  const extra = (await features.background?.()) || { http: [], browser: [], discovery: null, engines: {} };
  const http = [
    { name: '币安连接保活', target: `币安 API（公开接口 networks/active），当前保持 ${warmSockets() || 0} 条热连接`, every: '15 秒（闲置时不发）', active: busy, why: '保持 HTTPS 长连接，下单少一次握手（服务器实测约 76ms）；条数 = 自动化用到的钱包数 + 1（有人在用页面 / 插件时按钱包总数），最多 6 条' },
    { name: '钱包登录状态检查', target: `币安 CLI（${wallets.length} 个钱包串行）`, every: busy ? '30 秒' : '5 分钟（闲置）', active: true, why: '掉线时顶部标红、自动化健康度；顺带每 10 分钟核对登录账号。余额只给最近 10 分钟看过的钱包预热，其余打开页面时现查' },
    { name: '报价币池子预热', target: '后台节点（NodeReal）→ 公共节点', every: '20 分钟（闲置时跳过）', active: busy, why: '报价币库存的池子地址缓存不过期，快捷买入少等几秒' },
    { name: 'gang V3 部署复核', target: 'BSC 公共节点（只读）', every: '最多 10 分钟一次（交易 V3 或页面查询 V3 状态时触发）', active: Boolean(v3), why: '链上状态变了立即视为停用（地址见 gangv3.mjs BUILTIN_V3）' },
    ...extra.http,
    { name: '发射后转移：V3 / 打新发射检查', target: '后台节点（NodeReal）→ 公共节点（转账本身走交易节点）', every: '15 秒', active: Boolean(xfer.armed), why: '这两类没有可订阅的发射事件' },
    { name: '发射后转移：V2 保险检查', target: '后台节点（NodeReal）→ 公共节点', every: '2 分钟（WSS 断线时 15 秒）', active: Boolean(xfer.armed), why: '防 WSS 漏推毕业事件' },
  ];
  const browser = [
    { name: '顶部状态条', api: '/api/automation', every: '4 秒（页面在后台时暂停）' },
    ...extra.browser,
    { name: '性能指标', api: '/api/metrics', every: '30 秒' },
    { name: '后端版本检查', api: '/api/version', every: '60 秒' },
  ];
  return {
    edition: EDITION(),
    wss: { ...hubStatus(), subs: hubSubscriptions() },
    // 后台 / 非即时读请求的分流：public = 公共节点完成的请求数，fallback = 公共节点都不行、回落到付费节点的次数
    publicRpc: await publicRpcStats(),
    http,
    browser,
    discovery: extra.discovery,
    engines: { ...extra.engines, autoXfer: Boolean(xfer.armed) },
  };
}

/*
 * 交易台「自动化事件」的历史部分：V2 / V3 狙击、自动打新、发射后转移的事件只在内存里，服务一重启就清空，
 * 而 Four 的事件落盘在 sniper.json —— 结果重启后只剩几天前的 Four 记录（2026-10-28 发现）。
 * 本进程启动之前的部分改从执行日志重建（journal.jsonl，最近 3 天），启动之后仍用内存事件，两段不重叠。
 */
const HISTORY_MS = 3 * 86400 * 1000;
const JOURNAL_EVENT = {
  gangsnipe: 'V2', gangsnipe3: 'V3', fairauto: '打新', autoxfer: '转移',
};
let historyCache = { at: 0, rows: [] };
async function journalHistory() {
  if (Date.now() - historyCache.at < 60000) return historyCache.rows;
  const since = PROCESS_STARTED - HISTORY_MS;
  const rows = [];
  for (const r of await readJournal(20000, { withRotated: true })) {
    const t = Date.parse(r.at);
    if (!(t >= since && t < PROCESS_STARTED)) continue;
    const [mod, kind] = String(r.type).split('.');
    const src = JOURNAL_EVENT[mod];
    if (!src) continue;
    const short = (a) => (a ? `${String(a).slice(0, 10)}…` : '');
    const bnb = (w) => (w ? `${fromWei(BigInt(w))} BNB` : '');
    let type = kind;
    let text;
    switch (kind) {
      case 'buy': text = `${r.symbol || ''} ${short(r.token)}：${r.fast ? '极速买入' : '发起买入'} ${bnb(r.spendWei)} · ${r.steps || ''}${r.ms != null ? ` · 发现→执行 ${r.ms}ms` : ''}`; break;
      case 'mint': text = `${short(r.token)}：打新 ${r.shares} 份 ${bnb(r.valueWei)}`; break;
      case 'sent': text = `${r.walletId}：已转 ${short(r.token)} → ${short(r.to)}`; break;
      case 'skip': case 'fail': text = `${short(r.token)}${r.walletId ? ` · ${r.walletId}` : ''}：${r.error || ''}`; break;
      case 'unbought': type = 'refund'; text = `${short(r.token)}：买入没有发出${r.refundedBudget ? '，预算已退回' : ''}`; break;
      case 'arm': text = `已预授权：钱包 ${(r.walletIds || [r.walletId]).filter(Boolean).join('、')}${r.maxPerTokenBnb ? `，单币 ≤ ${r.maxPerTokenBnb} BNB，总预算 ${r.totalBnb} BNB` : ''}`; break;
      case 'resume': text = `服务重启后已恢复预授权${r.spentBnb ? `（已花 ${r.spentBnb} BNB）` : ''}`; type = 'arm'; break;
      case 'disarm': text = `已解除预授权（${r.reason || ''}）`; break;
      case 'drop': text = `钱包 ${r.walletId} 已移出：${r.reason || ''}`; break;
      case 'token': text = `加入监控：${short(r.token)}`; break;
      case 'autosell': type = r.ok ? 'sell' : 'fail'; text = `${short(r.token)}：自动卖出${r.ok ? ` ${fromWei(BigInt(r.amount || '0'))} 枚` : `失败：${r.error || ''}`}`; break;
      default: continue;
    }
    rows.push({ src, at: r.at, type, text: `${text}（重启前记录）`, token: r.token || null, txHash: r.txHash || null });
  }
  historyCache = { at: Date.now(), rows: rows.reverse() };
  return historyCache.rows;
}

/*
 * 买入记录：从执行日志汇总某个钱包最近 3 天买过的代币（快捷交易 / 一键 / 直接买入 / 狙击 / 极速狙击 / 自动打新），
 * 按代币合并，附当前链上余额，方便在交易台一键选中去卖出。只读：日志 + balanceOf。
 */
const BUY_RECORD_MS = 3 * 86400 * 1000;
const BUY_RECORD_MAX = 30;
const erc20BalAbi = parseAbi(['function balanceOf(address) view returns (uint256)', 'function decimals() view returns (uint8)']);
async function buyRecords(walletId) {
  const wallet = await walletEvm(walletId);
  const since = Date.now() - BUY_RECORD_MS;
  const rows = await readJournal(20000, { withRotated: true });
  const ended = new Map(); // jobId → state
  const jobValue = new Map(); // jobId → 计入的 BNB（oneclick.start 的 maxValueWei；用报价币库存付款时是 0）
  for (const r of rows) if (r.type === 'oneclick.end' && r.jobId) ended.set(r.jobId, r.state);
  const byToken = new Map();
  const add = (token, at, { platform, spentWei = 0n, symbol = null, txHash = null, src }) => {
    if (!ADDR_RE.test(String(token || ''))) return;
    const k = String(token).toLowerCase();
    const e = byToken.get(k) || { token, firstAt: at, lastAt: at, count: 0, spentWei: 0n, platform, symbol: null, txHash: null, src };
    e.count += 1;
    e.spentWei += BigInt(spentWei || 0);
    if (at >= e.lastAt) Object.assign(e, { lastAt: at, platform: platform || e.platform, txHash: txHash || e.txHash, src });
    if (at < e.firstAt) e.firstAt = at;
    if (symbol) e.symbol = symbol;
    byToken.set(k, e);
  };
  const SNIPE_SRC = { gangsnipe: '狙击 V2', gangsnipe3: '狙击 V3' };
  for (const r of rows) {
    const at = Date.parse(r.at);
    if (!(at > since) || r.walletId !== walletId) continue;
    const [mod, kind] = String(r.type).split('.');
    if (r.type === 'oneclick.start') {
      // 只算买入、而且最终完成的任务；库存备货 / 授权（platform=inventory）、转账不算
      if (!(r.steps || []).includes('buy') || r.platform === 'inventory' || ended.get(r.jobId) !== 'done') continue;
      jobValue.set(r.jobId, BigInt(r.maxValueWei || 0));
      add(r.token, at, { platform: r.platform, spentWei: r.maxValueWei || 0, src: '交易台' });
    } else if (SNIPE_SRC[mod] && kind === 'buy') {
      // 普通狙击的买入会再写一条 oneclick.start（同一个 jobId）：只在极速（没有 jobId）时计次，避免重复
      // 只补上 symbol 和来源（那条 oneclick.start 已经按「是否完成」计过次；任务失败的不会出现在 byToken 里）
      if (r.jobId) {
        const e = byToken.get(String(r.token).toLowerCase());
        if (e && ended.get(r.jobId) === 'done') {
          // 金额以狙击记的 BNB 等值为准（用报价币库存付款时任务里记的是 0），替换掉那条任务计入的数
          e.spentWei += BigInt(r.spendWei || 0) - (jobValue.get(r.jobId) || 0n);
          Object.assign(e, { symbol: r.symbol || e.symbol, src: SNIPE_SRC[mod] });
        }
        continue;
      }
      add(r.token, at, { platform: mod === 'gangsnipe3' ? 'gangv3' : 'gang', spentWei: r.spendWei, symbol: r.symbol, txHash: r.txHash, src: SNIPE_SRC[mod] });
    } else if (r.type === 'fairauto.mint') {
      add(r.token, at, { platform: 'fair', spentWei: r.valueWei, txHash: r.txHash, src: '自动打新' });
    }
  }
  const list = [...byToken.values()].sort((a, b) => b.lastAt - a.lastAt).slice(0, BUY_RECORD_MAX);
  // 余额 / 名称：展示用，走公共节点；单个读失败只影响那一行
  return runBackground(async () => Promise.all(list.map(async (e) => {
    let balance = null;
    let decimals = 18;
    let symbol = e.symbol;
    try {
      const [bal, meta] = await Promise.all([
        rpcFor('56', 'eth_call', [{ to: e.token, data: encodeFunctionData({ abi: erc20BalAbi, functionName: 'balanceOf', args: [wallet] }) }, 'latest'])
          .then((d) => decodeFunctionResult({ abi: erc20BalAbi, functionName: 'balanceOf', data: d })),
        tokenMeta(e.token).catch(() => null),
      ]);
      balance = bal;
      if (meta) { decimals = meta.decimals ?? 18; symbol = symbol || meta.symbol; }
    } catch { /* 读不到余额 */ }
    return {
      token: e.token, symbol: symbol || '?', platform: e.platform, src: e.src, count: e.count,
      spentBnb: fromWei(e.spentWei), firstAt: new Date(e.firstAt).toISOString(), lastAt: new Date(e.lastAt).toISOString(), txHash: e.txHash,
      balance: balance == null ? null : balance.toString(), decimals,
      balanceText: balance == null ? null : (Number(balance) / 10 ** decimals).toLocaleString('en-US', { maximumFractionDigits: 4 }),
    };
  })));
}

const RECENT_FAIL_MS = 10 * 60 * 1000;
const OK_EVENT_TYPES = new Set(['buy', 'bought', 'done', 'mint', 'sent']);

/** 全局状态条：每项自动化开着没有、到什么时候、花了多少；四路事件按时间合并（只读，内存数据，很轻） */
async function automationStatus() {
  const wallets = await listWallets();
  const limits = await getLimits();
  const perWallet = await Promise.all(wallets.map(async (w) => ({
    id: w.id, name: w.name, spentToday: fromWei(await spentToday(w.id)), direct: armStatus(w.id),
  })));
  const xfer = xferStatus();
  const brief = (s) => ({
    armed: s.armed, standby: s.standby, today: s.today,
    maxPerDay: s.arm?.maxPerDay ?? null, spentBnb: s.arm?.spentBnb ?? null, totalBnb: s.arm?.totalBnb ?? null,
    expiresAt: s.arm?.expiresAt ?? null, wallets: (s.arm?.wallets || []).map((x) => x.id),
  });
  // 时间统一成 ISO（Four 的事件时间是毫秒数字，其它是 ISO 字符串）；Four 的「参数已更新」很长又不是交易事件，不进合并流
  const iso = (t) => { const d = new Date(typeof t === 'string' && /^\d+$/.test(t) ? Number(t) : t); return Number.isNaN(d.getTime()) ? null : d.toISOString(); };
  const ev = (src, list, textKey = 'text') => (list || []).slice(0, 40).filter((e) => e.type !== 'config').map((e) => ({
    src, at: iso(e.at), type: e.type, text: e[textKey] ?? e.text ?? e.msg ?? '', token: e.token || null, txHash: e.txHash || null,
  }));
  const history = await journalHistory().catch(() => []);
  const wss = hubStatus();
  // 运行健康度（只对开着的自动化算）：err 红 = 一定会失败或刚失败过；warn 橙 = 能跑但打了折扣；null = 正常
  const statusOf = new Map(wallets.map((w) => [w.id, w.lastStatus?.status || null]));
  const nameOf = (id) => wallets.find((w) => w.id === id)?.name || id;
  const health = (list, walletIds = [], dropped = [], failTypes = ['fail']) => {
    const off = walletIds.filter((id) => statusOf.get(id) && statusOf.get(id) !== 'CONNECTED');
    if (off.length) return { level: 'err', why: `钱包未登录：${off.map(nameOf).join('、')}（这些钱包的交易都会失败）` };
    // 最近一条结果事件是失败、且在 10 分钟内 → 红；之后有过成功就不算
    for (const e of list || []) {
      if (OK_EVENT_TYPES.has(e.type)) break;
      if (failTypes.includes(e.type)) {
        if (Date.now() - Date.parse(iso(e.at)) < RECENT_FAIL_MS) return { level: 'err', why: `最近一笔失败：${String(e.text ?? e.msg ?? '').slice(0, 140)}` };
        break;
      }
    }
    if (dropped.length) return { level: 'warn', why: `已移出：${dropped.map(nameOf).join('、')}` };
    if (!wss.connected) return { level: 'warn', why: 'WSS 未连接：改用 HTTP 轮询，发现新币会慢几秒' };
    return null;
  };
  const snipeHealth = (s) => (s.armed && !s.standby
    ? health(s.events, (s.arm?.wallets || []).map((x) => x.id), (s.arm?.wallets || []).filter((x) => !x.active).map((x) => x.id))
    : null);
  // 狙击 / Four / 自动打新（全量版功能包）：轻量版没有这三项，前端按 edition 不画对应的胶囊
  const f = features.automation?.({ brief, ev, health, snipeHealth }) || { events: [] };
  const events = [...f.events, ...ev('转移', xfer.events), ...history.slice(0, 60)]
    .filter((e) => e.at)
    .sort((a, b) => String(b.at).localeCompare(String(a.at)))
    .slice(0, 60);
  return {
    edition: EDITION(),
    limits,
    wallets: perWallet.map((w) => ({ ...w, status: statusOf.get(w.id), health: w.direct?.armed ? health([], [w.id]) : null })),
    ...(f.snipe ? { snipe: f.snipe, four: f.four, fairAuto: f.fairAuto } : {}),
    autoXfer: {
      armed: xfer.armed, tokens: xfer.tokens.length, done: xfer.arm?.doneCount ?? 0, expiresAt: xfer.arm?.expiresAt ?? null, target: xfer.arm?.target?.name ?? null,
      health: xfer.armed ? health(xfer.events, (xfer.arm.wallets || []).map((x) => x.id)) : null,
    },
    wss,
    events,
  };
}

// Four 狙击的其它接口在 features/snipe.mjs（全量版）；bStock 授权是手动交易也要用的，两个版本都有
const sniperRoutes = [
  {
    method: 'POST',
    match: /^\/api\/sniper\/approve$/,
    // 预授权 bStock 计价币给 Core：构造 approve 并 preview（走受控 preview/execute，用户确认后执行）
    async handler(_req, _m, _url, body) {
      const walletId = assertString(body.walletId, 'walletId', 64);
      const quote = ['bncb', 'nvdab'].includes(body.quote) ? body.quote : null;
      if (!quote) throw new Error('quote 必须是 bncb 或 nvdab（WBNB 底池用 BNB 付款，无需授权）');
      const amountWei = tokensToWei(String(body.amount ?? '0'));
      const q = QUOTES[quote];
      const tx = buildApproveTx(q.addr, amountWei);
      const from = await walletEvm(walletId);
      const r = await doPreview(walletId, { chainId: '56', from, to: tx.to, value: tx.value, inputData: tx.inputData });
      return { preview: r.preview, ms: r.ms, quote: q.symbol, quoteAddr: q.addr, amount: String(body.amount), spender: OPENFOUR.core };
    },
  },
];

// ---- Four 内盘手动交易：读状态 / 生成买入计划 / 生成卖出计划 ----
// 只做只读计算 + contract-call preview（会记录 requestId），广播仍走 /api/w/:id/execute（需 confirm）
function previewExecutable(preview) {
  const sim = preview?.simulationResult || {};
  return Boolean(preview?.requestId) && !sim.simulationErrorDetail
    && (!sim.simulationCode || /^0+$/.test(String(sim.simulationCode)));
}

/*
 * 预先估算 gasLimit 传给 baw preview：以钱包身份 eth_estimateGas，×1.3 + 20000 留余量。
 * 2026-10-27 实测 A/B（同一笔 gang 买入，各 4 次）：带 gasLimit 930~961ms，不带 876~1051ms，没有可测差异，
 * 而估算本身多一次 RPC、给少了还会 out-of-gas。默认关闭；QUICK_PREVIEW_GAS=1 可开启。
 */
const PREVIEW_GAS = process.env.QUICK_PREVIEW_GAS === '1';
async function estimateGasLimit(from, tx) {
  if (!PREVIEW_GAS) return null;
  try {
    const hex = await rpcFor('56', 'eth_estimateGas', [{ from, to: tx.to, value: `0x${BigInt(tx.value || 0).toString(16)}`, data: tx.inputData }]);
    const est = Number(BigInt(hex));
    const gas = Math.ceil(est * 1.3) + 20000;
    return gas >= 21000 && gas <= 15000000 ? gas : null;
  } catch {
    return null;
  }
}

async function previewStep(walletId, from, step) {
  // 调用方给了固定 gasLimit（狙击极速通道）就原样用，币安按它模拟、上链；否则按 QUICK_PREVIEW_GAS 决定是否估算
  const gasLimit = step.gasLimit || await estimateGasLimit(from, step.tx);
  const r = await doPreview(walletId, {
    chainId: '56', from, to: step.tx.to, value: step.tx.value, inputData: step.tx.inputData,
    ...(gasLimit ? { gasLimit } : {}),
  });
  const sim = r.preview?.simulationResult || {};
  const ok = previewExecutable(r.preview);
  const raw = sim.simulationErrorDetail || sim.simulationCode || '';
  const reason = ok ? '' : (decodeAgentError(raw) || raw || '模拟失败（未返回原因）');
  return {
    kind: step.kind, label: step.label,
    to: step.tx.to, value: String(step.tx.value), inputData: step.tx.inputData,
    preview: r.preview, ok, error: reason, ms: r.ms, gasLimit,
  };
}

function planPublic(plan) {
  return {
    token: plan.token, symbol: plan.symbol, native: plan.native, unit: plan.unit,
    quoteAsset: plan.quoteAsset, summary: plan.summary, note: plan.note || null,
  };
}

const fourTradeRoutes = [
  {
    method: 'POST',
    match: /^\/api\/four\/inspect$/,
    async handler(_req, _m, _url, body) {
      const token = assertAddress(body.token, 'token');
      const walletId = assertString(body.walletId, 'walletId', 64);
      const from = await walletEvm(walletId);
      return { walletId, from, ...(await inspectToken(token, from)) };
    },
  },
  {
    // 钱包持有的 Four 代币（只读）：候选来自 baw 余额 + 狙击买入记录 + 前端补充 CA，逐个链上核实
    method: 'POST',
    match: /^\/api\/four\/holdings$/,
    async handler(_req, _m, _url, body) {
      const walletId = assertString(body.walletId, 'walletId', 64);
      const from = await walletEvm(walletId);
      if (body.refresh) cacheInvalidate(`balance:${walletId}`);
      const skip = new Set([...Object.values(QUOTES).map((q) => q.addr.toLowerCase()), OPENFOUR.wbnb.toLowerCase()]);
      const candidates = [];
      let balanceError = null;
      try {
        const { tokens } = await walletBalance(walletId);
        for (const t of tokens) {
          const addr = String(t.address || '');
          if (String(t.binanceChainId) !== '56' || !ADDR_RE.test(addr) || /^0xe{40}$/i.test(addr)) continue;
          if (skip.has(addr.toLowerCase())) continue;
          candidates.push({ token: addr, usdValue: t.value ?? t.usdValue ?? null, source: 'balance' });
        }
      } catch (err) {
        balanceError = err.message; // 未登录等：仍可用狙击记录 / 补充 CA 查
      }
      for (const t of features.fourTargets?.() || []) {
        if (t.stage === 'bought' && ADDR_RE.test(String(t.token))) candidates.push({ token: t.token, source: 'sniper' });
      }
      const extra = Array.isArray(body.extra) ? body.extra.slice(0, 20) : [];
      for (const a of extra) if (ADDR_RE.test(String(a))) candidates.push({ token: String(a), source: 'manual' });
      const holdings = await listHoldings({ trader: from, candidates: candidates.slice(0, 60) });
      return { walletId, from, holdings, balanceError };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/four\/buy$/,
    async handler(_req, _m, _url, body) {
      const token = assertAddress(body.token, 'token');
      const walletId = assertString(body.walletId, 'walletId', 64);
      const mode = body.mode === 'quote' ? 'quote' : 'amount';
      const slippageBps = assertSlippageBps(body.slippageBps);
      const amountWei = tokensToWei(String(body.amount ?? ''));
      if (amountWei <= 0n) throw new Error('数量必须大于 0');
      const from = await walletEvm(walletId);
      const plan = await planBuy({ token, trader: from, mode, amountWei, slippageBps });
      const steps = [];
      if (plan.approveTx) {
        steps.push(await previewStep(walletId, from, {
          kind: 'approve', label: `授权 ${plan.unit} 给 Core（先执行这一步，再重新生成买入计划）`, tx: plan.approveTx,
        }));
      } else {
        steps.push(await previewStep(walletId, from, { kind: 'buy', label: plan.summary.text, tx: plan.tx }));
      }
      return { walletId, from, plan: planPublic(plan), steps };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/four\/sell$/,
    async handler(_req, _m, _url, body) {
      const token = assertAddress(body.token, 'token');
      const walletId = assertString(body.walletId, 'walletId', 64);
      const slippageBps = assertSlippageBps(body.slippageBps);
      const amountWei = tokensToWei(String(body.amount ?? ''));
      const from = await walletEvm(walletId);
      const plan = await planSell({ token, trader: from, amountWei, slippageBps });
      const steps = [];
      if (plan.approveTx) {
        steps.push(await previewStep(walletId, from, {
          kind: 'approve', label: `授权 ${plan.symbol} 给 Core（先执行这一步，再重新生成卖出计划）`, tx: plan.approveTx,
        }));
      } else {
        steps.push(await previewStep(walletId, from, { kind: 'sell', label: plan.summary.text, tx: plan.tx }));
      }
      return {
        walletId, from,
        plan: { ...planPublic(plan), amount: plan.amount, balance: plan.balance },
        steps,
      };
    },
  },
];

// ---- 快捷交易（多平台）：识别平台 → 生成计划并 preview 第一步 → 前端确认后走 /api/w/:id/execute ----
const QUICK_PLATFORM_IDS = new Set(['auto', ...listPlatforms().map((p) => p.id)]);

function quickParams(body) {
  const side = body.side === 'sell' ? 'sell' : body.side === 'buy' ? 'buy' : null;
  if (!side) throw new Error('side 必须是 buy / sell');
  const platform = String(body.platform || 'auto');
  if (!QUICK_PLATFORM_IDS.has(platform)) throw new Error(`未知平台：${platform}`);
  let percent = null;
  let amount = null;
  if (side === 'sell' && body.percent != null && body.percent !== '') {
    const p = Number(body.percent);
    if (!(p > 0 && p <= 100) || !/^\d{1,3}(\.\d{1,2})?$/.test(String(body.percent))) throw new Error('卖出比例需要在 0~100% 之间');
    percent = String(body.percent);
  } else {
    amount = assertAmount(body.amount);
  }
  // quoteIn：多步计划里「换报价币 / 包装 / 授权」上链后，用已有报价币继续（整数最小单位）
  let quoteIn = null;
  if (body.quoteIn != null && body.quoteIn !== '') {
    if (side !== 'buy' || !/^\d{1,78}$/.test(String(body.quoteIn))) throw new Error('quoteIn 只能用于买入，且必须是整数');
    quoteIn = String(body.quoteIn);
  }
  return {
    address: assertAddress(body.address, 'address'),
    walletId: assertString(body.walletId, 'walletId', 64),
    side, platform, amount, percent, quoteIn,
    slippageBps: assertSlippageBps(body.slippageBps),
  };
}

/** BNB 十进制字符串 → wei（直接买入的金额检查用） */
function parseBnbWei(s) {
  const [w, f = ''] = String(s).split('.');
  return BigInt(w) * 10n ** 18n + BigInt((f + '0'.repeat(18)).slice(0, 18) || '0');
}

/**
 * 生成快捷交易计划 + 预览第一步（/api/quick/plan 与直接买入共用）。
 * 买入时：单笔上限检查；第一步预览通过则登记一键执行 bundle（2 分钟有效、一次性）。
 */
async function buildQuickPlan(p) {
  const from = await walletEvm(p.walletId);
  const started = Date.now();
  const plan = await planQuick({ wallet: from, ...p });
  const planMs = Date.now() - started;
  const flat = flatQuickSteps(plan);
  // 单笔买入上限：所有步骤附带的 BNB 合计（换币 / 包装 / 直付）+ 用报价币库存付的部分折合的 BNB
  let spendWei = 0n;
  if (p.side === 'buy') {
    // 买入计划必须显式给出 bnbEquivWei（用已有报价币付的部分折合的 BNB；全部在 value 里时为 '0'）。
    // 缺省（undefined）与 null 一样按「估不出」处理：设了单笔上限就拒绝，绝不按 0 放行
    if (plan.bnbEquivWei == null) {
      const { maxBuyBnb } = await getLimits();
      if (Number(maxBuyBnb) > 0) throw new Error('估不出这笔用报价币支付的部分折合多少 BNB（PancakeSwap 上没有可用池子，或该平台未提供折算），无法检查单笔上限，已拒绝');
    }
    spendWei = flat.reduce((a, s) => a + BigInt(s.value || '0'), 0n) + BigInt(plan.bnbEquivWei || '0');
    await assertBuyLimit(spendWei);
  } else if (plan.pay?.raw != null) {
    // 卖出已发射的打新代币：会跌破出局线（永久失去持有奖励）时在计划和确认框里明确警告
    const g = features.sellGuard ? await features.sellGuard({ wallet: from, token: plan.token, amountRaw: plan.pay.raw }).catch(() => null) : null;
    if (g) { plan.warnings = [g, ...(plan.warnings || [])]; plan.fairOut = g; }
  }
  // 只 preview 第一步：后面的步骤依赖前一步上链后的状态（余额 / 授权），执行到时再 preview
  // preview 失败（未登录 / 会话过期等）不影响看报价：步骤标记失败并带原因，按钮不可执行
  let first;
  const t0 = Date.now();
  try {
    first = await previewStep(p.walletId, from, { kind: flat[0].kind, label: flat[0].label, tx: plan.steps[0].tx });
  } catch (err) {
    first = { ok: false, preview: null, error: `preview 失败：${err.message}` };
  }
  const previewMs = Date.now() - t0;
  const steps = [{ ...flat[0], ...first, replan: flat[0].replan, next: flat[0].next }, ...flat.slice(1)];
  const { steps: _s, detect, timing, ...pub } = plan;
  let oneClick = null;
  // 一键执行：买入和卖出都支持（卖出 = 授权本次数量 → 卖出 → 解包，2026-10-28 用户确认，上限复核同买入）
  if (first.ok) {
    const b = rememberBundle({ walletId: p.walletId, from, req: p, plan, steps });
    oneClick = { bundleId: b.id, bounds: publicBounds(b.bounds) };
  }
  return {
    walletId: p.walletId, from, plan: { ...pub, candidates: detect.candidates }, steps, planMs, spendWei: spendWei.toString(),
    timing: { ...timing, previewMs, totalMs: Date.now() - started }, oneClick,
  };
}

/** 启动一键执行任务（确认后的一键买入与预授权直接买入共用；上限复核在 oneclick.mjs） */
async function startQuickJob(bundleId, walletId) {
  const from = await walletEvm(walletId);
  return startJob(bundleId, walletId, {
    preview: (wid, step) => previewStep(wid, from, { kind: step.kind, label: step.label, tx: { to: step.to, value: step.value, inputData: step.inputData } }),
    execute: (wid, requestId) => doExecute(wid, requestId),
    replan: async (req) => {
      const plan = await planQuick({ wallet: from, ...req });
      return { plan, steps: flatQuickSteps(plan) };
    },
    // 买入完成后自动授权给卖出合约（config.autoApprove，默认关；docs/AUTOMATION_RULES.md 规则 3 第九个例外，见 quick/autoapprove.mjs）
    onDone: (job, ctx) => afterBuy(job, ctx, { previewStep, doExecute }),
  });
}

/** 计划步骤扁平化（前端与一键执行共用的结构） */
function flatQuickSteps(plan) {
  for (const s of plan.steps) tagRoutePlatform(s.tx.inputData, plan.platform);
  return plan.steps.map((s) => ({
    kind: s.kind, label: s.label, replan: Boolean(s.replan), next: s.next || null,
    to: s.tx.to, value: String(s.tx.value ?? '0'), inputData: s.tx.inputData,
  }));
}

/*
 * 插件 / 快捷交易的「当前代币持仓」：余额以链上为准（一次 batch：每个钱包 balanceOf + BNB 余额，走后台节点），
 * 价值 / 成本 / 盈亏取 GMGN 持仓（20 秒缓存；GMGN 没收录或没配置时只显示余额）。
 * 链上结果缓存 POSITION_TTL_MS；fresh=1（刚成交）跳过链上缓存，GMGN 仍用缓存（省额度，盈亏晚几十秒无所谓）。
 */
const POSITION_TTL_MS = 4000;
const GMGN_WAIT_MS = 3000;
const balanceOfAbi = parseAbi(['function balanceOf(address) view returns (uint256)']);
const fmtUnits = (raw, dec) => {
  const s = BigInt(raw).toString().padStart(dec + 1, '0');
  const frac = s.slice(-dec).replace(/0+$/, '');
  return `${s.slice(0, -dec) || '0'}${frac ? `.${frac}` : ''}`;
};
async function quickPosition(token, allIds, { fresh = false } = {}) {
  // 只看本系统买入的持仓（狙击 / 自动打新 / 一键买入，见 quick/positions.mjs）：没买过的钱包不读链上，全都没买过就直接返回
  addFourTargets(features.fourTargets?.() || []);
  const walletIds = allIds.filter((id) => managedPosition(id, token));
  if (!walletIds.length) return { token, managed: false, rows: [], unmanaged: allIds };
  const wallets = await Promise.all(walletIds.map(async (id) => ({ id, address: await walletEvm(id) })));
  const key = `pos:${token.toLowerCase()}:${walletIds.join(',')}`;
  let chain = fresh ? null : cacheGet(key);
  if (!chain) {
    const meta = await tokenMeta(token).catch(() => { throw new Error('读不到代币信息（不是 ERC20 代币合约？）'); });
    const calls = wallets.flatMap((w) => [
      { method: 'eth_call', params: [{ to: token, data: encodeFunctionData({ abi: balanceOfAbi, functionName: 'balanceOf', args: [w.address] }) }, 'latest'] },
      { method: 'eth_getBalance', params: [w.address, 'latest'] },
    ]);
    const r = await runBackground(() => rpcBatch(calls), '持仓 / 识别展示');
    chain = {
      meta,
      rows: wallets.map((w, i) => {
        const tok = r.results[2 * i];
        const bnb = r.results[2 * i + 1];
        return { raw: tok != null && tok !== '0x' ? BigInt(tok).toString() : null, bnbWei: bnb != null ? BigInt(bnb).toString() : null };
      }),
      at: Date.now(),
    };
    cacheSet(key, chain, POSITION_TTL_MS);
  }
  // GMGN 最多等 GMGN_WAIT_MS（限频排队 + 请求本身可能十几秒）：等不到就先只返回链上余额，
  // 请求在后台继续跑完进缓存（gmgn.mjs 20 秒缓存 + 在途合并），下一次刷新就有估值
  const gm = await Promise.all(wallets.map((w) => Promise.race([
    walletHoldings(w.address)
      .then((h) => (h.rows || []).find((x) => String(x.token || '').toLowerCase() === token.toLowerCase()) || null)
      .catch(() => null),
    new Promise((r) => { setTimeout(() => r(null), GMGN_WAIT_MS).unref?.(); }),
  ])));
  const price = gm.find((g) => g?.price)?.price ?? null; // 美元 / 枚
  const dec = chain.meta.decimals;
  let totalRaw = 0n;
  const rows = wallets.map((w, i) => {
    const c = chain.rows[i];
    const g = gm[i];
    if (c.raw) totalRaw += BigInt(c.raw);
    const amount = c.raw ? Number(fmtUnits(c.raw, dec)) : null;
    const m = managedPosition(w.id, token);
    return {
      walletId: w.id, address: w.address, source: sourceText(m?.sources), firstAt: m?.firstAt || null, buys: m?.buys || 0,
      raw: c.raw, balance: c.raw ? fmtUnits(c.raw, dec) : null, bnb: c.bnbWei ? fmtUnits(c.bnbWei, 18) : null,
      usdValue: amount != null && price != null ? amount * price : null,
      cost: g?.accuCost ?? null, unrealized: g?.unrealized ?? null, unrealizedPnl: g?.unrealizedPnl ?? null,
      totalProfit: g?.totalProfit ?? null, totalPnl: g?.totalPnl ?? null, avgBuy: g?.avgBuy ?? null,
    };
  });
  const sum = (k) => (rows.some((x) => x[k] != null) ? rows.reduce((a, x) => a + (x[k] || 0), 0) : null);
  return {
    managed: true, unmanaged: allIds.filter((id) => !walletIds.includes(id)),
    token: chain.meta.address, symbol: chain.meta.symbol, decimals: dec, priceUsd: price, gmgn: gm.some(Boolean),
    total: {
      raw: totalRaw.toString(), balance: fmtUnits(totalRaw, dec), held: rows.filter((x) => x.raw && x.raw !== '0').length,
      usdValue: sum('usdValue'), cost: sum('cost'), unrealized: sum('unrealized'), totalProfit: sum('totalProfit'),
    },
    rows, chainAt: new Date(chain.at).toISOString(),
  };
}

let routeImporting = false;
const quickRoutes = [
  {
    method: 'GET',
    match: /^\/api\/quick\/position$/,
    async handler(_req, _m, url) {
      const token = assertAddress(url.searchParams.get('address'), 'address');
      const ids = [...new Set(String(url.searchParams.get('walletIds') || '').split(',').map((s) => s.trim()).filter(Boolean))];
      if (!ids.length || ids.length > 5) throw new Error('walletIds 需要 1~5 个');
      ids.forEach((id) => assertString(id, 'walletId', 64));
      return quickPosition(token, ids, { fresh: url.searchParams.get('fresh') === '1' });
    },
  },
  {
    // 插件本地判断用：所选钱包的地址（地址栏 / 剪贴板是自己的钱包就不识别）+ 本系统买过的币（不在里面就不问持仓）
    method: 'GET',
    match: /^\/api\/quick\/positions$/,
    async handler(_req, _m, url) {
      const ids = [...new Set(String(url.searchParams.get('walletIds') || '').split(',').map((s) => s.trim()).filter(Boolean))];
      if (!ids.length || ids.length > 5) throw new Error('walletIds 需要 1~5 个');
      ids.forEach((id) => assertString(id, 'walletId', 64));
      addFourTargets(features.fourTargets?.() || []);
      const all = await listWallets();
      const addresses = (await Promise.all(all.map((w) => walletEvm(w.id).catch(() => null)))).filter(Boolean).map((a) => a.toLowerCase());
      return { tokens: managedTokens(ids), walletAddresses: addresses };
    },
  },
  {
    method: 'GET',
    match: /^\/api\/quick\/platforms$/,
    async handler() { return listPlatforms(); },
  },
  {
    method: 'POST',
    match: /^\/api\/quick\/detect$/,
    async handler(_req, _m, _url, body) {
      const address = assertAddress(body.address, 'address');
      const walletId = assertString(body.walletId, 'walletId', 64);
      const from = await walletEvm(walletId);
      return detectAll(address, { wallet: from });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/quick\/plan$/,
    async handler(_req, _m, _url, body) {
      return buildQuickPlan(quickParams(body));
    },
  },
  {
    // 路由记录（每个币对走过的 SmartRouter 路径与成败）与固定路由
    method: 'GET',
    match: /^\/api\/routes$/,
    async handler() { return listRoutes(); },
  },
  {
    method: 'POST',
    match: /^\/api\/routes\/(pin|unpin|resume)$/,
    async handler(_req, [action], _url, body) {
      const pair = assertString(body.pair, 'pair', 100);
      if (!/^0x[0-9a-f]{40}>0x[0-9a-f]{40}$/.test(pair)) throw new Error('pair 格式不对');
      if (action === 'pin') {
        const pathKey = assertString(body.pathKey, 'pathKey', 200);
        if (!/^0x[0-9a-f]{40}(>0x[0-9a-f]{40}){0,3}$/.test(pathKey)) throw new Error('pathKey 格式不对');
        return pinRoute(pair, pathKey);
      }
      return action === 'unpin' ? unpinRoute(pair) : resumePin(pair);
    },
  },
  {
    // 从执行日志导入历史成交的路径（已导入过的交易跳过）
    method: 'POST',
    match: /^\/api\/routes\/import$/,
    async handler() {
      if (routeImporting) throw new Error('正在导入，请稍等');
      routeImporting = true;
      try { return await importRouteHistory(); } finally { routeImporting = false; }
    },
  },
  {
    // 直接买入（不弹确认框）：只有该钱包已预授权、金额 / 滑点在策略内时才执行；其余检查与一键买入完全相同
    method: 'POST',
    match: /^\/api\/quick\/autobuy$/,
    async handler(_req, _m, _url, body) {
      const p = quickParams({ ...body, side: 'buy' });
      if (!p.amount) throw new Error('直接买入需要填 BNB 数量');
      // quoteIn 只给手动多步流程 / 服务端重新报价用：直接买入（免确认）一律按 BNB 金额生成计划
      if (p.quoteIn != null) throw new Error('直接买入不接受 quoteIn');
      assertArmed(p.walletId, { amountWei: parseBnbWei(p.amount), slippageBps: p.slippageBps });
      const r = await buildQuickPlan(p);
      // 计划出来后按实际花费（含库存折合的 BNB）再过一次预授权策略
      assertArmed(p.walletId, { amountWei: BigInt(r.spendWei), slippageBps: p.slippageBps });
      if (!r.oneClick) {
        const why = r.steps[0]?.error || '第一步预览未通过';
        journal('autobuy.blocked', { walletId: p.walletId, token: p.address, amount: p.amount, error: why });
        throw new Error(`没有买入：${why}`);
      }
      // 计划阶段已过单笔上限（assertBuyLimit）；执行时每笔广播前再过每日上限（reserveDaily）
      // 必须 await：startQuickJob 是 async，不 await 会把 Promise 序列化成 {}，前端拿不到任务状态（曾导致 reading 'map'）
      const job = await startQuickJob(r.oneClick.bundleId, p.walletId);
      return { ...r, job };
    },
  },
  {
    method: 'GET',
    match: /^\/api\/quick\/arm$/,
    async handler(_req, _m, url) {
      return armStatus(assertString(url.searchParams.get('walletId'), 'walletId', 64));
    },
  },
  {
    method: 'POST',
    match: /^\/api\/quick\/arm$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'ARM') throw new Error('缺少预授权确认（confirm=ARM）');
      const walletId = assertString(body.walletId, 'walletId', 64);
      await walletEvm(walletId);
      return arm({ walletId, maxSlippageBps: assertSlippageBps(body.maxSlippageBps), hours: body.hours });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/quick\/disarm$/,
    async handler(_req, _m, _url, body) {
      return disarm(assertString(body.walletId, 'walletId', 64));
    },
  },
  {
    // 买入上限：单笔 / 每日（每个钱包），以及今天已用量
    method: 'GET',
    match: /^\/api\/limits$/,
    async handler(_req, _m, url) {
      const walletId = url.searchParams.get('walletId');
      const limits = await getLimits();
      return { ...limits, spentToday: walletId ? fromWei(await spentToday(walletId)) : null };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/limits$/,
    async handler(_req, _m, _url, body) {
      const r = await setLimits({ maxBuyBnb: String(body.maxBuyBnb ?? '0').trim(), dailyBnb: String(body.dailyBnb ?? '0').trim() });
      disarmAll('limits-changed'); // 预授权是按当时的上限确认的：上限一改立即失效
      features.onLimitsChanged?.(); // 狙击 / 自动打新（全量版）
      return r;
    },
  },
  {
    // 粘贴 CA 后预热（只读、低优先级）：识别结果和池子地址进缓存，点「买入」时少等几秒
    method: 'POST',
    match: /^\/api\/quick\/warm$/,
    async handler(_req, _m, _url, body) {
      const address = assertAddress(body.address, 'address');
      const platform = String(body.platform || 'auto');
      if (!QUICK_PLATFORM_IDS.has(platform)) throw new Error(`未知平台：${platform}`);
      const from = await walletEvm(assertString(body.walletId, 'walletId', 64));
      return warmToken({ address, platform, wallet: from, detectAll, detectOne });
    },
  },
  // ---- 钱包持仓（GMGN OpenAPI，只读）：持仓 / 历史仓位 / 交易记录 / 收益统计 ----
  {
    method: 'GET',
    match: /^\/api\/gmgn\/status$/,
    async handler() { return gmgnStatus(); },
  },
  {
    method: 'POST',
    match: /^\/api\/gmgn\/apikey$/,
    async handler(_req, _m, _url, body) { return setApiKey(body.apiKey); },
  },
  {
    method: 'POST',
    match: /^\/api\/gmgn\/keygen$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'KEYGEN') throw new Error('缺少确认（confirm=KEYGEN）');
      return generateSigner({ replace: body.replace === true });
    },
  },
  {
    method: 'GET',
    match: /^\/api\/gmgn\/(holdings|history|activity|stats)$/,
    async handler(_req, [kind], url) {
      // 查询对象：本机钱包（walletId）或任意地址（address，比如要看别人的钱包）
      const id = url.searchParams.get('walletId');
      const addr = url.searchParams.get('address');
      const wallet = addr ? assertAddress(addr, 'address') : await walletEvm(assertString(id, 'walletId', 64));
      const cursor = String(url.searchParams.get('cursor') || '').slice(0, 200);
      const fresh = url.searchParams.get('fresh') === '1'; // 用户点击：跳过本地缓存
      if (kind === 'holdings' || kind === 'history') {
        // 头像来源（币安图标 / gang 链上 logoURI）与持仓并行登记，失败不影响持仓
        const [r] = await Promise.all([
          walletHoldings(wallet, { cursor, closed: kind === 'history', fresh, onToken: registerHoldingLogo }),
          registerBinanceIcons(wallet).catch(() => {}),
        ]);
        return kind === 'holdings' && !cursor ? withNativeBnb(r, wallet) : r;
      }
      if (kind === 'activity') {
        const token = url.searchParams.get('token');
        return walletActivity(wallet, { cursor, token: token ? assertAddress(token, 'token') : '', fresh });
      }
      const period = url.searchParams.get('period') === '30d' ? '30d' : '7d';
      return walletStats([wallet], period, { fresh });
    },
  },
  // ---- 全局自动化状态条：所有预授权 / 自动执行的汇总 + 合并事件流；「全部解除」一键止损 ----
  {
    method: 'GET',
    match: /^\/api\/automation$/,
    async handler() { return automationStatus(); },
  },
  {
    // 「服务重启后自动恢复预授权」开关（config.resumeArms，默认开）
    method: 'GET',
    match: /^\/api\/automation\/resume$/,
    async handler() { return { enabled: (await getConfig()).resumeArms !== false, saved: Object.keys(savedArms()) }; },
  },
  {
    method: 'POST',
    match: /^\/api\/automation\/resume$/,
    async handler(_req, _m, _url, body) {
      if (typeof body.enabled !== 'boolean') throw new Error('enabled 必须是 true / false');
      await saveConfig({ resumeArms: body.enabled });
      journal('resume.setting', { enabled: body.enabled });
      return { enabled: body.enabled };
    },
  },
  {
    // 「买入后自动授权」开关（config.autoApprove，默认关；docs/AUTOMATION_RULES.md 规则 3 第九个例外）。只能从控制台改，插件的 EXT_ROUTES 不含
    method: 'GET',
    match: /^\/api\/quick\/autoapprove$/,
    async handler() { return { enabled: (await getConfig()).autoApprove === true, ...autoApproveStatus() }; },
  },
  {
    method: 'POST',
    match: /^\/api\/quick\/autoapprove$/,
    async handler(_req, _m, _url, body) {
      if (typeof body.enabled !== 'boolean') throw new Error('enabled 必须是 true / false');
      if (body.enabled && body.confirm !== 'AUTO_APPROVE') throw new Error('打开买入后自动授权需要确认（confirm=AUTO_APPROVE）');
      await saveConfig({ autoApprove: body.enabled });
      journal('autoapprove.setting', { enabled: body.enabled });
      return { enabled: body.enabled, ...autoApproveStatus() };
    },
  },
  // ---- 浏览器插件配对（只能从控制台页面调用：插件的 EXT_ROUTES 不含这些） ----
  {
    method: 'GET',
    match: /^\/api\/extension$/,
    async handler() {
      return { paired: Boolean(ext.key), origins: [...ext.origins], keyHint: ext.key ? `…${ext.key.slice(-4)}` : '' };
    },
  },
  {
    // 生成新的配对密钥（旧的立即失效），只返回这一次；origin = chrome-extension://<插件 ID>
    method: 'POST',
    match: /^\/api\/extension\/pair$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'PAIR') throw new Error('缺少确认（confirm=PAIR）');
      const raw = String(body.extensionId || '').trim().replace(/^chrome-extension:\/\//, '').replace(/\/.*$/, '');
      const origin = `chrome-extension://${raw}`;
      if (!EXT_ORIGIN_RE.test(origin)) throw new Error('插件 ID 不对：应该是 32 位小写字母（插件设置页里显示，或 chrome://extensions 里看）');
      const key = randomBytes(32).toString('hex');
      await saveConfig({ extension: { key, origins: [origin], pairedAt: new Date().toISOString() } });
      setExtensionConfig({ key, origins: [origin] });
      journal('extension.pair', { origin });
      return { key, origin };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/extension\/revoke$/,
    async handler() {
      await saveConfig({ extension: null });
      setExtensionConfig(null);
      journal('extension.revoke', {});
      return { paired: false };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/automation\/disarm-all$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'DISARM_ALL') throw new Error('缺少确认（confirm=DISARM_ALL）');
      disarmEverything('kill-switch');
      return automationStatus();
    },
  },
  // ---- 发射后自动转移（quick/autoxfer.mjs）：gang 代币发射后转到白名单地址（docs/AUTOMATION_RULES.md 规则 3 第七个例外） ----
  {
    method: 'GET',
    match: /^\/api\/autoxfer$/,
    async handler() { return xferStatus(); },
  },
  {
    method: 'POST',
    match: /^\/api\/autoxfer\/arm$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'ARM') throw new Error('缺少预授权确认（confirm=ARM）');
      const tokens = (Array.isArray(body.tokens) ? body.tokens : []).slice(0, 100).map((t) => ({ token: assertAddress(String(t), 'token'), source: 'manual' }));
      return armXfer(body.config || {}, autoXferDeps(), { tokens });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/autoxfer\/disarm$/,
    async handler() { return disarmXfer('manual'); },
  },
  {
    // 加入监控要确认（confirm=ADD）：扩大了自动转账的范围；移出不用
    method: 'POST',
    match: /^\/api\/autoxfer\/token$/,
    async handler(_req, _m, _url, body) {
      const add = body.add === true;
      if (add && body.confirm !== 'ADD') throw new Error('缺少确认（confirm=ADD）');
      return setXferToken(assertAddress(body.token, 'token'), add);
    },
  },
  {
    // 全部移出监控（缩小自动转账的范围，不需要确认参数；页面上会先弹确认框）
    method: 'POST',
    match: /^\/api\/autoxfer\/tokens\/clear$/,
    async handler() { return clearXferTokens(); },
  },
  // gang 内盘狙击（/api/gangsnipe*）在 features/snipe.mjs（全量版）
  // ---- 一键转移（quick/transfer.mjs）：非 BNB 代币 → 已保存的白名单地址；确认一次后逐笔执行（docs/AUTOMATION_RULES.md 规则 3 第五个例外） ----
  {
    method: 'GET',
    match: /^\/api\/transfer\/targets$/,
    async handler() { return listTargets(); },
  },
  {
    method: 'POST',
    match: /^\/api\/transfer\/check$/,
    async handler(_req, _m, _url, body) {
      return checkAddress(assertAddress(body.address, 'address'), { ownWallets: await ownEvmAddresses(), existing: (await listTargets()).map((t) => t.address) });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/transfer\/targets$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'ADD_TARGET') throw new Error('缺少白名单确认（confirm=ADD_TARGET）');
      const r = await addTarget({ name: body.name, address: assertAddress(body.address, 'address') }, { ownWallets: await ownEvmAddresses() });
      journal('transfer.target.add', { id: r.entry.id, name: r.entry.name, address: r.entry.address });
      return r;
    },
  },
  {
    method: 'DELETE',
    match: /^\/api\/transfer\/targets\/([0-9a-f-]{36})$/,
    async handler(_req, [id]) {
      journal('transfer.target.remove', { id });
      const r = await removeTarget(id);
      if (xferStatus().arm?.targetId === id) disarmXfer('target-removed'); // 自动转移的收款地址被删：立即失效
      return r;
    },
  },
  {
    method: 'POST',
    match: /^\/api\/transfer\/holdings$/,
    async handler(_req, _m, _url, body) {
      const walletId = assertString(body.walletId, 'walletId', 64);
      const from = await walletEvm(walletId);
      if (body.refresh) cacheInvalidate(`balance:${walletId}`);
      const candidates = [];
      let balanceError = null;
      try {
        const { tokens } = await walletBalance(walletId);
        for (const t of tokens) {
          const addr = String(t.address || '');
          if (String(t.binanceChainId) !== '56' || !ADDR_RE.test(addr) || /^0xe{40}$/i.test(addr)) continue; // 跳过原生 BNB
          candidates.push({ token: addr, usdValue: t.value ?? t.usdValue ?? null });
        }
      } catch (err) {
        balanceError = err.message;
      }
      const extra = Array.isArray(body.extra) ? body.extra.slice(0, 20) : [];
      for (const a of extra) if (ADDR_RE.test(String(a))) candidates.unshift({ token: String(a) });
      return { walletId, from, rows: await listTransferable({ wallet: from, candidates }), balanceError };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/transfer\/plan$/,
    async handler(_req, _m, _url, body) {
      const walletId = assertString(body.walletId, 'walletId', 64);
      const from = await walletEvm(walletId);
      const plan = await planTransfer({ wallet: from, targetId: String(body.targetId || ''), items: body.items, ownWallets: await ownEvmAddresses() });
      const flat = flatQuickSteps(plan);
      let first;
      try {
        first = await previewStep(walletId, from, { kind: flat[0].kind, label: flat[0].label, tx: plan.steps[0].tx });
      } catch (err) {
        first = { ok: false, preview: null, error: `preview 失败：${err.message}` };
      }
      const steps = [{ ...flat[0], ...first }, ...flat.slice(1)];
      const { steps: _s, ...pub } = plan;
      let oneClick = null;
      if (first.ok) {
        const b = rememberBundle({ walletId, from, req: { address: plan.target.address, platform: 'transfer', amount: String(steps.length) }, plan, steps });
        oneClick = { bundleId: b.id, bounds: publicBounds(b.bounds) };
      }
      return { walletId, from, plan: pub, steps, oneClick };
    },
  },
  // ---- 报价币库存 + 常驻授权（quick/inventory.mjs）：备货 / 同步授权 / 撤销都先出计划，用户确认后走一键执行 ----
  {
    method: 'GET',
    match: /^\/api\/inventory$/,
    async handler(_req, _m, url) {
      const from = await walletEvm(assertString(url.searchParams.get('walletId'), 'walletId', 64));
      return inventoryStatus(from);
    },
  },
  {
    // 批量预授权（无上限）的候选：gang 最近在用的报价币 + 库存列表里的
    method: 'GET',
    match: /^\/api\/inventory\/candidates$/,
    async handler(_req, _m, url) {
      const from = await walletEvm(assertString(url.searchParams.get('walletId'), 'walletId', 64));
      return approvalCandidates(from);
    },
  },
  {
    method: 'POST',
    match: /^\/api\/inventory\/add$/,
    async handler(_req, _m, _url, body) {
      const r = await addFromCa(assertAddress(body.ca, 'ca'));
      warmInventoryQuotes().catch(() => null); // 新加的报价币立即预热池子（后台）
      return r;
    },
  },
  {
    method: 'POST',
    match: /^\/api\/inventory\/remove$/,
    async handler(_req, _m, _url, body) {
      const wallets = (await listWallets()).map((w) => w.evm).filter((a) => ADDR_RE.test(String(a || '')));
      return removeToken(String(body.platform || ''), assertAddress(body.token, 'token'), wallets);
    },
  },
  {
    method: 'POST',
    match: /^\/api\/inventory\/cap$/,
    async handler(_req, _m, _url, body) { return setCap(String(body.capBnb ?? '')); },
  },
  {
    method: 'POST',
    match: /^\/api\/inventory\/plan$/,
    async handler(_req, _m, _url, body) {
      const walletId = assertString(body.walletId, 'walletId', 64);
      const platform = String(body.platform || '');
      const token = assertAddress(body.token, 'token');
      const from = await walletEvm(walletId);
      const action = ['revoke', 'revoke-all', 'unlimited'].includes(body.action) ? body.action : 'stock';
      const plan = action === 'revoke'
        ? await planRevoke({ wallet: from, platform, token })
        : action === 'revoke-all'
          ? await planRevokeMany({ wallet: from, items: body.items })
          : action === 'unlimited'
            ? await planUnlimited({ wallet: from, items: body.items })
            : await planStock({ wallet: from, platform, token, amountBnb: String(body.amountBnb ?? '0').trim() || '0', slippageBps: assertSlippageBps(body.slippageBps) });
      const flat = flatQuickSteps(plan);
      let first;
      try {
        first = await previewStep(walletId, from, { kind: flat[0].kind, label: flat[0].label, tx: plan.steps[0].tx });
      } catch (err) {
        first = { ok: false, preview: null, error: `preview 失败：${err.message}` };
      }
      const steps = [{ ...flat[0], ...first }, ...flat.slice(1)];
      const { steps: _s, ...pub } = plan;
      let oneClick = null;
      if (first.ok) {
        const b = rememberBundle({ walletId, from, req: { address: token, platform: 'inventory', amount: String(body.amountBnb ?? '0') }, plan, steps });
        oneClick = { bundleId: b.id, bounds: publicBounds(b.bounds) };
      }
      return { walletId, from, action, plan: pub, steps, oneClick };
    },
  },
  {
    // 一键买入：用户对整笔计划 + 上限确认一次（confirm=ONECLICK），服务端自动 preview → execute → 等上链 → 重新报价
    method: 'POST',
    match: /^\/api\/quick\/oneclick$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'ONECLICK') throw new Error('缺少一键买入确认（confirm=ONECLICK）');
      const walletId = assertString(body.walletId, 'walletId', 64);
      return await startQuickJob(assertToken(body.bundleId, 'bundleId'), walletId);
    },
  },
  {
    method: 'GET',
    match: /^\/api\/quick\/oneclick\/([0-9a-f]{24})$/,
    async handler(_req, [id]) { return jobStatus(id); },
  },
  {
    // 执行日志里「开始了但没结束」的一键任务（服务重启 / 崩溃时中断）：已完成的步骤不会回滚，需要人工处理
    method: 'GET',
    match: /^\/api\/quick\/unfinished$/,
    async handler() {
      const list = await unfinishedJobs();
      const jobs = list.filter((j) => { try { return jobStatus(j.jobId).state !== 'running'; } catch { return true; } });
      return [...jobs, ...(await orphanExecutes())]; // 再加上广播途中服务中断的单笔交易
    },
  },
  // gang V3：默认关闭；地址必须链上核验通过 + 用户确认（confirm=ENABLE）才启用，启用时服务端重新核验
  {
    method: 'GET',
    match: /^\/api\/gangv3\/status$/,
    async handler() { return gangV3Status(); },
  },
  {
    method: 'POST',
    match: /^\/api\/gangv3\/verify$/,
    async handler(_req, _m, _url, body) {
      const dep = { pad: assertAddress(body.pad, 'pad'), router: assertAddress(body.router, 'router') };
      return runBackground(() => verifyDeployment(mainnetCtx, dep), '手动核验'); // 手动核验：只读、非即时，走公共节点
    },
  },
  {
    method: 'POST',
    match: /^\/api\/gangv3\/enable$/,
    async handler(_req, _m, _url, body) {
      if (body.confirm !== 'ENABLE') throw new Error('缺少启用确认（confirm=ENABLE）');
      return enableGangV3({
        pad: assertAddress(body.pad, 'pad'),
        router: assertAddress(body.router, 'router'),
        attest: body.attest === true,
      });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/gangv3\/disable$/,
    async handler() { features.onV3Disabled?.(); return disableGangV3(); },
  },
  {
    method: 'POST',
    match: /^\/api\/gangv3\/check$/,
    async handler() { await checkForMainnet({ force: true }); return gangV3Status(); },
  },
  // ---- 发现开关（quick/gangv3.mjs discoveryCfg）：V3 / 打新要不要找新部署、可信时要不要自动启用 ----
  {
    method: 'GET',
    match: /^\/api\/discovery$/,
    async handler() { return discoveryCfg(); },
  },
  {
    method: 'POST',
    match: /^\/api\/discovery$/,
    async handler(_req, _m, _url, body) {
      const cur = (await getConfig()).discovery || {};
      const next = { ...cur };
      for (const k of ['v3', 'fair', 'autoEnable']) {
        if (body[k] === undefined) continue;
        if (typeof body[k] !== 'boolean') throw new Error(`${k} 必须是 true / false`);
        next[k] = body[k];
      }
      await saveConfig({ discovery: next });
      journal('discovery.setting', { v3: next.v3 !== false, fair: next.fair !== false, autoEnable: next.autoEnable !== false });
      return syncChainWatch();
    },
  },
  // 后台任务清单：WSS 订阅（实时）+ 定时 HTTP 请求（哪些在跑、多久一次）
  {
    method: 'GET',
    match: /^\/api\/system\/background$/,
    async handler() { return backgroundTasks(); },
  },
  // gang 打新 / 自动打新（/api/fair/*）在 features/snipe.mjs（全量版）
  {
    // 交易回执（只读）：前端等上一步上链后再 preview 下一步 / 重新报价
    method: 'GET',
    match: /^\/api\/quick\/receipt$/,
    async handler(_req, _m, url) {
      const hash = String(url.searchParams.get('hash') || '');
      if (!/^0x[0-9a-fA-F]{64}$/.test(hash)) throw new Error('tx hash 格式不正确');
      const r = await rpcFor('56', 'eth_getTransactionReceipt', [hash]);
      if (!r) return { status: 'pending' };
      return { status: r.status === '0x1' ? 'success' : 'failed', blockNumber: Number(r.blockNumber) };
    },
  },
];

const routes = [
  {
    method: 'GET',
    match: /^\/api\/wallets$/,
    async handler() {
      const list = await listWallets();
      return list.map((w) => ({ id: w.id, name: w.name }));
    },
  },
  {
    method: 'POST',
    match: /^\/api\/wallets$/,
    async handler(_req, _m, _url, body) {
      return createWallet(body.name);
    },
  },
  {
    method: 'DELETE',
    match: /^\/api\/wallets\/([^/]+)$/,
    async handler(_req, [id]) {
      return deleteWallet(id);
    },
  },
  {
    method: 'POST',
    match: /^\/api\/wallets\/([^/]+)\/signin$/,
    async handler(_req, [id]) {
      const { data } = await bawJson(id, ['auth', 'signin', '--json']);
      if (data.status === 'ALREADY_CONNECTED') return { alreadyConnected: true };
      const qrDataUrl = data.urlForWeb ? await QRCode.toDataURL(data.urlForWeb, { width: 320, margin: 1 }) : null;
      return { ...data, qrDataUrl };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/wallets\/([^/]+)\/verify$/,
    async handler(_req, [id], _url, body) {
      const qrCodeId = assertToken(body.qrCodeId, 'qrCodeId');
      const { data } = await bawJson(id, ['auth', 'verify', '--qrCodeId', qrCodeId, '--json'], 330000);
      invalidateWalletCache(id);
      // 登录成功后马上核对账号：扫错码时当场提示，不等到下单才报 351808
      let identityChanged = null;
      try { identityChanged = await checkWalletIdentity(id); } catch { /* 地址暂时取不到：预热任务稍后再查 */ }
      return { ...data, identityChanged };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/wallets\/([^/]+)\/signout$/,
    async handler(_req, [id]) {
      const { data } = await bawJson(id, ['auth', 'signout', '--json']);
      invalidateWalletCache(id);
      return data;
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/status$/,
    async handler(_req, [id]) {
      const key = `status:${id}`;
      const cached = cacheGet(key);
      if (cached) return cached;
      const r = await bawJson(id, ['wallet', 'status', '--json']);
      const payload = { status: r.data.status };
      cacheSet(key, payload, 10000);
      return payload;
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/summary$/,
    async handler(_req, [id]) {
      const key = `summary:${id}`;
      const cached = cacheGet(key);
      if (cached) return cached;

      const wallet = await getWallet(id);
      let addresses = wallet?.addresses || [];
      if (!addresses.length) {
        const address = await bawJson(id, ['wallet', 'address', '--json']);
        addresses = address.data.addresses;
        await setWalletAddresses(id, addresses);
      }

      // 先用上次状态秒开，再后台刷新
      const payload = { status: wallet?.lastStatus?.status || 'UNKNOWN', addresses };
      cacheSet(key, payload, 10000);
      bawJson(id, ['wallet', 'status', '--json'])
        .then(async (r) => {
          const fresh = { status: r.data.status, addresses };
          cacheSet(key, fresh, 20000);
          await setLastStatus(id, r.data.status);
        })
        .catch(() => {});
      return payload;
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/settings$/,
    async handler(_req, [id]) {
      const key = `settings:${id}`;
      const cached = cacheGet(key);
      if (cached) return cached;
      const r = await bawJson(id, ['wallet', 'settings', '--json']);
      cacheSet(key, r.data, 60000);
      return r.data;
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/balance$/,
    async handler(_req, [id]) {
      const payload = await walletBalance(id);
      // 附带认证标记，概览页据此提示未认证代币
      const tokens = await Promise.all(payload.tokens.map(async (t) => ({
        ...t,
        verified: await isVerified(t.binanceChainId, t.address).catch(() => false),
      })));
      return { ...payload, tokens };
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/tokens$/,
    async handler(_req, [id], url) {
      const chainId = String(url.searchParams.get('chainId') || '56');
      if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
      // 持仓读取失败（未登录等）不影响认证列表展示
      const holdings = await walletBalance(id).then((b) => b.tokens).catch(() => []);
      return tokenCatalog(chainId, holdings);
    },
  },
  {
    method: 'GET',
    match: /^\/api\/token-logo$/,
    async handler(_req, _m, url) {
      const chainId = String(url.searchParams.get('chainId') || '');
      const address = String(url.searchParams.get('address') || '');
      if (!CHAINS.has(chainId) || !ADDR_RE.test(address)) throw new Error('invalid token');
      const logo = await runBackground(() => tokenLogo(chainId, address), '代币图标'); // 展示用：查链走公共节点
      if (!logo) throw new HttpError(404, 'no logo');
      return new BinaryReply(logo.type, logo.body);
    },
  },
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/history$/,
    async handler(req, [id], url) {
      const size = Math.min(Number(url.searchParams.get('size') || 20) || 20, 100);
      const r = await bawJson(id, ['wallet', 'tx-history', '--size', String(size), '--json']);
      return r.data;
    },
  },
  {
    // 钱包是否被币安锁定（有交易在等 App 确认时，所有新交易都会被拒）。只读
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/lock$/,
    async handler(_req, [id], url) {
      if (url.searchParams.get('fresh') === '1') walletLocks.delete(id);
      const s = await walletLockStatus(id);
      return { ...s, message: s.locked ? lockedMessage(id) : null };
    },
  },
  {
    // 买入记录：最近 3 天买过的代币（按代币合并 + 当前余额），交易台一键选中去卖出。只读
    method: 'GET',
    match: /^\/api\/buys$/,
    async handler(_req, _m, url) {
      return { rows: await buyRecords(assertString(url.searchParams.get('walletId'), 'walletId', 64)) };
    },
  },
  // 狙击看板（/api/snipeboard）在 features/snipe.mjs（全量版）
  {
    method: 'GET',
    match: /^\/api\/w\/([^/]+)\/gas$/,
    async handler(_req, [id], url) {
      const chainId = String(url.searchParams.get('chainId') || '56');
      if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
      const r = await bawJson(id, ['wallet', 'gas-price', '--binanceChainId', chainId, '--json']);
      return r.data;
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/quote$/,
    async handler(_req, [id], _url, body) {
      const chainId = assertString(String(body.chainId), 'chainId', 10);
      if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
      const args = [
        'market-order', 'quote',
        '--binanceChainId', chainId,
        '--fromTokenQty', assertAmount(body.amount),
        '--fromToken', assertAddress(body.fromToken, 'fromToken'),
        '--toToken', assertAddress(body.toToken, 'toToken'),
        // 报价与成交使用同一个显式滑点，避免报价按 CLI 默认 auto 计算
        '--slippage', assertSwapSlippage(body.slippage),
        '--json',
      ];
      if (String(body.fromToken).toLowerCase() === String(body.toToken).toLowerCase()) {
        throw new Error('支付代币与获得代币不能相同');
      }
      const r = await bawJson(id, args);
      return { quote: r.data, ms: r.ms };
    },
  },
  {
    // 代币美元单价（只读，兑换页估值用）：BSC 上按 Pancake 智能路由估算 1 枚 → USDT；BNB 用 WBNB。缓存 20 秒
    method: 'GET',
    match: /^\/api\/price$/,
    async handler(_req, _m, url) {
      const chainId = String(url.searchParams.get('chainId') || '56');
      if (chainId !== '56') return { usd: null, source: null };
      const raw = String(url.searchParams.get('token') || '');
      const token = /^0xe{40}$/i.test(raw) ? WBNB_ADDR : assertAddress(raw, 'token');
      return runBackground(() => bscUsdPrice(token), '价格展示'); // 展示用价格：走公共节点
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/swap$/,
    async handler(_req, [id], _url, body) {
      if (body.confirm !== 'SWAP') throw new Error('missing confirmation');
      const chainId = assertString(String(body.chainId), 'chainId', 10);
      if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
      const args = [
        'market-order', 'swap',
        '--binanceChainId', chainId,
        '--fromTokenQty', assertAmount(body.amount),
        '--fromToken', assertAddress(body.fromToken, 'fromToken'),
        '--toToken', assertAddress(body.toToken, 'toToken'),
        '--slippage', assertSwapSlippage(body.slippage),
        '--json',
      ];
      const r = await bawJson(id, args, 180000);
      invalidateWalletCache(id);
      // place-order 只返回 orderId：按 orderId 轮询订单，拿到 txHash / 最终状态再返回
      const order = r.data?.orderId ? await waitMarketOrder(id, String(r.data.orderId)) : null;
      if (order?.status === 'FAILED') {
        throw new Error(`兑换失败（订单 ${order.orderId}）${order.txHash ? `，交易 ${order.txHash}` : ''}`);
      }
      return {
        result: { ...r.data, txHash: order?.txHash || null, status: order?.status || 'PENDING', toTokenActualQty: order?.toTokenActualQty || null },
        ms: r.ms,
      };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/send$/,
    async handler(_req, [id], _url, body) {
      if (body.confirm !== 'SEND') throw new Error('missing confirmation');
      const chainId = assertString(String(body.chainId), 'chainId', 10);
      if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
      const args = [
        'wallet', 'send',
        '--binanceChainId', chainId,
        '--amount', assertAmount(body.amount),
        '--tokenAddress', assertAddress(body.tokenAddress, 'tokenAddress'),
        '--recipient', assertAddress(body.recipient, 'recipient'),
        '--json',
      ];
      const r = await bawJson(id, args, 180000);
      invalidateWalletCache(id);
      return { result: r.data, ms: r.ms };
    },
  },
  {
    method: 'GET',
    match: /^\/api\/metrics$/,
    async handler(_req, _m, url) {
      const period = url.searchParams.get('period') || 'all';
      return metricsSnapshot(period);
    },
  },
  {
    method: 'GET',
    match: /^\/api\/addressbook$/,
    async handler() {
      return listAddresses();
    },
  },
  {
    method: 'POST',
    match: /^\/api\/addressbook$/,
    async handler(_req, _m, _url, body) {
      return addAddress({
        name: body.name,
        address: assertAddress(body.address, 'address'),
        chainId: body.chainId,
      });
    },
  },
  {
    method: 'DELETE',
    match: /^\/api\/addressbook\/([^/]+)$/,
    async handler(_req, [id]) {
      return removeAddress(id);
    },
  },
  {
    method: 'GET',
    match: /^\/api\/token$/,
    async handler(_req, _m, url) {
      const chainId = String(url.searchParams.get('chainId') || '56');
      const address = String(url.searchParams.get('address') || '');
      if (!/^0x[0-9a-fA-F]{40}$/.test(address)) throw new Error('代币地址格式不正确');
      const key = `token:${chainId}:${address.toLowerCase()}`;
      const cached = cacheGet(key);
      if (cached) return cached;

      const abi = parseAbi([
        'function symbol() view returns (string)',
        'function name() view returns (string)',
        'function decimals() view returns (uint8)',
      ]);
      const read = async (fn) => {
        const raw = await rpcFor(chainId, 'eth_call', [{
          to: address, data: encodeFunctionData({ abi, functionName: fn }),
        }, 'latest']);
        return decodeFunctionResult({ abi, functionName: fn, data: raw });
      };
      // 代币名称 / 精度：非即时，走公共节点（结果缓存 5 分钟）
      const [symbol, decimals, name] = await runBackground(() => Promise.all([
        read('symbol').catch(() => null),
        read('decimals').catch(() => null),
        read('name').catch(() => null),
      ]));
      if (decimals == null) throw new Error('该地址不是可识别的 ERC20 代币');
      const verified = await isVerified(chainId, address).catch(() => false);
      const payload = { address, chainId, symbol, name, decimals: Number(decimals), verified };
      cacheSet(key, payload, 300000);
      return payload;
    },
  },
  {
    method: 'GET',
    match: /^\/api\/modules$/,
    async handler() {
      return listModules();
    },
  },
  {
    method: 'GET',
    match: /^\/api\/modules\/export$/,
    async handler() {
      return { exportedAt: new Date().toISOString(), modules: await listModules() };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/modules\/import$/,
    async handler(_req, _m, _url, body) {
      const incoming = Array.isArray(body.modules) ? body.modules : [];
      if (!incoming.length) throw new Error('导入内容为空');
      const added = [];
      for (const m of incoming.slice(0, 200)) {
        // 与「保存模块」同一长度上限，防止导入超大文本撑爆 modules.json
        if (!m || typeof m.text !== 'string' || !m.text.trim() || m.text.length > 40000) continue;
        added.push(await createModule({
          name: m.name || '导入模块',
          text: m.text,
          protocol: m.protocol,
          intent: m.intent,
        }));
      }
      return { imported: added.length };
    },
  },
  {
    method: 'POST',
    match: /^\/api\/modules$/,
    async handler(_req, _m, _url, body) {
      return createModule({
        name: body.name,
        text: assertString(body.text, 'text', 40000),
        protocol: body.protocol,
        intent: body.intent,
      });
    },
  },
  {
    method: 'DELETE',
    match: /^\/api\/modules\/([^/]+)$/,
    async handler(_req, [id]) {
      return removeModule(id);
    },
  },
  {
    method: 'POST',
    match: /^\/api\/modules\/([^/]+)\/run$/,
    async handler(_req, [id], _url, body) {
      const mod = await getModule(id);
      if (!mod) throw new Error('模块不存在');
      return analyzePrompt({ text: mod.text, wallet: await assertOwnAddress(body.wallet) });
    },
  },
  {
    method: 'GET',
    match: /^\/api\/settings$/,
    async handler() {
      return publicConfig(await getConfig());
    },
  },
  {
    method: 'POST',
    match: /^\/api\/settings$/,
    async handler(_req, _m, _url, body) {
      const patch = { ai: {}, rpcs: {}, wss: {} };
      // 每个节点独立保存：空字符串表示「不修改、保留原值」，只有显式的 clear 才清空。
      // 这样在设置页只填其中一个节点并保存时，不会把其它已配置的节点覆盖成空。
      if (body.rpcs && typeof body.rpcs === 'object') {
        for (const id of ['56', '1', '8453', '4663']) {
          if (typeof body.rpcs[id] !== 'string') continue;
          const v = body.rpcs[id].trim();
          if (v) patch.rpcs[id] = assertRpcUrl(v);
        }
      }
      // 显式清空某些链的 RPC：body.clearRpcs = ['4663', ...]
      if (Array.isArray(body.clearRpcs)) {
        for (const id of body.clearRpcs) if (['56', '1', '8453', '4663'].includes(String(id))) patch.rpcs[String(id)] = '';
      }
      if (body.wss && typeof body.wss === 'object' && typeof body.wss['56'] === 'string') {
        const v = body.wss['56'].trim();
        if (v) patch.wss['56'] = assertWssUrl(v);
      }
      if (body.clearWss === true) patch.wss['56'] = '';
      // 启用的节点同时并入备用池，保证「当前启用」始终出现在候选列表里
      const curPools = (await getConfig()).pools || {};
      const addToPool = (key, url) => {
        if (!url) return;
        const list = [...(patch.pools?.[key] || curPools[key] || [])];
        if (!list.includes(url)) list.push(url);
        patch.pools = { ...(patch.pools || {}), [key]: list };
      };
      for (const id of ['56', '1', '8453', '4663']) if (patch.rpcs[id]) addToPool(`rpc:${id}`, patch.rpcs[id]);
      if (patch.wss['56']) addToPool('wss:56', patch.wss['56']);
      if (typeof body.bscRpc === 'string') patch.rpcs['56'] = assertRpcUrl(body.bscRpc.trim());
      if (typeof body.ethRpc === 'string') patch.rpcs['1'] = assertRpcUrl(body.ethRpc.trim());
      const newKey = typeof body.aiKey === 'string' ? body.aiKey.trim() : '';
      if (typeof body.aiBaseUrl === 'string' && body.aiBaseUrl.trim()) {
        const next = assertServiceUrl(body.aiBaseUrl.trim(), 'AI Base URL');
        const current = (await getConfig()).ai;
        // 换主机时必须同时给新 Key：否则旧 Key 会在下一次解析时被发到新主机
        if (new URL(next).host !== new URL(current.baseUrl).host && current.apiKey && !newKey) {
          throw new Error('更换 AI Base URL 主机时必须同时填写该服务的 API Key（旧 Key 不会发往新主机）');
        }
        patch.ai.baseUrl = next;
      }
      if (typeof body.aiModel === 'string' && body.aiModel.trim()) patch.ai.model = body.aiModel.trim().slice(0, 100);
      if (newKey) patch.ai.apiKey = newKey;
      if (body.clearAiKey === true) patch.ai.apiKey = '';
      await saveConfig(patch);
      reloadHub().catch(() => {}); // WSS 节点变了：共享连接迁移到新节点（订阅自动带过去）
      return publicConfig(await getConfig());
    },
  },
  {
    // 双节点 WSS 订阅开关（默认关）：开了以后备用节点同时订阅全部日志、先到先用，并统计谁快（后台任务页显示）
    method: 'POST',
    match: /^\/api\/settings\/wss-dual$/,
    async handler(_req, _m, _url, body) {
      if (typeof body.enabled !== 'boolean') throw new Error('enabled 需要是 true / false');
      await saveConfig({ wssDual: body.enabled });
      await reloadHub().catch(() => {});
      journal('settings.wssDual', { enabled: body.enabled });
      return publicConfig(await getConfig());
    },
  },
  {
    method: 'POST',
    match: /^\/api\/settings\/test-rpc$/,
    async handler(_req, _m, _url, body) {
      const chainId = String(body.chainId || '56');
      const config = await getConfig();
      const url = body.url ? assertRpcUrl(String(body.url).trim()) : chainRpcUrl(chainId, config);
      if (!url) throw new Error(`链 ${chainId} 未配置 RPC`);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
          signal: controller.signal,
        });
        const payload = await res.json();
        if (payload.error) throw new Error(payload.error.message || 'RPC error');
        return { ok: true, chainId, block: Number(BigInt(payload.result)) };
      } catch (err) {
        throw new Error(`链 ${chainId} RPC 连接失败：${err.message}`);
      } finally {
        clearTimeout(timer);
      }
    },
  },
  {
    method: 'POST',
    match: /^\/api\/settings\/nodes$/,
    // 备用节点池管理：action = add（加入，可选立即启用）| activate（切换启用）| remove（删除）
    async handler(_req, _m, _url, body) {
      const kind = body.kind === 'wss' ? 'wss' : 'rpc';
      const chainId = String(body.chainId || '56');
      const allowed = kind === 'wss' ? ['56'] : ['56', '1', '8453', '4663'];
      if (!allowed.includes(chainId)) throw new Error('不支持的链');
      const key = `${kind}:${chainId}`;
      const assertUrl = kind === 'wss' ? assertWssUrl : assertRpcUrl;
      // 规范列表：当前启用（主）始终在内，索引与前端 publicConfig 一致
      const { list, active: activeUrl } = nodeList(await getConfig(), kind, chainId);
      const setActive = (patch, url) => { if (kind === 'wss') patch.wss = { 56: url }; else patch.rpcs = { [chainId]: url }; };

      if (body.action === 'add') {
        const url = assertUrl(String(body.url || '').trim());
        if (!url) throw new Error('地址为空');
        if (!list.includes(url)) list.push(url);
        const patch = { pools: { [key]: list } }; // 始终把主节点一并持久化，保证索引稳定
        if (body.activate) setActive(patch, url);
        await saveConfig(patch);
      } else if (body.action === 'activate') {
        const url = list[Number(body.index)];
        if (!url) throw new Error('候选节点不存在');
        const patch = { pools: { [key]: list }, [kind === 'wss' ? 'wss' : 'rpcs']: {} };
        setActive(patch, url);
        await saveConfig(patch);
      } else if (body.action === 'remove') {
        const url = list[Number(body.index)];
        if (!url) throw new Error('候选节点不存在');
        const next = list.filter((_, i) => i !== Number(body.index));
        const patch = { pools: { [key]: next } };
        if (url === activeUrl) setActive(patch, next[0] || ''); // 删掉当前启用的则回退到第一条或清空
        await saveConfig(patch);
      } else {
        throw new Error('未知 action');
      }
      if (kind === 'wss') reloadHub().catch(() => {});
      return publicConfig(await getConfig());
    },
  },
  {
    method: 'POST',
    match: /^\/api\/settings\/test-wss$/,
    async handler(_req, _m, _url, body) {
      const url = body.url ? assertWssUrl(String(body.url).trim()) : chainWssUrl('56', await getConfig());
      if (!url) throw new Error('未配置 BSC WSS 节点');
      try {
        const r = await testWss(url);
        return { ok: true, block: r.block, rttMs: r.rttMs };
      } catch (err) {
        throw new Error(`WSS 连接失败：${err.message}`);
      }
    },
  },
  {
    method: 'POST',
    match: /^\/api\/agent\/analyze$/,
    async handler(_req, _m, _url, body) {
      return analyzePrompt({
        text: assertString(body.text, 'text', 40000),
        wallet: await assertOwnAddress(body.wallet),
      });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/task\/plan$/,
    async handler(_req, _m, _url, body) {
      return planMint({
        wallet: await assertOwnAddress(body.wallet),
        text: assertString(body.text, 'text', 40000),
      });
    },
  },
  {
    method: 'GET',
    match: /^\/api\/tx\/receipt$/,
    async handler(_req, _m, url) {
      const hash = String(url.searchParams.get('hash') || '');
      const contract = String(url.searchParams.get('contract') || '');
      const wallet = String(url.searchParams.get('wallet') || '');
      if (!/^0x[0-9a-fA-F]{64}$/.test(hash)) throw new Error('tx hash 格式不正确');
      if (!/^0x[0-9a-fA-F]{40}$/.test(contract) || !/^0x[0-9a-fA-F]{40}$/.test(wallet)) {
        throw new Error('contract/wallet 地址不正确');
      }
      return decodeMintReceipt({ hash, contract, wallet });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/ai\/parse$/,
    async handler(_req, _m, _url, body) {
      return parsePrompt({
        text: assertString(body.text, 'text', 40000),
        wallet: assertAddress(body.wallet, 'wallet'),
      });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/flap\/plan$/,
    async handler(_req, [id], _url, body) {
      const expect = {
        probe: body.expect?.probe || '',
        quote: body.expect?.quote || '',
        decimals: body.expect?.decimals || '',
      };
      // 计划里的 wallet 会进入 probe 调用与额度判断，必须就是路径上的这个钱包
      const evm = await walletEvm(id);
      if (body.wallet && String(body.wallet).toLowerCase() !== evm.toLowerCase()) {
        throw new Error('wallet 与当前钱包地址不一致');
      }
      const op = ['buy', 'sell', 'claim', 'query'].includes(body.op) ? body.op : null;
      if (!op) throw new Error('op 必须是 buy / sell / claim / query');
      return planFlap({
        wallet: evm,
        market: assertAddress(body.market, 'market'),
        op,
        amount: String(body.amount ?? '0'),
        bps: Number(body.bps || 0),
        slippageBps: op === 'buy' || op === 'sell' ? assertSlippageBps(body.slippageBps) : 0,
        expect,
      });
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/preview$/,
    async handler(_req, [id], _url, body) {
      return doPreview(id, body);
    },
  },
  {
    method: 'POST',
    match: /^\/api\/w\/([^/]+)\/execute$/,
    async handler(_req, [id], _url, body) {
      if (body.confirm !== 'EXECUTE') throw new Error('missing confirmation');
      return doExecute(id, assertToken(body.requestId, 'requestId'));
    },
  },
  ...sniperRoutes,
  ...fourTradeRoutes,
  ...quickRoutes,
];

// 全量版功能包（狙击 / 打新 / 新部署发现）：有就加载，路由追加到最后；轻量版没有这个文件
await loadFeatures();
routes.push(...features.routes);
console.log(`[edition] ${EDITION() === 'full' ? '全量版（含狙击 / 打新）' : '轻量版（不含狙击 / 打新）'}`);

/** 发射后自动转移的依赖：同一套预览（白名单 + 记录 requestId）与广播（doExecute） */
function autoXferDeps() {
  return {
    walletEvm,
    listTargets,
    // 钱包实际持有的 BSC 代币（币安余额接口）：预授权时把已持有、未发射的 gang 代币加入监控
    heldTokens: async (walletId) => {
      const { tokens } = await walletBalance(walletId);
      return tokens.filter((t) => String(t.binanceChainId) === '56' && ADDR_RE.test(String(t.address || '')) && !/^0xe{40}$/i.test(t.address)).map((t) => t.address);
    },
    preview: (walletId, from, step) => previewStep(walletId, from, step),
    execute: (walletId, requestId) => doExecute(walletId, requestId),
  };
}

/**
 * 启动后恢复预授权（arms.json，见 arms.mjs）。设置里关掉 resumeArms 就一律不恢复（并清掉记录）。
 * 每项单独判断，失败只写日志、不影响其它项；结果汇总写 resume.summary，并在控制台打印一行。
 */
async function resumeSavedArms() {
  const saved = savedArms();
  const keys = Object.keys(saved);
  if (!keys.length) return;
  if ((await getConfig()).resumeArms === false) {
    for (const k of keys) clearArm(k);
    journal('resume.summary', { disabled: true, keys });
    console.log('[resume] 设置里关闭了「重启后自动恢复预授权」：已丢弃保存的预授权');
    return;
  }
  const results = [];
  for (const key of keys) {
    const s = saved[key];
    try {
      if (key.startsWith('direct:')) {
        if (!(await getWallet(s.walletId))) throw new Error('钱包已不存在');
        const r = await resumeDirect(s);
        if (!r.ok) throw new Error(r.why);
      } else if (key === 'autoxfer') {
        await resumeXfer(s, autoXferDeps());
      } else if (EDITION() === 'lite' && /^(snipe:|fairauto$|four$)/.test(key)) {
        // 轻量版没有这些功能：只跳过、不删记录（同一目录临时按轻量版起一次，不能把全量版的预授权清掉；
        // 回到全量版时照常按到期时间 / 上限签名复核）
        results.push({ key, ok: false, why: '轻量版不含这个功能（记录保留）' });
        journal('resume.skip', { key, why: '轻量版不含这个功能（记录保留）' });
        continue;
      } else if (!(await features.resume?.(key, s))) {
        throw new Error('未知类型');
      }
      results.push({ key, ok: true });
    } catch (err) {
      results.push({ key, ok: false, why: err.message });
      if (!features.keepOnResumeFail?.(key)) clearArm(key); // 恢复失败的不再留着（Four 的监听态由引擎自己维护）
      journal('resume.skip', { key, why: err.message });
    }
  }
  journal('resume.summary', { results });
  console.log(`[resume] ${results.map((r) => `${r.key}=${r.ok ? '已恢复' : `未恢复（${r.why}）`}`).join('；')}`);
}

/** BSC 代币美元单价：Pancake 智能路由估算 1 枚 → USDT，缓存 20 秒（/api/price 与持仓里的 BNB 行共用） */
async function bscUsdPrice(token) {
  const key = `price:56:${token.toLowerCase()}`;
  const hit = cacheGet(key);
  if (hit) return hit;
  const USDT = '0x55d398326f99059fF775485246999027B3197955';
  let usd = null;
  if (token.toLowerCase() === USDT.toLowerCase()) usd = 1;
  else {
    const meta = await tokenMeta(token).catch(() => null);
    if (meta) {
      const out = await estimateOut(token, USDT, 10n ** BigInt(meta.decimals)).catch(() => 0n);
      if (out > 0n) usd = Number(out) / 1e18; // BSC USDT 为 18 位
    }
  }
  const r = { usd, source: usd == null ? null : 'Pancake 池子报价（1 枚 → USDT）' };
  cacheSet(key, r, 20000);
  return r;
}

/**
 * GMGN 的持仓接口只返回代币，不含原生 BNB：第一页补一行 BNB（链上余额 × WBNB 价），合计 / 交易台 / 持仓页都能看到。
 * 读不到余额就原样返回（不影响代币持仓）。
 */
async function withNativeBnb(r, wallet) {
  const rows = r?.rows || [];
  if (rows.some((x) => x.native)) return r;
  // 持仓展示：余额与价格走公共节点
  const [wei, px] = await runBackground(() => Promise.all([
    rpcFor('56', 'eth_getBalance', [wallet, 'latest']).then((x) => BigInt(x)).catch(() => null),
    bscUsdPrice(WBNB_ADDR).then((x) => x.usd).catch(() => null),
  ]));
  if (wei == null || wei === 0n) return r;
  const balance = Number(fromWei(wei));
  const row = {
    token: null, native: true, logoToken: WBNB_ADDR, symbol: 'BNB', name: 'BNB（原生币）',
    price: px, balance, usdValue: px != null ? balance * px : null,
    unrealized: null, unrealizedPnl: null, realized: null, realizedPnl: null, totalProfit: null, totalPnl: null,
  };
  return { ...r, rows: [row, ...rows] };
}

/** contract-call preview：路由与狙击引擎共用（含全部白名单校验与 preview 记录） */
async function doPreview(walletId, body) {
  const chainId = assertString(String(body.chainId), 'chainId', 10);
  if (!CHAINS.has(chainId)) throw new Error('invalid chainId');
  const from = assertAddress(body.from, 'from');
  // 签名方必须是路径上的钱包本身，避免拿 A 钱包会话去签 B 地址的交易
  if (from.toLowerCase() !== (await walletEvm(walletId)).toLowerCase()) throw new Error('from 与该钱包地址不一致');
  const to = assertAddress(body.to, 'to');
  const value = assertWei(body.value);
  const inputData = assertHexData(body.inputData);
  const args = [
    'contract-call', 'preview',
    '--binanceChainId', chainId,
    '--from', from,
    '--to', to,
    '--value', value,
    '--inputData', inputData,
    '--json',
  ];
  const direct = { binanceChainId: chainId, from, to, value, inputData };
  if (body.gasLimit != null) {
    const gas = Number(body.gasLimit);
    if (!Number.isInteger(gas) || gas < 21000 || gas > 15000000) throw new Error('gasLimit 必须在 21000..15000000');
    args.splice(args.length - 1, 0, '--gasLimit', String(gas));
    direct.gasLimit = gas;
  }
  const r = await contractCall(walletId, 'preview', direct, args, 60000);
  if (r.data?.requestId) {
    rememberPreview(String(r.data.requestId), { walletId, chainId, from, to, value, inputData });
  }
  return { preview: r.data, ms: r.ms };
}

/*
 * 币安风控挂起 → 钱包锁定。
 * 一笔交易被风控挂起（execute 返回 PENDING_CONFIRMATION、没有 txHash）后，在用户到币安 App 确认 / 拒绝、或它过期之前，
 * 币安会拒绝这个钱包的**所有**新交易（API_351716，文案说「同一地址」，实测换个合约也一样；`wallet tx-lock` = LOCKED）。
 * 狙击、卖出、直接买入都会因此失败，所以要把原因说清楚，并让前端能查到锁定状态。
 * 2026-10-28 实测：一个钱包的授权交易被挂起后，之后 3 次卖出、2 次授权别的币都被 351716 拒绝。
 */
const LOCKED_RE = /API_351716|already in progress/i;
const appHolds = new Map(); // walletId → { at, to, selector, status }：本服务发出、被风控挂起的最后一笔
const walletLocks = new Map(); // walletId → { at, locked }：tx-lock 查询缓存
const LOCK_TTL_MS = 8000;
const SELECTOR_LABEL = { '0x095ea7b3': '授权（approve）', '0xa9059cbb': '转账（transfer）' };

function holdText(walletId) {
  const h = appHolds.get(walletId);
  if (!h) return '';
  const t = new Date(h.at).toLocaleTimeString('zh-CN', { hour12: false });
  return `${t} 发出的「${SELECTOR_LABEL[h.selector] || `合约调用 ${h.selector}`}」→ ${h.to}`;
}
function lockedMessage(walletId) {
  const h = holdText(walletId);
  return `这个钱包有一笔交易在等币安 App 确认${h ? `（${h}）` : ''}。确认或拒绝之前，币安会拒绝这个钱包的所有新交易（包括狙击、卖出），`
    + '重试不会成功。请打开币安 App → Agentic Wallet 处理这笔交易，或等它过期后再操作（API_351716）';
}

/** 启动时从执行日志恢复「被挂起的最后一笔」（最近 2 小时；之后又有正常广播的就不算） */
async function restoreHolds() {
  const since = Date.now() - 2 * 3600 * 1000;
  for (const r of await readJournal(3000).catch(() => [])) {
    if (r.type !== 'execute.done' || !r.walletId || !(Date.parse(r.at) > since)) continue;
    if (r.txHash) appHolds.delete(r.walletId);
    else appHolds.set(r.walletId, { at: Date.parse(r.at), to: r.to, selector: r.selector, status: r.status ?? null });
  }
}

/** 钱包是否被币安锁定（只读，CLI wallet tx-lock，缓存 8 秒） */
async function walletLockStatus(walletId) {
  const c = walletLocks.get(walletId);
  if (c && Date.now() - c.at < LOCK_TTL_MS) return c;
  const r = await bawJson(walletId, ['wallet', 'tx-lock', '--binanceChainId', '56', '--json'], 30000);
  const locked = String(r.data?.status || '').toUpperCase() === 'LOCKED';
  if (!locked) appHolds.delete(walletId);
  const out = { at: Date.now(), locked, status: r.data?.status ?? null, hold: appHolds.get(walletId) || null, holdText: holdText(walletId) || null };
  walletLocks.set(walletId, out);
  return out;
}

/** contract-call execute：只执行本服务为该钱包生成、未过期、未用过的 preview */
/**
 * equivWei（仅服务端内部调用传入）：这笔用报价币库存支付时折合的 BNB。每日上限按 max(value, equivWei) 计，
 * 否则用库存买入（value=0）完全不占每日额度。
 */
async function doExecute(walletId, requestId, { equivWei = 0n } = {}) {
  const rec = takePreview(requestId, walletId);
  const dailyWei = BigInt(rec.value || '0') > BigInt(equivWei) ? BigInt(rec.value || '0') : BigInt(equivWei);
  // 先记「准备广播」再调 CLI：即使广播过程中服务崩溃，日志里也能看到这笔
  const base = { walletId, requestId, to: rec.to, value: rec.value, selector: String(rec.inputData).slice(0, 10), ...(equivWei ? { equivWei: String(equivWei) } : {}) };
  // 每日 BNB 上限：所有功能共用的最后一道兜底（超限直接拒绝广播，preview 记录已被消费，需要重新预览）
  let release;
  try {
    release = await reserveDaily(walletId, dailyWei);
  } catch (err) {
    journal('execute.blocked', { ...base, error: err.message });
    throw err;
  }
  // 等这一行落盘再广播（追加写 < 1ms）：服务在广播途中被杀，重启后每日上限仍会把这笔算进去
  await journal('execute.begin', base);
  let r;
  try {
    r = await contractCall(walletId, 'execute', { requestId }, ['contract-call', 'execute', '--requestId', requestId, '--json'], 180000);
  } catch (err) {
    // CLI 超时 / 没返回 JSON（中途退出）/ 直连时请求已发出但没拿到明确答复：交易可能已经广播，按「已花」计入每日上限（宁可多算）
    const maybeSent = err.stage === 'network' || /^timeout after|did not return JSON/.test(String(err.message));
    release(maybeSent);
    journal('execute.error', { ...base, error: err.message, maybeSent });
    if (LOCKED_RE.test(String(err.message))) {
      walletLocks.delete(walletId); // 让下一次查锁状态重新问币安
      const e = new Error(lockedMessage(walletId));
      e.code = 'WALLET_LOCKED';
      throw e;
    }
    throw err;
  }
  await journal('execute.done', { ...base, txHash: r.data?.txHash || null, status: r.data?.status ?? r.data?.orderStatus ?? null, fields: Object.keys(r.data || {}), ms: r.ms });
  release(true); // 计入当天已花（内存计数），同时释放在途
  invalidateWalletCache(walletId);
  noteRouteSent(rec.inputData, r.data?.txHash); // 经 SmartRouter 的兑换：后台等回执，记进路由记录
  // 被币安风控挂起（没有 txHash）：记下是哪一笔。确认 / 拒绝 / 过期之前，币安会拒绝这个钱包的所有新交易（API_351716）
  if (!r.data?.txHash) {
    appHolds.set(walletId, { at: Date.now(), to: rec.to, selector: base.selector, status: r.data?.status ?? null });
    walletLocks.delete(walletId);
  } else if (appHolds.has(walletId)) {
    appHolds.delete(walletId); // 能正常广播，说明之前的挂起已经处理掉了
  }
  // 没有 txHash 不等于失败：币安风控可能把这笔挂起，等用户在 App 里确认（abnormalTxnHandling=NeedConfirmation，
  // gang 卖出实测如此）。前端据此提示「去 App 确认」，而不是当成已广播去等回执
  return { result: r.data, ms: r.ms, needsAppConfirm: !r.data?.txHash };
}

const server = http.createServer(async (req, res) => {
  // Host 白名单：挡住 DNS 重绑定；先于 new URL，避免畸形 Host 头抛出未捕获异常
  const host = String(req.headers.host || '');
  if (!ALLOWED_HOSTS.has(host)) {
    res.writeHead(421, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('host not allowed');
    return;
  }
  let url;
  try {
    url = new URL(req.url, `http://${host}`);
  } catch {
    res.writeHead(400); res.end('bad url'); return;
  }

  // 公网部署：IP 白名单 + 登录会话（本机运行时 authGate 直接放行）
  try {
    if (await authGate(req, res, url, { localHosts: LOCAL_HOSTS, extension: extensionCheck })) return;
  } catch (err) {
    console.error(`[auth] ${err.message}`);
    if (!res.headersSent) { res.writeHead(500); res.end('auth error'); }
    return;
  }

  if (url.pathname.startsWith('/api/')) {
    try {
      if (!['GET', 'POST', 'DELETE'].includes(req.method)) { json(res, 405, { ok: false, error: 'method not allowed' }); return; }
      assertApiRequest(req, url);
      // 页面 / 插件在用（serviceBusy 判断闲置用）；页面挂着自动轮询的状态接口不算，否则开着标签页就永远不闲置
      if (!PASSIVE_API.has(url.pathname)) lastUserApiAt = Date.now();
      const body = req.method === 'POST' ? await readBody(req) : {};
      for (const route of routes) {
        if (route.method !== req.method) continue;
        const m = url.pathname.match(route.match);
        if (!m) continue;
        const data = await route.handler(req, m.slice(1), url, body);
        if (data instanceof BinaryReply) {
          res.writeHead(200, {
            ...SECURITY_HEADERS,
            'content-type': data.type,
            'cache-control': 'private, max-age=86400',
          });
          res.end(data.body);
          return;
        }
        json(res, 200, { ok: true, data });
        return;
      }
      json(res, 404, { ok: false, error: 'not found' });
    } catch (err) {
      json(res, err instanceof HttpError ? err.status : 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, SECURITY_HEADERS); res.end('method not allowed'); return;
  }

  let pathname = url.pathname === '/' ? '/index.html' : url.pathname;
  if (!/^\/[A-Za-z0-9._/-]+$/.test(pathname) || pathname.includes('..')) {
    res.writeHead(400, SECURITY_HEADERS); res.end('bad path'); return;
  }

  try {
    let file = await readFile(path.join(__dirname, 'public', pathname));
    const headers = {
      ...SECURITY_HEADERS,
      'content-type': MIME[path.extname(pathname)] || 'application/octet-stream',
    };
    if (pathname === '/index.html') {
      // 令牌只注入到同源页面；禁止缓存，避免旧令牌残留。
      // 脚本 / 样式地址注入内容哈希（static_cache.mjs，对齐 gmgn-toolkit）：同步新代码后下一次打开页面自动换版本号
      const html = stripEditionBlocks(file.toString('utf8'), EDITION())
        .replace(TOKEN_PLACEHOLDER, API_TOKEN).replace('__AUTH_MODE__', authEnabled ? 'public' : 'local').replace('__EDITION__', EDITION());
      file = Buffer.from(await injectCacheBusters(html, path.join(__dirname, 'public')), 'utf8');
      headers['cache-control'] = 'no-store';
    } else {
      // private：Cloudflare 一律不缓存（静态文件在登录闸门后面，不能让 CDN 绕过闸门）。
      // 带 ?v=<内容哈希> 的内容是确定的 → 浏览器长缓存；不带的每次回源确认
      headers['cache-control'] = url.searchParams.has('v') ? 'private, max-age=31536000, immutable' : 'private, no-cache';
    }
    res.writeHead(200, headers);
    res.end(file);
  } catch {
    res.writeHead(404, SECURITY_HEADERS); res.end('not found');
  }
});

// 端口被占用 = 已有实例在跑：退出码 98，start.cmd 的守护循环据此不再重启
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`[webui] ${HOST}:${PORT} 已被占用（已有实例在运行）`);
    process.exit(98);
  }
  throw err;
});

/*
 * 「服务需重启」提示：记下启动时后端代码的最后修改时间；页面定期查 /api/version，
 * 磁盘上的后端代码比运行中的新时提示重启（避免「页面是新的、后端还是旧的」）。
 */
const BACKEND_DIRS = ['', 'quick', 'quick/platforms', 'agent', 'four', 'features'];
async function backendMtime() {
  const { readdir, stat } = await import('node:fs/promises');
  let max = 0;
  for (const d of BACKEND_DIRS) {
    const dir = path.join(__dirname, d);
    for (const f of await readdir(dir).catch(() => [])) {
      if (!f.endsWith('.mjs')) continue;
      const s = await stat(path.join(dir, f)).catch(() => null);
      if (s && s.mtimeMs > max) max = s.mtimeMs;
    }
  }
  return max;
}
const BOOT = { at: Date.now(), codeMtime: 0 };
backendMtime().then((m) => { BOOT.codeMtime = m; });
routes.unshift({
  method: 'GET',
  match: /^\/api\/version$/,
  async handler() {
    const now = await backendMtime();
    return { startedAt: BOOT.at, edition: EDITION(), stale: BOOT.codeMtime > 0 && now > BOOT.codeMtime + 1000 };
  },
});

server.listen(PORT, HOST, async () => {
  try {
    await writeFile(TOKEN_FILE, API_TOKEN, { encoding: 'utf8', mode: 0o600 });
  } catch (err) {
    console.warn(`无法写入 ${TOKEN_FILE}：${err.message}（仅影响 eval 等同机脚本）`);
  }
  console.log(`wallet console: http://${HOST}:${PORT}`);
  warmQuickRouter(serviceBusy);
  startPositions({ fourTargets: () => features.fourTargets?.() || [] }).catch((err) => console.warn(`[positions] 启动扫描失败：${err.message}`));
  // 第一次启动时把执行日志里的历史兑换导入路由记录（之后只增量记录；页面上可手动再导入）
  setTimeout(() => {
    if (listRoutes().importedAt || routeImporting) return;
    routeImporting = true;
    importRouteHistory()
      .then((s) => console.log(`[routes] 历史兑换导入：扫描 ${s.scanned}、导入 ${s.imported}（其中失败 ${s.failed}）、跳过 ${s.skipped}`))
      .catch((err) => console.warn(`[routes] 历史导入失败：${err.message}`))
      .finally(() => { routeImporting = false; });
  }, 20000).unref?.();
  keepBinanceWarm(serviceBusy, binanceSocketsWanted); // 到币安的 HTTPS 长连接保活（直连 preview / execute 用），条数按钱包数；闲置时不发
  setTimeout(() => { gangQuoteIndex().catch(() => {}); }, 5000).unref?.(); // 后台建 gang 报价币索引（批量预授权 / 添加报价币用）
  features.start?.(); // 全量版：新部署发现 / gang V3 与打新监控
  // 恢复重启前的预授权（arms.json）：等 4 秒让 WSS 连接 / 路由预热先起来
  setTimeout(() => { resumeSavedArms().catch((err) => console.error(`[resume] ${err.message}`)); }, 4000).unref?.();
  restoreHolds().catch(() => null); // 重启前被币安风控挂起的那一笔（钱包锁定提示用）
  // 后台预热缓存：启动 3 秒后首刷，之后每 PREWARM_INTERVAL_MS 刷一次（unref 不阻止进程退出）
  setTimeout(() => { prewarmAll(); }, 3000).unref?.();
  // 闲置（没有自动化在跑、10 分钟内没人用页面 / 插件）时登录状态 5 分钟查一次，有人用或有自动化时按 PREWARM_INTERVAL_MS
  setInterval(() => {
    if (serviceBusy() || Date.now() - lastIdlePrewarm > IDLE_PREWARM_MS) { lastIdlePrewarm = Date.now(); prewarmAll(); }
  }, PREWARM_INTERVAL_MS).unref?.();
});
