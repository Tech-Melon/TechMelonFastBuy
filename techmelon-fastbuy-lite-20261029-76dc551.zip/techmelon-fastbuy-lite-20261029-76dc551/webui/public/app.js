const NATIVE = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';

/* 链元数据。代币不再写死在前端：由服务端 /api/w/:id/tokens 按链返回
 * （本地预设稳定币经链上复核 + Uniswap 官方代币列表 + 钱包持仓）。
 * gasReserve：MAX 时为原生币预留的 gas。 */
const CHAINS = [
  { id: '56', name: 'BSC', native: 'BNB', gasReserve: '0.002' },
  { id: '1', name: 'Ethereum', native: 'ETH', gasReserve: '0.005' },
  { id: '8453', name: 'Base', native: 'ETH', gasReserve: '0.0005' },
  { id: '42161', name: 'Arbitrum', native: 'ETH', gasReserve: '0.0005' },
  { id: '137', name: 'Polygon', native: 'POL', gasReserve: '0.5' },
];

const state = {
  wallets: [],
  active: null,
  summary: null,
  quote: null,
  preview: null,
  flap: { plan: null, previews: {}, executed: {} },
  ai: null,
  aiPlan: null,
  agent: null,
  agentResult: null,
  modules: [],
  selectedWallets: new Set(),
  addresses: [],
  metricsPeriod: (() => {
    try { return localStorage.getItem('walletui:metricsPeriod') || '24h'; } catch { return '24h'; }
  })(),
  mint: { previews: {}, executed: {} },
  trade: { from: null, to: null },
  send: { token: null },
};

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

/*
 * 版本：全量版（含狙击 / 打新 / 发射台）或轻量版（没有这些页面和后端接口）。服务端写进 <meta name="edition">。
 * 轻量版的页面里没有狙击 / 打新 / 发射台的元素：初始化（wire）时找不到的元素绑到一个不挂在页面上的占位元素，
 * 这些功能的加载 / 轮询按 FULL 跳过，不会去请求不存在的接口。
 */
const EDITION = document.querySelector('meta[name="edition"]')?.content === 'lite' ? 'lite' : 'full';
const FULL = EDITION === 'full';
/** 绑定事件用：元素不存在（轻量版裁掉了）时返回占位元素，赋 onclick / addEventListener 都无副作用 */
const $w = (sel) => document.querySelector(sel) || document.createElement('div');

/* ---------- 安全 HTML 模板 ----------
 * 所有写入 innerHTML 的动态内容必须经过 h`...`：插值默认转义，
 * 只有 h`` 生成的 SafeHtml（或数组）才会原样拼接。链上 symbol、LLM 输出、
 * 钱包名、错误信息等一律视为不可信数据。 */
class SafeHtml {
  constructor(html) { this.html = html; }
  toString() { return this.html; }
}

const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' };

function escHtml(value) {
  return String(value ?? '').replace(/[&<>"'`]/g, (c) => HTML_ESCAPES[c]);
}

function toHtml(value) {
  if (value instanceof SafeHtml) return value.html;
  if (Array.isArray(value)) return value.map(toHtml).join('');
  return escHtml(value);
}

function h(strings, ...values) {
  let out = strings[0];
  values.forEach((v, i) => { out += toHtml(v) + strings[i + 1]; });
  return new SafeHtml(out);
}

function rowsHtml(rows) {
  return rows.map(([k, v]) => h`<div class="row"><span class="muted">${k}</span><span class="mono">${addrTextHtml(v)}</span></div>`);
}

function warnsHtml(list) {
  if (!list?.length) return '';
  return h`<p class="warn">${list.map((w, i) => (i ? h`<br>${w}` : h`${w}`))}</p>`;
}

/** wei（整数字符串 / number）→ 十进制字符串，BigInt 运算不丢精度 */
function weiToHuman(wei, decimals = 18) {
  let s;
  // CLI 的 balanceChanges 用 JSON number 表示，超过 2^53 已丢精度：标「≈」，不冒充精确值
  if (typeof wei === 'number') s = wei.toLocaleString('fullwide', { useGrouping: false, maximumFractionDigits: 0 });
  else s = String(wei ?? '0');
  // 双精度只有约 15 位有效数字：1e17 这类整数是精确的，有效数字更多时才可能丢精度
  const approx = typeof wei === 'number' && !Number.isSafeInteger(wei)
    && s.replace(/^-/, '').replace(/0+$/, '').length > 15;
  if (approx) return `≈${weiToHuman(s, decimals)}`;
  const neg = s.startsWith('-');
  if (neg) s = s.slice(1);
  if (!/^\d+$/.test(s)) return String(wei);
  const d = Number(decimals) || 0;
  const padded = s.padStart(d + 1, '0');
  const whole = d ? padded.slice(0, -d) : padded;
  const frac = d ? padded.slice(-d).replace(/0+$/, '') : '';
  return `${neg ? '-' : ''}${whole}${frac ? `.${frac}` : ''}`;
}

/** 交易 value 的可读形式：0.1 BNB / 0.01 ETH（各链原生币符号不同） */
function nativeValue(chainId, wei) {
  return `${weiToHuman(wei)} ${nativeSymbol(chainId)}`;
}

/** 代币地址的可读名：0xeeee… 是各链原生币的通用占位地址（EIP-7528），不是合约 */
function tokenLabel(chainId, address, info) {
  if (String(address).toLowerCase() === NATIVE) return `${nativeSymbol(chainId)}（原生币，无合约）`;
  const sym = info?.symbol || presetSymbol(chainId, address);
  return sym ? `${sym}（${short(address)}）` : address;
}

/** CLI preview 的人类可读摘要：模拟结果、余额变化（按代币精度换算）、授权变化、风险 */
function previewSummary(preview, chainId) {
  const sim = preview?.simulationResult || {};
  const infos = preview?.tokenInfos || {};
  const infoOf = (a) => infos[a] || infos[String(a).toLowerCase()]
    || Object.entries(infos).find(([k]) => k.toLowerCase() === String(a).toLowerCase())?.[1];
  const ok = !sim.simulationErrorDetail && (!sim.simulationCode || /^0+$/.test(String(sim.simulationCode)));
  const rows = [['模拟结果', ok ? '成功' : `失败：${sim.simulationErrorDetail || sim.simulationCode}`]];
  for (const bc of sim.balanceChanges || []) {
    const info = infoOf(bc.contractAddress);
    const isNative = String(bc.contractAddress).toLowerCase() === NATIVE;
    const amount = weiToHuman(bc.change, isNative ? 18 : (info?.decimals ?? 18));
    const sign = /^≈?-/.test(amount) ? '' : '+';
    const sym = isNative ? nativeSymbol(chainId) : (info?.symbol || '代币');
    rows.push([`余额变化 · ${tokenLabel(chainId, bc.contractAddress, info)}`, `${sign}${amount} ${sym}`]);
  }
  const warns = [];
  if (sim.allowanceChanges?.length) warns.push(`包含 ${sim.allowanceChanges.length} 项授权（allowance）变化，请核对授权对象与额度`);
  if (sim.authorityChanges?.length) warns.push(`包含 ${sim.authorityChanges.length} 项权限变化`);
  const risks = preview?.risks?.riskDetails || [];
  if (risks.length) warns.push(`风险提示 ${risks.length} 项：${risks.map((r) => r.riskDesc || r.riskType || JSON.stringify(r)).join('；')}`);
  return { ok, rows, warns };
}

/** 把 preview 渲染到步骤里：可读摘要在上，原始 JSON 折叠 */
function renderPreview(el, preview, chainId) {
  const s = previewSummary(preview, chainId);
  el.hidden = false;
  el.classList.remove('pre-err');
  el.innerHTML = h`
    <div class="preview-summary">${rowsHtml(s.rows)}${warnsHtml(s.warns)}</div>
    <details><summary>原始返回（JSON）· 0xeeee… 代表原生币占位地址</summary><pre class="pre">${JSON.stringify(preview, null, 2)}</pre></details>`;
  if (!s.ok) el.classList.add('pre-err');
  return s.ok;
}

/** 预览拿到 requestId 且模拟成功才允许执行：模拟失败的交易不该能一键广播 */
function previewExecutable(preview, chainId) {
  return Boolean(preview?.requestId) && previewSummary(preview, chainId).ok;
}

function previewSummaryText(preview, chainId) {
  const s = previewSummary(preview, chainId);
  return [...s.rows.map(([k, v]) => `${k}：${v}`), ...s.warns].join('；');
}

/** 说明性信息（非风险）：灰色小字，与红色警告区分 */
function notesHtml(list) {
  if (!list?.length) return '';
  return h`<ul class="notes">${list.map((n) => h`<li>${n}</li>`)}</ul>`;
}

function checksTableHtml(checks, title = '校验') {
  return h`
    <table class="table">
      <thead><tr><th>${title}</th><th>结果</th><th>值</th></tr></thead>
      <tbody>${(checks || []).map((c) => h`<tr><td>${c.name}</td><td>${c.ok ? '✅' : '❌'}</td><td class="mono">${caHtml(String(c.detail))}</td></tr>`)}</tbody>
    </table>`;
}

/** 计划步骤所在链：服务端在 tx.chainId 中给出；旧计划（Flap/Gang/Mint/custom）都在 BSC */
function stepChainId(step) {
  return String(step?.tx?.chainId ?? '56');
}

function sourceLabel(source) {
  if (source === 'llm') return 'DeepSeek';
  if (source === 'rules+llm') return '规则（模型补全）';
  return '规则解析';
}

function chainName(id) {
  return CHAINS.find((c) => c.id === String(id))?.name || String(id);
}

const EXPLORERS = {
  56: 'https://bscscan.com', 1: 'https://etherscan.io', 8453: 'https://basescan.org',
  42161: 'https://arbiscan.io', 137: 'https://polygonscan.com',
};

/** 交易哈希 → 区块浏览器链接（新窗口打开，不带 referrer） */
function txLinkHtml(chainId, hash, text) {
  const base = EXPLORERS[String(chainId)] || EXPLORERS[56];
  if (!/^0x[0-9a-fA-F]{64}$/.test(String(hash || ''))) return h`${text ?? short(hash)}`;
  return h`<a class="txlink mono" href="${`${base}/tx/${hash}`}" target="_blank" rel="noopener noreferrer" title="${hash}">${text ?? short(hash)} ↗</a>`;
}

/** 执行成功后的提示：带可点击的交易链接，停留更久 */
function toastTx(prefix, chainId, hash) {
  if (!hash) return toast(`${prefix}：已提交（未返回交易哈希，请到交易历史核对）`);
  const el = $('#toast');
  el.innerHTML = h`${prefix}：${txLinkHtml(chainId, hash)}`;
  el.classList.remove('err');
  el.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { el.hidden = true; }, 12000);
}

/** 链原生币符号 */
function nativeSymbol(chainId) {
  return CHAINS.find((c) => c.id === String(chainId))?.native || 'BNB';
}

/** 已加载代币目录里的符号；不在目录里返回空串 */
function presetSymbol(chainId, address) {
  return catalogToken(chainId, address)?.symbol || '';
}

/* ---------- 代币目录 / 图标 / 选择器 ---------- */

const catalogs = new Map(); // `${wallet}:${chain}` -> { at, data }
const CATALOG_TTL = 15000;

async function loadCatalog(chainId, force = false) {
  const key = `${state.active}:${chainId}`;
  const hit = catalogs.get(key);
  if (!force && hit && Date.now() - hit.at < CATALOG_TTL) return hit.data;
  const data = await api(`/api/w/${state.active}/tokens?chainId=${chainId}`);
  catalogs.set(key, { at: Date.now(), data });
  return data;
}

function catalogToken(chainId, address) {
  const data = catalogs.get(`${state.active}:${chainId}`)?.data;
  const a = String(address || '').toLowerCase();
  return data?.tokens.find((t) => t.address.toLowerCase() === a) || null;
}

/** 按地址解析代币：先查目录，没有再读链上 symbol/decimals（标记为未认证/自定义） */
async function resolveToken(chainId, address) {
  const known = catalogToken(chainId, address);
  if (known) return known;
  if (String(address).toLowerCase() === NATIVE) {
    return { address: NATIVE, symbol: nativeSymbol(chainId), name: nativeSymbol(chainId), decimals: 18, native: true, verified: true };
  }
  const info = await api(`/api/token?chainId=${chainId}&address=${address}`);
  return { address, symbol: info.symbol || '?', name: info.name || '', decimals: info.decimals, verified: Boolean(info.verified), source: '自定义合约', custom: true };
}

/** 符号首字母 + 按地址稳定配色，作为图标加载前 / 无图标时的占位 */
function avatarHtml(chainId, t, size = '') {
  const addr = String(t?.address || '');
  let hash = 0;
  for (const ch of addr.toLowerCase()) hash = (hash * 31 + ch.charCodeAt(0)) % 360;
  const letter = String(t?.symbol || '?').replace(/^\$/, '').slice(0, 1).toUpperCase();
  return h`<span class="tok-ava ${size}" style="--hue:${hash}" data-logo="${t?.hasLogo ? `${chainId}|${addr}` : ''}" aria-hidden="true">${letter}</span>`;
}

const logoUrls = new Map(); // `${chain}|${addr}` -> objectURL | '' | Promise
let logoObserver = null;

/** 图标走带令牌的接口取回，再转成 blob URL；滚动到可见区域才加载 */
function hydrateLogos(root = document) {
  if (!logoObserver) {
    logoObserver = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        logoObserver.unobserve(e.target);
        applyLogo(e.target);
      }
    }, { rootMargin: '120px' });
  }
  root.querySelectorAll('.tok-ava[data-logo]:not([data-logo=""])').forEach((el) => {
    const key = el.dataset.logo;
    const url = logoUrls.get(key);
    if (typeof url === 'string') { if (url) setLogo(el, url); return; }
    logoObserver.observe(el);
  });
}

async function applyLogo(el) {
  const key = el.dataset.logo;
  let entry = logoUrls.get(key);
  if (entry === undefined) {
    const [chainId, address] = key.split('|');
    const url = `/api/token-logo?chainId=${chainId}&address=${address}`;
    const get = () => fetch(url, { headers: { 'x-api-token': API_TOKEN } });
    entry = get()
      .then(async (r) => (r.status === 401 && await refreshApiToken() ? get() : r))
      .then((r) => (r.ok ? r.blob() : null))
      .then((b) => (b && b.type.startsWith('image/') ? URL.createObjectURL(b) : ''))
      .catch(() => '');
    logoUrls.set(key, entry);
  }
  const url = await entry;
  logoUrls.set(key, url);
  if (url && el.dataset.logo === key) setLogo(el, url);
}

function setLogo(el, url) {
  if (el.querySelector('img')) return;
  const img = document.createElement('img');
  img.alt = '';
  img.src = url;
  el.classList.add('has-img');
  el.appendChild(img);
}

function verifiedBadge(t) {
  if (t.native) return '';
  if (t.verified) return h`<span class="vbadge ok" title="${t.source || '认证'}">✓ 认证</span>`;
  return h`<span class="vbadge warn" title="不在预设与官方代币列表中">未认证</span>`;
}

function tokenButtonHtml(chainId, t) {
  if (!t) return h`<span class="tok-pick-empty">选择代币</span><span class="caret">▾</span>`;
  return h`${avatarHtml(chainId, t)}<span class="tok-sym">${t.symbol}</span>${t.verified || t.native ? '' : h`<span class="vdot" title="未认证">!</span>`}<span class="caret">▾</span>`;
}

/** 十进制字符串 × 百分比（BigInt 运算，避免浮点误差），结果去掉末尾 0 */
function decPercent(value, pct, maxDecimals = 18) {
  const s = String(value || '0');
  if (!/^\d+(\.\d+)?$/.test(s)) return '0';
  const [w, f = ''] = s.split('.');
  const scale = 30;
  const n = BigInt(w + (f + '0'.repeat(scale)).slice(0, scale));
  const out = (n * BigInt(Math.round(pct * 100))) / 10000n;
  const str = out.toString().padStart(scale + 1, '0');
  const whole = str.slice(0, -scale).replace(/^0+(?=\d)/, '');
  const frac = str.slice(-scale).slice(0, maxDecimals).replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole;
}

function decSub(a, b) {
  const scale = 30;
  const toBig = (v) => {
    const [w, f = ''] = String(v || '0').split('.');
    return BigInt(w + (f + '0'.repeat(scale)).slice(0, scale));
  };
  const out = toBig(a) - toBig(b);
  if (out <= 0n) return '0';
  const str = out.toString().padStart(scale + 1, '0');
  const frac = str.slice(-scale).replace(/0+$/, '');
  return frac ? `${str.slice(0, -scale)}.${frac}` : str.slice(0, -scale);
}

/** 按比例填数量：原生币 100% 时预留 gas */
function amountByPercent(chainId, token, pct) {
  if (!token?.balance) return '';
  const decimals = Number.isInteger(token.decimals) ? token.decimals : 18;
  if (token.native && pct >= 100) {
    const reserve = CHAINS.find((c) => c.id === String(chainId))?.gasReserve || '0';
    // 向下取 8 位小数：既好读，又保证不超过余额
    return decPercent(decSub(token.balance, reserve), 100, Math.min(decimals, 8));
  }
  // ERC20 的 MAX 保留完整精度（卖光不留碎屑）；比例按 8 位小数向下取
  return decPercent(token.balance, pct, pct >= 100 ? decimals : Math.min(decimals, 8));
}

/**
 * 打开代币选择器。返回选中的代币对象，取消返回 null。
 * 列表：我的持仓 → 认证代币；可搜索符号/名称，或粘贴合约地址（读链上信息，标记为未认证）。
 */
function pickToken(chainId, { title = '选择代币', exclude = '' } = {}) {
  return new Promise((resolve) => {
    const dialog = $('#tokenDialog');
    const search = $('#tokenSearch');
    const listEl = $('#tokenList');
    $('#tokenDialogTitle').textContent = `${title} · ${chainName(chainId)}`;
    search.value = '';
    let data = null;
    let lookupSeq = 0;
    let done = false;

    const finish = (value) => {
      if (done) return;
      done = true;
      dialog.close();
      resolve(value);
    };

    const row = (t) => h`
      <button type="button" class="tok-row" role="option" data-addr="${t.address}">
        ${avatarHtml(chainId, t)}
        <span class="tok-main">
          <span class="tok-line"><b>${t.symbol}</b>${verifiedBadge(t)}${t.address.toLowerCase() === exclude.toLowerCase() ? h`<span class="muted small">另一侧已选 · 选择后两侧互换</span>` : ''}</span>
          <span class="muted tok-name">${t.name || ''}${t.native ? '' : h` · <span class="mono">${caHtml(t.address)}</span>`}</span>
        </span>
        <span class="tok-bal">${t.held ? h`<b class="mono">${fmt(t.balance, 6)}</b><span class="muted">$${fmt(t.value, 2)}</span>` : ''}</span>
      </button>`;

    const render = async () => {
      if (!data) return;
      const q = search.value.trim();
      const ql = q.toLowerCase();
      const isAddr = /^0x[0-9a-fA-F]{40}$/.test(q);
      let items = data.tokens;
      if (q) {
        items = items.filter((t) => (isAddr
          ? t.address.toLowerCase() === ql
          : t.symbol.toLowerCase().includes(ql) || String(t.name).toLowerCase().includes(ql)));
        // 符号完全匹配的排前面
        items = [...items].sort((a, b) => (b.symbol.toLowerCase() === ql) - (a.symbol.toLowerCase() === ql));
      }
      const held = items.filter((t) => t.held || t.native);
      const rest = items.filter((t) => !(t.held || t.native));
      const LIMIT = 150;
      listEl.innerHTML = h`
        ${held.length ? h`<div class="tok-group">我的持仓 / 原生币</div>${held.map(row)}` : ''}
        ${rest.length ? h`<div class="tok-group">认证代币</div>${rest.slice(0, LIMIT).map(row)}` : ''}
        ${rest.length > LIMIT ? h`<p class="hint center">还有 ${rest.length - LIMIT} 个，请输入关键字缩小范围</p>` : ''}
        ${!items.length && !isAddr ? h`<p class="hint center">没有匹配的代币。可以直接粘贴合约地址。</p>` : ''}`;
      hydrateLogos(listEl);

      if (isAddr && !items.length) {
        const seq = ++lookupSeq;
        listEl.innerHTML = '<p class="hint center">正在读取链上代币信息…</p>';
        try {
          const t = await resolveToken(chainId, q);
          if (seq !== lookupSeq) return;
          listEl.innerHTML = h`<div class="tok-group">自定义合约</div>${row(t)}
            <p class="warn small">该合约不在预设与官方代币列表中，名称和符号可被任意伪造，请确认合约地址来源可信。</p>`;
          bindRows([t]);
        } catch (err) {
          if (seq !== lookupSeq) return;
          listEl.innerHTML = h`<p class="err small">${err.message}</p>`;
        }
        return;
      }
      bindRows(items);
    };

    const bindRows = (items) => {
      listEl.querySelectorAll('.tok-row:not([disabled])').forEach((b) => {
        b.onclick = () => finish(items.find((t) => t.address === b.dataset.addr) || null);
      });
    };

    search.oninput = render;
    search.onkeydown = (e) => {
      if (e.key === 'Enter') listEl.querySelector('.tok-row:not([disabled])')?.click();
    };
    $('#tokenDialogClose').onclick = () => finish(null);
    dialog.onclose = () => finish(null);
    listEl.innerHTML = '<p class="hint center">加载中…</p>';
    dialog.showModal();
    setTimeout(() => search.focus(), 0);

    loadCatalog(chainId).then((d) => {
      data = d;
      $('#tokenListFoot').textContent = `认证来源：本地预设（链上复核）+ ${(d.list?.sources || []).join(' + ')}`
        + (d.list?.error ? `（部分不可用：${d.list.error}）` : '');
      render();
    }).catch((err) => {
      listEl.innerHTML = h`<p class="err small">${err.message}</p>`;
    });
  });
}

/** 只允许 http(s) 链接，挡住 javascript: 等协议 */
function safeHttpUrl(value) {
  try {
    const u = new URL(String(value));
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : '';
  } catch {
    return '';
  }
}

// 服务端每次启动生成的本地 API 令牌（注入在 index.html 的 meta 中）
let API_TOKEN = document.querySelector('meta[name="api-token"]')?.content || '';
let tokenRefresh = null;

/**
 * 服务重启后令牌会轮换，已打开的页面拿着旧令牌会全部 401（「missing or invalid api token」）。
 * 同源重新取一次 index.html 读新令牌：跨站页面读不到同源响应，安全模型不变。
 */
function refreshApiToken() {
  if (!tokenRefresh) {
    tokenRefresh = fetch('/', { cache: 'no-store', credentials: 'same-origin' })
      .then((r) => (r.ok ? r.text() : ''))
      .then((html) => {
        const m = html.match(/<meta name="api-token" content="([0-9a-f]{64})"/);
        if (!m) return false;
        const changed = m[1] !== API_TOKEN;
        API_TOKEN = m[1];
        return changed;
      })
      .catch(() => false)
      .finally(() => { setTimeout(() => { tokenRefresh = null; }, 1000); });
  }
  return tokenRefresh;
}

async function api(path, method = 'GET', body, retried = false) {
  const headers = { 'x-api-token': API_TOKEN };
  // 服务端对所有 POST 都要求 application/json（即使无 body）；DELETE/GET 不需要
  if (body || method === 'POST') headers['content-type'] = 'application/json';
  const res = await fetch(path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  // 公网部署：登录会话过期 → 回登录页（请求在登录闸门就被拦下，业务逻辑没有执行）
  if (res.status === 401 && res.headers.get('x-auth-required')) {
    location.assign('/login');
    throw new Error('登录已过期，请重新登录');
  }
  // 401 在服务端鉴权闸门就被拦下、业务逻辑没有执行，所以换新令牌后重试一次是安全的（包括变更类请求）
  if (res.status === 401 && !retried && await refreshApiToken()) return api(path, method, body, true);
  const payload = await res.json().catch(() => ({ ok: false, error: 'invalid response' }));
  if (res.status === 401) throw new Error('本地服务令牌已失效（服务可能刚重启），请刷新页面');
  if (!res.ok || !payload.ok) throw new Error(payload.error || `HTTP ${res.status}`);
  return payload.data;
}

function toast(message, isError = false) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.toggle('err', isError);
  el.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { el.hidden = true; }, isError ? 7000 : 3500);
}

function short(addr) {
  return addr && addr.length > 14 ? `${addr.slice(0, 8)}…${addr.slice(-6)}` : addr || '—';
}

function fmt(value, digits = 6) {
  const n = Number(value);
  if (!Number.isFinite(n)) return value ?? '—';
  if (n === 0) return '0';
  if (Math.abs(n) >= 1000) return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  return n.toLocaleString('en-US', { maximumFractionDigits: digits });
}

/* ---------- 地址一键复制 ----------
 * 页面上显示的合约 / 钱包地址一律用 caHtml() 渲染：点一下复制完整地址（悬停看全称）。
 * 复制由 document 上的一个捕获阶段监听统一处理（wireCopy），渲染处不用逐个绑定；
 * 捕获阶段拦下点击，所以地址放在按钮 / 可点击行里时，点地址只复制，不会触发外层动作。 */
const ADDR40 = /^0x[0-9a-fA-F]{40}$/;
function caHtml(addr, text) {
  const a = String(addr || '');
  if (!ADDR40.test(a)) return h`${text ?? short(a)}`;
  return h`<span class="ca-copy mono" data-copy="${a}" title="${a}（点击复制）">${text ?? short(a)}</span>`;
}
/** 紧跟在 BscScan 链接后面的小复制按钮（链接本身点击仍然打开浏览器） */
function copyBtnHtml(addr) {
  return ADDR40.test(String(addr || '')) ? h`<button type="button" class="copy-btn" data-copy="${addr}" title="复制 ${addr}" aria-label="复制地址">⧉</button>` : '';
}
/** 纯文本里的完整地址变成可复制（保留全称，确认框里要看全地址核对）；SafeHtml 原样返回 */
function addrTextHtml(v) {
  if (v instanceof SafeHtml || Array.isArray(v)) return v;
  const s = String(v ?? '');
  const out = [];
  let last = 0;
  for (const m of s.matchAll(/0x[0-9a-fA-F]{40}(?![0-9a-fA-F])/g)) {
    out.push(h`${s.slice(last, m.index)}`, caHtml(m[0], m[0]));
    last = m.index + m[0].length;
  }
  out.push(h`${s.slice(last)}`);
  return h`${out}`;
}
function wireCopy() {
  document.addEventListener('click', async (e) => {
    const el = e.target.closest?.('[data-copy]');
    if (!el) return;
    e.preventDefault();
    e.stopPropagation();
    const a = el.dataset.copy;
    try {
      await navigator.clipboard.writeText(a);
      toast(`已复制 ${short(a)}`);
      el.classList.add('copied');
      setTimeout(() => el.classList.remove('copied'), 900);
    } catch { toast('复制失败（浏览器不允许访问剪贴板）', true); }
  }, true);
}

async function copyAddr(selector) {
  const text = $(selector).textContent;
  if (!text || text === '—') return;
  try {
    await navigator.clipboard.writeText(text);
    toast('地址已复制');
  } catch {
    toast('复制失败', true);
  }
}

function setBusy(button, busy, label) {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.textContent;
    button.disabled = true;
    button.textContent = label || '处理中…';
  } else {
    button.disabled = false;
    if (button.dataset.label) button.textContent = button.dataset.label;
  }
}

function confirmDialog(title, rows, warn) {
  return new Promise((resolve) => {
    const dialog = $('#confirmDialog');
    $('#confirmTitle').textContent = title;
    $('#confirmBody').innerHTML = h`${rows.map(([k, v]) => h`<div class="row"><span class="muted">${k}</span><span class="mono">${addrTextHtml(v)}</span></div>`)}${warn ? h`<p class="warn">${warn}</p>` : ''}`;

    const cleanup = () => {
      $('#confirmOk').onclick = null;
      $('#confirmCancel').onclick = null;
      dialog.close();
    };
    $('#confirmOk').onclick = () => { cleanup(); resolve(true); };
    $('#confirmCancel').onclick = () => { cleanup(); resolve(false); };
    dialog.showModal();
  });
}

function fillChainSelects() {
  for (const sel of ['#tradeChain', '#sendChain', '#ccChain']) {
    const el = $(sel);
    if (!el) continue;
    el.innerHTML = h`${CHAINS.map((c) => h`<option value="${c.id}">${c.name} (${c.id})</option>`)}`;
  }
}

const FORM_KEY = 'walletui:formState';
const FORM_FIELDS = [
  'tradeChain', 'tradeAmount', 'tradeSlippage', 'sendChain', 'sendAmount', 'sendRecipient',
  'flapMarket', 'flapOp', 'flapSlip', 'flapAmount', 'flapBps',
  'ccChain', 'ccTo', 'ccValue', 'ccData', 'aiText',
  'addrBookSelect', 'newWalletName', 'addrBookName',
  'fourMode', 'fourPreset', 'fourSlip', 'fourChase', 'fourTax', 'fourFee', 'fourWait', 'fourGasMode', 'fourGasLimit', 'fourExclude',
  'fourTradeToken', 'fourTradeSide', 'fourTradeMode', 'fourTradeAmount', 'fourTradeSlip',
  'quickToken', 'quickTokenFour', 'quickTokenGang', 'quickTokenFlap', 'quickSlip', 'quickSlipCustom', 'quickPresets', 'quickBuyAmount', 'quickSellAmount',
  'invAmount', 'invSlip', 'invCa', 'xferPct', 'xferExtra', 'xferNewName',
  'axHours', 'axV2Pct', 'axV3Pct', 'axFairPct', 'axFairMode', 'axTokens', // 发射后自动转移（复选框 / 钱包 / 收款地址见 AX_KEY）
  'quickArmHours', // 直接买入有效期
  // 内盘狙击的参数按发射台（V2 / V3）各存一份，见 saveSnipeForm / loadSnipeForm，不放在这里
  'gmgnAddress', // GMGN API Key 是凭据，不存浏览器
  'fairPad', 'fairRouter', 'fairToken', 'fairShares', 'v3Pad', 'v3Router',
  'fairAutoShares', 'fairAutoPerSale', 'fairAutoTotal', 'fairAutoMaxSales', 'fairAutoMintFee', 'fairAutoExitFee', 'fairAutoHours',
  'sboardDays', 'sboardSrc', 'sboardWallet', // 狙击看板（sboardWallet 的选项是动态的，在 fillSboardWallets 里恢复）
];

function readFormState() {
  try { return JSON.parse(localStorage.getItem(FORM_KEY) || '{}'); } catch { return {}; }
}

function saveField(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const stateObj = readFormState();
  stateObj[id] = el.value;
  try { localStorage.setItem(FORM_KEY, JSON.stringify(stateObj)); } catch { /* ignore */ }
}

function restoreFormState() {
  const st = readFormState();

  for (const id of ['tradeAmount', 'tradeSlippage', 'sendAmount', 'sendRecipient',
    'flapMarket', 'flapOp', 'flapSlip', 'flapAmount', 'flapBps',
    'ccChain', 'ccTo', 'ccValue', 'ccData', 'aiText',
    'newWalletName', 'addrBookSelect', 'addrBookName',
    'fourMode', 'fourPreset', 'fourSlip', 'fourChase', 'fourTax', 'fourFee', 'fourWait', 'fourGasMode', 'fourGasLimit', 'fourExclude',
    'fourTradeToken', 'fourTradeSide', 'fourTradeMode', 'fourTradeAmount', 'fourTradeSlip',
    'quickToken', 'quickTokenFour', 'quickTokenGang', 'quickTokenFlap', 'quickSlip', 'quickSlipCustom', 'quickPresets', 'quickBuyAmount', 'quickSellAmount',
    'invAmount', 'invSlip', 'invCa', 'xferPct', 'xferExtra', 'xferNewName',
    'axHours', 'axV2Pct', 'axV3Pct', 'axFairPct', 'axFairMode', 'axTokens', 'quickArmHours',
    'gmgnAddress',
    'fairPad', 'fairRouter', 'fairToken', 'fairShares', 'v3Pad', 'v3Router',
    'fairAutoShares', 'fairAutoPerSale', 'fairAutoTotal', 'fairAutoMaxSales', 'fairAutoMintFee', 'fairAutoExitFee', 'fairAutoHours',
    'sboardDays', 'sboardSrc']) {
    const el = document.getElementById(id);
    if (el && st[id] != null) el.value = st[id];
  }
  syncQuickSlipCustom();
  // 旧版本没有 gas 模式：当时填 0 表示自动
  if (FULL && st.fourGasMode == null && st.fourGasLimit != null && Number(st.fourGasLimit) === 0) {
    $('#fourGasMode').value = 'auto';
    $('#fourGasLimit').value = '1000000';
  }
  syncGasMode('four');
  // 以前被浏览器自动填进去的「用户名」（如 deepseek-chat）会被存下来：不是地址就清掉
  const ga = $('#gmgnAddress');
  if (ga && ga.value && !/^0x[0-9a-fA-F]{40}$/.test(ga.value.trim())) { ga.value = ''; saveField('gmgnAddress'); }

  if (st.tradeChain) $('#tradeChain').value = st.tradeChain;
  if (st.sendChain) $('#sendChain').value = st.sendChain;
  syncSlippageButtons();
  $('#ccValueUnit').textContent = nativeSymbol($('#ccChain').value);
  toggleFlapFields();
}

/* 兑换 / 转账选中的代币（地址按链保存，切换钱包后用新钱包的余额重新解析） */
const TOKEN_SEL_KEY = 'walletui:tokenSel';

function readTokenSel() {
  try { return JSON.parse(localStorage.getItem(TOKEN_SEL_KEY) || '{}'); } catch { return {}; }
}

function saveTokenSel() {
  const v = {
    trade: { chainId: $('#tradeChain').value, from: state.trade.from?.address, to: state.trade.to?.address },
    send: { chainId: $('#sendChain').value, token: state.send.token?.address },
  };
  try { localStorage.setItem(TOKEN_SEL_KEY, JSON.stringify(v)); } catch { /* ignore */ }
}

/** 找默认代币：原生币；获得侧默认该链 USDT/USDC */
function defaultToken(data, side) {
  if (side === 'from') return data.tokens.find((t) => t.native) || data.tokens[0];
  return data.tokens.find((t) => /^USDT/.test(t.symbol) && t.verified)
    || data.tokens.find((t) => t.symbol === 'USDC' && t.verified)
    || data.tokens[1];
}

/** 用最新目录刷新已选代币（余额会变）；restore=true 时按本地保存的地址恢复 */
async function refreshTradeTokens({ restore = false } = {}) {
  const chainId = $('#tradeChain').value;
  try {
    const data = await loadCatalog(chainId, true);
    const saved = readTokenSel().trade || {};
    const pick = async (side) => {
      const want = restore && saved.chainId === chainId ? saved[side] : state.trade[side]?.address;
      if (want) {
        const hit = data.tokens.find((t) => t.address.toLowerCase() === want.toLowerCase());
        if (hit) return hit;
        try { return await resolveToken(chainId, want); } catch { /* 读不到就回落默认 */ }
      }
      return defaultToken(data, side);
    };
    state.trade.from = await pick('from');
    state.trade.to = await pick('to');
    if (state.trade.to?.address === state.trade.from?.address) state.trade.to = defaultToken(data, 'to');
  } catch (err) {
    $('#fromBalance').textContent = err.message;
  }
  renderTradeTokens();
  // 启动 / 切换链时恢复了数量与滑点：直接报价，不用再点按钮
  if (restore || !state.quote) invalidateQuote();
}

function renderTradeTokens() {
  const chainId = $('#tradeChain').value;
  const { from, to } = state.trade;
  $('#fromTokenBtn').innerHTML = tokenButtonHtml(chainId, from);
  $('#toTokenBtn').innerHTML = tokenButtonHtml(chainId, to);
  $('#fromBalance').textContent = from ? `余额 ${from.held || from.native ? fmt(from.balance || 0, 8) : '0'}` : '';
  $('#toBalance').textContent = to ? `余额 ${to.held || to.native ? fmt(to.balance || 0, 8) : '0'}` : '';
  const warn = [from, to].filter((t) => t && !t.verified && !t.native);
  $('#tokenHint').hidden = !warn.length;
  $('#tokenHint').innerHTML = warn.length
    ? h`⚠ ${warn.map((t) => h`<b>${t.symbol}</b> <span class="mono" title="${t.address}">${caHtml(t.address)}</span>`)} 未认证：不在预设与官方代币列表中，名称可被伪造，确认框会列出完整合约地址`
    : '';
  updateFromUsd();
  updateSwapButton();
  hydrateLogos($('#view-trade'));
}

/**
 * 代币美元单价：优先用钱包持仓（value / balance，币安钱包给的价格）；没有持仓时 BSC 上向服务端要池子报价（1 枚 → USDT），缓存 30 秒。
 * 拿不到返回 null。
 */
const priceCache = new Map();
async function tokenUsdPrice(t, chainId) {
  if (!t) return null;
  if (t.balance && Number(t.balance) > 0 && Number(t.value) > 0) return Number(t.value) / Number(t.balance);
  if (String(chainId) !== '56' || !t.address) return null;
  const key = `${chainId}:${String(t.address).toLowerCase()}`;
  const hit = priceCache.get(key);
  if (hit && Date.now() - hit.at < 30000) return hit.usd;
  try {
    const r = await api(`/api/price?chainId=${encodeURIComponent(chainId)}&token=${encodeURIComponent(t.address)}`);
    priceCache.set(key, { usd: r.usd, at: Date.now() });
    return r.usd;
  } catch { return null; }
}

/** 美元金额显示：小额多保留几位 */
const usdText = (v) => `$${fmt(v, v >= 1 ? 2 : 4)}`;

/** 支付侧金额的 USD 估值 */
let fromUsdSeq = 0;
async function updateFromUsd() {
  const seq = ++fromUsdSeq;
  const t = state.trade.from;
  const amount = Number($('#tradeAmount').value);
  const price = await tokenUsdPrice(t, $('#tradeChain').value);
  if (seq !== fromUsdSeq || t !== state.trade.from) return; // 期间改了数量 / 换了代币：只显示最新一次
  $('#fromUsd').textContent = price && amount > 0 ? `≈ ${usdText(amount * price)}` : '';
}

/**
 * 获得侧的美元价值：获得数量 × 获得代币单价；和支付侧价值对比，显示差了多少（价格冲击 + 手续费 + 税的合计）。
 * 返回 { toUsd, fromUsd, diffPct }，拿不到价格的项为 null。
 */
async function quoteValue(quote, from, to, chainId) {
  const [fp, tp] = await Promise.all([tokenUsdPrice(from, chainId), tokenUsdPrice(to, chainId)]);
  const fromUsd = fp ? Number(quote.fromCoinAmount) * fp : null;
  const toUsd = tp ? Number(quote.toCoinAmount) * tp : null;
  const diffPct = fromUsd && toUsd ? ((toUsd - fromUsd) / fromUsd) * 100 : null;
  return { fromUsd, toUsd, diffPct };
}

function syncSlippageButtons() {
  const v = $('#tradeSlippage').value;
  $$('[data-slip]').forEach((b) => {
    const on = b.dataset.slip === v;
    b.classList.toggle('active', on);
    b.setAttribute('aria-checked', String(on));
  });
}

async function chooseTradeToken(side) {
  const chainId = $('#tradeChain').value;
  const other = side === 'from' ? state.trade.to : state.trade.from;
  const t = await pickToken(chainId, { title: side === 'from' ? '选择支付代币' : '选择获得代币', exclude: other?.address || '' });
  if (!t) return;
  const otherSide = side === 'from' ? 'to' : 'from';
  // 选了另一侧已有的代币：两侧互换，而不是让两侧相同
  if (other && other.address.toLowerCase() === t.address.toLowerCase()) state.trade[otherSide] = state.trade[side];
  state.trade[side] = t;
  invalidateQuote();
  saveTokenSel();
  renderTradeTokens();
}

async function refreshSendToken({ restore = false } = {}) {
  const chainId = $('#sendChain').value;
  try {
    const data = await loadCatalog(chainId, true);
    const saved = readTokenSel().send || {};
    const want = restore && saved.chainId === chainId ? saved.token : state.send.token?.address;
    let t = want ? data.tokens.find((x) => x.address.toLowerCase() === want.toLowerCase()) : null;
    if (!t && want) t = await resolveToken(chainId, want).catch(() => null);
    state.send.token = t || defaultToken(data, 'from');
  } catch (err) {
    $('#sendBalance').textContent = err.message;
  }
  renderSendToken();
}

function renderSendToken() {
  const chainId = $('#sendChain').value;
  const t = state.send.token;
  $('#sendTokenBtn').innerHTML = tokenButtonHtml(chainId, t);
  $('#sendTokenMeta').innerHTML = !t ? ''
    : t.native ? h`${chainName(chainId)} 原生币`
      : h`合约 <span class="mono">${t.address}</span> ${verifiedBadge(t)}`;
  $('#sendBalance').textContent = t ? `可用 ${fmt(t.balance || 0, 8)} ${t.symbol}` : '';
  hydrateLogos($('#view-send'));
}

/* ---------- wallet ---------- */

function renderWalletTabs() {
  $('#walletTabs').innerHTML = h`${state.wallets
    .map((w) => h`<button class="wallet-tab ${w.lastStatus?.status && w.lastStatus.status !== 'CONNECTED' ? 'off' : ''}" data-id="${w.id}">${w.name}</button>`)}`;
  $$('.wallet-tab').forEach((btn) => {
    btn.onclick = () => selectWallet(btn.dataset.id);
  });
}

async function selectWallet(id) {
  state.active = id;
  try { localStorage.setItem('walletui:lastWallet', id); } catch { /* ignore */ }
  // 顶部钱包标签和「操作钱包」保持一致（两边互相同步；值相同时不再触发，避免来回）
  const qw = $('#quickWallet');
  if (qw && qw.value !== id && [...qw.options].some((o) => o.value === id)) {
    qw.value = id;
    qw.dispatchEvent(new Event('change')); // 会同时触发 onchange 和 addEventListener 的监听
  }
  state.quote = null;
  state.preview = null;
  state.flap = { plan: null, previews: {}, executed: {} };
  state.ai = null;
  $$('.wallet-tab').forEach((b) => b.classList.toggle('active', b.dataset.id === id));
  $('#connStatus').className = 'status';
  $('#connStatus').innerHTML = '<span class="dot"></span>加载中';
  $('#quoteBox').hidden = true;
  $('#btnSwap').disabled = true;
  $('#toAmount').textContent = '—';
  $('#toAmount').classList.add('placeholder');
  $('#btnExecute').disabled = true;
  $('#previewOut').hidden = true;
  $('#flapSummary').hidden = true;
  $('#flapSteps').innerHTML = '';
  $('#aiResult').hidden = true;
  $('#aiChecks').innerHTML = '';
  $('#aiSteps').innerHTML = '';
  $('#btnAiSaveModule').disabled = true;
  resetOverview();
  try {
    await refreshWallet();
    setTimeout(() => {
      if (state.active === id) {
        loadSummary().then(() => loadWalletSettings()).catch(() => {});
      }
    }, 2600);
  } catch (err) {
    toast(err.message, true);
  }
}

function resetOverview() {
  $('#wStatus').textContent = '—';
  $('#wEvm').textContent = '—';
  $('#wSol').textContent = '—';
  $('#wExpire').textContent = '—';
  $('#wQuota').textContent = '—';
  $('#quotaBar').style.width = '0%';
  $('#wDevMode').textContent = '';
  $('#balanceTable').querySelector('tbody').innerHTML = '<tr><td colspan="3" class="muted">加载中…</td></tr>';
}

async function refreshWallet() {
  const restore = !state.trade.from;
  // 兑换 / 转账的余额跟着钱包与交易结果刷新
  refreshTradeTokens({ restore });
  refreshSendToken({ restore });
  await Promise.all([loadSummary(), loadBalance(), loadMetrics()]);
  loadWalletSettings().catch((err) => console.warn('settings failed:', err.message));
  if ($('#view-history').classList.contains('active')) loadHistory();
}

function scheduleRefresh() {
  refreshWallet().catch(() => {});
  setTimeout(() => refreshWallet().catch(() => {}), 6000);
}

async function loadSummary() {
  const data = await api(`/api/w/${state.active}/summary`);
  state.summary = data;
  const evm = data.addresses.find((a) => a.chainName === 'Ethereum')?.address || data.addresses[0]?.address;
  const sol = data.addresses.find((a) => a.chainName === 'Solana')?.address;

  const statusLabel = data.status === 'CONNECTED' ? '已连接' : data.status === 'UNCONNECTED' ? '未连接' : '检查中…';
  $('#wStatus').innerHTML = h`<span class="dot" style="display:inline-block;background:${data.status === 'CONNECTED' ? 'var(--green)' : data.status === 'UNCONNECTED' ? 'var(--red)' : '#888'};margin-right:6px"></span>${statusLabel}`;
  $('#wEvm').textContent = evm || '—';
  $('#wEvm').title = evm || '';
  $('#wSol').textContent = sol || '—';
  $('#wSol').title = sol || '';

  $('#connStatus').className = data.status === 'CONNECTED' ? 'status ok' : data.status === 'UNCONNECTED' ? 'status bad' : 'status';
  $('#connStatus').innerHTML = h`<span class="dot"></span>${statusLabel}`;
}

async function loadWalletSettings() {
  const walletId = state.active;
  if (!walletId) return;
  const data = await api(`/api/w/${walletId}/settings`);
  if (state.active !== walletId) return;

  $('#wExpire').textContent = data.sessionExpireTime?.replace('T', ' ').slice(0, 19) || '—';
  const used = Number(data.quotaUsed || 0);
  const limit = Number(data.dailyLimit || 1);
  $('#wQuota').textContent = `${fmt(used, 2)} / ${fmt(limit, 0)} USDT（剩余 ${fmt(data.quotaLeft, 2)}）`;
  $('#quotaBar').style.width = `${Math.min(100, (used / limit) * 100)}%`;

  const dev = data.devMode || {};
  $('#wDevMode').textContent = dev.enabled
    ? `开发者模式已开启（单日 ${dev.dailyLimit}，${dev.expiresAt?.slice(0, 10)} 到期）`
    : '开发者模式未开启（合约调用需要它）';
}

async function loadBalance() {
  const tbody = $('#balanceTable').querySelector('tbody');
  try {
    const { tokens, ms } = await api(`/api/w/${state.active}/balance`);
    const total = tokens.reduce((s, t) => s + (Number(t.value) || 0), 0);
    $('#totalValue').textContent = `$${fmt(total, 2)}`;
    tbody.innerHTML = tokens.length
      ? h`${[...tokens].sort((a, b) => Number(b.value || 0) - Number(a.value || 0)).map((t) => {
        const isNative = String(t.address).toLowerCase() === NATIVE;
        const tok = {
          address: t.address, symbol: t.symbol, verified: t.verified, native: isNative,
          hasLogo: isNative || Boolean(catalogToken(t.binanceChainId, t.address)?.hasLogo) || Boolean(t.verified),
        };
        return h`
        <tr>
          <td><div class="tok-cell">${avatarHtml(t.binanceChainId, tok)}<div>
            <div class="tok-line"><b>${t.symbol}</b>${verifiedBadge(tok)}</div>
            <div class="muted mono small">${chainName(t.binanceChainId)} · ${isNative ? '原生币' : caHtml(t.address)}</div>
          </div></div></td>
          <td class="right mono">${fmt(t.balance, 8)}</td>
          <td class="right mono">$${fmt(t.value, 2)}</td>
        </tr>`;
      })}`
      : '<tr><td colspan="3" class="muted">无非零余额</td></tr>';
    $('#balanceHint').textContent = `查询耗时 ${ms} ms · 未认证代币请谨慎交互`;
    hydrateLogos($('#balanceTable'));
  } catch (err) {
    tbody.innerHTML = h`<tr><td colspan="3" class="muted">${err.message}</td></tr>`;
  }
}

async function openQuoteSwap(token, need) {
  document.querySelector('.tab[data-view="trade"]').click();
  $('#tradeChain').value = '56';
  try {
    const data = await loadCatalog('56');
    state.trade.from = data.tokens.find((t) => t.native);
    state.trade.to = await resolveToken('56', token);
  } catch (err) {
    return toast(err.message, true);
  }
  // need 是报价币数量，不是 BNB 数量：不自动填支付金额，避免按错误单位下单
  $('#tradeAmount').value = '';
  invalidateQuote();
  saveTokenSel();
  renderTradeTokens();
  $('#tradeAmount').focus();
  toast(`还需要约 ${fmt(need, 6)} ${state.trade.to?.symbol || '报价币'}：请输入要支付的 BNB 数量，再获取报价核对能换到多少`);
}

/* ---------- trade ---------- */

/* 交互：参数齐全后自动报价（防抖 450ms，只采用最新一次请求的结果）；
 * 执行按钮的文字随状态变化，直接告诉用户还差什么。报价超过 30 秒执行前自动重报。 */
const QUOTE_DEBOUNCE_MS = 450;
const QUOTE_MAX_AGE_MS = 30000;
let quoteSeq = 0;
let quoteTimer = null;
let quoteLoading = false;

/** 当前兑换参数是否可报价；不可时返回原因（显示在执行按钮上） */
function tradeReadiness() {
  const { from, to } = state.trade;
  const amount = $('#tradeAmount').value.trim();
  if (!from || !to) return { ok: false, reason: '选择代币' };
  if (from.address.toLowerCase() === to.address.toLowerCase()) return { ok: false, reason: '两侧代币相同' };
  if (!amount || !/^\d+(\.\d+)?$/.test(amount) || !(Number(amount) > 0)) return { ok: false, reason: '输入数量' };
  if ((from.held || from.native) && decGreater(amount, from.balance || '0')) return { ok: false, reason: `${from.symbol} 余额不足` };
  if (!(from.held || from.native)) return { ok: false, reason: `钱包里没有 ${from.symbol}` };
  if (!$('#tradeSlippage').value) return { ok: false, reason: '选择滑点' };
  return { ok: true, amount };
}

function updateSwapButton() {
  const btn = $('#btnSwap');
  const r = tradeReadiness();
  let label = '执行兑换';
  if (!r.ok) label = r.reason;
  else if (quoteLoading) label = '报价中…';
  else if (!state.quote) label = '等待报价';
  btn.textContent = label;
  btn.dataset.label = label;
  btn.disabled = !(r.ok && state.quote && !quoteLoading);
  $('#btnQuote').disabled = !r.ok || quoteLoading;
}

function setToAmount(text, placeholder) {
  $('#toAmount').textContent = text;
  $('#toAmount').classList.toggle('placeholder', placeholder);
  if (placeholder) { const u = $('#toUsd'); if (u) { u.textContent = ''; u.classList.remove('warn-text'); } } // 报价失效：价值一起清掉
}

/** 任何兑换参数变化都让旧报价失效（避免按旧数量/旧代币成交），参数齐全时自动重新报价 */
function invalidateQuote({ requote = true } = {}) {
  updateFromUsd();
  fitAmountFont();
  clearTimeout(quoteTimer);
  quoteSeq += 1; // 让在途的旧报价作废
  quoteLoading = false;
  state.quote = null;
  $('#quoteBox').hidden = true;
  $('#quoteErr').hidden = true;
  $('#quoteLatency').textContent = '';
  const r = tradeReadiness();
  setToAmount(r.ok && requote ? '报价中…' : '0', true);
  if (r.ok && requote) {
    quoteLoading = true;
    quoteTimer = setTimeout(() => getQuote(), QUOTE_DEBOUNCE_MS);
  }
  updateSwapButton();
}

/** 长数字缩小字号，避免被截断成「0.128580…」 */
function fitAmountFont() {
  const len = Math.max($('#tradeAmount').value.length, $('#toAmount').textContent.length);
  const size = len > 16 ? 20 : len > 12 ? 24 : 30;
  $('#tradeAmount').style.fontSize = `${size}px`;
  $('#toAmount').style.fontSize = `${size}px`;
}

/** 十进制字符串比较 a > b（BigInt，避免浮点误差导致「刚好全部」被判余额不足） */
function decGreater(a, b) {
  const scale = 36;
  const toBig = (v) => {
    const [w, f = ''] = String(v || '0').split('.');
    return BigInt((w || '0') + (f + '0'.repeat(scale)).slice(0, scale));
  };
  return toBig(a) > toBig(b);
}

/** 数量输入只保留数字和一个小数点（中文逗号/句号也按小数点处理） */
function sanitizeAmountInput(el) {
  let v = el.value.replace(/[，。,]/g, '.').replace(/[^\d.]/g, '');
  const i = v.indexOf('.');
  if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, '');
  if (v.startsWith('.')) v = `0${v}`;
  if (v !== el.value) el.value = v;
}

/** 交换支付 / 获得方向 */
function flipTrade() {
  [state.trade.from, state.trade.to] = [state.trade.to, state.trade.from];
  $('#tradeAmount').value = '';
  invalidateQuote();
  saveTokenSel();
  renderTradeTokens();
}

function setTradePercent(pct) {
  const v = amountByPercent($('#tradeChain').value, state.trade.from, pct);
  if (!v || v === '0') return toast('余额不足（原生币会预留 gas）', true);
  $('#tradeAmount').value = v;
  saveField('tradeAmount');
  invalidateQuote();
}

/** 按滑点估算最少获得（仅展示用，实际下限由 CLI/链上决定） */
function minReceived(amount, slippagePct) {
  const n = Number(amount) * (1 - Number(slippagePct) / 100);
  return Number.isFinite(n) ? n : null;
}

/** 报价；返回是否拿到了最新报价。过期 / 被新参数取代的响应直接丢弃 */
async function getQuote() {
  clearTimeout(quoteTimer);
  const r = tradeReadiness();
  if (!r.ok) {
    quoteLoading = false;
    updateSwapButton();
    return false;
  }
  const seq = ++quoteSeq;
  const { from, to } = state.trade;
  const wallet = state.active;
  const body = {
    chainId: $('#tradeChain').value,
    fromToken: from.address,
    toToken: to.address,
    // 金额以十进制字符串传给服务端，避免 Number 精度丢失 / 科学计数法
    amount: r.amount,
    slippage: $('#tradeSlippage').value,
  };
  quoteLoading = true;
  setToAmount('报价中…', true);
  updateSwapButton();
  try {
    const { quote, ms } = await api(`/api/w/${wallet}/quote`, 'POST', body);
    if (seq !== quoteSeq || wallet !== state.active) return false;
    state.quote = {
      ...body, quote, at: Date.now(),
      unverified: [from, to].filter((t) => !t.verified && !t.native).map((t) => `${t.symbol}（${t.address}）`),
    };
    const minOut = minReceived(quote.toCoinAmount, body.slippage);
    setToAmount(fmt(quote.toCoinAmount, 8), false);
    fitAmountFont();
    const rate = Number(quote.toCoinAmount) / Number(quote.fromCoinAmount);
    $('#quoteBox').hidden = false;
    $('#quoteBox').innerHTML = h`
      <div class="row"><span class="muted">价格</span><span class="mono">1 ${quote.fromCoinSymbol} ≈ ${Number.isFinite(rate) ? fmt(rate, 8) : '—'} ${quote.toCoinSymbol}</span></div>
      <div class="row"><span class="muted">预计获得</span><span class="mono">${fmt(quote.toCoinAmount, 8)} ${quote.toCoinSymbol}</span></div>
      <div class="row"><span class="muted">最少获得（约）</span><span class="mono">${minOut == null ? '—' : `${fmt(minOut, 8)} ${quote.toCoinSymbol}`}</span></div>
      <div class="row"><span class="muted">滑点</span><span class="mono">${body.slippage}%</span></div>
      <div class="row" id="quoteValueRow" hidden></div>`;
    $('#quoteLatency').textContent = `报价 ${ms} ms · ${new Date().toLocaleTimeString('zh-CN', { hour12: false })}`;
    // 获得价值（异步：可能要向服务端查单价），报价已被新的覆盖就不再写
    quoteValue(quote, from, to, body.chainId).then((v) => {
      if (seq !== quoteSeq) return;
      if (v.toUsd == null) { $('#toUsd').textContent = ''; return; }
      const diff = v.diffPct == null ? '' : `（较支付 ${v.diffPct >= 0 ? '+' : ''}${v.diffPct.toFixed(2)}%）`;
      $('#toUsd').textContent = `≈ ${usdText(v.toUsd)}${diff}`;
      $('#toUsd').classList.toggle('warn-text', v.diffPct != null && v.diffPct < -5);
      const row = $('#quoteValueRow');
      row.hidden = false;
      row.innerHTML = h`<span class="muted">获得价值</span><span class="mono">≈ ${usdText(v.toUsd)}${v.fromUsd != null ? ` · 支付 ≈ ${usdText(v.fromUsd)}` : ''}${diff}</span>`;
      if (v.diffPct != null && v.diffPct < -5) {
        row.insertAdjacentHTML('afterend', h`<p class="warn">获得价值比支付少 ${Math.abs(v.diffPct).toFixed(2)}%：价格冲击、手续费或代币税偏高，确认前请核对数量或改小金额。</p>`);
      }
    }).catch(() => {});
    return true;
  } catch (err) {
    if (seq !== quoteSeq) return false;
    setToAmount('—', true);
    // 报价错误显示在卡片里，不只是一闪而过的 toast
    $('#quoteErr').hidden = false;
    $('#quoteErr').textContent = `报价失败：${err.message}`;
    return false;
  } finally {
    if (seq === quoteSeq) {
      quoteLoading = false;
      updateSwapButton();
    }
  }
}

async function doSwap() {
  if (!state.quote) return;
  // 报价太旧：先重报价，让用户看到最新数字再确认
  if (Date.now() - state.quote.at > QUOTE_MAX_AGE_MS) {
    const fresh = await getQuote();
    if (!fresh) return;
    toast('报价已超过 30 秒，已按最新价格重新报价，请核对后确认');
  }
  const q = state.quote;
  if (!q) return;
  const minOut = minReceived(q.quote.toCoinAmount, q.slippage);
  const ok = await confirmDialog('确认兑换', [
    ['钱包', state.wallets.find((w) => w.id === state.active)?.name || state.active],
    ['链', chainName(q.chainId)],
    ['支付', `${fmt(q.amount, 8)} ${q.quote.fromCoinSymbol}`],
    ['预计获得', `${fmt(q.quote.toCoinAmount, 8)} ${q.quote.toCoinSymbol}`],
    ['最少获得（约）', minOut == null ? '—' : `${fmt(minOut, 8)} ${q.quote.toCoinSymbol}`],
    ['滑点', `${q.slippage}%`],
    ['支付合约', q.fromToken.toLowerCase() === NATIVE ? '原生币' : q.fromToken],
    ['获得合约', q.toToken.toLowerCase() === NATIVE ? '原生币' : q.toToken],
    ...(q.unverified.length ? [['未认证代币', q.unverified.join('、')]] : []),
  ], q.unverified.length
    ? '包含未认证代币：名称和符号可被伪造，请逐字核对合约地址。兑换会立即广播且不可撤销。'
    : '兑换会立即广播且不可撤销，实际成交以链上为准。');
  if (!ok) return;

  const btn = $('#btnSwap');
  setBusy(btn, true);
  let submitted = false;
  try {
    const { result } = await api(`/api/w/${state.active}/swap`, 'POST', { ...q, confirm: 'SWAP' });
    submitted = true;
    if (result.txHash) {
      toastTx(result.status === 'FINISHED' ? '兑换已成交' : '兑换已广播', q.chainId, result.txHash);
    } else {
      toast(`兑换已提交，订单 ${result.orderId || '—'} 仍在处理中，请稍后在交易历史核对`);
    }
    scheduleRefresh();
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
    // 已广播的报价作废，并清空数量：防止连点「执行兑换」重复下单
    if (submitted) {
      $('#tradeAmount').value = '';
      saveField('tradeAmount');
      invalidateQuote({ requote: false });
    } else {
      updateSwapButton();
    }
  }
}

/* ---------- send ---------- */

/** 切换转账链：同名代币自动换成新链合约（不同链合约地址不同、精度也可能不同），没有同名就回到原生币 */
async function applySendChain(chainId) {
  const prev = state.send.token;
  $('#sendChain').value = chainId;
  saveField('sendChain');
  let next = null;
  try {
    const data = await loadCatalog(chainId);
    next = prev && !prev.native
      ? data.tokens.find((t) => t.verified && t.symbol === prev.symbol) || null
      : data.tokens.find((t) => t.native);
    if (!next) {
      next = data.tokens.find((t) => t.native);
      if (prev && !prev.native) toast(`${chainName(chainId)} 上没有认证的 ${prev.symbol}，已切回原生币`, true);
    }
  } catch (err) {
    toast(err.message, true);
  }
  state.send.token = next;
  saveTokenSel();
  renderSendToken();
}

async function chooseSendToken() {
  const t = await pickToken($('#sendChain').value, { title: '选择转账代币' });
  if (!t) return;
  state.send.token = t;
  saveTokenSel();
  renderSendToken();
}

async function doSend() {
  const t = state.send.token;
  if (!t) return toast('请先选择代币', true);
  const body = {
    chainId: $('#sendChain').value,
    tokenAddress: t.address,
    amount: $('#sendAmount').value.trim(),
    recipient: $('#sendRecipient').value.trim(),
  };
  if (!/^\d+(\.\d+)?$/.test(body.amount) || !(Number(body.amount) > 0)) return toast('请输入大于 0 的数量', true);
  if (!/^0x[0-9a-fA-F]{40}$/.test(body.tokenAddress)) return toast('代币合约地址格式不正确', true);
  if (!/^0x[0-9a-fA-F]{40}$/.test(body.recipient)) return toast('收款地址格式不正确', true);
  if (Number(body.amount) > Number(t.balance || 0)) return toast(`余额不足：可用 ${fmt(t.balance || 0, 8)} ${t.symbol}`, true);

  const unverified = !t.verified && !t.native;
  const ok = await confirmDialog('确认转账', [
    ['钱包', state.wallets.find((w) => w.id === state.active)?.name || state.active],
    ['链', chainName(body.chainId)],
    ['代币', `${t.symbol}${unverified ? '（未认证）' : ''}`],
    ['代币合约', t.native ? '原生币' : body.tokenAddress],
    ['数量', `${body.amount} ${t.symbol}`],
    ['收款', body.recipient],
  ], unverified
    ? '该代币未认证（不在预设与官方代币列表中），请确认合约地址是你要转的代币。转账不可撤销。'
    : '转账不可撤销，请再次核对收款地址。');
  if (!ok) return;

  const btn = $('#btnSend');
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${state.active}/send`, 'POST', { ...body, confirm: 'SEND' });
    toastTx('转账已提交', body.chainId, result.txHash);
    scheduleRefresh();
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- advanced ---------- */

/** 合约调用参数变化后旧 preview 作废，避免确认框与实际执行内容不一致 */
function invalidateCallPreview() {
  state.preview = null;
  $('#btnExecute').disabled = true;
  $('#previewOut').hidden = true;
  $('#ccValueUnit').textContent = nativeSymbol($('#ccChain').value);
}

function toWei(value) {
  const [whole, frac = ''] = String(value || '0').split('.');
  const decimals = (frac + '0'.repeat(18)).slice(0, 18);
  return (BigInt(whole || '0') * 10n ** 18n + BigInt(decimals || '0')).toString();
}

async function previewCall() {
  const btn = $('#btnPreview');
  setBusy(btn, true);
  try {
    const evm = evmOf();
    const body = {
      chainId: $('#ccChain').value,
      from: evm,
      to: $('#ccTo').value.trim(),
      value: toWei($('#ccValue').value),
      inputData: $('#ccData').value.trim(),
    };
    if (!/^0x[0-9a-fA-F]{40}$/.test(body.to)) throw new Error('目标合约地址不正确');
    if (!/^0x[0-9a-fA-F]*$/.test(body.inputData)) throw new Error('calldata 必须是 0x 开头的 hex');
    const { preview } = await api(`/api/w/${state.active}/preview`, 'POST', body);
    // 记录 preview 对应的参数，确认框按它展示，而不是读当前输入框
    state.preview = { ...preview, _chainId: body.chainId, _to: body.to, _value: $('#ccValue').value.trim() };
    renderPreview($('#previewOut'), preview, body.chainId);
    $('#btnExecute').disabled = !previewExecutable(preview, body.chainId);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function executeCall() {
  if (!state.preview?.requestId) return;
  const p = state.preview;
  const ok = await confirmDialog('确认执行合约调用', [
    ['链', chainName(p._chainId)],
    ['目标', p.parsedTx?.contractAddress || p._to],
    ['value', `${p._value || '0'} ${nativeSymbol(p._chainId)}`],
    ['requestId', p.requestId],
  ], '这是原始 calldata 调用，请确认已理解 preview 中的解析结果与风险提示。');
  if (!ok) return;
  const btn = $('#btnExecute');
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${state.active}/execute`, 'POST', {
      requestId: p.requestId, confirm: 'EXECUTE',
    });
    toastTx('合约调用已提交', p._chainId, result.txHash);
    setBusy(btn, false);
    // preview 已被消费：清空并禁用执行，避免 finally 把按钮重新点亮
    state.preview = null;
    btn.disabled = true;
    scheduleRefresh();
  } catch (err) {
    toast(err.message, true);
    setBusy(btn, false);
  }
}

/* ---------- 多步计划：按顺序放行 ---------- */

/**
 * 步骤 i 执行成功后：锁住它的预览/执行（防止重复广播），并放行第 i+1 步的预览。
 * container 为步骤容器选择器，attr 为按钮 data 属性名（flap: act / agent: agent）。
 */
function markStepDone(container, attr, i) {
  const q = (act, idx) => document.querySelector(`${container} [data-${attr}="${act}"][data-i="${idx}"]`);
  const pv = q('preview', i);
  const ex = q('execute', i);
  if (pv) { pv.disabled = true; pv.dataset.label = ''; }
  if (ex) { ex.dataset.label = ''; ex.textContent = '已提交'; ex.disabled = true; }
  const next = q('preview', i + 1);
  if (next) { next.disabled = false; next.title = ''; }
}

/* ---------- flap ---------- */

function evmOf() {
  const addr = state.summary?.addresses.find((a) => a.chainName === 'Ethereum')?.address
    || state.summary?.addresses.find((a) => a.address?.startsWith('0x'))?.address;
  if (!addr) throw new Error('尚未加载钱包地址');
  return addr;
}

function flapFields() {
  const op = $('#flapOp').value;
  const amount = $('#flapAmount').value.trim();
  const bps = Number($('#flapBps').value);
  const slip = $('#flapSlip').value;
  return { op, amount, bps, slippageBps: Number(slip) };
}

async function flapPlan(override) {
  const btn = $('#btnFlapPlan');
  setBusy(btn, true);
  try {
    const f = override || flapFields();
    const market = $('#flapMarket').value.trim();
    if ((f.op === 'buy' || f.op === 'sell') && !f.slippageBps) {
      throw new Error('请显式选择滑点（不提供默认值）');
    }
    if (f.op === 'buy' && !f.amount) throw new Error('请输入买入金额');
    const body = {
      wallet: evmOf(),
      market,
      op: f.op,
      amount: f.amount || '0',
      bps: f.bps,
      slippageBps: f.slippageBps,
      expect: state.ai?.config ? {
        probe: state.ai.config.PROBE,
        quote: state.ai.config.QUOTE_TOKEN,
        decimals: state.ai.config.QUOTE_DECIMALS,
      } : {},
    };
    const started = performance.now();
    const plan = await api(`/api/w/${state.active}/flap/plan`, 'POST', body);
    $('#flapLatency').textContent = `${Math.round(performance.now() - started)} ms`;
    state.flap = { plan, previews: {}, executed: {} };
    renderFlapPlan(plan);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

function renderFlapPlan(plan) {
  $('#flapSummary').hidden = false;
  const rows = [
    ['操作', plan.op],
    ['Market', plan.market],
    ['Probe', plan.probe],
    ['计价', plan.isErc20 ? `ERC20 ${plan.quoteToken}` : '原生 BNB'],
    ['PHASE', plan.phase],
  ];
  if (plan.op === 'buy') {
    rows.push(['支付', `${plan.quote.grossHuman} ${plan.isErc20 ? '' : 'BNB'}`.trim()]);
    rows.push(['手续费', `${plan.quote.feeHuman}`]);
    rows.push(['预计份额', plan.quote.sharesHuman]);
    rows.push(['最小份额', plan.quote.minShares]);
  }
  if (plan.op === 'sell') {
    rows.push(['卖出比例', `${plan.quote.bps / 100}%`]);
    rows.push(['预计得到', plan.quote.outHuman]);
    rows.push(['最小输出', plan.quote.minOut]);
  }
  if (plan.op === 'claim') rows.push(['可领取', plan.claimableHuman]);
  if (plan.op === 'query' && plan.summary) {
    const s = plan.summary;
    rows.push(['持有份额', s.heldSharesHuman]);
    rows.push(['当前可卖出', s.sellOk ? '是' : '否']);
    rows.push(['剩余可买份额', s.roomSharesHuman]);
    rows.push(['可领取', s.claimableHuman]);
  }

  $('#flapSummary').innerHTML = h`${rowsHtml(rows)}${warnsHtml(plan.warnings)}`;

  const steps = plan.steps || [];
  $('#flapSteps').innerHTML = steps.length
    ? h`<h3 class="steps-title">执行步骤</h3>${steps.map((s, i) => h`
        <div class="step" data-step="${i}">
          <div class="step-head">
            <span class="step-label">${i + 1}. ${s.label}</span>
            <span class="mono muted">BSC · ${s.tx.to} · value ${nativeValue('56', s.tx.value)}</span>
          </div>
          <div class="actions">
            <button class="ghost" data-act="preview" data-i="${i}" ${i > 0 ? h`disabled title="请先执行第 ${i} 步"` : ''}>预览</button>
            <button class="danger" data-act="execute" data-i="${i}" disabled>执行</button>
          </div>
          <div class="preview-out" id="step-pre-${i}" hidden></div>
        </div>`)}`
    : '<p class="hint">查询操作无交易步骤。</p>';

  $$('#flapSteps [data-act="preview"]').forEach((b) => { b.onclick = () => flapStepPreview(Number(b.dataset.i)); });
  $$('#flapSteps [data-act="execute"]').forEach((b) => { b.onclick = () => flapStepExecute(Number(b.dataset.i)); });
}

async function flapStepPreview(i) {
  const plan = state.flap.plan;
  const step = plan.steps[i];
  const btn = document.querySelector(`#flapSteps [data-act="preview"][data-i="${i}"]`);
  setBusy(btn, true);
  try {
    const body = {
      chainId: '56', from: evmOf(), to: step.tx.to, value: step.tx.value, inputData: step.tx.inputData,
    };
    const { preview } = await api(`/api/w/${state.active}/preview`, 'POST', body);
    state.flap.previews[i] = preview;
    renderPreview($(`#step-pre-${i}`), preview, '56');
    document.querySelector(`#flapSteps [data-act="execute"][data-i="${i}"]`).disabled = !previewExecutable(preview, '56');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function flapStepExecute(i) {
  const preview = state.flap.previews[i];
  const step = state.flap.plan.steps[i];
  if (!preview?.requestId) return;
  const ok = await confirmDialog(`确认执行第 ${i + 1} 步`, [
    ['步骤', step.label],
    ['目标', step.tx.to],
    ['value', nativeValue('56', step.tx.value)],
    ['requestId', preview.requestId],
  ], '确认后会广播这笔交易，不可撤销。');
  if (!ok) return;

  const btn = document.querySelector(`#flapSteps [data-act="execute"][data-i="${i}"]`);
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${state.active}/execute`, 'POST', {
      requestId: preview.requestId, confirm: 'EXECUTE',
    });
    toastTx(`第 ${i + 1} 步已提交`, '56', result.txHash);
    state.flap.executed[i] = result;
    markStepDone('#flapSteps', 'act', i);
    scheduleRefresh();
  } catch (err) {
    toast(err.message, true);
  } finally {
    if (!state.flap.executed[i]) setBusy(btn, false);
  }
}

/* ---------- ai ---------- */

async function aiParse() {
  const text = $('#aiText').value.trim();
  if (!text) return toast('请先粘贴提示词', true);
  const btn = $('#btnAiParse');
  setBusy(btn, true);
  $('#aiSteps').innerHTML = '';
  $('#aiChecks').innerHTML = '';
  state.aiPlan = null;
  try {
    const started = performance.now();
    const result = await api('/api/agent/analyze', 'POST', { text, wallet: evmOf() });
    state.agentResult = result;
    // 保留原始提示词：批量执行时要按每个钱包重新生成计划
    state.agent = { plan: result.plan, previews: {}, executed: {}, text };
    $('#btnAiSaveModule').disabled = false;
    $('#aiLatency').textContent = `${result.elapsedMs} ms · ${sourceLabel(result.source)}`;
    renderAgentPlan(result);
  } catch (err) {
    // 带 {参数} 占位符的模板本身解析不出完整操作是正常的：仍允许保存为模块，运行时再填值
    if (TEMPLATE_RE.test(text)) {
      state.agentResult = null;
      state.agent = { plan: null, previews: {}, executed: {}, text };
      $('#btnAiSaveModule').disabled = false;
      toast(`这是带参数的模板（${templateKeys(text).join('、')}），可直接保存为模块，运行时填值`);
    } else {
      toast(err.message, true);
    }
  } finally {
    setBusy(btn, false);
  }
}

const TEMPLATE_RE = /\{[^{}\n]{1,30}\}/;

function templateKeys(text) {
  return [...new Set([...String(text).matchAll(/\{([^{}\n]{1,30})\}/g)].map((m) => m[1]))];
}

function renderAgentPlan(result) {
  const plan = result.plan;
  const spec = result.spec;
  const rows = [
    ['来源', sourceLabel(result.source)],
    ['协议', spec.protocol],
    ['操作', spec.intent],
  ];
  if (result.llmUsage?.total_tokens) {
    rows.push(['Tokens', `${result.llmUsage.prompt_tokens} + ${result.llmUsage.completion_tokens} = ${result.llmUsage.total_tokens}`]);
  }
  if (result.planError) rows.push(['状态', '已解析，但生成计划失败']);

  if (!plan) {
    $('#aiResult').hidden = false;
    const errText = result.planError || '无法生成计划';
    const fundMatch = errText.match(/quote=(0x[0-9a-fA-F]{40})\|need=([\d.]+)/);
    $('#aiResult').innerHTML = h`${rowsHtml(rows)}<p class="err">${errText.split('|')[0]}</p>${fundMatch ? h`<div class="actions"><button id="btnBuyQuote" class="primary">去兑换报价币</button></div>` : ''}`;
    if (fundMatch) {
      $('#btnBuyQuote').onclick = () => openQuoteSwap(fundMatch[1], Number(fundMatch[2]));
    }
    $('#aiSteps').innerHTML = '';
    $('#aiChecks').innerHTML = '';
    return;
  }

  if (plan.protocol === 'foundry' || plan.kind === 'mint') {
    rows.push(['合约', plan.spec.contract]);
    rows.push(['数量', String(plan.spec.quantity)]);
    rows.push(['链上报价', `${plan.quoteHuman} BNB`]);
  } else if (plan.kind === 'custom') {
    rows.push(['合约', plan.spec.contract]);
    rows.push(['函数', plan.spec.signature]);
    (plan.spec.args || []).forEach((a, i) => rows.push([`参数 ${i + 1}`, a]));
    rows.push(['value', `${plan.spec.valueBnb} BNB`]);
    if (plan.spec.gasLimit) rows.push(['gasLimit', String(plan.spec.gasLimit)]);
  } else if (plan.kind === 'swap') {
    const q = plan.quote || {};
    const chainId = String(plan.spec?.chainId || '56');
    const native = nativeSymbol(chainId);
    rows.push(['链', chainName(chainId)]);
    rows.push(['代币', plan.spec?.params?.token || '—']);
    if (q.side === 'buy') {
      rows.push(['支付', `${q.amountIn} ${native}`]);
      rows.push(['预计获得', `${q.amountOut} 代币`]);
      rows.push(['最少获得', `${q.minOutHuman ?? q.minOut} 代币`]);
    } else {
      rows.push(['卖出', `${q.amountIn} 代币${q.percent ? `（持仓的 ${q.percent}%）` : ''}`]);
      rows.push(['预计获得', `${q.amountOut} ${native}`]);
      rows.push(['最少获得', `${q.minOutHuman ?? q.minOut} ${native}`]);
    }
    if (q.route) rows.push(['路由', q.route]);
    rows.push(['滑点', `${(q.slipBps ?? 0) / 100}%`]);
  } else if (plan.kind === 'transfer') {
    const p = plan.spec?.params || {};
    const chainId = String(plan.spec?.chainId || '56');
    rows.push(['链', chainName(chainId)]);
    rows.push(['代币', p.token?.toLowerCase() === NATIVE ? nativeSymbol(chainId) : (presetSymbol(chainId, p.token) || p.token)]);
    rows.push(['数量', String(p.amount)]);
    rows.push(['收款', p.to]);
  } else if (plan.kind === 'gang' && plan.spec.side === 'sell') {
    rows.push(['市场', 'Gang 内盘（LaunchpadV2）· 卖出']);
    rows.push(['代币', `${plan.spec.symbol}（${plan.spec.token}）`]);
    rows.push(['卖出', `${plan.spec.tokenInHuman} ${plan.spec.symbol}${plan.spec.percent ? `（持仓的 ${plan.spec.percent}%）` : ''}`]);
    rows.push(['预计所得', `${plan.spec.expectedOut} ${plan.spec.quoteSymbol}（已扣 1% 手续费）`]);
    rows.push(['最少所得', `${plan.spec.minOut} ${plan.spec.quoteSymbol}`]);
    rows.push(['滑点', `${(plan.spec.slippageBps ?? 0) / 100}%`]);
  } else if (plan.kind === 'gang') {
    rows.push(['市场', 'Gang 内盘（LaunchpadV2）· 买入']);
    rows.push(['代币', plan.spec.token]);
    rows.push(['支付', `${plan.spec.amountBnb} BNB`]);
    rows.push(['报价币', plan.spec.quoteSymbol || plan.spec.quote]);
    rows.push(['滑点', `${(plan.spec.slippageBps ?? 0) / 100}%`]);
  } else {
    rows.push(['Market', plan.market]);
    rows.push(['PHASE', String(plan.phase)]);
    if (plan.quote?.sharesHuman) rows.push(['预计份额', plan.quote.sharesHuman]);
    if (plan.quote?.outHuman) rows.push(['预计得到', plan.quote.outHuman]);
  }
  if (spec.assumptions?.length) rows.push(['假设', spec.assumptions.join('；')]);
  if (result.missing?.length) rows.push(['缺失', result.missing.join('；')]);

  $('#aiResult').hidden = false;
  $('#aiResult').innerHTML = h`${rowsHtml(rows)}${result.llmError ? h`<p class="warn">模型调用失败，已回退规则：${result.llmError}</p>` : ''}${warnsHtml(plan.warnings)}${notesHtml(plan.notes)}`;

  $('#aiChecks').innerHTML = checksTableHtml(plan.checks);

  const steps = plan.steps || [];
  $('#aiSteps').innerHTML = steps.length
    ? h`<h3 class="steps-title">执行步骤</h3>${steps.map((s, i) => h`
        <div class="step">
          <div class="step-head">
            <span class="step-label">${i + 1}. ${s.label}</span>
            <span class="mono muted">${chainName(stepChainId(s))} · ${s.tx.to} · value ${nativeValue(stepChainId(s), s.tx.value)}</span>
          </div>
          ${s.recipient ? h`<div class="mono muted">收款：${s.recipient}</div>` : ''}
          <div class="actions">
            <button class="ghost" data-agent="preview" data-i="${i}" ${i > 0 ? h`disabled title="请先执行第 ${i} 步"` : ''}>预览</button>
            <button class="danger" data-agent="execute" data-i="${i}" disabled>执行</button>
          </div>
          <div class="preview-out" id="agent-pre-${i}" hidden></div>
        </div>`)}`
    : '<p class="hint">该操作没有交易步骤（只读查询）。</p>';

  $$('#aiSteps [data-agent="preview"]').forEach((b) => { b.onclick = () => agentPreview(Number(b.dataset.i)); });
  $$('#aiSteps [data-agent="execute"]').forEach((b) => { b.onclick = () => agentExecute(Number(b.dataset.i)); });
}

async function agentPreview(i) {
  const step = state.agent.plan.steps[i];
  const btn = document.querySelector(`#aiSteps [data-agent="preview"][data-i="${i}"]`);
  setBusy(btn, true);
  try {
    const body = {
      chainId: stepChainId(step), from: evmOf(), to: step.tx.to, value: step.tx.value, inputData: step.tx.inputData,
    };
    if (step.tx.gasLimit) body.gasLimit = step.tx.gasLimit;
    const { preview } = await api(`/api/w/${state.active}/preview`, 'POST', body);
    state.agent.previews[i] = preview;
    renderPreview($(`#agent-pre-${i}`), preview, stepChainId(step));
    document.querySelector(`#aiSteps [data-agent="execute"][data-i="${i}"]`).disabled = !previewExecutable(preview, stepChainId(step));
  } catch (err) {
    // 模拟失败的原因（如 Sold out）固定显示在步骤里，不只是一闪而过的 toast
    const pre = $(`#agent-pre-${i}`);
    pre.hidden = false;
    pre.classList.add('pre-err');
    pre.textContent = `模拟失败：${err.message}`;
    delete state.agent.previews[i];
    document.querySelector(`#aiSteps [data-agent="execute"][data-i="${i}"]`).disabled = true;
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function agentExecute(i) {
  const preview = state.agent.previews[i];
  const step = state.agent.plan.steps[i];
  if (!preview?.requestId) return;

  // 勾选了批量就必须走批量：不能因为没勾钱包而悄悄只对当前钱包执行
  if ($('#useBatchWallets')?.checked) {
    if (!state.selectedWallets.size) return toast('已开启批量执行，但还没有勾选钱包：去「钱包」页勾选，或取消批量', true);
    await agentBatchExecute(i, step);
    return;
  }

  const ok = await confirmDialog(`确认执行第 ${i + 1} 步`, [
    ['步骤', step.label],
    ['链', chainName(stepChainId(step))],
    ['目标', step.tx.to],
    ...(step.recipient ? [['收款', step.recipient]] : []),
    ['value', nativeValue(stepChainId(step), step.tx.value)],
    ['requestId', preview.requestId],
  ], '确认后会广播这笔交易，不可撤销。');
  if (!ok) return;

  const btn = document.querySelector(`#aiSteps [data-agent="execute"][data-i="${i}"]`);
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${state.active}/execute`, 'POST', {
      requestId: preview.requestId, confirm: 'EXECUTE',
    });
    toastTx(`第 ${i + 1} 步已提交`, stepChainId(step), result.txHash);
    state.agent.executed[i] = result;
    markStepDone('#aiSteps', 'agent', i);
    scheduleRefresh();
    if (result.txHash && state.agent.plan.protocol === 'foundry') {
      const receipt = await pollReceipt(result.txHash, state.agent.plan.spec.contract);
      renderAgentReceipt(receipt);
    }
  } catch (err) {
    toast(err.message, true);
    // 已广播后的回执查询失败不能把执行按钮重新点亮
    if (!state.agent.executed[i]) setBusy(btn, false);
  }
}

async function agentBatchExecute(i, step) {
  const ids = [...state.selectedWallets];
  const names = ids.map((id) => state.wallets.find((w) => w.id === id)?.name || id);
  const text = state.agent?.text;
  if (!text) return toast('缺少原始提示词，无法为其他钱包重新生成计划，请重新解析', true);

  const ok = await confirmDialog('批量执行', [
    ['步骤', step.label],
    ['钱包', names.join('、')],
    ['链', chainName(stepChainId(step))],
  ], '会为每个钱包单独重新生成计划并 preview，每个钱包都要你再确认一次；取消或任一失败即停止。');
  if (!ok) return;

  // 记录本步骤已成功广播的钱包：中途失败后重跑批量时跳过它们，避免重复下单
  state.agent.batchDone = state.agent.batchDone || {};
  const done = state.agent.batchDone[i] || (state.agent.batchDone[i] = new Set());

  const results = [];
  for (const id of ids) {
    const name = state.wallets.find((w) => w.id === id)?.name || id;
    if (done.has(id)) {
      results.push(`${id}: 已执行过，跳过`);
      continue;
    }
    try {
      const summary = await api(`/api/w/${id}/summary`);
      const from = summary.addresses.find((a) => a.chainName === 'Ethereum')?.address;
      if (!from) throw new Error('没有 EVM 地址');

      // 收款人、minOut、额度检查都依赖钱包地址，必须按该钱包重新生成计划
      const result = await api('/api/agent/analyze', 'POST', { text, wallet: from });
      if (!result.plan) throw new Error(result.planError || '该钱包无法生成计划');
      const own = result.plan.steps?.[i];
      if (!own || own.label !== step.label || own.tx.to.toLowerCase() !== step.tx.to.toLowerCase()
        || stepChainId(own) !== stepChainId(step)) {
        throw new Error(`该钱包的第 ${i + 1} 步与当前钱包不同（可能需要额外 approve），请单独执行`);
      }

      const body = { chainId: stepChainId(own), from, to: own.tx.to, value: own.tx.value, inputData: own.tx.inputData };
      if (own.tx.gasLimit) body.gasLimit = own.tx.gasLimit;
      const { preview } = await api(`/api/w/${id}/preview`, 'POST', body);
      if (!previewExecutable(preview, stepChainId(own))) throw new Error(`预览模拟未通过：${previewSummaryText(preview, stepChainId(own))}`);

      const go = await confirmDialog(`确认执行：${name}`, [
        ['钱包', `${name} · ${from}`],
        ['步骤', own.label],
        ['链', chainName(stepChainId(own))],
        ['目标', own.tx.to],
        ...(own.recipient ? [['收款', own.recipient]] : []),
        ['value', nativeValue(stepChainId(own), own.tx.value)],
        ['模拟', previewSummaryText(preview, stepChainId(own))],
      ], '确认后会广播这笔交易，不可撤销；取消将停止后续钱包。');
      if (!go) {
        results.push(`${id}: 已取消`);
        break;
      }
      await api(`/api/w/${id}/execute`, 'POST', { requestId: preview.requestId, confirm: 'EXECUTE' });
      done.add(id);
      results.push(`${id}: ok`);
    } catch (err) {
      results.push(`${id}: ${err.message}`);
      break;
    }
  }
  const allOk = ids.every((id) => done.has(id));
  toast(results.join(' | '), !allOk);
  if (allOk) {
    state.agent.executed[i] = { batch: results };
    markStepDone('#aiSteps', 'agent', i);
  }
  scheduleRefresh();
}

function renderAgentReceipt(receipt) {  const el = $('#aiSteps');
  const box = document.createElement('div');
  if (receipt.status === 'pending') {
    box.innerHTML = h`<p class="hint">交易已提交（${short(receipt.hash)}），尚未拿到回执，可在交易历史核对。</p>`;
  } else if (receipt.status === 'failed') {
    box.innerHTML = '<p class="err">回执为 failed，请到 BscScan 查看原因。</p>';
  } else {
    const parts = receipt.parts || [];
    box.innerHTML = h`
      <div class="quote-box" style="margin-top:12px">
        <div class="row"><span class="muted">交易</span><span class="mono">${receipt.hash}</span></div>
        <div class="row"><span class="muted">区块</span><span class="mono">${receipt.blockNumber}</span></div>
        <div class="row"><span class="muted">收到</span><span class="mono">${parts.length ? parts.map((p) => `${p.name}×${p.count}`).join('，') : '未解析到 ERC-1155 转移'}</span></div>
      </div>`;
  }
  el.appendChild(box);
}

function renderMintPlan(plan) {
  $('#aiResult').hidden = false;
  $('#aiResult').innerHTML = h`
    <div class="row"><span class="muted">类型</span><span class="mono">ERC-1155 Mint → 纯 BNB 转账（data=0x）</span></div>
    <div class="row"><span class="muted">合约</span><span class="mono">${plan.spec.contract}</span></div>
    <div class="row"><span class="muted">数量</span><span class="mono">${plan.spec.quantity}</span></div>
    <div class="row"><span class="muted">链上报价</span><span class="mono">${plan.quoteHuman} BNB</span></div>`;

  $('#aiChecks').innerHTML = h`${checksTableHtml(plan.checks, '预检')}${warnsHtml(plan.warnings)}`;

  const step = plan.steps[0];
  $('#aiSteps').innerHTML = h`
    <h3 class="steps-title">执行步骤</h3>
    <div class="step">
      <div class="step-head">
        <span class="step-label">1. ${step.label}</span>
        <span class="mono muted">BSC · ${step.tx.to} · value ${nativeValue('56', step.tx.value)}</span>
      </div>
      <div class="actions">
        <button class="ghost" id="btnMintPreview">预览</button>
        <button class="danger" id="btnMintExecute" disabled>执行</button>
      </div>
      <div class="preview-out" id="mintPre" hidden></div>
    </div>
    <div id="mintReceipt"></div>`;

  $('#btnMintPreview').onclick = () => mintPreview();
  $('#btnMintExecute').onclick = () => mintExecute();
}

async function mintPreview() {
  const plan = state.aiPlan;
  const step = plan.steps[0];
  const btn = $('#btnMintPreview');
  setBusy(btn, true);
  try {
    const body = {
      chainId: '56', from: evmOf(), to: step.tx.to, value: step.tx.value, inputData: '0x',
    };
    const { preview } = await api(`/api/w/${state.active}/preview`, 'POST', body);
    state.mint.preview = preview;
    renderPreview($('#mintPre'), preview, '56');
    $('#btnMintExecute').disabled = !previewExecutable(preview, '56');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function mintExecute() {
  const preview = state.mint.preview;
  const plan = state.aiPlan;
  if (!preview?.requestId) return;
  const ok = await confirmDialog('确认 Mint', [
    ['合约', plan.spec.contract],
    ['数量', String(plan.spec.quantity)],
    ['支付', `${plan.quoteHuman} BNB`],
    ['data', '0x（纯转账，合约按收到金额自动 mint）'],
  ], '确认后会广播交易，不可撤销。');
  if (!ok) return;

  const btn = $('#btnMintExecute');
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${state.active}/execute`, 'POST', {
      requestId: preview.requestId, confirm: 'EXECUTE',
    });
    toastTx('Mint 已提交', '56', result.txHash);
    scheduleRefresh();
    if (result.txHash) {
      const receipt = await pollReceipt(result.txHash, plan.spec.contract);
      renderMintReceipt(receipt);
    }
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function pollReceipt(hash, contract) {
  for (let i = 0; i < 6; i += 1) {
    const data = await api(`/api/tx/receipt?hash=${hash}&contract=${contract}&wallet=${evmOf()}`);
    if (data.status !== 'pending') return { ...data, hash };
    await new Promise((r) => setTimeout(r, 4000));
  }
  return { status: 'pending', hash };
}

function renderMintReceipt(receipt) {
  const el = $('#mintReceipt');
  if (receipt.status === 'pending') {
    el.innerHTML = h`<p class="hint">交易已提交（${short(receipt.hash)}），尚未拿到回执，请稍后在交易历史核对。</p>`;
    return;
  }
  if (receipt.status === 'failed') {
    el.innerHTML = '<p class="err">交易回执为 failed，请把交易哈希拿到 BscScan 核对原因。</p>';
    return;
  }
  const parts = receipt.parts || [];
  el.innerHTML = h`
    <div class="quote-box" style="margin-top:12px">
      <div class="row"><span class="muted">交易</span><span class="mono">${receipt.hash}</span></div>
      <div class="row"><span class="muted">区块</span><span class="mono">${receipt.blockNumber}</span></div>
      <div class="row"><span class="muted">收到的部件</span><span class="mono">${parts.length ? parts.map((p) => `${p.name}×${p.count}`).join('，') : '未在回执中解析到 ERC-1155 转移'}</span></div>
    </div>`;
}

function renderAi(ai) {
  const rows = [
    ['来源', ai.source === 'llm' ? '模型' : '规则'],
    ['操作', ai.operation || '未识别'],
    ['金额', ai.amount ?? '—'],
    ['比例', ai.percent != null ? `${ai.percent}%` : '—'],
    ['滑点', ai.slippageBps != null ? `${ai.slippageBps / 100}%` : '—'],
    ['CHAIN_ID', ai.config.CHAIN_ID],
    ['MARKET', ai.config.MARKET],
    ['QUOTE', `${ai.config.QUOTE_SYMBOL || '—'} · ${ai.config.QUOTE_DECIMALS || '—'} decimals`],
  ];
  const missing = ai.missing?.length ? h`<p class="warn">缺少：${ai.missing.join('、')}</p>` : '';
  const llmErr = ai.llmError ? h`<p class="warn">模型调用失败，已回退规则解析：${ai.llmError}</p>` : '';

  $('#aiResult').hidden = false;
  $('#aiResult').innerHTML = h`${rowsHtml(rows)}${missing}${llmErr}${ai.operation ? h`<div class="actions"><button id="btnAiApply" class="primary">填入 Flap 并生成计划</button></div>` : ''}`;

  $('#aiChecks').innerHTML = h`${checksTableHtml(ai.checks)}${warnsHtml(ai.warnings)}`;

  if (ai.operation) $('#btnAiApply').onclick = applyAi;
}

function applyAi() {
  const ai = state.ai;
  if (!ai) return;
  $('#flapMarket').value = ai.config.MARKET;
  $('#flapOp').value = ai.operation === 'dex_exit' ? 'sell' : ai.operation;
  if (ai.amount) $('#flapAmount').value = ai.amount;
  if (ai.slippageBps) $('#flapSlip').value = String(ai.slippageBps);
  toggleFlapFields();
  const tab = document.querySelector('.tab[data-view="flap"]');
  tab.click();
  if (ai.missing?.length) {
    toast(`请在 Flap 页补全：${ai.missing.join('、')}`, true);
    return;
  }
  flapPlan({
    op: $('#flapOp').value,
    amount: ai.amount || '0',
    bps: ai.percent ? Math.round(ai.percent * 100) : 5000,
    slippageBps: ai.slippageBps ?? 0,
  });
}

/* ---------- modules ---------- */

async function loadModules() {
  try {
    state.modules = await api('/api/modules');
    renderModules();
  } catch (err) {
    toast(err.message, true);
  }
}

function renderModules() {
  const el = $('#modulesList');
  if (!state.modules.length) {
    el.innerHTML = '<p class="muted">还没有保存的模块。在「AI 执行」解析成功后点「保存为模块」。</p>';
    return;
  }
  el.innerHTML = h`
    <table class="table">
      <thead><tr><th>名称</th><th>协议 / 操作</th><th>创建时间</th><th></th></tr></thead>
      <tbody>${state.modules.map((m) => h`
        <tr>
          <td>${m.name}${m.params?.length ? h`<div class="methods">${m.params.map((p) => h`<span class="chip">{${p.key}}</span>`)}</div>` : ''}</td>
          <td class="mono">${m.protocol} / ${m.intent}</td>
          <td class="mono">${m.createdAt ? new Date(m.createdAt).toLocaleString('zh-CN', { hour12: false }).slice(0, 16) : '—'}</td>
          <td class="right">
            <button class="ghost" data-mod-run="${m.id}">运行</button>
            <button class="ghost" data-mod-del="${m.id}">删除</button>
          </td>
        </tr>`)}</tbody>
    </table>`;

  $$('[data-mod-run]').forEach((b) => { b.onclick = () => runModule(b.dataset.modRun); });
  $$('[data-mod-del]').forEach((b) => { b.onclick = () => deleteModule(b.dataset.modDel); });
}

async function saveCurrentModule() {
  // 保存「被解析过」的那份提示词，避免解析后改了文本导致模块内容与协议/操作标签不一致
  const text = state.agent?.text || '';
  if (!text) return toast('没有可保存的提示词', true);
  const suggested = state.agentResult?.spec?.protocol
    ? `${state.agentResult.spec.protocol}-${state.agentResult.spec.intent}`
    : '新模块';
  const name = window.prompt('给这个交互模块起个名字', suggested);
  if (!name) return;
  try {
    await api('/api/modules', 'POST', {
      name,
      text,
      protocol: state.agentResult?.spec?.protocol,
      intent: state.agentResult?.spec?.intent,
    });
    toast('模块已保存');
    await loadModules();
  } catch (err) {
    toast(err.message, true);
  }
}

async function runModule(id) {
  const mod = state.modules.find((m) => m.id === id);
  if (!mod) return;
  let text = mod.text;
  for (const param of mod.params || []) {
    const value = window.prompt(`填写 ${param.key}`, '');
    if (value == null) return;
    const trimmed = value.trim();
    if (!trimmed) return toast(`${param.key} 不能为空`, true);
    text = text.split(`{${param.key}}`).join(trimmed);
  }
  try {
    const result = await api('/api/agent/analyze', 'POST', { text, wallet: evmOf() });
    state.agentResult = result;
    state.agent = { plan: result.plan, previews: {}, executed: {}, text };
    $('#btnAiSaveModule').disabled = false;
    document.querySelector('.tab[data-view="ai"]').click();
    renderAgentPlan(result);
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteModule(id) {
  const mod = state.modules.find((m) => m.id === id);
  const ok = await confirmDialog('删除模块', [
    ['模块', mod?.name || id],
    ['协议 / 操作', mod ? `${mod.protocol} / ${mod.intent}` : '—'],
  ], '删除后需要重新保存。');
  if (!ok) return;
  try {
    await api(`/api/modules/${id}`, 'DELETE');
    toast('模块已删除');
    await loadModules();
  } catch (err) {
    toast(err.message, true);
  }
}

async function exportModules() {
  const data = await api('/api/modules/export');
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `wallet-modules-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}

async function importModules(file) {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const modules = Array.isArray(parsed) ? parsed : parsed.modules;
    if (!Array.isArray(modules) || !modules.length) throw new Error('文件里没有模块数组');
    const r = await api('/api/modules/import', 'POST', { modules });
    toast(`已导入 ${r.imported} 个模块`);
    await loadModules();
  } catch (err) {
    toast(err.message, true);
  } finally {
    $('#modulesFile').value = '';
  }
}

/* ---------- metrics ---------- */

async function loadMetrics() {
  try {
    const m = await api(`/api/metrics?period=${state.metricsPeriod}`);
    renderMetrics(m);
  } catch (err) {
    $('#metricsBody').textContent = err.message;
  }
}

function renderMetrics(m) {
  const by = Object.entries(m.rpc.byMethod).sort((a, b) => b[1] - a[1]);
  const llmRecent = m.llm.recent.slice(0, 5)
    .map((x) => h`<span class="chip">${evTime(x.at)} · ${x.ms}ms · ${x.tokens || 0} tok</span>`);
  const none = h`<span class="muted">暂无</span>`;
  const cliChips = Object.entries(m.cli?.byCmd || {}).sort((a, b) => b[1] - a[1]).slice(0, 6)
    .map(([k, v]) => h`<span class="chip">${k} × ${v}</span>`);

  const latencyEl = $('#rpcLatency');
  if (latencyEl) {
    const ms = m.rpc.lastMs || 0;
    latencyEl.textContent = ms ? `RPC ${ms}ms` : 'RPC —';
    latencyEl.className = `latency ${ms ? (ms < 300 ? 'good' : ms < 800 ? 'mid' : 'bad') : ''}`;
  }
  $$('.period-btn').forEach((b) => b.classList.toggle('active', b.dataset.period === state.metricsPeriod));

  $('#metricsBody').innerHTML = h`
    <div class="stat"><span class="muted">交易节点（主节点）调用</span><b>${m.rpc.count}</b>
      <span class="muted">平均 ${m.rpc.avgMs}ms · 失败 ${m.rpc.errors}（占每秒额度的只有这一类）</span></div>
    <div class="stat"><span class="muted">非即时请求（后台节点 / 公共节点）</span><b>${(m.rpc.byNode?.bg?.count || 0) + (m.rpc.byNode?.public?.count || 0)}</b>
      <span class="muted">后台节点 ${m.rpc.byNode?.bg?.count || 0}（失败 ${m.rpc.byNode?.bg?.errors || 0}）· 公共节点 ${m.rpc.byNode?.public?.count || 0}（失败 ${m.rpc.byNode?.public?.errors || 0}）</span></div>
    <div class="stat"><span class="muted">baw CLI 调用</span><b>${m.cli?.count ?? 0}</b>
      <span class="muted">平均 ${m.cli?.avgMs ?? 0}ms · 失败 ${m.cli?.errors ?? 0}</span>
      <div class="methods">${cliChips.length ? cliChips : none}</div></div>
    <div class="stat"><span class="muted">DeepSeek 调用</span><b>${m.llm.calls}</b>
      <span class="muted">平均 ${m.llm.avgMs}ms · tokens ${m.llm.tokens}</span>
      <div class="methods">${llmRecent.length ? llmRecent : none}</div></div>
    <div class="stat" style="grid-column:1/-1">
      <span class="muted">按节点（主机名，含主节点失败后切到的备用；同一家的不同链分开算）</span>
      <div class="methods">${Object.keys(m.rpc.byHost || {}).length ? Object.entries(m.rpc.byHost).sort((a, b) => b[1] - a[1]).map(([k, v]) => h`<span class="chip">${k} × ${v}</span>`) : h`<span class="muted">更新后开始统计</span>`}</div>
      <span class="muted">后台任务各用了多少（后台节点 bg / 公共节点 public / 回落主节点 paid）</span>
      <table class="table"><thead><tr><th>任务</th><th class="right">bg</th><th class="right">public</th><th class="right">paid</th></tr></thead><tbody>
        ${Object.keys(m.rpc.byTask || {}).length
          ? Object.entries(m.rpc.byTask).sort((a, b) => (b[1].bg || 0) - (a[1].bg || 0)).map(([k, v]) => h`<tr><td>${k}</td><td class="right mono">${v.bg || 0}</td><td class="right mono">${v.public || 0}</td><td class="right mono">${v.paid || 0}</td></tr>`)
          : h`<tr><td colspan="4" class="muted">更新后开始统计</td></tr>`}
      </tbody></table>
    </div>
    <div class="stat" style="grid-column:1/-1">
      <span class="muted">接口分布</span>
      <div class="methods">${by.length ? by.map(([k, v]) => h`<span class="chip">${k} × ${v}</span>`) : none}</div>
      <table class="table">
        <thead><tr><th>最近调用</th><th>方法</th><th class="right">耗时</th></tr></thead>
        <tbody>${m.rpc.recent.length
          ? m.rpc.recent.slice(0, 8).map((r) => h`<tr><td class="muted">${evTime(r.at)}</td><td class="mono">${r.method}</td><td class="right mono">${r.ms}ms</td></tr>`)
          : h`<tr><td colspan="3" class="muted">本次启动后暂无明细（明细只保存在内存，重启清空）</td></tr>`}</tbody>
      </table>
    </div>`;
}

async function loadAiHint() {
  try {
    const s = await api('/api/settings');
    $('#aiKeyHint').innerHTML = s.ai.hasKey
      ? ''
      : '⚠️ 未配置 DeepSeek API Key，当前使用规则解析。去 <a href="#settings">设置</a> 填写（只保存在本机 config.json）。';
  } catch { /* ignore */ }
}

/* ---------- address book ---------- */

async function loadAddressBook() {
  try {
    const list = await api('/api/addressbook');
    state.addresses = list;
    $('#addrBookSelect').innerHTML = h`<option value="">从地址簿选择…</option>${list.map((e) => h`<option value="${e.id}">${e.name} · ${e.address.slice(0, 8)}…${e.address.slice(-4)} (${e.chainId})</option>`)}`;
    const savedId = readFormState().addrBookSelect;
    if (savedId && list.some((e) => e.id === savedId)) {
      $('#addrBookSelect').value = savedId;
    }
    $('#addrChips').innerHTML = h`${list.slice(0, 8).map((e) =>
      h`<button type="button" class="chip chip-btn" data-addr-id="${e.id}" title="${e.address}">${e.name}</button>`)}`;
    $$('#addrChips [data-addr-id]').forEach((b) => {
      b.onclick = () => {
        const entry = list.find((x) => x.id === b.dataset.addrId);
        if (!entry) return;
        $('#sendRecipient').value = entry.address;
        if (entry.chainId && entry.chainId !== $('#sendChain').value) applySendChain(entry.chainId);
        $('#addrBookSelect').value = entry.id;
        saveField('sendRecipient');
        saveField('addrBookSelect');
      };
    });
  } catch { /* ignore */ }
}

async function saveAddress() {
  const address = $('#sendRecipient').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return toast('先填写合法的收款地址', true);
  const name = $('#addrBookName').value.trim() || '未命名';
  try {
    await api('/api/addressbook', 'POST', { name, address, chainId: $('#sendChain').value });
    $('#addrBookName').value = '';
    await loadAddressBook();
    toast('地址已保存');
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteAddress() {
  const id = $('#addrBookSelect').value;
  if (!id) return toast('先在地址簿里选择一个地址', true);
  await api(`/api/addressbook/${id}`, 'DELETE');
  await loadAddressBook();
  toast('已删除');
}

/* ---------- wallet admin ---------- */

function saveSelectedWallets() {
  try {
    localStorage.setItem('walletui:selectedWallets', JSON.stringify([...state.selectedWallets]));
  } catch { /* ignore */ }
  updateBatchHint();
}

/** 启动时恢复批量勾选（之前只有打开「钱包」页才会恢复，导致批量开关悄悄失效） */
function restoreSelectedWallets() {
  try {
    const saved = JSON.parse(localStorage.getItem('walletui:selectedWallets') || '[]');
    state.selectedWallets = new Set(saved.filter((id) => state.wallets.some((w) => w.id === id)));
  } catch {
    state.selectedWallets = new Set();
  }
  updateBatchHint();
}

function updateBatchHint() {
  const el = $('#batchHint');
  if (!el) return;
  const names = [...state.selectedWallets].map((id) => state.wallets.find((w) => w.id === id)?.name || id);
  el.textContent = names.length ? `已勾选 ${names.length} 个钱包：${names.join('、')}` : '未勾选钱包（在「钱包」页勾选）';
}

function walletStatusLabel(status) {
  if (status === 'CONNECTED') return '已连接';
  if (status === 'UNCONNECTED') return '未连接';
  return '未知';
}

async function loadWalletAdmin() {
  try {
    const list = await api('/api/wallets');
    state.wallets = list;
    restoreSelectedWallets();
    const statuses = await Promise.all(list.map((w) =>
      api(`/api/w/${w.id}/status`).then((r) => r.status).catch(() => 'UNKNOWN')));

    $('#walletAdminList').innerHTML = h`
      <div class="actions" style="margin:0 0 10px">
        <button class="ghost" id="btnBatchLogout">退出选中</button>
        <button class="ghost" id="btnBatchDelete">删除选中</button>
        <span class="hint" id="batchCount" style="margin:0"></span>
      </div>
      <table class="table">
        <thead><tr>
          <th style="width:34px"><input type="checkbox" id="wCheckAll" /></th>
          <th>名称</th><th>状态</th><th></th>
        </tr></thead>
        <tbody>${list.map((w, i) => h`
          <tr class="${statuses[i] === 'CONNECTED' ? '' : 'row-err'}">
            <td><input type="checkbox" data-w-check="${w.id}" ${state.selectedWallets.has(w.id) ? h`checked` : ''} /></td>
            <td>${w.name}<div class="muted mono" title="${w.evm || ''}">${w.id}${w.evm ? h` · ${caHtml(w.evm)}` : ''}</div></td>
            <td><span class="pill ${statuses[i] === 'CONNECTED' ? 'pill-green' : statuses[i] === 'UNKNOWN' ? 'pill-muted' : 'pill-red'}">${statuses[i] === 'CONNECTED' ? '● ' : '✕ '}${walletStatusLabel(statuses[i])}</span></td>
            <td class="right">
              <button class="${statuses[i] === 'CONNECTED' ? 'ghost' : 'primary'}" data-w-login="${w.id}">${statuses[i] === 'CONNECTED' ? '登录' : '重新登录'}</button>
              <button class="ghost" data-w-logout="${w.id}">退出</button>
              <button class="ghost" data-w-delete="${w.id}">删除</button>
            </td>
          </tr>`)}</tbody>
      </table>`;

    const syncCount = () => {
      $('#batchCount').textContent = state.selectedWallets.size
        ? `已勾选 ${state.selectedWallets.size} 个钱包`
        : '';
    };
    $$('[data-w-check]').forEach((box) => {
      box.onchange = () => {
        if (box.checked) state.selectedWallets.add(box.dataset.wCheck);
        else state.selectedWallets.delete(box.dataset.wCheck);
        saveSelectedWallets();
        syncCount();
      };
    });
    $('#wCheckAll').onchange = (e) => {
      if (e.target.checked) list.forEach((w) => state.selectedWallets.add(w.id));
      else state.selectedWallets.clear();
      saveSelectedWallets();
      loadWalletAdmin();
    };
    syncCount();

    $$('[data-w-login]').forEach((b) => { b.onclick = () => walletLogin(b.dataset.wLogin); });
    $$('[data-w-logout]').forEach((b) => { b.onclick = () => walletLogout(b.dataset.wLogout); });
    $$('[data-w-delete]').forEach((b) => { b.onclick = () => walletDelete(b.dataset.wDelete); });
    $('#btnBatchLogout').onclick = batchLogout;
    $('#btnBatchDelete').onclick = batchDelete;
  } catch (err) {
    $('#walletAdminList').textContent = err.message;
  }
}

async function walletDelete(id) {
  const wallet = state.wallets.find((w) => w.id === id);
  const ok = await confirmDialog('删除钱包', [
    ['钱包', wallet?.name || id],
    ['本地目录', `profiles/${id}`],
  ], '会删除本地会话目录（不影响币安账户与链上资产）。删除后需重新扫码才能恢复使用。');
  if (!ok) return;
  try {
    await api(`/api/wallets/${id}`, 'DELETE');
    state.selectedWallets.delete(id);
    saveSelectedWallets();
    state.wallets = await api('/api/wallets');
    renderWalletTabs();
    toast('钱包已删除');
    await loadWalletAdmin();
    if (state.active === id && state.wallets.length) await selectWallet(state.wallets[0].id);
  } catch (err) {
    toast(err.message, true);
  }
}

async function batchLogout() {
  if (!state.selectedWallets.size) return toast('先勾选钱包', true);
  const ok = await confirmDialog('批量退出', [['数量', String(state.selectedWallets.size)]], '只清除本机会话，不影响资产。');
  if (!ok) return;
  for (const id of [...state.selectedWallets]) {
    try { await api(`/api/wallets/${id}/signout`, 'POST'); } catch { /* 继续 */ }
  }
  toast('已退出选中钱包');
  await loadWalletAdmin();
}

async function batchDelete() {
  if (!state.selectedWallets.size) return toast('先勾选钱包', true);
  const ok = await confirmDialog('批量删除', [['数量', String(state.selectedWallets.size)]], '将删除本地会话目录，不影响链上资产。');
  if (!ok) return;
  for (const id of [...state.selectedWallets]) {
    try { await api(`/api/wallets/${id}`, 'DELETE'); } catch { /* 继续 */ }
    state.selectedWallets.delete(id);
  }
  saveSelectedWallets();
  state.wallets = await api('/api/wallets');
  renderWalletTabs();
  await loadWalletAdmin();
  if (!state.wallets.some((w) => w.id === state.active) && state.wallets.length) {
    await selectWallet(state.wallets[0].id);
  }
}

async function walletLogin(id) {
  const dialog = $('#loginDialog');
  $('#loginQr').removeAttribute('src');
  $('#loginCode').textContent = '';
  $('#loginLink').textContent = '';
  $('#loginState').textContent = '正在生成二维码…';
  dialog.showModal();
  try {
    const r = await api(`/api/wallets/${id}/signin`, 'POST');
    if (r.alreadyConnected) {
      $('#loginState').textContent = '该钱包已连接';
      await loadWalletAdmin();
      return;
    }
    $('#loginQr').src = r.qrDataUrl || '';
    $('#loginCode').textContent = r.pairingCode;
    const loginUrl = safeHttpUrl(r.urlForWeb);
    $('#loginLink').innerHTML = loginUrl
      ? h`或被打开：<a href="${loginUrl}" target="_blank" rel="noreferrer noopener">${loginUrl}</a>`
      : '';
    $('#loginState').textContent = '请用币安 App 扫码并核对配对码，等待确认…';
    const v = await api(`/api/wallets/${id}/verify`, 'POST', { qrCodeId: r.qrCodeId });
    state.wallets = await api('/api/wallets');
    renderWalletTabs();
    await loadWalletAdmin();
    const ch = v?.identityChanged;
    if (ch) {
      // 扫错码：留着弹窗让用户看清楚，同时推顶部告警（全部自动化已在后端解除）
      $('#loginState').textContent = `⚠ 登录成功，但账号和之前不同：原地址 ${ch.from}，现在是 ${ch.to}`
        + `${ch.sameAs ? `（和「${walletNameOf(ch.sameAs)}」是同一个账号，很可能扫错了码）` : ''}。全部自动化预授权已解除；扫错了就退出后用正确的账号重新扫码`;
      toast('登录的币安账号和之前不同，请核对', true);
      pollV3Alerts();
      return;
    }
    $('#loginState').textContent = '登录成功';
    toast('登录成功');
    dialog.close();
  } catch (err) {
    $('#loginState').textContent = `失败：${err.message}`;
    toast(err.message, true);
  }
}

async function walletLogout(id) {
  const ok = await confirmDialog('退出钱包', [['钱包', id]], '只清除本机会话，不影响币安账户与链上资产。');
  if (!ok) return;
  try {
    await api(`/api/wallets/${id}/signout`, 'POST');
    toast('已退出');
    await loadWalletAdmin();
    if (state.active === id) await selectWallet(id);
  } catch (err) {
    toast(err.message, true);
  }
}

async function addWallet() {
  const name = $('#newWalletName').value.trim();
  if (!name) return toast('请输入钱包名称', true);
  try {
    const w = await api('/api/wallets', 'POST', { name });
    $('#newWalletName').value = '';
    state.wallets = await api('/api/wallets');
    renderWalletTabs();
    await loadWalletAdmin();
    await walletLogin(w.id);
  } catch (err) {
    toast(err.message, true);
  }
}

/* ---------- settings ---------- */

async function loadSettings() {
  const s = await api('/api/settings');
  const map = { '56': '#setRpc', '1': '#setEthRpc', '8453': '#setBaseRpc', '4663': '#setRhRpc' };
  for (const [id, sel] of Object.entries(map)) {
    const info = s.rpcs?.[id];
    const input = $(sel);
    if (!info) continue;
    input.value = '';
    input.placeholder = info.custom ? info.masked : (info.masked || '留空则未配置');
    input.title = info.custom ? '已配置自定义节点' : '使用公共/默认节点';
  }
  $('#rpcState').textContent = Object.values(s.rpcs || {}).filter((x) => x.custom).length
    ? `已配置 ${Object.values(s.rpcs).filter((x) => x.custom).length} 条自定义 RPC`
    : '全部使用公共节点';
  const wss = s.wss?.['56'];
  if (wss) {
    $('#setWss').value = '';
    $('#setWss').placeholder = wss.set ? wss.masked : 'wss://xxx.bsc.quiknode.pro/<token>/';
    $('#setWss').title = wss.set ? '已配置 WSS 节点' : '未配置';
  }
  renderNodePools(s.pools || {});
  renderWssDual(s);
  $('#setAiBase').value = s.ai.baseUrl;
  $('#setAiModel').value = s.ai.model;
  $('#aiState').textContent = s.ai.hasKey
    ? `模型已启用（${s.ai.model}，Key ${s.ai.keyHint}）`
    : '未配置 Key，使用规则解析（毫秒级）。';
}

async function saveRpc() {
  const btn = $('#btnRpcSave');
  setBusy(btn, true);
  try {
    const s = await api('/api/settings', 'POST', {
      rpcs: {
        56: $('#setRpc').value.trim(),
        1: $('#setEthRpc').value.trim(),
        8453: $('#setBaseRpc').value.trim(),
        4663: $('#setRhRpc').value.trim(),
      },
      wss: { 56: $('#setWss').value.trim() },
    });
    $('#rpcState').textContent = Object.values(s.rpcs || {}).filter((x) => x.custom).length
      ? `已配置 ${Object.values(s.rpcs).filter((x) => x.custom).length} 条自定义 RPC`
      : '全部使用公共节点';
    await loadSettings();
    toast('RPC 已保存');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function testRpc(chainId) {
  const map = { '56': '#setRpc', '1': '#setEthRpc', '8453': '#setBaseRpc', '4663': '#setRhRpc' };
  const btn = document.querySelector(`[data-test-chain="${chainId}"]`);
  setBusy(btn, true);
  try {
    const r = await api('/api/settings/test-rpc', 'POST', {
      chainId,
      url: $(map[chainId])?.value.trim() || '',
    });
    toast(`链 ${chainId} RPC 可用，最新区块 ${r.block}`);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- 备用节点池 ---------- */

const POOL_INPUT = { 'rpc:56': '#setRpc', 'rpc:1': '#setEthRpc', 'rpc:8453': '#setBaseRpc', 'rpc:4663': '#setRhRpc', 'wss:56': '#setWss' };

/** 后台任务页：双节点 WSS 的连接状态与「谁先推到」统计（没开双节点时不显示） */
function wssRaceHtml(w) {
  const b = w?.backup;
  if (!b || b.state === 'off') return '';
  const race = w.race;
  const side = (name, x) => h`<tr><td>${name}</td><td class="mono">${x.first}</td><td class="mono">${x.leadP50 ?? '—'}${x.leadP50 != null ? ' ms' : ''}</td><td class="mono">${x.leadP90 ?? '—'}${x.leadP90 != null ? ' ms' : ''}</td><td class="mono">${x.only}</td></tr>`;
  return h`<h3 style="font-size:13px;margin:14px 0 6px">双节点订阅 · 备用 ${b.url || '—'}（${b.connected ? `已连接${b.rttMs != null ? ` · ${b.rttMs}ms` : ''}` : b.state}，镜像 ${b.mirrored} 个日志订阅）</h3>
    ${race ? h`<p class="muted" style="margin:0 0 6px">${evTime(race.since)} 起，两路都推到的日志 <b>${race.paired}</b> 条</p>
    <table class="table"><thead><tr><th>节点</th><th>先到次数</th><th>先到时领先（中位）</th><th>领先（P90）</th><th>只有它推了</th></tr></thead><tbody>
      ${side('主节点', race.main)}${side('备用节点', race.backup)}
    </tbody></table>
    ${race.samples.length ? h`<p class="muted" style="margin:6px 0 0">最近：${race.samples.slice(0, 6).map((s) => `${s.label?.slice(0, 14) || ''} ${s.first === 'main' ? '主' : '备'}先到 ${s.leadMs}ms`).join('；')}</p>` : ''}` : ''}`;
}

/** gang V3 官方新玩法回看：每种玩法前 5 个币（只读） */
async function loadSnipeModes(fresh = false) {
  const box = $('#snipeModes');
  if (!box) return;
  box.innerHTML = h`<p class="muted">读取中…（首次要回扫登记记录，十几秒）</p>`;
  let d;
  try { d = await api(`/api/gangsnipe/modes?n=5${fresh ? '&fresh=1' : ''}`); } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; return; }
  $('#snipeModesAt').textContent = `更新于 ${evTime(d.at)} · 官方工厂 ${d.factories} 个${d.adminOk === false ? ' · ⚠ 税收处理合约已不归官方登记合约' : ''}`;
  const pct = (b) => (b == null ? '—' : `${b / 100}%`);
  box.innerHTML = d.types.length ? h`${d.types.map((t) => h`
    <h4 style="font-size:13px;margin:10px 0 4px">${t.type}（已发 ${t.launched} 个${t.pending ? ` · 已克隆未建成 ${t.pending}` : ''}）</h4>
    <table class="table"><thead><tr><th>#</th><th>代币</th><th>创建时间</th><th class="right">进度</th><th>买税 / 卖税</th><th>分红</th><th>创建者</th><th>本系统</th></tr></thead><tbody>
      ${t.rows.map((r) => h`<tr>
        <td class="mono">${r.rank}</td>
        <td><b>${r.symbol}</b> ${caHtml(r.token)}</td>
        <td class="mono">${r.createdAt ? new Date(r.createdAt).toLocaleString('zh-CN', { hour12: false }) : '—'}</td>
        <td class="right mono">${r.graduated ? h`<span class="pnl-up">已毕业</span>` : r.progressPct == null ? '—' : `${r.progressPct}%`}</td>
        <td class="mono">${pct(r.buyTaxBps)} / ${pct(r.sellTaxBps)}</td>
        <td class="mono">${pct(r.dividendBps)}</td>
        <td class="mono">${r.creator ? caHtml(r.creator) : '—'}</td>
        <td>${r.ours ? h`<span class="${r.ours.type === 'gangsnipe3.buy' || r.ours.type === 'gangsnipe3.landed' ? 'pnl-up' : 'muted'}">${r.ours.text || r.ours.type}</span>${r.ours.txHash ? h` ${txLinkHtml('56', r.ours.txHash)}` : ''}` : h`<span class="muted">—</span>`}</td>
      </tr>`)}
    </tbody></table>`)}` : h`<p class="muted">还没有官方新玩法</p>`;
  wireEvAddrs(box);
}

/** 双节点 WSS 订阅开关：状态以后端为准（不进 localStorage）；没有备用 wss 时提示先加一条 */
function renderWssDual(s) {
  const box = $('#setWssDual');
  if (!box) return;
  box.checked = s.wssDual === true;
  $('#setWssDualHint').textContent = s.wssBackup
    ? `备用：${s.wssBackup}${s.wssDual ? '（已开启，对比结果见「后台任务」）' : ''}`
    : '节点池里还没有备用 wss：先在上面「加为备用」';
}

async function toggleWssDual() {
  const box = $('#setWssDual');
  const want = box.checked;
  try {
    renderWssDual(await api('/api/settings/wss-dual', 'POST', { enabled: want }));
    toast(want ? '已开启双节点订阅' : '已关闭双节点订阅');
  } catch (err) {
    box.checked = !want;
    toast(err.message, 'error');
  }
}

function renderNodePools(pools) {
  for (const box of $$('.node-pool')) {
    const key = box.dataset.pool;
    const list = pools[key] || [];
    if (!list.length) { box.innerHTML = ''; continue; } // 该链未配置自定义节点
    box.innerHTML = h`
      <div class="pool-head">节点（主 / 备用，可切换）</div>
      ${list.map((n) => h`
        <span class="chip ${n.active ? 'node-active' : ''}" title="${n.masked}">
          <b class="node-tag">${n.active ? '主·使用中' : '备用'}</b>
          <span class="mono">${n.masked}</span>
          ${n.active ? '' : h`<button class="chip-btn" data-act="activate" data-key="${key}" data-i="${n.i}">设为主</button>`}
          <button class="chip-btn" data-act="remove" data-key="${key}" data-i="${n.i}" title="删除">✕</button>
        </span>`)}`;
    box.querySelectorAll('[data-act="activate"]').forEach((b) => { b.onclick = () => activateNode(b.dataset.key, b.dataset.i); });
    box.querySelectorAll('[data-act="remove"]').forEach((b) => { b.onclick = () => removeNode(b.dataset.key, b.dataset.i); });
  }
}

async function addAltNode(key) {
  const url = $(POOL_INPUT[key])?.value.trim();
  if (!url) return toast('请先在输入框填入要加入的节点地址', true);
  const [kind, chainId] = key.split(':');
  try {
    renderNodePools(await api('/api/settings/nodes', 'POST', { kind, chainId, url, action: 'add', activate: false }));
    $(POOL_INPUT[key]).value = '';
    toast('已加入备用（未启用）');
  } catch (err) { toast(err.message, true); }
}

async function activateNode(key, index) {
  const [kind, chainId] = key.split(':');
  try {
    const s = await api('/api/settings/nodes', 'POST', { kind, chainId, index: Number(index), action: 'activate' });
    renderNodePools(s.pools || {});
    await loadSettings();
    toast('已切换启用节点');
  } catch (err) { toast(err.message, true); }
}

async function removeNode(key, index) {
  const [kind, chainId] = key.split(':');
  try {
    const s = await api('/api/settings/nodes', 'POST', { kind, chainId, index: Number(index), action: 'remove' });
    renderNodePools(s.pools || {});
    await loadSettings();
    toast('已删除候选节点');
  } catch (err) { toast(err.message, true); }
}

async function clearRpcNode(chainId) {
  const ok = await confirmDialog('清除节点', [['链', chainId]], '清除后该链恢复使用公共/默认节点。');
  if (!ok) return;
  try {
    await api('/api/settings', 'POST', { clearRpcs: [String(chainId)] });
    await loadSettings();
    toast(`链 ${chainId} 已清除`);
  } catch (err) { toast(err.message, true); }
}

async function clearWssNode() {
  const ok = await confirmDialog('清除 WSS 节点', [['链', '56']], '清除后 Four 狙击将无法订阅事件，需重新填写。');
  if (!ok) return;
  try {
    await api('/api/settings', 'POST', { clearWss: true });
    await loadSettings();
    toast('WSS 已清除');
  } catch (err) { toast(err.message, true); }
}

async function testWssNode() {
  const btn = $('#btnTestWss');
  setBusy(btn, true);
  try {
    const r = await api('/api/settings/test-wss', 'POST', { url: $('#setWss').value.trim() });
    toast(`WSS 可用，最新区块 ${r.block}，往返 ${r.rttMs}ms`);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- Four 狙击 ---------- */

let fourTimer = null;

const FOUR_WALLETS_KEY = 'walletui:fourWallets';

const FOUR_BUCKETS = [['wbnb', 'Wbnb'], ['bncb', 'Bncb'], ['nvdab', 'Nvdab']];

function fourBucketsFromForm() {
  const b = {};
  for (const [key, cap] of FOUR_BUCKETS) {
    b[key] = {
      enabled: $(`#bk${cap}Enabled`).checked,
      maxTargets: Number($(`#bk${cap}N`).value || 1),
      amountTokens: $(`#bk${cap}Amount`).value.trim() || '10m',
      quoteCap: $(`#bk${cap}Cap`).value.trim() || '0',
    };
  }
  return b;
}

function fourConfigFromForm() {
  const wallets = $$('#fourWallets input[type=checkbox]:checked').map((c) => c.value);
  return {
    mode: $('#fourMode').value,
    presetId: $('#fourPreset').value.trim(),
    wallets,
    buckets: fourBucketsFromForm(),
    slippageBps: Number($('#fourSlip').value),
    chaseBps: Number($('#fourChase').value),
    taxMaxBps: Number($('#fourTax').value),
    feeMaxBps: Number($('#fourFee').value),
    maxWaitBlocks: Number($('#fourWait').value || 20),
    gasLimit: (() => {
      // 自动 = 0（后端估算）；固定时误填 / 留空的值（如 8）按推荐值 100 万处理，并回写输入框
      if ($('#fourGasMode').value === 'auto') return 0;
      const v = Number($('#fourGasLimit').value || 0);
      if (!(Number.isInteger(v) && v >= 21000 && v <= 15000000)) {
        $('#fourGasLimit').value = '1000000';
        saveField('fourGasLimit');
        return 1000000;
      }
      return v;
    })(),
    onlyFfff: $('#fourOnlyFfff').checked,
    holderOnly: $('#fourHolderOnly').checked,
    excludeNameRe: $('#fourExclude').value.trim(),
  };
}

function saveFourWallets() {
  const ids = $$('#fourWallets input[type=checkbox]:checked').map((c) => c.value);
  try { localStorage.setItem(FOUR_WALLETS_KEY, JSON.stringify(ids)); } catch { /* ignore */ }
}

function readFourWallets() {
  try { return JSON.parse(localStorage.getItem(FOUR_WALLETS_KEY) || '[]'); } catch { return []; }
}

function fillFourForm(cfg) {
  if (!cfg) return;
  $('#fourMode').value = cfg.mode;
  $('#fourPreset').value = cfg.presetId;
  $('#fourSlip').value = String(cfg.slippageBps);
  $('#fourChase').value = String(cfg.chaseBps ?? 5000);
  $('#fourTax').value = String(cfg.taxMaxBps);
  $('#fourFee').value = String(cfg.feeMaxBps);
  $('#fourWait').value = cfg.maxWaitBlocks;
  $('#fourGasMode').value = cfg.gasLimit === 0 ? 'auto' : 'fixed';
  if (cfg.gasLimit) $('#fourGasLimit').value = cfg.gasLimit;
  syncGasMode('four');
  $('#fourOnlyFfff').checked = cfg.onlyFfff !== false;
  $('#fourHolderOnly').checked = cfg.holderOnly !== false;
  $('#fourExclude').value = cfg.excludeNameRe || '';
  for (const [key, cap] of FOUR_BUCKETS) {
    const b = cfg.buckets?.[key];
    if (!b) continue;
    $(`#bk${cap}Enabled`).checked = Boolean(b.enabled);
    $(`#bk${cap}N`).value = b.maxTargets;
    $(`#bk${cap}Amount`).value = b.amountTokens;
    $(`#bk${cap}Cap`).value = b.quoteCap;
  }
}

function renderFourWalletChecks() {
  // 优先本地勾选记忆；运行中/已授权时以后端生效的钱包为准
  const backend = (state.four?.running || state.four?.armed) ? state.four?.config?.wallets : null;
  const saved = readFourWallets();
  const sel = new Set(backend?.length ? backend : (saved.length ? saved : [...(state.selectedWallets || [])]));
  $('#fourWallets').innerHTML = h`${(state.wallets || []).map((w) => h`
    <label class="chip" style="cursor:pointer">
      <input type="checkbox" value="${w.id}" ${sel.has(w.id) ? h`checked` : ''} /> ${w.name}
    </label>`)}`;
  $$('#fourWallets input[type=checkbox]').forEach((c) => { c.onchange = saveFourWallets; });
}

async function loadFour() {
  // 轻量版只有「内盘手动交易」：不读 Four 狙击状态、不轮询
  if (!FULL) { fillApproveWallets(); fillFourTradeWallets(); return; }
  try {
    const s = await api('/api/sniper/state');
    state.four = s;
    // 后端已持久化 config（sniper.json），直接回填，刷新/重启都不丢
    fillFourForm(s.config);
    applyFourState(s);
    renderFourWalletChecks();
    fillApproveWallets();
    fillFourTradeWallets();
    if (!fourTimer) fourTimer = setInterval(pollFour, 1500);
  } catch (err) {
    toast(err.message, true);
  }
}

function applyFourState(s) {
  // 顶部状态胶囊：运行 / WSS / 预授权
  const wsMap = { idle: ['未连接', 'muted'], connecting: ['连接中', 'amber'], open: ['已连接', 'green'], closed: ['已断开', 'muted'], error: ['异常', 'red'] };
  const [wsLabel, wsColor] = wsMap[s.wsStatus?.state] || ['未连接', 'muted'];
  $('#fourWsState').innerHTML = h`
    <span class="pill ${s.running ? 'pill-green' : 'pill-muted'}">${s.running ? '● 运行中' : '○ 已停止'}</span>
    <span class="pill pill-${wsColor}">WSS·${wsLabel}${s.wsRttMs != null ? ` ${s.wsRttMs}ms` : ''}</span>
    <span class="pill ${s.armed ? 'pill-red' : 'pill-muted'}">${s.armed ? '🔓 已预授权' : '🔒 未授权'}</span>`;

  // 命中进度(按桶) + 关键参数
  const bh = s.bucketHits || {};
  const cb = s.config?.buckets || {};
  const hitPill = (k, label, cls) => (cb[k]?.enabled
    ? h`<span class="hit-pill hit-${cls} ${(bh[k] || 0) >= (cb[k].maxTargets || 0) ? 'hit-full' : ''}">${label} ${bh[k] || 0}/${cb[k].maxTargets || 0}</span>`
    : h`<span class="hit-pill hit-off">${label} 关</span>`);
  const pct = s.totalTargets ? Math.min(100, Math.round((s.hitCount / s.totalTargets) * 100)) : 0;
  $('#fourDigest').innerHTML = h`
    <div class="four-hits">
      <span class="hit-total">命中 ${s.hitCount}/${s.totalTargets ?? 7}</span>
      ${hitPill('wbnb', 'WBNB', 'wbnb')}${hitPill('bncb', 'BNCB', 'bncb')}${hitPill('nvdab', 'NVDAB', 'nvdab')}
      <span class="hit-block">区块 ${s.lastBlock || '—'}</span>
    </div>
    <div class="hit-bar"><span style="${`width:${pct}%`}"></span></div>
    <div class="four-params">
      <span class="chip">模式 ${s.mode}</span>
      <span class="chip">滑点 ${(s.config?.slippageBps || 0) / 100}%</span>
      <span class="chip">追价 ${s.config?.chaseBps ? `+${s.config.chaseBps / 100}%` : '不重试'}</span>
      <span class="chip">税上限 ${(s.config?.taxMaxBps || 0) / 100}%</span>
      <span class="chip">费率上限 ${(s.config?.feeMaxBps || 0) / 100}%</span>
      <span class="chip">等待 ${s.config?.maxWaitBlocks ?? '—'}块</span>
      <span class="chip">gasLimit ${s.config?.gasLimit ? s.config.gasLimit : '自动'}</span>
      <span class="chip ${s.config?.onlyFfff ? 'chip-on' : 'chip-off'}">尾号 ffff ${s.config?.onlyFfff ? '✓' : '✕'}</span>
      <span class="chip ${s.config?.holderOnly ? 'chip-on' : 'chip-off'}">全员分红 ${s.config?.holderOnly ? '✓' : '✕'}</span>
    </div>`;

  const tbody = $('#fourTargets').querySelector('tbody');
  tbody.innerHTML = (s.targets || []).length
    ? h`${[...s.targets].reverse().map((t) => h`
      <tr class="four-trow ${fourRowClass(t)}">
        <td>${t.hitIndex || '—'}</td>
        <td>${tokenLinkHtml(t.token, t.symbol)}${t.txHash ? h`<br>${txLinkHtml('56', t.txHash, '↗ 买入交易')}` : ''}</td>
        <td>${addrLinkHtml(t.creator)}</td>
        <td>${t.buyTaxBps != null ? `${t.buyTaxBps / 100}/${t.sellTaxBps / 100}%` : '—'}</td>
        <td>${t.phaseName || '—'}</td>
        <td>${fourStageLabel(t)}</td>
      </tr>`)}`
    : '<tr><td colspan="6" class="muted">暂无命中</td></tr>';

  $('#fourEvents').innerHTML = (s.events || []).length
    ? h`${s.events.slice(0, 60).map((e) => h`
      <div class="log-row lv-${evLevel(e.type)}">
        <span class="log-time mono">${new Date(e.at).toLocaleTimeString('zh-CN', { hour12: false })}</span>
        <span class="log-icon">${fourEventIcon(e.type)}</span>
        <span class="log-msg">${e.msg}</span>
        <span class="log-links">${e.txHash ? txLinkHtml('56', e.txHash, '↗ 交易') : ''}${e.token ? tokenLinkHtml(e.token) : ''}</span>
      </div>`)}`
    : '<p class="muted small">暂无事件</p>';
}

/** 代币地址 → BscScan 代币页链接（醒目按钮样式） */
function tokenLinkHtml(token, symbol) {
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(token || ''))) return h`${symbol || '—'}`;
  const label = symbol ? `${symbol} ${short(token)}` : short(token);
  return h`<a class="chain-link" href="${`${EXPLORERS[56]}/token/${token}`}" target="_blank" rel="noopener noreferrer" title="${token}">${label} ↗</a>${copyBtnHtml(token)}`;
}

/** 地址 → BscScan 地址页链接 */
function addrLinkHtml(addr) {
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(addr || ''))) return h`${short(addr)}`;
  return h`<a class="chain-link" href="${`${EXPLORERS[56]}/address/${addr}`}" target="_blank" rel="noopener noreferrer" title="${addr}">${short(addr)} ↗</a>${copyBtnHtml(addr)}`;
}

/** 命中行颜色：全买到绿 · 部分买到橙 · 出错 / 下了单一个都没买到（已退回名额）红 · 跳过不着色 */
function fourRowClass(t) {
  const ws = Object.values(t.wallets || {});
  if (t.stage === 'bought') return ws.length && ws.some((w) => w.stage !== 'bought') ? 'row-warn' : 'row-ok';
  if (t.stage === 'error' || (t.stage === 'skipped' && ws.length)) return 'row-err';
  return '';
}

function fourStageLabel(t) {
  // 每个钱包的结果（auto 并行下单后才有）：已买 x/n，并列出各钱包状态
  const ws = Object.entries(t.wallets || {});
  const okN = ws.filter(([, w]) => w.stage === 'bought').length;
  const per = ws.length ? `（${ws.map(([id, w]) => `${id}${w.stage === 'bought' ? '✓' : `✗${w.error ? ` ${String(w.error).slice(0, 40)}` : ''}`}`).join(' / ')}）` : '';
  const map = {
    detected: '发现', skipped: `跳过：${t.reason || ''}`, ready: '可买', planned: '已计划',
    bought: ws.length ? `已买入 ${okN}/${ws.length}${per}` : '已买入', error: `错误：${t.reason || ''}`,
  };
  return map[t.stage] || t.stage;
}

function fourEventIcon(type) {
  return { detect: '🔍', skip: '⏭️', refund: '↩️', qualify: '✓', ready: '🎯', plan: '📝', bought: '✅', exec: '⚙️', error: '⚠️', wss: '🔌', arm: '🔓', disarm: '🔒', start: '▶️', stop: '⏹️', config: '⚙️' }[type] || '•';
}

async function pollFour() {
  if (!document.querySelector('#view-four').classList.contains('active')) return;
  try {
    const s = await api('/api/sniper/state');
    state.four = s;
    applyFourState(s);
  } catch { /* 轮询失败忽略 */ }
}

async function saveFourConfig() {
  const btn = $('#btnFourSaveCfg');
  setBusy(btn, true);
  try {
    const s = await api('/api/sniper/config', 'POST', { config: fourConfigFromForm() });
    state.four = s;
    applyFourState(s);
    toast('参数已保存（改参数会自动解除预授权）');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function fourStart() {
  const btn = $('#btnFourStart');
  setBusy(btn, true);
  try {
    await api('/api/sniper/config', 'POST', { config: fourConfigFromForm() });
    const s = await api('/api/sniper/start', 'POST', {});
    state.four = s;
    applyFourState(s);
    toast('已开始监听');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function fourStop() {
  try {
    applyFourState(await api('/api/sniper/stop', 'POST', {}));
    toast('已停止');
  } catch (err) { toast(err.message, true); }
}

async function fourArm() {
  const cfg = state.four?.config;
  const digest = state.four?.digest || '';
  if (!cfg || cfg.mode !== 'auto') return toast('请先把模式设为「自动」并保存参数', true);
  const ok = await confirmDialog('预授权自动狙击', [
    ['模式', '自动'],
    ['钱包', (cfg.wallets || []).join(', ') || '—'],
    ['单币预算', `${cfg.budgetBnb} BNB`],
    ['总预算', `${cfg.totalBudgetBnb} BNB`],
    ['滑点', `${cfg.slippageBps / 100}%`],
    ['前 N 个', cfg.maxTargets],
    ['税上限', `${cfg.taxMaxBps / 100}%`],
    ['费率上限', `${cfg.feeMaxBps / 100}%`],
  ], '确认后，引擎会在上述范围内自动预览并广播买入交易，无需逐笔确认。改动任何参数都会立即解除授权。');
  if (!ok) return;
  try {
    applyFourState(await api('/api/sniper/arm', 'POST', { confirm: 'ARM', digest }));
    toast('已预授权');
  } catch (err) { toast(err.message, true); }
}

async function fourDisarm() {
  try { applyFourState(await api('/api/sniper/disarm', 'POST', {})); toast('已解除授权'); }
  catch (err) { toast(err.message, true); }
}

async function clearFourLog() {
  try { applyFourState(await api('/api/sniper/clear-log', 'POST', {})); toast('日志已清空'); }
  catch (err) { toast(err.message, true); }
}

/* ---------- 预授权 bStock 计价币 ---------- */

function fillApproveWallets() {
  const sel = $('#apWallet');
  if (!sel) return;
  const prev = sel.value;
  sel.innerHTML = h`${(state.wallets || []).map((w) => h`<option value="${w.id}">${w.name}</option>`)}`;
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

async function approvePreview() {
  const btn = $('#btnApprovePreview');
  setBusy(btn, true);
  state.approve = null;
  $('#btnApproveExec').disabled = true;
  try {
    const walletId = $('#apWallet').value;
    const quote = $('#apQuote').value;
    const amount = $('#apAmount').value.trim();
    const r = await api('/api/sniper/approve', 'POST', { walletId, quote, amount });
    state.approve = { walletId, preview: r.preview, quote: r.quote, amount };
    renderPreview($('#apOut'), r.preview, '56');
    $('#btnApproveExec').disabled = !previewExecutable(r.preview, '56');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function approveExec() {
  const a = state.approve;
  if (!a?.preview?.requestId) return;
  const quote = String(a.quote || '').toUpperCase(); // 下拉框的值是小写 bncb / nvdab
  const ok = await confirmDialog('确认授权', [
    ['钱包', walletNameOf(a.walletId)],
    ['计价币', quote],
    ['授权额度', `${a.amount} ${quote}`],
    ['授权给', 'Four Core（OpenFour 发射台合约）'],
  ], '这是一笔真实授权交易（花 gas）。确认后会广播，允许 Core 在该额度内划扣你的计价币。');
  if (!ok) return;
  const btn = $('#btnApproveExec');
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${a.walletId}/execute`, 'POST', { requestId: a.preview.requestId, confirm: 'EXECUTE' });
    toastTx('授权已提交', '56', result.txHash);
    state.approve = null;
    $('#btnApproveExec').disabled = true;
    $('#apOut').hidden = true;
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function fourDryRun() {
  const btn = $('#btnFourDry');
  const token = $('#fourDryToken').value.trim();
  const walletId = state.active;
  if (!/^0x[0-9a-fA-F]{40}$/.test(token)) return toast('请输入有效代币地址', true);
  setBusy(btn, true);
  try {
    await api('/api/sniper/config', 'POST', { config: fourConfigFromForm() });
    const r = await api('/api/sniper/dry-run', 'POST', { token, walletId });
    const out = $('#fourDryOut');
    out.hidden = false;
    out.innerHTML = h`
      <div class="row"><span class="muted">代币</span><span class="mono">${r.symbol || ''} ${caHtml(r.token)}</span></div>
      <div class="row"><span class="muted">钱包</span><span class="mono">${walletId} · ${caHtml(r.from)}</span></div>
      <div class="row"><span class="muted">耗时</span><span class="mono">${r.elapsedMs}ms</span></div>
      ${r.steps.map((st) => h`<div class="row"><span>${st.ok ? '✅' : '❌'}</span><span>${st.msg}</span></div>`)}`;
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- Four 内盘手动交易（按 CA 买 / 卖） ---------- */

const FOUR_TRADE_WALLET_KEY = 'walletui:fourTradeWallet';

function fillFourTradeWallets() {
  const sel = $('#fourTradeWallet');
  if (!sel) return;
  let prev = sel.value;
  if (!prev) { try { prev = localStorage.getItem(FOUR_TRADE_WALLET_KEY) || state.active; } catch { prev = state.active; } }
  sel.innerHTML = h`${(state.wallets || []).map((w) => h`<option value="${w.id}">${w.name}</option>`)}`;
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
  sel.onchange = () => {
    try { localStorage.setItem(FOUR_TRADE_WALLET_KEY, sel.value); } catch { /* ignore */ }
    // 持仓属于上一个钱包：清掉，避免用 A 的列表去卖 B
    state.fourHoldings = null;
    const box = $('#fourHoldings');
    if (box) { box.hidden = true; box.innerHTML = ''; }
  };
}

/** 读取 CA 与钱包（数量校验交给四个交易参数） */
function fourTradeTarget() {
  const token = $('#fourTradeToken').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(token)) throw new Error('请输入有效的代币地址（0x + 40 位 hex）');
  const walletId = $('#fourTradeWallet').value;
  if (!walletId) throw new Error('请先选择一个钱包');
  return { token, walletId };
}

function fourTradeParams() {
  const t = fourTradeTarget();
  const amount = $('#fourTradeAmount').value.trim();
  if (!amount) throw new Error('请填写数量');
  return {
    ...t,
    side: $('#fourTradeSide').value === 'sell' ? 'sell' : 'buy',
    mode: $('#fourTradeMode').value === 'quote' ? 'quote' : 'amount',
    amount,
    slippageBps: Number($('#fourTradeSlip').value),
  };
}

const fmt18 = (v, digits = 4) => {
  const n = Number(v) / 1e18;
  if (!Number.isFinite(n)) return '—';
  return n.toLocaleString(undefined, { maximumFractionDigits: digits });
};

function renderFourTradeState(r) {
  const box = $('#fourTradeState');
  if (!box) return;
  box.hidden = false;
  const tick = (c) => (c.ok === true ? '✅' : c.ok === false ? '❌' : '❔');
  const tax = (b) => (b == null ? '—' : `${(Number(b) / 100).toFixed(2)}%`);
  box.innerHTML = h`
    <div class="row"><span class="muted">代币</span><span class="mono">${r.symbol || ''} ${caHtml(r.token)}</span></div>
    <div class="row"><span class="muted">类型 / 阶段</span><span>${r.agentMode ? 'Agent ID 专属' : '普通内盘'} · ${r.phaseName}</span></div>
    <div class="row"><span class="muted">计价币</span><span>${r.native ? 'BNB（WBNB）' : (r.quoteKey ? r.quoteKey.toUpperCase() : caHtml(r.quoteAsset))}</span></div>
    <div class="row"><span class="muted">1% 持仓上限</span><span class="mono">${fmt18(r.holdCap, 0)} 枚（已持 ${fmt18(r.balance, 0)} · 剩余 ${fmt18(r.room, 0)}）</span></div>
    <div class="row"><span class="muted">税率</span><span>买 ${tax(r.buyTaxBps)} · 卖 ${tax(r.sellTaxBps)}</span></div>
    ${(r.checks || []).map((c) => h`<div class="row"><span>${tick(c)}</span><span>${c.label}</span></div>`)}`;
}

function renderFourTradeSteps(data) {
  const box = $('#fourTradeSteps');
  if (!box) return;
  box.innerHTML = h`${(data.steps || []).map((st, i) => h`
    <div class="step">
      <div class="step-head">
        <span class="step-label">${st.kind === 'approve' ? '授权' : st.kind === 'sell' ? '卖出' : '买入'} · ${data.plan.symbol}</span>
        <span class="pill ${st.ok ? 'pill-green' : 'pill-red'}">${st.ok ? '模拟通过' : '模拟失败'}</span>
      </div>
      <div class="muted">${st.label}</div>
      ${st.error ? h`<p class="err">模拟失败：${st.error}</p>` : ''}
      ${st.preview?.requestId ? h`<div class="row"><span class="muted">requestId</span><span class="mono">${st.preview.requestId}</span></div>` : ''}
      <div class="actions">
        <button class="danger" data-step="${i}" ${st.ok ? '' : 'disabled'}>确认并执行</button>
      </div>
    </div>`)}`;
  $$('#fourTradeSteps button[data-step]').forEach((b) => { b.onclick = () => fourTradeExec(Number(b.dataset.step)); });
}

async function fourInspect() {
  const btn = $('#btnFourInspect');
  let t;
  try { t = fourTradeTarget(); } catch (err) { return toast(err.message, true); }
  setBusy(btn, true);
  try {
    renderFourTradeState(await api('/api/four/inspect', 'POST', t));
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function fourTradePlan() {
  const btn = $('#btnFourPlan');
  let p;
  try { p = fourTradeParams(); } catch (err) { return toast(err.message, true); }
  setBusy(btn, true);
  $('#fourTradeSteps').innerHTML = '';
  $('#fourTradeOut').hidden = true;
  try {
    const path = p.side === 'sell' ? '/api/four/sell' : '/api/four/buy';
    const r = await api(path, 'POST', {
      token: p.token, walletId: p.walletId, mode: p.mode, amount: p.amount, slippageBps: p.slippageBps,
    });
    state.fourTrade = { walletId: p.walletId, data: r };
    state.fourTradeState = await api('/api/four/inspect', 'POST', { token: p.token, walletId: p.walletId }).catch(() => null);
    if (state.fourTradeState) renderFourTradeState(state.fourTradeState);
    const out = $('#fourTradeOut');
    out.hidden = false;
    out.innerHTML = h`
      <div class="row"><span class="muted">计划</span><span>${r.plan.summary.text}</span></div>
      <div class="row"><span class="muted">钱包</span><span class="mono">${p.walletId} · ${caHtml(r.from)}</span></div>
      ${r.plan.note ? h`<p class="warn">${r.plan.note}</p>` : ''}`;
    renderFourTradeSteps(r);
  } catch (err) {
    toast(err.message, true);
    // 失败时也把「卡在哪一项」显示出来（白名单 / Agent ID / 额度 / 阶段）
    try {
      state.fourTradeState = await api('/api/four/inspect', 'POST', { token: p.token, walletId: p.walletId });
      renderFourTradeState(state.fourTradeState);
    } catch { /* 读状态失败就只弹错误 */ }
  } finally {
    setBusy(btn, false);
  }
}

async function fourTradeExec(idx) {
  const t = state.fourTrade;
  const st = t?.data?.steps?.[idx];
  if (!st?.preview?.requestId) return;
  const plan = t.data.plan;
  const action = st.kind === 'approve' ? '授权给 Core' : st.kind === 'sell' ? '内盘卖出' : '内盘买入';
  const lockNote = state.fourTradeState?.agentMode ? '内盘代币在毕业(迁移)前无法转出，只能经 Core 卖回。' : '';
  const ok = await confirmDialog('确认广播', [
    ['钱包', t.walletId],
    ['代币', h`${plan.symbol} ${caHtml(plan.token)}`],
    ['动作', action],
    ['计划', plan.summary.text],
    ['requestId', st.preview.requestId],
  ], st.kind === 'approve'
    ? '这是一笔真实授权交易（花 gas）。授权完成后需要重新点「生成计划并预览」。'
    : `确认后立即广播，链上不可撤销。${lockNote}`);
  if (!ok) return;
  const btn = $$('#fourTradeSteps button[data-step]')[idx];
  setBusy(btn, true);
  try {
    const { result } = await api(`/api/w/${t.walletId}/execute`, 'POST', { requestId: st.preview.requestId, confirm: 'EXECUTE' });
    toastTx(st.kind === 'approve' ? '授权已提交' : st.kind === 'sell' ? '卖出已提交' : '买入已提交', '56', result.txHash);
    btn.disabled = true;
    scheduleRefresh();
    // 卖出后几秒再刷新持仓（等交易上链）
    if (st.kind === 'sell' && state.fourHoldings?.walletId === t.walletId) setTimeout(() => loadFourHoldings(), 4000);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- Four 持仓：读取所选钱包持有的 OpenFour 代币，一键填入卖出 ---------- */

async function loadFourHoldings() {
  const btn = $('#btnFourHoldings');
  const box = $('#fourHoldings');
  const walletId = $('#fourTradeWallet').value;
  if (!walletId) return toast('请先选择一个钱包', true);
  const ca = $('#fourTradeToken').value.trim();
  setBusy(btn, true);
  box.hidden = false;
  box.innerHTML = '<p class="muted">读取中…（逐个链上核实，代币多时需要几秒）</p>';
  try {
    const r = await api('/api/four/holdings', 'POST', {
      walletId, refresh: true, extra: /^0x[0-9a-fA-F]{40}$/.test(ca) ? [ca] : [],
    });
    state.fourHoldings = r;
    renderFourHoldings(r);
  } catch (err) {
    box.innerHTML = h`<p class="err">${err.message}</p>`;
  } finally {
    setBusy(btn, false);
  }
}

function renderFourHoldings(r) {
  const box = $('#fourHoldings');
  const list = r.holdings || [];
  const warn = r.balanceError ? h`<p class="warn">钱包余额读取失败（${r.balanceError}），仅显示狙击记录 / 当前 CA 中的持仓</p>` : '';
  if (!list.length) {
    box.innerHTML = h`${warn}<p class="muted">该钱包（${caHtml(r.from)}）没有持有 Four 内盘代币。刚买入的币若未出现，把 CA 填进上方输入框再读一次。</p>`;
    return;
  }
  box.innerHTML = h`${warn}
    <table class="table">
      <thead><tr><th>代币</th><th class="right">持有</th><th>阶段</th><th class="right">全卖预计到手</th><th class="right">操作</th></tr></thead>
      <tbody>${list.map((t, i) => h`
        <tr>
          <td><div>${t.symbol || '?'}</div><div class="muted mono">${caHtml(t.token)}</div></td>
          <td class="right mono">${fmt18(t.balance, 2)}</td>
          <td><span class="pill ${t.sellable ? 'pill-green' : 'pill-muted'}">${t.paused ? '已暂停' : t.phaseName}</span></td>
          <td class="right mono">${t.receiveText != null ? `${t.receiveText} ${t.unit}` : '—'}${t.usdValue != null ? h`<div class="muted">≈ $${Number(t.usdValue).toFixed(2)}</div>` : ''}</td>
          <td class="right"><div class="hold-actions">
            <button class="danger" data-hold="${i}" data-pct="100" ${t.sellable ? '' : 'disabled'}>卖出全部</button>
            <button class="ghost" data-hold="${i}" data-pct="50" ${t.sellable ? '' : 'disabled'}>卖 50%</button>
            <button class="ghost" data-hold="${i}" data-pct="0">填入</button>
          </div></td>
        </tr>`)}</tbody>
    </table>
    <p class="hint">点「卖出」只会生成计划并预览，真正广播前仍需在下方「确认并执行」。非 Trading 阶段（已毕业/暂停）不能经 Core 卖出。</p>`;
  $$('#fourHoldings button[data-hold]').forEach((b) => {
    b.onclick = () => pickFourHolding(Number(b.dataset.hold), Number(b.dataset.pct));
  });
}

/** 把持仓填进手动交易表单；pct>0 时按比例算卖出数量（BigInt 精确）并直接生成卖出计划 */
function pickFourHolding(idx, pct) {
  const t = state.fourHoldings?.holdings?.[idx];
  if (!t) return;
  $('#fourTradeToken').value = t.token;
  $('#fourTradeSide').value = 'sell';
  $('#fourTradeSide').onchange();
  if (pct > 0) {
    const wei = (BigInt(t.balance) * BigInt(pct)) / 100n;
    $('#fourTradeAmount').value = weiToHuman(wei.toString(), 18);
  }
  for (const id of ['fourTradeToken', 'fourTradeSide', 'fourTradeAmount']) saveField(id);
  if (pct > 0) fourTradePlan();
  else fourInspect();
}

async function saveAi() {
  const btn = $('#btnAiSave');
  setBusy(btn, true);
  try {
    await api('/api/settings', 'POST', {
      aiBaseUrl: $('#setAiBase').value.trim(),
      aiModel: $('#setAiModel').value.trim(),
      aiKey: $('#setAiKey').value.trim(),
    });
    $('#setAiKey').value = '';
    await loadSettings();
    toast('AI 设置已保存');
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function clearAiKey() {
  await api('/api/settings', 'POST', { clearAiKey: true });
  await loadSettings();
  toast('已清除 API Key');
}

/* ---------- history ---------- */

async function loadHistory() {
  const tbody = $('#historyTable').querySelector('tbody');
  tbody.innerHTML = '<tr><td colspan="4" class="muted">加载中…</td></tr>';
  try {
    const data = await api(`/api/w/${state.active}/history?size=20`);
    const rows = data.transactions || [];
    tbody.innerHTML = rows.length
      ? h`${rows.map((t) => h`
        <tr>
          <td class="mono">${String(t.txTime || '').replace('T', ' ').slice(0, 19)}</td>
          <td>${t.txType}</td>
          <td>${t.status}</td>
          <td>${txLinkHtml(t.binanceChainId || t.chainId || '56', t.txHash)}</td>
        </tr>`)}`
      : '<tr><td colspan="4" class="muted">暂无记录</td></tr>';
  } catch (err) {
    tbody.innerHTML = h`<tr><td colspan="4" class="muted">${err.message}</td></tr>`;
  }
}

/* ---------- 快捷交易（多平台）：识别平台 → 计划 + preview → 确认一次 → execute ---------- */

const QUICK_WALLET_KEY = 'walletui:quickWallet';
const QUICK_DEFAULT_PRESETS = '0.01,0.05,0.1';
const QUICK_RECEIPT_WAIT_MS = 90000;
const QUICK_RECEIPT_POLL_MS = 1500;

function fillQuickWallets() {
  const sel = $('#quickWallet');
  if (!sel) return;
  // 操作钱包是全局的：优先当前值，其次顶部选中的钱包，再次上次记住的
  let prev = sel.value || state.active;
  if (!prev) { try { prev = localStorage.getItem(QUICK_WALLET_KEY) || ''; } catch { prev = ''; } }
  sel.innerHTML = h`${(state.wallets || []).map((w) => h`<option value="${w.id}">${w.name}</option>`)}`;
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
  sel.onchange = () => {
    try { localStorage.setItem(QUICK_WALLET_KEY, sel.value); } catch { /* ignore */ }
    clearQuickPlan(); // 计划属于上一个钱包：清掉，避免用 A 的 preview 去执行 B
    fillQuickBuyWallets();
    // 「操作钱包」是全局的：顶部钱包标签、持仓页的查看钱包跟着变
    if ($('#gmgnWallet') && [...$('#gmgnWallet').options].some((o) => o.value === sel.value)) $('#gmgnWallet').value = sel.value;
    if (state.active !== sel.value && state.wallets?.some((w) => w.id === sel.value)) selectWallet(sel.value);
    if (state.view === 'quick') loadDeskHoldings();
    loadAutomation();
  };
  fillQuickBuyWallets();
}

/* ---------- 多钱包同时买入：主钱包（上面的下拉框）固定参与，另外勾选的钱包一起买 ---------- */
const QUICK_BUY_WALLETS_KEY = 'walletui:quickBuyWallets'; // 额外勾选的钱包 id 数组（不含主钱包）

function readQuickBuyExtras() {
  try { const a = JSON.parse(localStorage.getItem(QUICK_BUY_WALLETS_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch { return []; }
}

function fillQuickBuyWallets() {
  const box = $('#quickBuyWallets');
  if (!box) return;
  const main = $('#quickWallet').value;
  const extra = new Set(readQuickBuyExtras());
  // 主钱包（顶部「钱包」）固定参与、排第一；其它钱包勾选后一起买
  const list = [...(state.wallets || [])].sort((a, b) => (b.id === main) - (a.id === main));
  box.innerHTML = h`${list.map((w) => h`
    <label title="${w.id === main ? '主钱包（顶部「钱包」），固定参与' : '勾选后一起买'}"><input type="checkbox" value="${w.id}" ${w.id === main || extra.has(w.id) ? h`checked` : ''} ${w.id === main ? h`disabled` : ''} /> ${w.name}</label>`)}`;
  $$('#quickBuyWallets input[type=checkbox]').forEach((c) => {
    c.onchange = () => {
      const ids = $$('#quickBuyWallets input[type=checkbox]:checked').map((x) => x.value).filter((id) => id !== $('#quickWallet').value);
      try { localStorage.setItem(QUICK_BUY_WALLETS_KEY, JSON.stringify(ids)); } catch { /* ignore */ }
      clearQuickPlan();
    };
  });
}

/** 这次买入用哪些钱包：主钱包排第一，再加勾选的其它钱包 */
function quickBuyWalletIds() {
  const main = $('#quickWallet').value;
  const known = new Set((state.wallets || []).map((w) => w.id));
  const extra = $$('#quickBuyWallets input[type=checkbox]:checked').map((c) => c.value).filter((id) => id !== main && known.has(id));
  return main ? [main, ...extra] : extra;
}

async function loadQuick() {
  fillQuickWallets();
  renderQuickPresets();
  if (FULL) {
    loadV3Status();
    loadFairStatus().then(() => { if (state.fair?.enabled) fairList(); });
    loadFairAuto();
    loadSnipe();
  }
  markQuickActive();
  renderQuickRecent();
  // 刷新后 CA 框里还留着上次的地址：重新识别一次，识别行不留空
  if (quickActiveCa() && !state.quickDetect) { renderQuickDetectLine({ pending: true }); state.quickWarmed = null; scheduleQuickWarm(); }
  loadQuickUnfinished();
  loadLimits();
  loadArm();
  loadWalletLock();
  if ($('#quickBuysBox')?.open) loadBuyRecords();
  try { $('#quickOneClick').checked = localStorage.getItem(QUICK_ONECLICK_KEY) === '1'; } catch { /* ignore */ }
}

/* ---------- 直接买入（预授权 arm）：有效期内点金额直接买，不弹确认框 ---------- */
async function loadArm() {
  const walletId = $('#quickWallet')?.value;
  if (!walletId) return;
  try {
    const s = await api(`/api/quick/arm?walletId=${encodeURIComponent(walletId)}`);
    state.quickArm = s.armed ? s : null;
    // 其它钱包（多钱包买入时开启过）也要看得见、解得掉
    const others = (state.wallets || []).filter((w) => w.id !== walletId);
    const os = await Promise.all(others.map((w) => api(`/api/quick/arm?walletId=${encodeURIComponent(w.id)}`).catch(() => ({ armed: false }))));
    state.quickArmOthers = others.filter((_, i) => os[i].armed).map((w) => w.id);
    const otherText = state.quickArmOthers.length ? ` ｜ 另外已开启：${state.quickArmOthers.map((id) => walletNameOf(id)).join('、')}` : '';
    $('#armStatus').textContent = (s.armed
      ? `${walletNameOf(walletId)}：已开启 · 单笔 ≤ ${s.maxBuyBnb} BNB · 每日 ≤ ${s.dailyBnb} BNB · 滑点 ≤ ${s.maxSlippageBps / 100}% · ${whenText(s.expiresAt)} 到期`
      : `${walletNameOf(walletId)}：${s.expired ? '已到期（需重新开启）' : '未开启'}`) + otherText;
    const any = Boolean(s.armed) || state.quickArmOthers.length > 0;
    if ($('#quickOneClickState')) $('#quickOneClickState').textContent = s.armed ? `（已开启 · 到 ${until(s.expiresAt)}）` : (s.expired ? '（已到期）' : '');
    $('#armBox').classList.toggle('pre-err', any);
    $('#btnDisarm').disabled = !any;
  } catch {
    state.quickArm = null;
    $('#armStatus').textContent = '后端是旧版本：重启 webui 后可用';
  }
}

/** 开启直接买入（预授权）。ids 不传时用主钱包；多钱包买入时一次确认、逐个开启。全部开启成功返回 true */
async function armQuick(ids) {
  const walletIds = Array.isArray(ids) ? ids : [$('#quickWallet').value].filter(Boolean); // 按钮 onclick 会传事件对象
  if (!walletIds.length) { toast('请先选择钱包', true); return false; }
  let ls;
  try { ls = await Promise.all(walletIds.map((id) => api(`/api/limits?walletId=${encodeURIComponent(id)}`))); } catch (err) { toast(err.message, true); return false; }
  const l = ls[0];
  if (!(Number(l.maxBuyBnb) > 0) || !(Number(l.dailyBnb) > 0)) {
    $('.quick-limits').open = true;
    toast('请先在「买入上限」里设好单笔上限和每日上限（都要大于 0），再开启直接买入', true);
    return false;
  }
  let slip;
  try { slip = quickSlipBps(); } catch (err) { toast(err.message, true); return false; }
  const hours = Number($('#quickArmHours')?.value.trim() || '4');
  if (!(hours >= 0.1 && hours <= 24)) { toast('直接买入的有效期需要在 0.1 ~ 24 小时之间（资金与授权 → 直接买入）', true); return false; }
  const hoursText = `${hours} 小时`;
  const multi = walletIds.length > 1;
  const ok = await confirmDialog('开启直接买入（预授权）', [
    [multi ? `钱包（${walletIds.length} 个）` : '钱包', walletIds.map((id) => walletNameOf(id)).join('、')],
    ['单笔上限', `${l.maxBuyBnb} BNB${multi ? ' / 每个钱包' : ''}`],
    ['每日上限', `${l.dailyBnb} BNB / 每个钱包（今天已花 ${walletIds.map((id, i) => `${walletNameOf(id)} ${ls[i].spentToday}`).join('、')} BNB）`],
    ['最大滑点', `${slip / 100}%`],
    ['有效期', `${hoursText}（到 ${new Date(Date.now() + hours * 3600e3).toLocaleString('zh-CN', { hour12: false })}；修改上限时失效；服务重启后按原到期时间自动恢复（设置里可关闭））`],
  ], `确认后会立即买入当前这一单${multi ? '（每个钱包各买一笔）' : ''}；之后 ${hoursText}内点买入金额直接下单，不再弹确认框。每笔仍经币安预览模拟与上限复核；被币安风控挂起的交易仍需你在 App 确认。`);
  if (!ok) return false;
  const done = [];
  let failed = null;
  for (const walletId of walletIds) {
    try {
      await api('/api/quick/arm', 'POST', { walletId, maxSlippageBps: slip, hours, confirm: 'ARM' });
      done.push(walletId);
    } catch (err) {
      failed = `${walletNameOf(walletId)}：${err.message}`;
      break;
    }
  }
  if (failed) {
    // 部分失败：已开启的全部撤回，不留下「看不见的预授权」
    await Promise.all(done.map((walletId) => api('/api/quick/disarm', 'POST', { walletId }).catch(() => {})));
    toast(`没有开启直接买入（已撤回其它钱包）：${failed}`, true);
  } else {
    toast(`已开启直接买入（${hoursText}内免确认${multi ? `，${walletIds.length} 个钱包` : ''}）`);
  }
  await loadArm();
  return !failed;
}

async function loadResumeSetting() {
  try {
    const r = await api('/api/automation/resume');
    $('#resumeArms').checked = r.enabled;
    $('#resumeArmsState').textContent = r.saved.length ? `（当前已保存 ${r.saved.length} 项：${r.saved.join('、')}）` : '（当前没有需要恢复的预授权）';
  } catch { $('#resumeArmsState').textContent = '（后端是旧版本：重启 webui 后可用）'; }
}

async function loadAutoApprove() {
  if (!$('#autoApprove')) return;
  try {
    const r = await api('/api/quick/autoapprove');
    $('#autoApprove').checked = r.enabled;
    const last = r.events?.[0];
    $('#autoApproveState').textContent = last ? `（最近：${new Date(last.at).toLocaleTimeString('zh-CN', { hour12: false })} ${last.text}）` : '';
  } catch { $('#autoApproveState').textContent = '（后端是旧版本：重启 webui 后可用）'; }
}

/** 「买入后自动授权」开关（docs/AUTOMATION_RULES.md 规则 3 第九个例外）：打开前确认一次规则，关闭直接生效 */
async function toggleAutoApprove(e) {
  const want = e.target.checked;
  if (want) {
    const ok = await confirmDialog('开启买入后自动授权', [
      ['适用', '交易台 / 插件的一键买入、直接买入，以及狙击走普通流程的买入（上链完成之后）'],
      ['做什么', '自动发一笔 approve：把刚买到的代币授权给该平台卖出用的合约'],
      ['授权对象', 'Four Core / gang LaunchpadV2 / 已启用的 LaunchpadV3 / Flap Portal / Pancake SmartRouter（按当前阶段，只能是这几个）'],
      ['额度', '钱包当前持有数量（不是无上限）；已经够了就不发'],
      ['费用', '每笔约 0.00003 BNB gas，不占买入上限'],
      ['不执行', '币安模拟不过、或预判要 App 确认（挂起会锁住钱包所有交易）'],
    ], '开启后不再逐笔确认这类授权。授权对象被攻击或恶意升级时，最多损失这份授权额度（= 当时持有的这个币）。随时可以关闭。');
    if (!ok) { e.target.checked = false; return; }
  }
  try {
    await api('/api/quick/autoapprove', 'POST', { enabled: want, ...(want ? { confirm: 'AUTO_APPROVE' } : {}) });
    toast(want ? '已开启：买入完成后自动授权给卖出合约' : '已关闭买入后自动授权');
  } catch (err) { e.target.checked = !want; toast(err.message, true); }
  loadAutoApprove();
}

/** 解除：所有已开启直接买入的钱包一起解除（多钱包买入时可能开过不止主钱包） */
async function disarmQuick() {
  const ids = [...new Set([$('#quickWallet').value, ...(state.quickArmOthers || [])].filter(Boolean))];
  const r = await Promise.allSettled(ids.map((walletId) => api('/api/quick/disarm', 'POST', { walletId })));
  const bad = r.filter((x) => x.status === 'rejected');
  if (bad.length) toast(bad[0].reason.message, true); else toast(ids.length > 1 ? `已解除直接买入（${ids.length} 个钱包）` : '已解除直接买入');
  loadArm();
}

/** 预授权有效时：点金额直接买（服务端校验策略 → 计划 → 预览 → 一键执行） */
async function quickAutoBuy() {
  let t;
  try { t = quickTarget(); } catch (err) { return toast(err.message, true); }
  const amount = $('#quickBuyAmount').value.trim();
  if (!amount) return toast('请填写或点选买入数量', true);
  const btn = $('#btnQuickBuy');
  setBusy(btn, true, '买入中…');
  $('#quickPlan').innerHTML = '<p class="muted">直接买入中…（报价、币安预览、自动执行）</p>';
  const clickedAt = Date.now();
  try {
    const r = await api('/api/quick/autobuy', 'POST', { ...t, amount });
    if (!r.job?.id) throw new Error('后端没有返回买入任务（可能是旧版本服务）：请到交易历史核对是否已成交，并重启 webui');
    state.quick = { req: { ...t, side: 'buy', amount }, data: r, done: new Set((r.steps || []).map((_, i) => i)), hashes: {}, clickedAt };
    renderQuickPlan();
    await followQuickJob(r.job, state.quick);
  } catch (err) {
    $('#quickPlan').innerHTML = h`<p class="err">${err.message}</p>`;
    toast(err.message, true);
    pushQuickRecent({ ok: false, text: `${walletNameOf(t.walletId)} 买入 ${short(t.address)} · ${amount} · ${err.message}` });
    loadArm(); // 可能已到期
  } finally {
    setBusy(btn, false);
    loadLimits();
  }
}

/**
 * 买入按钮 / 预设金额：
 * - 已开启直接买入（预授权有效）→ 直接下单，不弹窗；
 * - 勾了「直接买入」但还没开启 / 已到期 → 弹一次「开启直接买入」的策略确认，确认后这一单立即下单，之后有效期内不再弹窗；
 * - 没勾 → 生成计划，逐步手动确认。
 */
async function quickBuyClick() {
  const ids = quickBuyWalletIds();
  if (ids.length > 1) return quickMultiBuy(ids);
  state.quickMulti = null; // 停止渲染上一次的多钱包进度
  const armedNow = () => state.quickArm && Date.now() < new Date(state.quickArm.expiresAt).getTime();
  if (armedNow()) return quickAutoBuy();
  if ($('#quickOneClick').checked) {
    await loadArm(); // 以服务端状态为准（可能在别的标签页开启过）
    if (!armedNow()) await armQuick();
    if (armedNow()) return quickAutoBuy();
    return; // 用户取消了开启，或缺少上限：不下单
  }
  return quickPlan('buy');
}

/**
 * 多钱包同时买入：每个钱包各自报价 + 币安预览，并行执行，互不影响（一个失败不影响其它）。
 * - 勾了「直接买入」：每个钱包都要已预授权（没开启的一次确认开启），然后并行直接下单；
 * - 没勾：先并行生成每个钱包的计划，确认一次（列出每个钱包的金额和上限），再并行一键执行。
 * 同一时刻多个钱包买同一个币，后成交的价格会更高，由滑点兜底（最少收到不达标就失败，不会多花）。
 */
async function quickMultiBuy(ids) {
  let t;
  try { t = quickTarget(); } catch (err) { return toast(err.message, true); }
  const amount = $('#quickBuyAmount').value.trim();
  if (!amount) return toast('请填写或点选买入数量', true);
  const btn = $('#btnQuickBuy');
  const box = $('#quickPlan');
  state.quick = null; // 多钱包不走单钱包的逐步按钮
  const m = { rows: ids.map((walletId) => ({ walletId })), clickedAt: Date.now() };
  state.quickMulti = m;
  setBusy(btn, true, '买入中…');
  try {
    if ($('#quickOneClick').checked) {
      const arms = await Promise.all(ids.map((id) => api(`/api/quick/arm?walletId=${encodeURIComponent(id)}`).catch(() => ({ armed: false }))));
      const missing = ids.filter((_, i) => !arms[i].armed);
      if (missing.length && !(await armQuick(missing))) return;
      m.clickedAt = Date.now();
      box.innerHTML = h`<p class="muted">多钱包直接买入中…（${ids.length} 个钱包并行：报价、币安预览、自动执行）</p>`;
      await Promise.all(m.rows.map((row) => api('/api/quick/autobuy', 'POST', { ...t, walletId: row.walletId, amount })
        .then((r) => { row.data = r; row.job = r.job; }, (err) => { row.error = err.message; })));
    } else {
      box.innerHTML = h`<p class="muted">多钱包报价中…（${ids.length} 个钱包并行：识别平台、选路、币安预览）</p>`;
      await Promise.all(m.rows.map((row) => api('/api/quick/plan', 'POST', { ...t, walletId: row.walletId, side: 'buy', amount })
        .then((r) => { row.data = r; if (!r.oneClick) row.error = r.oneClickBlocked || r.steps?.[0]?.error || '第一步预览未通过'; }, (err) => { row.error = err.message; })));
      renderQuickMulti(m);
      const ready = m.rows.filter((r) => r.data?.oneClick);
      if (!ready.length) throw new Error('所有钱包都没能生成可执行的计划（看下方每个钱包的原因）');
      const rows = [];
      const p0 = ready[0].data.plan;
      rows.push(['平台 / 代币', h`${p0.platformLabel} · ${p0.symbol} ${caHtml(p0.token)}`]);
      for (const r of m.rows) {
        const name = walletNameOf(r.walletId);
        if (!r.data?.oneClick) { rows.push([name, `不买：${r.error}`]); continue; }
        const p = r.data.plan;
        const oc = r.data.oneClick;
        // 与单钱包一键买入（quickOneClick）同样的明细：每一步、BNB 合计上限、授权对象与额度、最少收到
        rows.push([name, h`${caHtml(r.data.from)} · 扣取 ${p.pay.text} · 预计 ${p.receive.expected} ${p.receive.symbol} · 最少收到 ${p.receive.min} ${p.receive.symbol} · 路由 ${p.route}`]);
        r.data.steps.forEach((s, i) => rows.push([`${name} · 第 ${i + 1} 步`, `${quickKindLabel(s.kind)} · ${s.label}`]));
        rows.push([`${name} · 上限 · BNB 合计`, `${weiToHuman(oc.bounds.maxValueWei)} BNB`]);
        for (const ap of oc.bounds.approvals) rows.push([`${name} · 上限 · 授权`, approvalBoundHtml(ap, r.data.steps)]);
      }
      rows.push(['上限 · 价格', '每步重新报价后「最少收到」不得低于本次确认值，否则该钱包自动停止']);
      rows.push(['滑点', `${Number(t.slippageBps) / 100}%（各钱包同时买，后成交的价格更高；最少收到不达标就失败，不会多花）`]);
      const ok = await confirmDialog(`确认多钱包一键买入（${ready.length} 个钱包）`, rows,
        '确认后服务端会让以上钱包并行执行各自的全部步骤（每步都经币安预览模拟、单笔 / 每日上限复核），不再逐笔确认；任何一步超出上限或模拟失败，该钱包立即停止，已完成的步骤不会回滚，其它钱包不受影响。计划 2 分钟内有效。');
      if (!ok) { renderQuickMulti(m); return; }
      m.clickedAt = Date.now();
      await Promise.all(ready.map((row) => api('/api/quick/oneclick', 'POST', { walletId: row.walletId, bundleId: row.data.oneClick.bundleId, confirm: 'ONECLICK' })
        .then((job) => { row.job = job; }, (err) => { row.error = err.message; })));
    }
    await followMultiJobs(m);
  } catch (err) {
    renderQuickMulti(m);
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
    loadLimits();
    loadArm();
  }
}

/** 同时轮询多个钱包的买入任务，直到都结束（以 Date.now() 截止） */
async function followMultiJobs(m) {
  const started = Date.now();
  const running = () => m.rows.filter((r) => r.job?.state === 'running');
  while (running().length && Date.now() - started < 200000) {
    renderQuickMulti(m);
    await new Promise((r) => setTimeout(r, 700));
    await Promise.all(running().map((row) => api(`/api/quick/oneclick/${row.job.id}`)
      .then((j) => { row.job = j; if (j.state !== 'running') row.finishedAt = Date.now(); }, () => {})));
  }
  for (const r of m.rows) if (r.job && !r.finishedAt) r.finishedAt = Date.now();
  renderQuickMulti(m);
  if ($('#invBox')?.open) loadInventory();
  refreshGmgnSoon();
  scheduleRefresh();
  const ok = m.rows.filter((r) => r.job?.state === 'done').length;
  const sec = ((Math.max(...m.rows.map((r) => r.finishedAt || Date.now())) - m.clickedAt) / 1000).toFixed(1);
  for (const r of m.rows) {
    const p = r.data?.plan;
    const done = r.job?.state === 'done';
    pushQuickRecent({
      ok: done,
      text: `${walletNameOf(r.walletId)} 买入 ${p?.symbol || ''} · ${p?.pay?.text || ''} · ${sec}s${done ? '' : ` · ${r.job?.error || r.error || '未买入'}`}`,
      tx: [...(r.job?.steps || [])].reverse().find((s) => s.txHash)?.txHash || null,
    });
  }
  toast(`多钱包买入：成功 ${ok}/${m.rows.length}，用时 ${sec} 秒`, ok < m.rows.length);
}

function renderQuickMulti(m) {
  if (state.quickMulti !== m) return;
  const stateText = (r) => {
    if (r.job) return { running: '执行中…', done: '✅ 完成', failed: '⛔ 已停止' }[r.job.state] || r.job.state;
    if (r.error) return '⛔ 未买入';
    return r.data ? '待确认' : '报价中…';
  };
  const sec = (r) => (r.job ? `${(((r.finishedAt || Date.now()) - m.clickedAt) / 1000).toFixed(1)} 秒` : '—');
  const lastTx = (r) => [...(r.job?.steps || [])].reverse().find((s) => s.txHash)?.txHash;
  $('#quickPlan').innerHTML = h`
    <div class="quote-box">
      <div class="row"><span class="muted">多钱包买入</span><span><b>${m.rows.length} 个钱包并行</b></span></div>
      <table class="table"><thead><tr><th>钱包</th><th>扣取</th><th>预计收到</th><th>步骤</th><th>状态</th><th>用时</th><th>交易</th></tr></thead><tbody>
        ${m.rows.map((r) => {
          const p = r.data?.plan;
          const err = r.job?.error || r.error;
          return h`<tr>
            <td>${walletNameOf(r.walletId)}</td>
            <td class="mono">${p ? p.pay.text : '—'}</td>
            <td class="mono">${p ? `${p.receive.expected} ${p.receive.symbol}` : '—'}</td>
            <td>${r.data?.steps ? r.data.steps.map((s) => quickKindLabel(s.kind)).join(' → ') : '—'}</td>
            <td>${stateText(r)}</td>
            <td class="mono">${sec(r)}</td>
            <td>${lastTx(r) ? txLinkHtml('56', lastTx(r)) : '—'}</td>
          </tr>${err ? h`<tr><td colspan="7"><span class="warn-text">${err}</span></td></tr>` : ''}`;
        })}
      </tbody></table>
    </div>`;
}

/** 轮询一键执行任务直到结束（以 Date.now() 截止，不累计 sleep） */
async function followQuickJob(job, q) {
  const started = Date.now();
  while (job.state === 'running' && Date.now() - started < 200000) {
    renderQuickJob(job, q);
    await new Promise((r) => setTimeout(r, 700));
    try { job = await api(`/api/quick/oneclick/${job.id}`); } catch { /* 网络抖动继续轮询 */ }
  }
  q.finishedAt = Date.now();
  if ($('#invBox')?.open) loadInventory(); // 用库存买入后刷新库存 / 授权余量
  refreshGmgnSoon();
  renderQuickJob(job, q);
  scheduleRefresh();
  const last = [...(job.steps || [])].reverse().find((s) => s.txHash);
  const total = q.clickedAt ? `${((q.finishedAt - q.clickedAt) / 1000).toFixed(1)} 秒` : `${(job.totalMs / 1000).toFixed(1)} 秒`;
  const p = q.data?.plan;
  pushQuickRecent({
    ok: job.state === 'done',
    text: `${walletNameOf(q.data?.walletId || q.req?.walletId)} ${q.req?.side === 'sell' ? '卖出' : '买入'} ${p?.symbol || short(q.req?.address || '')} · ${p?.pay?.text || q.req?.amount || ''} · ${total.replace(' 秒', 's')}${job.state === 'done' ? '' : ` · ${job.error || job.state}`}`,
    tx: last?.txHash || null,
  });
  const verb = q.req?.side === 'sell' ? '卖出' : '买入';
  if (job.state === 'done') toastTx(`${verb}完成，用时 ${total}`, '56', last?.txHash);
  else toast(`${verb}已停止（${total}）：${job.error || job.state}`, true);
  // 被风控挂起 / 钱包被锁：马上查一次锁定状态，顶部显示原因（之后自动轮询到解锁）
  const wid = q.data?.walletId || q.req?.walletId;
  if (job.state !== 'done' && (job.needsAppConfirm || /API_351716|等币安 App 确认|风控挂起/.test(String(job.error || '')))) loadWalletLock(wid, { fresh: true });
  if (job.state === 'done') loadBuyRecords();
  return job;
}

/* ---------- 买入上限（服务端强制：单笔 / 每日） ---------- */
async function loadLimits() {
  const walletId = $('#quickWallet')?.value || '';
  try {
    const l = await api(`/api/limits?walletId=${encodeURIComponent(walletId)}`);
    $('#limitMaxBuy').value = l.maxBuyBnb;
    $('#limitDaily').value = l.dailyBnb;
    const fmtCap = (v) => (Number(v) > 0 ? `${v} BNB` : '不限');
    $('#limitsSummary').textContent = `（单笔 ${fmtCap(l.maxBuyBnb)} · 每日 ${fmtCap(l.dailyBnb)}${l.spentToday != null ? ` · 该钱包今天已花 ${l.spentToday} BNB` : ''}）`;
    const cap = (v) => (Number(v) > 0 ? `≤ ${v}` : '不限');
    if ($('#quickCaps')) $('#quickCaps').textContent = `单笔 ${cap(l.maxBuyBnb)} · 每日 ${cap(l.dailyBnb)}`;
  } catch { $('#limitsSummary').textContent = '（后端是旧版本：重启 webui 后可用）'; }
}

async function saveLimits() {
  const btn = $('#btnLimitsSave');
  setBusy(btn, true, '保存中…');
  try {
    await api('/api/limits', 'POST', { maxBuyBnb: $('#limitMaxBuy').value.trim() || '0', dailyBnb: $('#limitDaily').value.trim() || '0' });
    toast('买入上限已保存（直接买入的预授权已随之解除，需要重新开启）');
    await loadLimits();
    await loadArm();
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- 报价币库存 + 常驻授权（备货 / 同步授权 / 撤销都先出计划，确认后一键执行） ---------- */
const INV_PLATFORM_LABEL = { gang: 'gang V2', four: 'Four', gangv3: 'gang V3' };
const INV_PLAT = {
  gang: { name: 'gang V2', sub: 'LaunchpadV2 · 不可升级', cls: 'plat-v2' },
  gangv3: { name: 'gang V3', sub: 'LaunchpadV3 · 未审计', cls: 'plat-v3' },
  four: { name: 'Four', sub: 'Four Core · 可升级', cls: 'plat-four' },
};
const INV_UNLIMITED = 2n ** 255n; // 与服务端 UNLIMITED 一致：额度 ≥ 这个值就算「无上限」

/** 授权状态 → 样式 / 文案 / 提示。颜色 + 符号 + 文字三重表达：未授权 · 已授权（额度 ≥ 库存）· 不足 · 无上限 */
function invAuthState(x) {
  if (!x) return { cls: 'auth-na', text: '—', title: '这个平台不用这个报价币' };
  if (x.error) return { cls: 'auth-low', text: '读取失败', title: x.error };
  let a = 0n;
  let b = 0n;
  try { a = BigInt(x.allowance || '0'); b = BigInt(x.balance || '0'); } catch { /* 当 0 处理 */ }
  if (a >= INV_UNLIMITED) return { cls: 'auth-unl', text: '⚠ 无上限', title: '无上限授权：授权对象可以转走这个代币的全部余额（含以后转入的），不用时撤销' };
  if (a === 0n) return { cls: 'auth-none', text: '○ 未授权', title: '没有授权：用这个报价币买入要多一笔授权' };
  if (b > 0n && a < b) return { cls: 'auth-low', text: `◐ 不足 ${x.allowanceText}`, title: `授权 ${x.allowanceText} 少于库存 ${x.balanceText}：点「同步授权」补齐` };
  return { cls: 'auth-ok', text: `● ${x.allowanceText}`, title: `已授权 ${x.allowanceText}（不少于库存），库存买入可一笔完成` };
}
const platTagHtml = (p) => h`<span class="plat-tag ${INV_PLAT[p]?.cls || ''}">${INV_PLAT[p]?.name || p}</span>`;

/** 当前选中的「报价币 × 平台」那一行（从最近一次读到的库存里找） */
function invSelRow() {
  const s = state.invSel;
  if (!s || !state.inventory) return null;
  return state.inventory.rows.find((x) => x.platform === s.platform && x.token.toLowerCase() === s.token.toLowerCase()) || null;
}

/** 选中格子的操作面板：写清楚「哪个币 → 哪个平台」、库存和授权状态，并按状态启用按钮 */
function renderInvPanel() {
  const x = invSelRow();
  const box = $('#invSel');
  if (!box) return;
  const on = (id, v) => { const el = $(id); if (el) el.disabled = !v; };
  if (!x) {
    box.innerHTML = h`<span class="muted">先点上表里的某个授权格子，选定「报价币 × 平台」，再在这里操作。</span>`;
    ['#btnInvStock', '#btnInvSync', '#btnInvRevoke', '#btnInvRemove'].forEach((id) => on(id, false));
    return;
  }
  const st = invAuthState(x);
  box.innerHTML = h`<span class="inv-sel-main"><b>${x.symbol}</b> <span class="muted mono">${caHtml(x.token)}</span> → ${platTagHtml(x.platform)} <span class="muted">${x.spenderLabel || ''} ${x.spender ? caHtml(x.spender) : ''}</span></span>
    <span>库存 <b class="mono">${x.balanceText ?? '—'}</b> · 当前授权 <span class="auth-badge ${st.cls}">${st.text}</span></span>
    ${x.platform === 'gangv3' ? h`<span class="inv-note">V3 合约未审计：优先用「同步授权」（额度 = 库存），不要无上限授权</span>` : ''}`;
  on('#btnInvStock', !x.error);
  on('#btnInvSync', !x.error && x.balance && x.balance !== '0');
  on('#btnInvRevoke', !x.error && x.allowance && x.allowance !== '0');
  on('#btnInvRemove', !x.auto);
}

/* ---------- 路由记录 / 固定路由（资金与授权页） ---------- */
const ROUTE_PLAT = { dex: '外盘', gang: 'gang V2', gangv3: 'gang V3', inventory: '库存备货', four: 'Four', flap: 'Flap' };
const shortTime = (iso) => (iso ? new Date(iso).toLocaleString('zh-CN', { hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');

async function loadRoutes() {
  const box = $('#routeTable');
  if (!box) return;
  let r;
  try { r = await api('/api/routes'); } catch (err) { box.textContent = err.message; return; }
  const pins = r.pairs.filter((p) => p.pin);
  const sugg = r.pairs.filter((p) => p.suggest);
  $('#routeSummary').textContent = `（${r.pairs.length} 个币对 · 已固定 ${pins.length}${pins.some((p) => p.pin.suspended) ? '（有暂停）' : ''} · 建议固定 ${sugg.length}${r.importedAt ? '' : ' · 未导入历史'}）`;
  if (!r.pairs.length) { box.innerHTML = h`<p class="muted">还没有记录：经 PancakeSwap 兑换成功后会出现在这里，或点「从执行日志导入历史」。</p>`; return; }
  box.innerHTML = r.pairs.map((p) => {
    const name = `${p.inSym || p.tokenIn.slice(0, 8)} → ${p.outSym || p.tokenOut.slice(0, 8)}`;
    const pin = p.pin;
    const pinLine = !pin ? ''
      : pin.suspended
        ? h`<div class="row" style="gap:8px"><span class="auth-badge auth-low">固定已暂停</span><span class="muted">连续 ${pin.fails} 次不通：${pin.lastError || ''}</span>
            <button class="ghost" data-route-act="resume" data-pair="${p.pair}">恢复</button><button class="ghost" data-route-act="unpin" data-pair="${p.pair}">取消固定</button></div>`
        : h`<div class="row" style="gap:8px"><span class="auth-badge auth-ok">📌 已固定</span><span class="muted">${shortTime(pin.pinnedAt)} 起${pin.fails ? ` · 最近不通 ${pin.fails} 次：${pin.lastError}` : ''}</span>
            <button class="ghost" data-route-act="unpin" data-pair="${p.pair}">取消固定</button></div>`;
    const better = pin?.better ? h`<div class="hint">后台复查（${shortTime(pin.better.at)}）：${pin.better.text} 池子报价多约 ${(pin.better.bps / 100).toFixed(2)}%，可以考虑改固定它</div>` : '';
    const rows = p.routes.map((x) => {
      const isPin = pin && pin.pathKey === x.pathKey;
      const plats = Object.entries(x.platforms || {}).map(([k, n]) => `${ROUTE_PLAT[k] || k}×${n}`).join(' ');
      const btn = isPin ? h`<span class="muted">当前固定</span>`
        : x.ok ? h`<button class="ghost" data-route-act="pin" data-pair="${p.pair}" data-path="${x.pathKey}">${pin ? '改固定这条' : '固定'}</button>` : h`<span class="muted">未成功过</span>`;
      return h`<tr>
        <td>${isPin ? '📌 ' : ''}${x.text}${p.suggest === x.pathKey ? h` <span class="auth-badge auth-unl">建议固定</span>` : ''}</td>
        <td class="mono">${x.ok} / ${x.fail}</td><td>${plats || '—'}</td>
        <td>${shortTime(x.lastOkAt)}${x.lastError ? h`<div class="muted" title="${x.lastError}">最近失败 ${shortTime(x.lastFailAt)}</div>` : ''}</td>
        <td>${btn}</td></tr>`;
    });
    return h`<div style="margin:10px 0"><b>${name}</b> <span class="muted mono">${p.routes.length} 条路径</span>${pinLine}${better}
      <table class="table"><thead><tr><th>路径</th><th>成功 / 失败</th><th>平台</th><th>最近成功</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }).join('');
}

async function routeAction(act, pair, pathKey) {
  try {
    await api(`/api/routes/${act}`, 'POST', { pair, pathKey });
    toast({ pin: '已固定：之后这个币对只沿这条路径报价', unpin: '已取消固定，恢复自动搜索', resume: '已恢复固定路由' }[act]);
  } catch (err) { toast(err.message, true); }
  loadRoutes();
}

async function importRoutes() {
  const btn = $('#btnRouteImport');
  btn.disabled = true;
  try {
    const s = await api('/api/routes/import', 'POST', {});
    toast(`导入完成：扫描 ${s.scanned} 笔，导入 ${s.imported}（链上失败 ${s.failed}），跳过 ${s.skipped}`);
  } catch (err) { toast(err.message, true); }
  btn.disabled = false;
  loadRoutes();
}

async function loadInventory() {
  const walletId = $('#quickWallet')?.value || '';
  const box = $('#invTable');
  if (!box || !walletId) return;
  try {
    const r = await api(`/api/inventory?walletId=${encodeURIComponent(walletId)}`);
    state.inventory = r;
    if (document.activeElement !== $('#invCap')) $('#invCap').value = r.capBnb;
    // 同一个报价币合并成一行，各平台的授权状态做成列（报价币 × 平台矩阵）
    const toks = new Map();
    for (const x of r.rows) {
      const k = x.token.toLowerCase();
      if (!toks.has(k)) toks.set(k, { token: x.token, symbol: x.symbol, balanceText: x.balanceText, valueBnb: x.valueBnb, cells: {} });
      const t = toks.get(k);
      if (t.symbol === '?' && x.symbol !== '?') Object.assign(t, { symbol: x.symbol, balanceText: x.balanceText, valueBnb: x.valueBnb });
      t.cells[x.platform] = x;
    }
    const list = [...toks.values()].sort((a, b) => Number(b.valueBnb || 0) - Number(a.valueBnb || 0) || String(a.symbol).localeCompare(String(b.symbol)));
    const total = list.reduce((a, t) => a + Number(t.valueBnb || 0), 0);
    $('#invSummary').textContent = `（${list.length} 种报价币 · 合计约 ${total.toFixed(4)} BNB · 每种上限 ${r.capBnb} BNB）`;
    // 只画有数据的平台列（没登记过 Four 的报价币就不显示 Four 列）；V3 是否启用看 spenders，不看有没有行
    const v3Enabled = (r.spenders || []).some((s) => s.platform === 'gangv3');
    const cols = (r.spenders || []).map((s) => s.platform).filter((p) => INV_PLAT[p] && r.rows.some((x) => x.platform === p));
    const big = (v) => { try { return BigInt(v || '0'); } catch { return 0n; } };
    const overview = cols.map((p) => {
      const rows = r.rows.filter((x) => x.platform === p && !x.error);
      // 就绪 = 有库存且授权额度不少于库存（与格子徽标 invAuthState 的「已授权 / 无上限」一致，不与「待授权」重叠）
      const ready = rows.filter((x) => big(x.balance) > 0n && big(x.allowance) >= big(x.balance));
      const need = rows.filter((x) => big(x.balance) > 0n && big(x.allowance) < big(x.balance));
      const unl = rows.filter((x) => big(x.allowance) >= INV_UNLIMITED);
      const names = (a) => a.map((x) => x.symbol).join('、');
      return h`<div class="inv-chip ${INV_PLAT[p].cls}">
        <div class="inv-chip-head">${INV_PLAT[p].name}<span class="muted"> · ${INV_PLAT[p].sub}</span></div>
        <div>${ready.length ? h`<span class="auth-badge auth-ok">就绪 ${ready.length}</span> ${names(ready)}` : h`<span class="auth-badge auth-none">就绪 0</span> <span class="muted">没有「有库存且已授权」的报价币</span>`}</div>
        ${need.length ? h`<div><span class="auth-badge auth-low">待授权 ${need.length}</span> ${names(need)}</div>` : ''}
        ${unl.length ? h`<div><span class="auth-badge auth-unl">无上限 ${unl.length}</span> ${names(unl)}</div>` : ''}
      </div>`;
    });
    const cellList = [];
    const sel = state.invSel;
    box.innerHTML = h`<div class="inv-overview">${overview}</div>
      ${v3Enabled ? '' : h`<p class="warn">gang V3 没有启用（或部署复核没通过），表里不显示 V3 的授权：先在「发射台」启用。</p>`}
      ${v3Enabled && !cols.includes('gangv3') ? h`<p class="muted">gang V3 已启用，但还没有 V3 币用过非 WBNB 报价币（WBNB 底池直接付 BNB，不需要授权）。</p>` : ''}
      <table class="table inv-matrix"><thead><tr><th>报价币</th><th class="right">库存</th><th class="right">折合 BNB</th>
        ${cols.map((p) => h`<th class="inv-colhead ${INV_PLAT[p].cls}">${INV_PLAT[p].name}<small>${INV_PLAT[p].sub}</small></th>`)}
      </tr></thead><tbody>
      ${list.map((t) => h`<tr>
        <td><b>${t.symbol}</b> <span class="muted mono">${caHtml(t.token)}</span></td>
        <td class="right mono">${t.balanceText ?? '—'}</td>
        <td class="right mono">${t.valueBnb ?? '—'}</td>
        ${cols.map((p) => {
    const x = t.cells[p];
    if (!x) {
      // 这个平台从没用这个币当过报价币：发射台不会从钱包拉它，不需要也不该授权（V3 的 WBNB 底池直接付 BNB）
      const why = p === 'gangv3'
        ? (t.token.toLowerCase() === '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c' ? 'gang V3 的 WBNB 底池直接付 BNB（GangRouter 一笔完成），不需要授权 WBNB' : 'gang V3 还没有币用它当报价币，不需要授权；以后有 V3 币用它，会自动出现在这一列')
        : '这个平台没有用它当报价币，不需要授权';
      return h`<td class="inv-cell"><span class="auth-badge auth-na" title="${why}">不需要</span></td>`;
    }
    const i = cellList.push(x) - 1;
    const st = invAuthState(x);
    const on = sel && sel.platform === x.platform && sel.token.toLowerCase() === x.token.toLowerCase();
    return h`<td class="inv-cell ${on ? 'sel' : ''}"><button type="button" class="auth-badge ${st.cls}" data-inv-sel="${i}" title="${st.title}">${st.text}</button>${x.auto ? h`<span class="inv-auto" title="gang V3 用过的报价币，自动列出，不用手动添加">自动</span>` : ''}</td>`;
  })}
      </tr>`)}
      </tbody></table>`;
    $$('#invTable [data-inv-sel]').forEach((b) => {
      b.onclick = () => {
        const x = cellList[Number(b.dataset.invSel)];
        state.invSel = { platform: x.platform, token: x.token };
        $$('#invTable .inv-cell.sel').forEach((c) => c.classList.remove('sel'));
        b.closest('td').classList.add('sel');
        renderInvPanel();
      };
    });
    renderInvPanel();
  } catch (err) {
    box.innerHTML = h`<p class="err">${/not found/.test(err.message) ? '后端是旧版本：重启 webui 后可用' : err.message}</p>`;
  }
}

async function invAdd() {
  const ca = $('#invCa').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(ca)) return toast('请粘贴有效的代币 CA', true);
  const btn = $('#btnInvAdd');
  setBusy(btn, true, '识别中…');
  try {
    const r = await api('/api/inventory/add', 'POST', { ca });
    const labels = (r.platforms || [r.platform]).map((p) => INV_PLATFORM_LABEL[p] || p).join(' + ');
    toast(`已添加 ${labels} 报价币 ${r.symbol}`);
    await loadInventory();
  } catch (err) { toast(err.message, true); } finally { setBusy(btn, false); }
}

async function invSaveCap() {
  try {
    await api('/api/inventory/cap', 'POST', { capBnb: $('#invCap').value.trim() });
    toast('库存上限已保存');
    await loadInventory();
  } catch (err) { toast(err.message, true); }
}

async function invRemove(row) {
  // 自动列出的 V3 报价币没有登记过，不用也不能移除
  if (row.auto) return toast('这是 gang V3 用过的报价币，自动列出的，不用移除', true);
  // 服务端会检查所有本机钱包：仍有授权时拒绝移除（要先撤销）
  if (row.allowance && row.allowance !== '0') return toast(`当前钱包对 ${row.spenderLabel} 仍有 ${row.allowanceText} 的授权：请先点「撤销授权」，再移除`, true);
  try {
    await api('/api/inventory/remove', 'POST', { platform: row.platform, token: row.token });
    state.invSel = null;
    await loadInventory();
  } catch (err) { toast(err.message, true); }
}

/** 生成计划 → 确认框展示明细 → 一键执行（每步币安预览） */
async function invPlan(row, action, btn) {
  const walletId = $('#quickWallet').value;
  if (!walletId) return toast('请先选择钱包', true);
  const amountBnb = action === 'stock' ? $('#invAmount').value.trim() : '0';
  if (action === 'stock' && !/^\d+(\.\d+)?$/.test(amountBnb)) return toast('请填写备货数量（BNB）', true);
  setBusy(btn, true, '生成中…');
  let r;
  try {
    r = await api('/api/inventory/plan', 'POST', {
      walletId, platform: row.platform, token: row.token, action: action === 'revoke' ? 'revoke' : 'stock',
      amountBnb, slippageBps: Number($('#invSlip').value),
    });
  } catch (err) {
    setBusy(btn, false);
    return toast(err.message, true);
  }
  setBusy(btn, false);
  if (!r.oneClick) return toast(r.steps[0]?.error || '第一步模拟未通过', true);
  const p = r.plan;
  const walletName = (state.wallets || []).find((w) => w.id === walletId)?.name || walletId;
  const title = { stock: '确认备货', sync: '确认同步授权', revoke: '确认撤销授权' }[action];
  const rows = [
    ['链', 'BSC（56）'],
    ['钱包', h`${walletName} · ${caHtml(r.from)}`],
    ['报价币', `${p.symbol} ${p.token}`],
    ['花费', p.pay.text],
    ...(action === 'stock' ? [['备货后库存', `预计 ${p.receive.expected}，最少 ${p.receive.min} ${p.symbol}`], ['路由', p.route], ['滑点', `${Number($('#invSlip').value) / 100}%`]] : []),
    ['授权对象', `${p.approve.spenderLabel} ${p.approve.spender}${p.approve.upgradeable ? '（可升级合约）' : ''}`],
    ['授权额度', `${p.approve.beforeText} → ${p.approve.amountText} ${p.symbol}`],
    ...r.steps.map((s, i) => [`第 ${i + 1} 步`, `${quickKindLabel(s.kind)} · ${s.label}`]),
  ];
  const ok = await confirmDialog(title, rows, action === 'revoke'
    ? '撤销后库存留在钱包，之后用库存买入会先多一笔授权。'
    : '确认后服务端依次执行以上步骤（每步都经币安预览模拟）。授权额度不超过库存量和库存上限；授权对象被攻击或恶意升级时，最多损失这份授权额度。');
  if (!ok) return;
  await invFollowJob(walletId, r.oneClick.bundleId, title);
}

/** 启动库存类一键任务（备货 / 授权 / 撤销 / 批量预授权）并展示进度 */
async function invFollowJob(walletId, bundleId, title) {
  let job;
  try {
    job = await api('/api/quick/oneclick', 'POST', { walletId, bundleId, confirm: 'ONECLICK' });
  } catch (err) { return toast(err.message, true); }
  const box = $('#invJob');
  box.hidden = false;
  const started = Date.now();
  const render = () => {
    const stateText = { running: '执行中…', done: '✅ 完成', failed: '⛔ 已停止' }[job.state] || job.state;
    box.innerHTML = h`<div class="row"><span class="muted">${title.replace('确认', '')}</span><span><b>${stateText}</b> · ${((Date.now() - started) / 1000).toFixed(1)} 秒</span></div>
      ${job.error ? h`<p class="err">${job.error}</p>` : ''}
      ${(job.steps || []).map((s) => h`<div class="row"><span>${s.label || quickKindLabel(s.kind)} · ${stepStatusText(s.status)}</span><span>${s.txHash ? txLinkHtml('56', s.txHash) : '—'}</span></div>`)}`;
  };
  render();
  while (job.state === 'running' && Date.now() - started < 200000) {
    await new Promise((res) => setTimeout(res, 800));
    try { job = await api(`/api/quick/oneclick/${encodeURIComponent(job.id)}`); } catch { /* 短暂失败继续轮询 */ }
    render();
  }
  await loadInventory();
  loadLimits();
}

/* ---------- 批量预授权（无上限）/ 批量撤销：gang V2 / V3 最近在用的报价币 + 库存列表，勾选后确认一次逐笔执行 ---------- */
async function invApproveLoad(mode = 'approve') {
  const revoke = mode === 'revoke';
  const walletId = $('#quickWallet').value;
  if (!walletId) return toast('请先选择钱包', true);
  const box = $('#invApproveBox');
  box.hidden = false;
  box.innerHTML = '<p class="muted">读取中…（第一次要扫最近 3 天的 gang 新币，约 10~30 秒）</p>';
  let r;
  try { r = await api(`/api/inventory/candidates?walletId=${encodeURIComponent(walletId)}`); } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; return; }
  // 撤销只列当前授权额度 > 0 的；预授权列全部
  const rows = revoke ? r.rows.filter((x) => !x.error && x.allowance && x.allowance !== '0') : r.rows;
  if (!rows.length) { box.innerHTML = h`<p class="muted">当前钱包对这些报价币的授权额度都是 0，没有可撤销的。</p>`; return; }
  state.invApprove = { walletId, rows, mode };
  box.innerHTML = h`
    <p class="hint">${revoke
    ? '只列出当前授权额度大于 0 的报价币（V2 和 V3 的授权是分开的），默认全部勾选，不需要的取消勾选。撤销只把额度设回 0，不动钱包里的代币；撤销后用库存买入 / 狙击的极速通道会因缺授权而退回普通流程或「没库存，跳过」，需要时再「同步授权」。'
    : `「次数」= 最近 ${r.scanDays} 天 gang 新币（V2 / V3 分别统计）用它当底池的个数。默认勾选：钱包里有余额的，和用过 ≥ 5 次的。已经是无上限的不能勾。V3 行的授权对象是 LaunchpadV3（未审计），无上限授权风险更大，也可以用库存里的「同步授权」只授权库存量。`}</p>
    <table class="table"><thead><tr><th></th><th>报价币</th><th>平台 / 授权给</th><th class="right">次数</th><th class="right">余额</th><th class="right">当前授权</th></tr></thead><tbody>
      ${rows.map((x, i) => {
        const pre = revoke ? !x.error : !x.unlimited && !x.error && (Number(x.balance || 0) > 0 || (x.uses || 0) >= 5);
        return h`<tr>
          <td><input type="checkbox" data-inv-approve="${i}" ${pre ? h`checked` : ''} ${(!revoke && x.unlimited) || x.error ? h`disabled` : ''} /></td>
          <td class="mono">${x.symbol} ${caHtml(x.token)}</td>
          <td>${platTagHtml(x.platform)} <span class="muted">${x.spenderLabel}</span>${x.upgradeable ? h` <span class="pill pill-amber">可升级</span>` : ''}</td>
          <td class="right mono">${x.uses ?? '—'}</td>
          <td class="right mono">${x.balanceText ?? '—'}</td>
          <td class="right">${h`<span class="auth-badge ${invAuthState(x).cls}" title="${invAuthState(x).title}">${invAuthState(x).text}</span>`}</td>
        </tr>`;
      })}
    </tbody></table>
    <div class="actions"><button class="danger" id="btnInvApproveGo">${revoke ? '撤销所选（额度设为 0）' : '预授权所选（无上限）'}</button></div>`;
  $('#btnInvApproveGo').onclick = invApproveGo;
}

async function invApproveGo() {
  const a = state.invApprove;
  if (!a) return;
  const revoke = a.mode === 'revoke';
  const picked = $$('#invApproveBox [data-inv-approve]:checked').map((c) => a.rows[Number(c.dataset.invApprove)]);
  if (!picked.length) return toast('请至少勾选一个报价币', true);
  const btn = $('#btnInvApproveGo');
  setBusy(btn, true, '生成中…');
  let r;
  try {
    r = await api('/api/inventory/plan', 'POST', {
      walletId: a.walletId, action: revoke ? 'revoke-all' : 'unlimited', platform: picked[0].platform, token: picked[0].token,
      items: picked.map((x) => ({ platform: x.platform, token: x.token })),
    });
  } catch (err) { setBusy(btn, false); return toast(err.message, true); }
  setBusy(btn, false);
  if (!r.oneClick) return toast(r.steps[0]?.error || '第一步模拟未通过', true);
  const walletName = (state.wallets || []).find((w) => w.id === a.walletId)?.name || a.walletId;
  const up = r.plan.approvals.some((x) => x.upgradeable);
  const title = revoke ? `确认批量撤销授权（${r.plan.approvals.length} 种）` : `确认批量预授权（${r.plan.approvals.length} 种，无上限）`;
  const ok = await confirmDialog(title, [
    ['链', 'BSC（56）'],
    ['钱包', h`${walletName} · ${caHtml(r.from)}`],
    // 每种报价币一行：「SYMBOL（平台）」→ 额度变化 + 授权对象（地址缩写，点击复制，悬停看全称）
    ...r.plan.approvals.map((x) => [`${x.symbol}（${INV_PLATFORM_LABEL[x.platform] || x.platform}）`,
      h`<b>${x.beforeText || '0'} → ${revoke ? '0' : h`<span class="warn-text">无上限</span>`}</b>
        <span class="muted">· 授权给 ${x.spenderLabel} ${caHtml(x.spender)}${x.upgradeable ? '（可升级合约）' : ''} · 代币 ${caHtml(x.token)}</span>`]),
    ['花费', r.plan.pay.text],
    ['步骤', `${r.steps.length} 笔授权，确认后逐笔执行（每笔都经币安预览）`],
  ], revoke
    ? '撤销只把授权额度设回 0，不动钱包里的代币。撤销后用库存买入 / 狙击的极速通道会因缺授权退回普通流程或「没库存，跳过」，需要时再到库存列表里「同步授权」。'
    : `无上限授权后，授权对象可以随时转走你钱包里这些代币的全部余额（不只是现在的库存，包括以后转入的）。gang LaunchpadV2 不可升级，风险来自合约本身的漏洞${r.plan.approvals.some((x) => x.platform === 'gangv3') ? '；gang LaunchpadV3 未经审计，风险更高，建议改用库存里的「同步授权」只授权库存量' : ''}${up ? '；Four Core 是可升级合约，升级权限方可以改合约逻辑，风险更高' : ''}。不用时点「批量撤销授权」或在库存列表里点「撤销」把额度设回 0。`);
  if (!ok) return;
  $('#invApproveBox').hidden = true;
  await invFollowJob(a.walletId, r.oneClick.bundleId, revoke ? '确认批量撤销' : '确认批量预授权');
}

/* ---------- 布局：页面跳转 / 全局状态条 / 全部解除 / 交易台持仓与事件 ---------- */
function gotoView(v) {
  const tab = document.querySelector(`.tab[data-view="${v}"]`);
  if (tab) tab.click();
}

const until = (iso) => (iso ? new Date(iso).toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' }) : '');

async function loadAutomation() {
  let s;
  try { s = await api('/api/automation'); } catch { return; }
  state.automation = s;
  checkWins(s.events);
  const pills = [];
  // 胶囊只放一句状态，细节放 title（鼠标悬停看）
  const pill = (cls, text, view, title = '') => pills.push(h`<span class="apill ${cls}" data-goto="${view}" title="${title}">${text}</span>`);
  // 开着的自动化按健康度着色（与事件日志同一套颜色）：正常绿 · 打折扣橙 · 会失败 / 刚失败红；原因放 title
  const live = (hl, text, view, title) => {
    if (hl?.level === 'err') pill('err', `✕ ${text}`, view, `${hl.why}\n${title}`);
    else if (hl?.level === 'warn') pill('wait', `● ${text}`, view, `${hl.why}\n${title}`);
    else pill('on', `● ${text}`, view, title);
  };
  // 钱包掉线放最前面：掉线后所有自动化都会失败（2026-10-27 币安升级全部下线，狙击报了一晚上错）
  for (const w of s.wallets.filter((x) => x.status && x.status !== 'CONNECTED')) {
    pill('err', `✕ ${w.name} 未登录`, 'wallets', '登录已失效：点击去「钱包」页重新扫码登录');
  }
  // 轻量版后端不返回 snipe / four / fairAuto：对应的胶囊不画
  for (const [k, label] of s.snipe ? [['v2', 'V2 狙击'], ['v3', 'V3 狙击']] : []) {
    const x = s.snipe[k];
    if (!x.armed) pill('', `○ ${label}`, 'snipe', '未开启：点击去「狙击」页');
    else if (x.standby) pill('wait', `◐ ${label} 待命`, 'snipe', `已预授权，等发射台上线 · 到 ${until(x.expiresAt)}`);
    else live(x.health, `${label} 运行中 ${x.today ?? 0}/${x.maxPerDay ?? '—'}`, 'snipe', `今天 ${x.today ?? 0} 个 / 每天最多 ${x.maxPerDay ?? '—'} · 已花 ${x.spentBnb}/${x.totalBnb} BNB · 到 ${until(x.expiresAt)}`);
  }
  const directs = s.wallets.filter((w) => w.direct?.armed);
  if (directs.length) live(directs.find((w) => w.health)?.health, `直接买入 到 ${until(directs[0].direct.expiresAt)}`, 'funds', `已开启：${directs.map((w) => w.name).join('、')}`);
  else pill('', '○ 直接买入', 'funds', '未开启：下单卡勾「直接买入」后首次买入时确认');
  if (!s.four) { /* 轻量版 */ } else if (s.four.armed) live(s.four.health, `Four 狙击 ${s.four.hitCount}/${s.four.totalTargets}`, 'four', `自动狙击中 · 已买 ${s.four.hitCount} / 名额 ${s.four.totalTargets} · 已花 ${s.four.spentBnb ?? 0} BNB`);
  else if (s.four.running) pill('wait', '◐ Four 监听', 'four', `只看不买（${s.four.mode}）`);
  else pill('', '○ Four 狙击', 'four', '未开启');
  if (!s.fairAuto) { /* 轻量版 */ } else if (s.fairAuto.armed && s.fairAuto.standby) pill('wait', '◐ 自动打新 待命', 'fairauto', `已预授权，等打新启用 · 到 ${until(s.fairAuto.expiresAt)}`);
  else if (s.fairAuto.armed) live(s.fairAuto.health, `自动打新 到 ${until(s.fairAuto.expiresAt)}`, 'fairauto', `已打 ${s.fairAuto.done} 个 · 已花 ${s.fairAuto.spentBnb} BNB`);
  else pill('', '○ 自动打新', 'fairauto', '未开启');
  if (s.autoXfer?.armed) live(s.autoXfer.health, `发射后转移 ${s.autoXfer.tokens} 个`, 'holdings', `转到 ${s.autoXfer.target} · 已转 ${s.autoXfer.done} 笔 · 到 ${new Date(s.autoXfer.expiresAt).toLocaleString('zh-CN', { hour12: false })}`);
  else if (s.autoXfer) pill('', '○ 发射后转移', 'holdings', '未开启：在「持仓」页设置');
  $('#autoPills').innerHTML = h`${pills}`;
  // 顶部钱包标签跟着刷新掉线红点（状态来自后台预热，30 秒一轮）
  for (const w of s.wallets) {
    const tab = document.querySelector(`.wallet-tab[data-id="${CSS.escape(w.id)}"]`);
    if (tab) { tab.classList.toggle('off', Boolean(w.status && w.status !== 'CONNECTED')); tab.title = w.status === 'CONNECTED' ? '' : '登录已失效，去「钱包」页重新登录'; }
  }
  const me = s.wallets.find((w) => w.id === $('#quickWallet')?.value);
  $('#autoSpent').textContent = `今日已花 ${me ? me.spentToday : '—'}${Number(s.limits.dailyBnb) > 0 ? ` / ${s.limits.dailyBnb} BNB` : ' BNB'} · WSS ${s.wss.connected ? (s.wss.rttMs != null ? `${s.wss.rttMs}ms` : '已连接') : '未连接'}`;
  $('#autoSpent').title = me ? `${me.name} 今天已花（${FULL ? '直接买入 + 狙击 + 打新' : '所有买入'}合计）` : '';
  const anyOn = s.snipe?.v2.armed || s.snipe?.v3.armed || directs.length || s.four?.armed || s.fairAuto?.armed || s.autoXfer?.armed;
  $('#btnKillAll').disabled = !anyOn;
  if (state.view === 'quick') renderDeskEvents(s.events);
}

/**
 * 定时刷新的日志区（每 4 秒重画）：内容没变就不重画；变了也保持你正在看的位置。
 * - 滚动条在最顶部（看最新）时：照常显示最新事件；
 * - 往下翻看历史时：记下视野里第一行（data-k）离顶部的距离，重画后把同一行放回原处，新事件插在上面也不会把你顶走；
 *   那一行已经被挤出列表时，退回原来的 scrollTop。
 * 返回 true = 重画过（调用方据此重新绑定事件）。
 */
function renderKeepScroll(box, html) {
  if (!box) return false;
  const s = String(html);
  // 只有「上次就是我画的、期间没被别处改过」才跳过（别处写过错误提示等，要照常重画）
  if (box._keptSrc === s && box.firstChild === box._keptFirst) return false;
  const saved = [...box.querySelectorAll('.ev-scroll')].map((sc) => {
    if (sc.scrollTop < 4) return null;
    const top = sc.getBoundingClientRect().top;
    const row = [...sc.querySelectorAll('tr[data-k]')].find((tr) => tr.getBoundingClientRect().bottom > top + 1);
    return { scrollTop: sc.scrollTop, key: row?.dataset.k, off: row ? row.getBoundingClientRect().top - top : 0 };
  });
  box.innerHTML = s;
  box._keptSrc = s;
  box._keptFirst = box.firstChild; // 别处再写 innerHTML 时首个节点会换掉
  [...box.querySelectorAll('.ev-scroll')].forEach((sc, i) => {
    const v = saved[i];
    if (!v) return;
    const row = v.key && [...sc.querySelectorAll('tr[data-k]')].find((tr) => tr.dataset.k === v.key);
    sc.scrollTop = row ? sc.scrollTop + (row.getBoundingClientRect().top - sc.getBoundingClientRect().top) - v.off : v.scrollTop;
  });
  return true;
}

function renderDeskEvents(events) {
  const box = $('#deskEvents');
  if (!box) return;
  const html = events?.length
    ? h`${evTableHtml(events, { limit: 200, withSrc: true })}`
    : h`<p class="muted">${FULL ? '暂无事件。开启狙击 / 自动打新后，发现、跳过、买入、上链都会出现在这里。' : '暂无事件。开启发射后转移后，加入监控、转出都会出现在这里。'}</p>`;
  if (renderKeepScroll(box, html)) wireEvAddrs(box);
}

/** 事件类型 → 中文标签（「V2 极速买入」「V2 跳过」…） */
const EV_KIND = {
  detect: '发现', skip: '跳过', buy: '买入', done: '上链', fail: '失败', error: '出错', drop: '移出', refund: '退回',
  slow: '普通流程', standby: '待命', listen: '监听', arm: '开启', disarm: '解除', mint: '打新', bought: '买入',
  exec: '执行', plan: '计划', qualify: '符合', ready: '就绪', start: '启动', stop: '停止', wss: '连接',
  sent: '已转出', confirm: '待 App 确认', token: '监控', config: '参数', sell: '自动卖出', newmode: '新玩法', bond: '保证金',
};
/**
 * 事件类型 → 级别（全站事件日志共用一套颜色）：
 *   ok 成功（绿）· err 失败（红）· warn 需要留意（橙）· info 流程进展（蓝）· mute 跳过 / 系统消息（灰）
 */
const EV_LEVEL = {
  buy: 'ok', bought: 'ok', done: 'ok', mint: 'ok', sent: 'ok', sell: 'ok',
  fail: 'err', error: 'err',
  slow: 'warn', refund: 'warn', confirm: 'warn', drop: 'warn', disarm: 'warn', standby: 'warn',
  detect: 'info', qualify: 'info', ready: 'info', plan: 'info', exec: 'info', token: 'info', arm: 'info', newmode: 'warn', bond: 'info',
  skip: 'mute', listen: 'mute', start: 'mute', stop: 'mute', wss: 'mute', config: 'mute',
};
const evLevel = (type) => EV_LEVEL[type] || 'mute';
function evKind(e) {
  if (e.type === 'buy' && /极速/.test(e.text || '')) return '极速买入';
  return EV_KIND[e.type] || e.type;
}
/** 一键任务每一步的状态（服务端是 preview / execute / confirm / replan / done / app-confirm 这些英文内部名） */
const STEP_STATUS_TEXT = {
  preview: '⏳ 币安模拟中', execute: '⏳ 广播中', confirm: '⏳ 等上链', replan: '⏳ 重新报价',
  done: '✅ 完成', 'app-confirm': '⏳ 等币安 App 确认', success: '✅ 已上链', failed: '⛔ 链上失败', timeout: '⚠ 等上链超时', sent: '已广播',
};
const stepStatusText = (s) => STEP_STATUS_TEXT[s] || s || '—';

/** WSS 连接状态（wsshub / WsRpc 的内部名）→ 中文 */
const WSS_STATE_TEXT = { open: '已连接', connecting: '连接中…', error: '连接出错（自动重连）', closed: '已关闭', idle: '空闲（没有功能在订阅）', off: '未配置' };
const wssStateText = (s) => WSS_STATE_TEXT[s] || s || '—';

/** 到期 / 时刻：24 小时制；不是今天的带上日期（预授权最长 24 小时，跨零点时只写时刻会看错） */
function whenText(at, { seconds = false } = {}) {
  if (!at) return '—';
  const d = new Date(at);
  if (Number.isNaN(d.getTime())) return '—';
  const t = d.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit', ...(seconds ? { second: '2-digit' } : {}) });
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return t;
  const tomorrow = new Date(today.getTime() + 86400e3);
  if (d.toDateString() === tomorrow.toDateString()) return `明天 ${t}`;
  return `${d.getMonth() + 1}/${d.getDate()} ${t}`;
}

/** 事件时间：本地时区；不是今天的带上日期 */
function evTime(at) {
  const d = new Date(at);
  const t = d.toLocaleTimeString('zh-CN', { hour12: false });
  return d.toDateString() === new Date().toDateString() ? t : `${d.getMonth() + 1}/${d.getDate()} ${t}`;
}
/** 事件日志表（狙击 / 打新 / 自动转移 / 总览共用）：整行按级别着色，标签是中文 */
function evTableHtml(events, { limit = 30, withSrc = false } = {}) {
  if (!events?.length) return '';
  return h`<div class="ev-scroll"><table class="table ev-table"><tbody>${events.slice(0, limit).map((e) => h`<tr class="lv-${evLevel(e.type)}" data-k="${`${e.at}|${e.src || ''}|${e.type}|${String(e.text || '').slice(0, 60)}`}">
    <td class="mono t" title="${new Date(e.at).toLocaleString('zh-CN', { hour12: false })}">${evTime(e.at)}</td>
    <td class="k"><span class="ev-tag">${withSrc && e.src ? `${e.src} ` : ''}${evKind(e)}</span></td>
    <td class="m">${evTextHtml(e.text)}${e.txHash ? h` ${txLinkHtml('56', e.txHash)}` : ''}</td>
  </tr>`)}</tbody></table></div>`;
}
/** 事件里的地址：下单框在当前页就填进去，否则复制 */
function wireEvAddrs(root) {
  root.querySelectorAll('[data-ca]').forEach((el) => {
    el.onclick = async () => {
      const inp = $('#quickToken');
      if (inp && inp.offsetParent !== null) {
        inp.value = el.dataset.ca;
        saveField('quickToken');
        onQuickCaInput({ target: inp });
        inp.scrollIntoView({ behavior: 'smooth', block: 'center' });
        toast('已填入下单框');
        return;
      }
      try { await navigator.clipboard.writeText(el.dataset.ca); toast('地址已复制'); } catch { toast('复制失败', true); }
    };
  });
}
/**
 * 服务端日志里写的是钱包 id（如 wallet-2、某个目录名），界面上换成钱包名。
 * 只替换完整的 id（前后不是字母数字 / 连字符），长的先换，避免 wallet-1 把 wallet-10 换坏。
 */
function walletIdsToNames(s) {
  const ws = [...(state.wallets || [])].filter((w) => w.id && w.name && w.name !== w.id).sort((a, b) => b.id.length - a.id.length);
  if (!ws.length) return s;
  const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`(?<![\\w-])(${ws.map((w) => esc(w.id)).join('|')})(?![\\w-])`, 'g');
  const names = new Map(ws.map((w) => [w.id, w.name]));
  return s.replace(re, (m) => names.get(m) || m);
}
/** 事件文本里的完整地址缩短显示（悬停看全称，点击填入下单框）；其余照常转义 */
function evTextHtml(text) {
  const s = walletIdsToNames(String(text || ''));
  const out = [];
  let last = 0;
  for (const m of s.matchAll(/0x[0-9a-fA-F]{40}/g)) {
    out.push(h`${s.slice(last, m.index)}`);
    out.push(h`<span class="addr" data-ca="${m[0]}" title="${m[0]}（点击填入下单框；不在下单页时复制）">${m[0].slice(0, 6)}…${m[0].slice(-4)}</span>`);
    last = m.index + m[0].length;
  }
  out.push(h`${s.slice(last)}`);
  return h`${out}`;
}

async function killAll() {
  const s = state.automation;
  const on = [];
  if (s?.snipe?.v2.armed) on.push('gang V2 狙击');
  if (s?.snipe?.v3.armed) on.push('gang V3 狙击');
  for (const w of s?.wallets || []) if (w.direct?.armed) on.push(`直接买入（${w.name}）`);
  if (s?.four?.armed) on.push('Four 自动狙击');
  if (s?.fairAuto?.armed) on.push('自动打新');
  if (s?.autoXfer?.armed) on.push('发射后自动转移');
  const ok = await confirmDialog('全部解除', [['会解除', on.join('、') || '（当前没有开启的）']],
    `立即解除以上所有预授权，之后不会再自动下单；已经广播出去的交易不受影响。${FULL ? 'Four 监听会继续（只看不买），' : ''}要重新开启需要再确认一次策略。`);
  if (!ok) return;
  try {
    await api('/api/automation/disarm-all', 'POST', { confirm: 'DISARM_ALL' });
    toast('已全部解除');
  } catch (err) { toast(err.message, true); }
  loadAutomation();
  loadArm();
  if (FULL && state.view === 'snipe') loadSnipe();
  if (FULL && state.view === 'fairauto') loadFairAuto();
  if (FULL && state.view === 'four') loadFour();
}

/** 交易台右侧：当前钱包持仓（GMGN），点一行 = 填入 CA 并切到卖出 */
async function loadDeskHoldings() {
  const box = $('#deskHoldings');
  const walletId = $('#quickWallet')?.value;
  if (!box || !walletId) return;
  const st = state.gmgnStatus || await loadGmgnStatus();
  if (!st?.apiKeySet) { box.innerHTML = h`<p class="muted">还没配置 GMGN API Key：到「持仓」页底部「GMGN API 设置」配置后这里会显示持仓。</p>`; return; }
  box.innerHTML = '<p class="muted">读取中…</p>';
  let r;
  try { r = await api(`/api/gmgn/holdings?walletId=${encodeURIComponent(walletId)}&fresh=1`); } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; return; }
  if ($('#quickWallet').value !== walletId) return; // 期间换了钱包
  const all = r.rows || [];
  state.deskHold = all;
  renderQuickSellHold();
  const rows = all.filter((x) => (x.usdValue || 0) >= 1).slice(0, 15);
  const total = all.reduce((a, x) => a + (x.usdValue || 0), 0);
  const bnbUsd = await tokenUsdPrice({ address: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c' }, '56').catch(() => null); // 按 WBNB 价折算
  if ($('#quickWallet').value !== walletId) return;
  $('#deskHoldSummary').textContent = `合计 ${usdFmt(total)}${bnbUsd ? ` ≈ ${(total / bnbUsd).toFixed(2)} BNB` : ''}`;
  $('#deskHoldSummary').title = `${all.length} 个代币 · 更新于 ${new Date().toLocaleTimeString('zh-CN', { hour12: false })}`;
  const pnlTitle = (v, p) => (p ? `${usdFmt(v)}（${pctFmt(p)}）` : usdFmt(v));
  box.innerHTML = rows.length ? h`<table class="table desk-hold"><thead><tr><th>代币</th><th class="right">价值</th><th class="right">未实现</th><th class="right">总利润</th><th class="right">操作</th></tr></thead><tbody>
    ${rows.map((x, i) => (x.native ? h`<tr>
      <td><div class="tok-cell">${avatarHtml('56', { address: x.logoToken, symbol: 'BNB', hasLogo: true })}<b title="原生币（链上余额）">BNB</b></div></td>
      <td class="right mono" title="${fmt(x.balance, 6)} BNB">${usdFmt(x.usdValue)}</td>
      <td class="right mono muted">—</td>
      <td class="right mono muted">—</td>
      <td class="right act"><a data-desk-send="1">转账</a></td>
    </tr>` : h`<tr class="clickable" data-desk-sell="${i}">
      <td><div class="tok-cell">${avatarHtml('56', { address: x.token, symbol: x.symbol, hasLogo: true })}<b title="${x.token || ''}">${x.symbol || '?'}</b></div></td>
      <td class="right mono">${usdFmt(x.usdValue)}</td>
      <td class="right mono ${pnlCls(x.unrealized)}" title="${pnlTitle(x.unrealized, x.unrealizedPnl)}">${usdFmt(x.unrealized)}</td>
      <td class="right mono ${pnlCls(x.totalProfit)}" title="${pnlTitle(x.totalProfit, x.totalPnl)}">${usdFmt(x.totalProfit)}</td>
      <td class="right act"><a data-desk-sell-btn="${i}">卖出</a> · <a data-desk-xfer="${i}">转移</a></td>
    </tr>`))}</tbody></table>${all.length > rows.length ? h`<p class="muted">另有 ${all.length - rows.length} 个价值低于 $1 的未显示</p>` : ''}`
    : h`<p class="muted">没有价值 ≥ $1 的持仓</p>`;
  hydrateLogos(box);
  $$('#deskHoldings [data-desk-send]').forEach((a) => { a.onclick = () => gotoView('send'); });
  $$('#deskHoldings [data-desk-xfer]').forEach((a) => {
    a.onclick = (e) => {
      e.stopPropagation();
      const x = rows[Number(a.dataset.deskXfer)];
      gotoView('holdings');
      const xb = $('#xferBox');
      if (xb) { xb.open = true; xb.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
      $('#btnXferLoad')?.click();
      toast(`在「一键转移」里勾选 ${x.symbol || short(x.token)}，选好白名单地址后确认`);
    };
  });
  $$('#deskHoldings [data-desk-sell]').forEach((tr) => {
    tr.onclick = () => {
      const x = rows[Number(tr.dataset.deskSell)];
      const el = $('#quickToken');
      el.value = x.token;
      saveField('quickToken');
      onQuickCaInput({ target: el });
      $('#quickSellAmount').value = '100%';
      saveField('quickSellAmount');
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      toast(`已填入 ${x.symbol}，卖出比例 100%：确认后点「卖出」`);
    };
  });
}

/* ---------- 钱包持仓（GMGN OpenAPI，只读） ---------- */
const GMGN_TAB_KEY = 'walletui:gmgnTab';
const GMGN_WALLET_KEY = 'walletui:gmgnWallet';
const GMGN_HIDE_SMALL_KEY = 'walletui:gmgnHideSmall';

/** 买入 / 卖出完成后，持仓面板开着就自动刷新（GMGN 入库有几秒延迟，等 4 秒再查） */
function refreshGmgnSoon() {
  clearTimeout(state.gmgnRefreshTimer);
  state.gmgnRefreshTimer = setTimeout(() => {
    if (state.view === 'quick') loadDeskHoldings();
    if (state.view === 'holdings' && $('#gmgnBox')?.open) loadGmgn();
  }, 4000);
}

const usdFmt = (v) => (v == null || !Number.isFinite(v) ? '—' : `${v < 0 ? '-' : ''}$${fmt(Math.abs(v), Math.abs(v) >= 1 ? 2 : 4)}`);
const pctFmt = (r) => (r == null || !Number.isFinite(r) ? '' : `${r >= 0 ? '+' : ''}${(r * 100).toFixed(1)}%`);
function durText(sec) {
  if (!sec || sec < 0) return '—';
  if (sec < 60) return `${Math.round(sec)}s`;
  if (sec < 3600) return `${Math.round(sec / 60)}m`;
  if (sec < 86400) return `${(sec / 3600).toFixed(1)}h`;
  return `${(sec / 86400).toFixed(1)}d`;
}
const pnlCls = (v) => (v == null ? '' : v >= 0 ? 'pnl-up' : 'pnl-down');

function gmgnTarget() {
  const addr = $('#gmgnAddress').value.trim();
  if (addr) {
    if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) throw new Error('地址格式不对');
    return `address=${addr}`;
  }
  const id = $('#gmgnWallet').value;
  if (!id) throw new Error('请选择钱包');
  return `walletId=${encodeURIComponent(id)}`;
}

function fillGmgnWallets() {
  const sel = $('#gmgnWallet');
  if (!sel) return;
  let prev = sel.value;
  if (!prev) { try { prev = localStorage.getItem(GMGN_WALLET_KEY) || ''; } catch { /* ignore */ } }
  sel.innerHTML = h`${(state.wallets || []).map((w) => h`<option value="${w.id}">${w.name}</option>`)}`;
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

async function loadGmgnStatus() {
  try {
    const s = await api('/api/gmgn/status');
    state.gmgnStatus = s;
    $('#gmgnSetupState').textContent = `（API Key ${s.apiKeySet ? `已设置 ${s.apiKeyMasked}` : '未设置'} · 签名密钥 ${s.signerSet ? '已生成' : '未生成'}${s.bannedUntil ? ` · 限频暂停到 ${whenText(s.bannedUntil, { seconds: true })}` : ''}）`;
    if (s.publicKeyPem) { $('#gmgnPubKey').hidden = false; $('#gmgnPubKey').textContent = s.publicKeyPem; }
    if (!s.apiKeySet || !s.signerSet) $('#gmgnSetup').open = true;
    return s;
  } catch { $('#gmgnSetupState').textContent = '（后端是旧版本：重启 webui 后可用）'; return null; }
}

async function loadGmgn(tab) {
  const t = tab || state.gmgnTab || 'holdings';
  state.gmgnTab = t;
  try { localStorage.setItem(GMGN_TAB_KEY, t); } catch { /* ignore */ }
  $$('#gmgnBox [data-gmgn-tab]').forEach((b) => b.classList.toggle('active', b.dataset.gmgnTab === t));
  const box = $('#gmgnTable');
  let q;
  try { q = gmgnTarget(); } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; return; }
  const st = state.gmgnStatus || await loadGmgnStatus();
  if (!st?.apiKeySet) { box.innerHTML = h`<p class="muted">先在下方「GMGN API 设置」里配置 API Key。</p>`; return; }
  box.innerHTML = '<p class="muted">读取中…（直接问 GMGN，不用本地缓存）</p>';
  const at = new Date();
  try {
    if (t === 'holdings' || t === 'history') {
      const [r, stats] = await Promise.all([
        api(`/api/gmgn/${t}?${q}&fresh=1`),
        api(`/api/gmgn/stats?${q}&period=7d&fresh=1`).catch(() => null),
      ]);
      const s = stats?.[0];
      $('#gmgnStats').innerHTML = s ? h`<div class="gmgn-stats">
        <div class="box"><span class="muted">近 7 天已实现</span><b class="${pnlCls(s.realized)}">${usdFmt(s.realized)}</b></div>
        <div class="box"><span class="muted">未实现</span><b class="${pnlCls(s.unrealized)}">${usdFmt(s.unrealized)}</b></div>
        <div class="box"><span class="muted">胜率</span><b>${s.winrate != null ? `${(s.winrate * 100).toFixed(0)}%` : '—'}</b></div>
        <div class="box"><span class="muted">买 / 卖</span><b>${s.buys ?? '—'} / ${s.sells ?? '—'}</b></div>
      </div>` : '';
      const all = r.rows || [];
      const hideSmall = t === 'holdings' && $('#gmgnHideSmall').checked;
      const rows = hideSmall ? all.filter((x) => (x.usdValue || 0) >= 1) : all;
      const now = Date.now() / 1000;
      const total = all.reduce((a, x) => a + (x.usdValue || 0), 0);
      const bnbUsd = await tokenUsdPrice({ address: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c' }, '56').catch(() => null); // 合计同时显示 BNB（按 WBNB 价）
      const bnbText = (usd) => (bnbUsd && usd != null ? ` ≈ ${fmt(usd / bnbUsd, 4)} BNB` : '');
      const timeText = at.toLocaleTimeString('zh-CN', { hour12: false });
      $('#gmgnSummary').textContent = t === 'holdings'
        ? `（${all.length} 个币 · 合计 ${usdFmt(total)}${bnbText(total)} · ${timeText} 更新）`
        : `（历史仓位 ${all.length} 个 · ${timeText} 更新）`;
      const pnlCell = (usd, pct) => h`<td class="right mono ${pnlCls(usd)}">${usdFmt(usd)}<div>${pctFmt(pct)}</div></td>`;
      const px = (v) => (v == null || !Number.isFinite(v) ? '—' : `$${v < 0.01 ? v.toPrecision(3) : fmt(v, 4)}`);
      box.innerHTML = rows.length ? h`<div class="table-scroll"><table class="table gmgn-table"><thead><tr>
          <th>代币</th>
          ${t === 'holdings' ? h`<th class="right">余额</th><th class="right">未实现利润</th>` : ''}
          <th class="right">已实现利润</th><th class="right">总利润</th>
          <th class="right">买入 / 均价</th><th class="right">卖出 / 均价</th><th></th>
        </tr></thead><tbody>${rows.map((x, i) => {
          const held = x.startAt ? (x.endAt || now) - x.startAt : null;
          // 原生 BNB（GMGN 不返回，服务端按链上余额补的一行）：只有余额，没有盈亏 / 买卖记录
          if (x.native) {
            return h`<tr>
              <td><div class="tok-cell">${avatarHtml('56', { address: x.logoToken, symbol: 'BNB', hasLogo: true })}
                <div><div class="tok-line"><b>BNB</b><span class="chip">原生币</span></div>
                <div class="muted">链上余额${x.price != null ? ` · ${px(x.price)}` : ''}</div></div></div></td>
              <td class="right mono"><b>${usdFmt(x.usdValue)}</b><div class="muted">${fmt(x.balance, 6)} BNB</div></td>
              <td class="right mono muted">—</td><td class="right mono muted">—</td><td class="right mono muted">—</td>
              <td class="right mono muted">—</td><td class="right mono muted">—</td>
              <td><button class="ghost" data-gmgn-send="1">去转账</button></td>
            </tr>`;
          }
          return h`<tr>
            <td><div class="tok-cell">${avatarHtml('56', { address: x.token, symbol: x.symbol, hasLogo: true })}
              <div><div class="tok-line"><b>${x.symbol || '?'}</b>${x.launchpad ? h`<span class="chip">${x.launchpad}</span>` : ''}${x.honeypot ? h`<span class="pill pill-amber">疑似貔貅</span>` : ''}</div>
              <div class="muted mono">${caHtml(x.token || '')}</div>
              <div class="muted">持有 ${durText(held)}${x.price != null ? ` · ${px(x.price)}` : ''}</div></div></div></td>
            ${t === 'holdings' ? h`<td class="right mono"><b>${usdFmt(x.usdValue)}</b>${bnbUsd && x.usdValue != null ? h`<div class="muted">${fmt(x.usdValue / bnbUsd, 4)} BNB</div>` : ''}<div class="muted">${x.balance != null ? fmt(x.balance, 2) : '—'} 枚</div></td>
              ${pnlCell(x.unrealized, x.unrealizedPnl)}` : ''}
            ${pnlCell(x.realized, x.realizedPnl)}
            ${pnlCell(x.totalProfit, x.totalPnl)}
            <td class="right mono">${usdFmt(x.boughtCost)}<div class="muted">${x.buys ?? 0} 笔</div><div class="muted">均 ${px(x.avgBuy)}</div>${x.transferIns ? h`<div class="muted">转入 ${x.transferIns}</div>` : ''}</td>
            <td class="right mono">${usdFmt(x.soldIncome)}<div class="muted">${x.sells ?? 0} 笔</div><div class="muted">均 ${px(x.avgSell)}</div>${x.transferOuts ? h`<div class="muted">转出 ${x.transferOuts}</div>` : ''}</td>
            <td>${t === 'holdings' && x.token ? h`<button class="ghost" data-gmgn-sell="${i}">去卖出</button>` : ''}</td>
          </tr>`;
        })}</tbody></table></div>
        ${hideSmall && rows.length < all.length ? h`<p class="muted">已隐藏 ${all.length - rows.length} 个价值低于 $1 的币</p>` : ''}
        ${r.next ? h`<p class="muted">还有更多（显示前 ${all.length} 个）</p>` : ''}` : h`<p class="muted">${t === 'holdings' ? (all.length ? `没有价值 ≥ $1 的持仓（隐藏了 ${all.length} 个小额）` : '没有持仓') : '没有历史仓位'}</p>`;
      hydrateLogos(box);
      $$('#gmgnTable [data-gmgn-send]').forEach((b) => { b.onclick = () => gotoView('send'); });
      $$('#gmgnTable [data-gmgn-sell]').forEach((b) => {
        b.onclick = () => {
          const x = rows[Number(b.dataset.gmgnSell)]; // rows 是过滤后的列表，与按钮下标一致
          gotoView('quick'); // 下单区在交易台
          const el = $('#quickToken');
          el.value = x.token;
          saveField('quickToken');
          onQuickCaInput({ target: el });
          $('#quickSellAmount').value = '100%';
          saveField('quickSellAmount');
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          toast(`已填入 ${x.symbol}：确认卖出比例后点「卖出」`);
        };
      });
    } else {
      $('#gmgnStats').innerHTML = '';
      const r = await api(`/api/gmgn/activity?${q}&fresh=1`);
      const rows = r.rows || [];
      const label = { buy: '买入', sell: '卖出', transferIn: '转入', transferOut: '转出', add: '加池', remove: '撤池' };
      $('#gmgnSummary').textContent = `（最近 ${rows.length} 笔）`;
      box.innerHTML = rows.length ? h`<table class="table"><thead><tr><th>时间</th><th>类型</th><th>币种</th><th class="right">数量</th><th class="right">金额</th><th class="right">单价</th><th>交易</th></tr></thead><tbody>
        ${rows.map((x) => h`<tr>
          <td class="mono">${x.time ? new Date(x.time * 1000).toLocaleString('zh-CN', { hour12: false }) : '—'}</td>
          <td class="${x.type === 'buy' ? 'pnl-up' : x.type === 'sell' ? 'pnl-down' : ''}">${label[x.type] || x.type}</td>
          <td class="mono">${x.symbol || '?'} <span class="muted">${caHtml(x.token || '')}</span></td>
          <td class="right mono">${x.amount != null ? fmt(x.amount, 2) : '—'}</td>
          <td class="right mono">${usdFmt(x.costUsd)}</td>
          <td class="right mono">${x.priceUsd != null ? `$${x.priceUsd.toPrecision(4)}` : '—'}</td>
          <td>${x.tx ? txLinkHtml('56', x.tx) : '—'}</td></tr>`)}
      </tbody></table>` : h`<p class="muted">没有交易记录</p>`;
    }
  } catch (err) {
    box.innerHTML = h`<p class="err">${err.message}</p>`;
    loadGmgnStatus();
  }
}

async function gmgnSaveKey() {
  const k = $('#gmgnApiKey').value.trim();
  if (!k) return toast('请填写 API Key', true);
  try { await api('/api/gmgn/apikey', 'POST', { apiKey: k }); $('#gmgnApiKey').value = ''; toast('GMGN API Key 已保存'); await loadGmgnStatus(); loadGmgn(); } catch (err) { toast(err.message, true); }
}

async function gmgnKeygen() {
  const has = state.gmgnStatus?.signerSet;
  const ok = await confirmDialog(has ? '重新生成 GMGN 签名密钥' : '生成 GMGN 签名密钥', [
    ['用途', 'GMGN OpenAPI 请求签名（查询持仓用），不是钱包私钥'],
    ['保存位置', '本机 webui/config.json（已 gitignore，不会回传网页）'],
  ], `${has ? '重新生成后，GMGN 上已上传的旧公钥会失效，需要重新上传新公钥并更新 API Key。' : ''}生成后把显示的公钥复制到 https://gmgn.ai/ai 创建 API Key；不要给这个 Key 绑定交易钱包。`);
  if (!ok) return;
  try {
    const r = await api('/api/gmgn/keygen', 'POST', { confirm: 'KEYGEN', replace: Boolean(has) });
    $('#gmgnPubKey').hidden = false;
    $('#gmgnPubKey').textContent = r.publicKeyPem;
    toast('已生成：复制下面的公钥到 gmgn.ai/ai');
    loadGmgnStatus();
  } catch (err) { toast(err.message, true); }
}

/* ---------- gang 内盘狙击（预授权后新币一创建就买 1%） ---------- */
const SNIPE_WALLET_KEY = 'walletui:snipeWallet';
const SNIPE_FIELDS = ['snipePerToken', 'snipeTotal', 'snipePerDay', 'snipeCreatorMax', 'snipeSymbolMax', 'snipeMaxBuyTax', 'snipeMaxSellTax', 'snipeMinDividend', 'snipeNewModeMax', 'snipeNewModePer', 'snipeNewModeTotal', 'snipeSlip', 'snipeImpact', 'snipeLoss', 'snipeHours',
  'snipeGasLimit', 'snipeSellDelay', 'snipeSellPct', 'snipeSellSlip'];

const SNIPE_WALLETS_KEY = 'walletui:snipeWallets';
const SNIPE_MAX_WALLETS = 5;
const snipeWalletIds = () => $$('#snipeWallets input[type=checkbox]:checked').map((c) => c.value);

/** 本地记住的勾选（数组）；没有时沿用旧版单选的记忆；都没有返回 null */
function readSnipeWallets() {
  try {
    const arr = JSON.parse(localStorage.getItem(SNIPE_WALLETS_KEY) || 'null');
    if (Array.isArray(arr) && arr.length) return arr;
    const one = localStorage.getItem(SNIPE_WALLET_KEY);
    return one ? [one] : null;
  } catch { return null; }
}

/**
 * 渲染钱包勾选：已预授权时以后端生效的钱包为准；否则用本地记忆；再没有就只勾一个（后端默认值或第一个钱包）。
 * 默认只勾一个钱包，多钱包需要你手动勾选。
 */
function fillSnipeWallets(backendIds, fallbackIds) {
  const box = $('#snipeWallets');
  if (!box) return;
  const list = state.wallets || [];
  const known = (ids) => (ids || []).filter((id) => list.some((w) => w.id === id));
  let sel = known(backendIds);
  if (!sel.length) sel = box.dataset.ready ? snipeWalletIds() : known(readSnipeWallets());
  if (!sel.length) sel = known(fallbackIds).slice(0, 1);
  if (!sel.length && list[0]) sel = [list[0].id];
  box.innerHTML = h`${list.map((w) => h`
    <label class="chip" style="cursor:pointer"><input type="checkbox" value="${w.id}" ${sel.includes(w.id) ? h`checked` : ''} /> ${w.name}</label>`)}`;
  box.dataset.ready = '1';
  $$('#snipeWallets input[type=checkbox]').forEach((c) => {
    c.onchange = () => {
      if (snipeWalletIds().length > SNIPE_MAX_WALLETS) { c.checked = false; return toast(`最多选 ${SNIPE_MAX_WALLETS} 个钱包`, true); }
      try { localStorage.setItem(SNIPE_WALLETS_KEY, JSON.stringify(snipeWalletIds())); } catch { /* ignore */ }
      onSnipeEdit();
      loadSnipeStock(); // 底池说明里的「有库存、能买」按所选钱包算
    };
  });
}

const walletNameOf = (id) => (state.wallets || []).find((w) => w.id === id)?.name || id;

/** 表单 → 策略（百分比输入换成 bps） */
function snipeConfig() {
  const pct = (id, def) => Math.round(Number($(`#${id}`).value.trim() || def) * 100);
  return {
    walletIds: snipeWalletIds(),
    amountMode: $('#snipeAmountMode').value === 'fixed' ? 'fixed' : 'percent',
    maxPerTokenBnb: $('#snipePerToken').value.trim() || '0.1',
    totalBnb: $('#snipeTotal').value.trim() || '3',
    maxPerDay: Number($('#snipePerDay').value.trim() || '30'),
    creatorMax: Number($('#snipeCreatorMax').value.trim() || '2'),
    symbolMax: Number($('#snipeSymbolMax').value.trim() || '0'),
    // V3 专属：留空 = 默认（买税 ≤ 3%、卖税 ≤ 3%、分红 100%）。要不限：税填 5（合约上限）、分红填 0。V2 不读这三项
    maxBuyTaxBps: pct('snipeMaxBuyTax', '3'),
    maxSellTaxBps: pct('snipeMaxSellTax', '3'),
    minDividendBps: pct('snipeMinDividend', '100'),
    // V3 官方新玩法（V2 不读）：默认开、同一玩法只狙前 5 个；每币金额默认同单币上限，总预算默认每币金额 × 名额
    newMode: (() => {
      const max = Number($('#snipeNewModeMax').value.trim() || '5');
      const per = $('#snipeNewModePer').value.trim() || $('#snipePerToken').value.trim() || '0.1';
      const total = $('#snipeNewModeTotal').value.trim() || String(Number((Number(per) * max).toFixed(6)));
      return { enabled: snipeVenue() === 'v3' && $('#snipeNewMode').checked, max, perTokenBnb: per, totalBnb: total };
    })(),
    slippageBps: pct('snipeSlip', '15'),
    maxImpactBps: pct('snipeImpact', '3'),
    maxLossBps: pct('snipeLoss', '5'),
    hours: Number($('#snipeHours').value.trim() || '4'),
    includeTaxed: snipeVenue() === 'v3' ? true : $('#snipeTaxed').checked,
    includeWbnb: snipePool() !== 'other',
    includeNonWbnb: snipePool() !== 'wbnb',
    skipNoStock: $('#snipeSkipNoStock').checked,
    quoteDeny: (state.snipeDeny || []).map((x) => x.address),
      // 自动 = 0（币安按模拟估算）；固定没填按 450000（低于它后端会拒绝）
    gasLimit: $('#snipeGasMode').value === 'auto' ? 0 : Number($('#snipeGasLimit').value.trim() || '450000'),
    autoSell: {
      enabled: $('#snipeAutoSell').checked,
      delaySec: Number($('#snipeSellDelay').value.trim() || '4'),
      percent: Number($('#snipeSellPct').value.trim() || '100'),
      slippageBps: pct('snipeSellSlip', '20'),
    },
  };
}

/*
 * 狙击参数按发射台各存一份（V2 / V3 分开）：localStorage `walletui:snipeForm:v2|v3`，
 * 内容是全部输入框 + 两个开关 + 不狙的底池名单。切换发射台时换成那一份；没有存过就用后端保存的参数回填。
 * 旧版（不分发射台）存的值迁移给 V2。
 */
/** 底池下拉：all = 全部 / wbnb = 只狙 BNB 计价 / other = 只狙其它报价币计价（替代原来两个勾选框，避免「都不勾」这种无效状态） */
const snipePool = () => $('#snipePool')?.value || 'all';
function setSnipePool(wbnb, other) {
  const el = $('#snipePool');
  if (el) el.value = wbnb && !other ? 'wbnb' : !wbnb && other ? 'other' : 'all'; // 旧数据里「都不勾」按全部处理
  syncSnipePoolHint();
}
/** 底池下拉的说明：按当前选择、发射台、不狙名单写清楚会狙哪些币、各自要什么 */
const SNIPE_WBNB = '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c';

/** 底池说明用的库存快照：按所选狙击钱包各读一次 /api/inventory（只读链上余额 / 授权，不发交易） */
async function loadSnipeStock() {
  const ids = snipeWalletIds();
  const seq = (state.snipeStockSeq = (state.snipeStockSeq || 0) + 1);
  if (!ids.length) { state.snipeStock = null; return syncSnipePoolHint(); }
  state.snipeStock = { loading: true, wallets: state.snipeStock?.wallets || [] };
  syncSnipePoolHint();
  const wallets = await Promise.all(ids.map((id) => api(`/api/inventory?walletId=${encodeURIComponent(id)}`)
    .then((r) => ({ id, rows: r.rows || [] }))
    .catch(() => ({ id, rows: null }))));
  if (seq !== state.snipeStockSeq) return; // 期间又换了钱包：以最新一次为准
  state.snipeStock = { at: Date.now(), wallets };
  syncSnipePoolHint();
}

/**
 * 按当前发射台汇总每个已登记报价币在所选钱包里的状态。
 * ready = 有余额且有授权（能走极速通道）；noAuth = 有余额没授权；empty = 没余额。
 * 多钱包时按「几个钱包就绪」计数。V3 的 WBNB 底池直接付 BNB，不列入。
 */
function snipeQuoteStatus(v3) {
  const st = state.snipeStock;
  if (!st?.wallets?.length) return null;
  const plat = v3 ? 'gangv3' : 'gang';
  const big = (v) => { try { return BigInt(v || '0'); } catch { return 0n; } };
  const ok = st.wallets.filter((w) => w.rows);
  const map = new Map();
  for (const w of ok) {
    for (const x of w.rows) {
      if (x.platform !== plat || x.error) continue;
      const k = x.token.toLowerCase();
      if (v3 && k === SNIPE_WBNB) continue;
      if (!map.has(k)) map.set(k, { token: x.token, symbol: x.symbol || '?', ready: 0, noAuth: 0 });
      const t = map.get(k);
      if (t.symbol === '?' && x.symbol) t.symbol = x.symbol;
      if (big(x.balance) > 0n && big(x.allowance) > 0n) t.ready++;
      else if (big(x.balance) > 0n) t.noAuth++;
    }
  }
  return { tokens: [...map.values()], walletCount: ok.length, failed: st.wallets.length - ok.length, loading: st.loading };
}

/** 底池说明：按下拉、发射台、不狙名单和所选钱包的库存，写清楚「会狙哪些 / 哪些会跳过」 */
function syncSnipePoolHint() {
  const el = $('#snipePool') && $('#snipePoolHint');
  if (!el) return;
  const pool = snipePool();
  const v3 = snipeVenue() === 'v3';
  const skip = $('#snipeSkipNoStock')?.checked;
  const denySet = new Set((state.snipeDeny || []).map((x) => x.address.toLowerCase()));
  const denyNames = (state.snipeDeny || []).map((x) => x.symbol || `${x.address.slice(0, 6)}…${x.address.slice(-4)}`);
  const qs = snipeQuoteStatus(v3);
  const lines = [];
  const name = (t, n) => (qs.walletCount > 1 ? `${t.symbol}（${n}/${qs.walletCount} 个钱包）` : t.symbol);

  // 1. BNB 计价
  if (pool === 'other') lines.push(h`<div>BNB 计价：<b>不狙</b>（一律跳过）；</div>`);
  else if (v3) lines.push(h`<div>BNB 计价：<b>狙</b>，用 BNB 一笔直接买，不需要库存；</div>`);
  else {
    const w = qs?.tokens.find((t) => t.token.toLowerCase() === SNIPE_WBNB);
    const s = !qs ? '' : !w || !w.ready ? `，但所选钱包${w?.noAuth ? '有 WBNB 没授权' : '没有 WBNB 库存'}${skip ? '，会跳过' : '，会临时换币'}` : w.ready < qs.walletCount ? `，WBNB 库存就绪 ${w.ready}/${qs.walletCount} 个钱包` : '，WBNB 库存已就绪';
    lines.push(h`<div>BNB 计价：<b>狙</b>，要用 WBNB 库存 + 对 LaunchpadV2 的授权${s}；</div>`);
  }

  // 2. 其它报价币计价
  if (pool === 'wbnb') lines.push(h`<div>其它报价币计价：<b>不狙</b>（一律跳过）；</div>`);
  else {
    lines.push(h`<div>其它报价币计价：<b>狙</b>，要有对应报价币的库存 + 对 ${v3 ? 'LaunchpadV3' : 'LaunchpadV2'} 的授权；</div>`);
    if (!qs) lines.push(h`<div class="muted">　· ${snipeWalletIds().length ? '正在读取所选钱包的库存…' : '先勾选狙击钱包，才能看到哪些报价币有库存'}</div>`);
    else {
      const others = qs.tokens.filter((t) => t.token.toLowerCase() !== SNIPE_WBNB && !denySet.has(t.token.toLowerCase()));
      const ready = others.filter((t) => t.ready > 0);
      const miss = others.filter((t) => t.ready < qs.walletCount);
      lines.push(h`<div>　· 有库存、能买：${ready.length ? h`<b>${ready.map((t) => name(t, t.ready)).join('、')}</b>` : h`<span class="warn-text">没有</span>`}；</div>`);
      if (miss.length) {
        const why = (t) => `${t.symbol}（${t.noAuth ? '有余额没授权' : '没余额'}）`;
        lines.push(h`<div>　· 没库存${skip ? '会跳过' : '会临时换币（慢 2~3 秒）'}：${miss.map(why).join('、')}；</div>`);
      }
      lines.push(h`<div>　· 库存表里没有的新报价币：${skip ? '跳过' : '临时换币'}；</div>`);
      if (qs.failed) lines.push(h`<div class="warn-text">　· 有 ${qs.failed} 个钱包库存读取失败，上面只按读到的钱包统计；</div>`);
    }
  }

  // 3. 不狙名单（在上面两类里再剔除）
  if (denyNames.length) lines.push(h`<div>不狙的底池：${denyNames.join('、')}（这些报价币计价的币都跳过）。</div>`);
  el.innerHTML = h`${lines}`;
}

const SNIPE_FORM_KEY = (v) => `walletui:snipeForm:${v}`;
const SNIPE_LEGACY_KEYS = { taxed: 'walletui:snipeTaxed', nonWbnb: 'walletui:snipeNonWbnb', deny: 'walletui:snipeQuoteDeny' };
const isAddr = (x) => /^0x[0-9a-fA-F]{40}$/.test(x?.address || '');

/** gasLimit 模式：自动时隐藏固定值输入框（prefix = 'snipe' | 'four'） */
function syncGasMode(prefix) {
  const auto = $(`#${prefix}GasMode`)?.value === 'auto';
  const label = $(`#${prefix}GasLimitLabel`);
  if (label) label.hidden = auto;
}

/** 「固定金额」时单币上限就是每币买入金额：标签跟着变 */
function syncSnipeAmountLabel() {
  $('#snipePerTokenLabel').textContent = $('#snipeAmountMode').value === 'fixed' ? '每币买入（BNB 等值，固定）' : '单币最多（BNB 等值）';
}

function saveSnipeForm() {
  const o = {
    taxed: $('#snipeTaxed').checked, wbnb: snipePool() !== 'other', nonWbnb: snipePool() !== 'wbnb', skipNoStock: $('#snipeSkipNoStock').checked,
    newMode: $('#snipeNewMode').checked,
    autoSell: $('#snipeAutoSell').checked,
    deny: state.snipeDeny || [], amountMode: $('#snipeAmountMode').value, gasMode: $('#snipeGasMode').value,
  };
  for (const id of SNIPE_FIELDS) o[id] = $(`#${id}`).value;
  try { localStorage.setItem(SNIPE_FORM_KEY(snipeVenue()), JSON.stringify(o)); } catch { /* ignore */ }
}

function legacySnipeForm() {
  try {
    const form = JSON.parse(localStorage.getItem(FORM_KEY) || '{}');
    const o = {};
    for (const id of SNIPE_FIELDS) if (form[id] != null) o[id] = form[id];
    const t = localStorage.getItem(SNIPE_LEGACY_KEYS.taxed);
    const n = localStorage.getItem(SNIPE_LEGACY_KEYS.nonWbnb);
    if (t != null) o.taxed = t === '1';
    if (n != null) o.nonWbnb = n === '1';
    o.deny = JSON.parse(localStorage.getItem(SNIPE_LEGACY_KEYS.deny) || '[]');
    return Object.keys(o).length > 1 || o.deny.length ? o : null;
  } catch { return null; }
}

/** 换成某个发射台的那份参数（没存过：输入框清空，等 renderSnipe 用后端保存值回填） */
function loadSnipeForm(v) {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(SNIPE_FORM_KEY(v)) || 'null'); } catch { o = null; }
  if (!o && v === 'v2') o = legacySnipeForm();
  for (const id of SNIPE_FIELDS) $(`#${id}`).value = o?.[id] ?? '';
  $('#snipeTaxed').checked = o?.taxed !== false;
  setSnipePool(o?.wbnb !== false, o?.nonWbnb !== false);
  $('#snipeSkipNoStock').checked = o?.skipNoStock !== false;
  $('#snipeNewMode').checked = o?.newMode !== false; // 默认开
  $('#snipeAutoSell').checked = o?.autoSell === true;
  syncSnipePoolHint();
  $('#snipeAmountMode').value = o?.amountMode === 'fixed' ? 'fixed' : 'percent';
  // 旧版本没有 gas 模式：当时填 0 表示自动
  // 默认自动（2026-10-29：固定 30 万全部预览失败）；旧版本没有 gas 模式时，填了非 0 的数才算固定。
  // 以前存下的固定值低于 450000（后端已不接受）一律改回自动
  const legacyFixed = o?.gasMode == null && Number(o?.snipeGasLimit) > 0;
  let gasFixed = o?.gasMode === 'fixed' || legacyFixed;
  if (gasFixed && !(Number($('#snipeGasLimit').value || 450000) >= 450000)) gasFixed = false;
  $('#snipeGasMode').value = gasFixed ? 'fixed' : 'auto';
  if (!gasFixed) $('#snipeGasLimit').value = '';
  syncGasMode('snipe');
  syncSnipeAmountLabel();
  state.snipeDeny = Array.isArray(o?.deny) ? o.deny.filter(isAddr) : [];
  renderSnipeDeny();
  const v3 = v === 'v3';
  $('#snipeTaxedWrap').hidden = v3;
  $('#snipeTaxedV3').hidden = !v3;
  for (const el of document.querySelectorAll('.snipe-v3-only')) el.hidden = !v3;
  if (v3 && !state.snipeModesLoaded) { state.snipeModesLoaded = true; loadSnipeModes(); } // 第一次切到 V3 时读一次回看面板
  $('#btnSnipeCopyV2').hidden = !v3;
}

/** V3 用 V2 那份参数（本机保存的表单），填完立即保存为 V3 的参数；钱包勾选是两个发射台共用的 */
function snipeCopyV2() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(SNIPE_FORM_KEY('v2')) || 'null'); } catch { o = null; }
  if (!o) o = legacySnipeForm();
  if (!o) return toast('本机没有保存过 V2 的参数', true);
  try { localStorage.setItem(SNIPE_FORM_KEY('v3'), JSON.stringify(o)); } catch { /* ignore */ }
  loadSnipeForm('v3');
  onSnipeEdit();
  const per = Number($('#snipePerToken')?.value || 0);
  toast(per > 0.1 ? '已复制。注意：V3 单币上限最多 0.1 BNB，请改小' : '已复制 V2 的参数到 V3');
}

const saveSnipeFilters = saveSnipeForm;
const restoreSnipeFilters = () => loadSnipeForm(snipeVenue());

function renderSnipeDeny() {
  syncSnipePoolHint(); // 说明行里有「另外跳过 N 个报价币」
  const box = $('#snipeDenyList');
  if (!box) return;
  const list = state.snipeDeny || [];
  box.innerHTML = list.length
    ? h`${list.map((x, i) => h`<span class="chip">${x.symbol || '?'} <span class="mono">${caHtml(x.address)}</span><button type="button" class="chip-x" data-deny-del="${i}" title="移除">✕</button></span>`)}`
    : h`<span class="muted">（空：所有底池都狙）</span>`;
  $$('#snipeDenyList [data-deny-del]').forEach((b) => {
    b.onclick = () => {
      state.snipeDeny.splice(Number(b.dataset.denyDel), 1);
      saveSnipeFilters();
      renderSnipeDeny();
      onSnipeEdit();
    };
  });
}

async function snipeDenyAdd() {
  const input = $('#snipeDenyInput');
  const address = input.value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return toast('请填写有效的报价币地址（0x + 40 位 hex）', true);
  const list = state.snipeDeny || (state.snipeDeny = []);
  if (list.some((x) => x.address.toLowerCase() === address.toLowerCase())) return toast('这个底池已经在名单里', true);
  if (list.length >= 30) return toast('不狙的底池最多 30 个', true);
  let symbol = '?';
  try { symbol = (await api(`/api/token?chainId=56&address=${encodeURIComponent(address)}`)).symbol || '?'; } catch { /* 读不到名字也能加 */ }
  list.push({ address, symbol });
  input.value = '';
  saveSnipeFilters();
  renderSnipeDeny();
  onSnipeEdit();
}

/** 已预授权时用后端生效的过滤条件回填（名字优先用本地记过的） */
function fillSnipeFilters(c) {
  if (c.includeTaxed !== undefined) $('#snipeTaxed').checked = c.includeTaxed !== false;
  if (c.includeWbnb !== undefined || c.includeNonWbnb !== undefined) setSnipePool(c.includeWbnb !== false, c.includeNonWbnb !== false);
  if (c.skipNoStock !== undefined) $('#snipeSkipNoStock').checked = c.skipNoStock !== false;
  if (c.newMode) {
    $('#snipeNewMode').checked = c.newMode.enabled === true;
    $('#snipeNewModeMax').value = String(c.newMode.max ?? 5);
    if (c.newMode.perTokenBnb) $('#snipeNewModePer').value = String(c.newMode.perTokenBnb);
    if (c.newMode.totalBnb) $('#snipeNewModeTotal').value = String(c.newMode.totalBnb);
  }
  syncSnipePoolHint();
  if (c.gasLimit !== undefined) {
    $('#snipeGasMode').value = c.gasLimit === 0 ? 'auto' : 'fixed';
    if (c.gasLimit) $('#snipeGasLimit').value = String(c.gasLimit);
    syncGasMode('snipe');
  }
  if (c.autoSell) {
    $('#snipeAutoSell').checked = c.autoSell.enabled === true;
    $('#snipeSellDelay').value = String(c.autoSell.delaySec ?? '');
    $('#snipeSellPct').value = String(c.autoSell.percent ?? '');
    $('#snipeSellSlip').value = c.autoSell.slippageBps != null ? String(c.autoSell.slippageBps / 100) : '';
  }
  if (Array.isArray(c.quoteDeny)) {
    const known = new Map((state.snipeDeny || []).map((x) => [x.address.toLowerCase(), x.symbol]));
    state.snipeDeny = c.quoteDeny.map((address) => ({ address, symbol: known.get(address.toLowerCase()) || '?' }));
    renderSnipeDeny();
  }
}

function fillSnipeForm(c) {
  $('#snipePerToken').value = c.maxPerTokenBnb;
  $('#snipeTotal').value = c.totalBnb;
  $('#snipePerDay').value = String(c.maxPerDay);
  $('#snipeCreatorMax').value = String(c.creatorMax);
  $('#snipeSymbolMax').value = String(c.symbolMax ?? 0);
  // V3 专属（旧配置没有这三项：按不限显示）
  $('#snipeMaxBuyTax').value = String((c.maxBuyTaxBps ?? 500) / 100);
  $('#snipeMaxSellTax').value = String((c.maxSellTaxBps ?? 500) / 100);
  $('#snipeMinDividend').value = String((c.minDividendBps ?? 0) / 100);
  $('#snipeAmountMode').value = c.amountMode === 'fixed' ? 'fixed' : 'percent';
  syncSnipeAmountLabel();
  $('#snipeSlip').value = String(c.slippageBps / 100);
  $('#snipeImpact').value = String(c.maxImpactBps / 100);
  $('#snipeLoss').value = String(c.maxLossBps / 100);
  $('#snipeHours').value = String(c.hours);
}

function renderSnipe(s) {
  state.snipe = s;
  const a = s.arm;
  fillSnipeWallets(a?.walletIds, s.saved?.walletIds); // 仅在已预授权时用后端生效的钱包
  if (a) { fillSnipeForm(a); fillSnipeFilters(a); } // 仅在已预授权时用后端值回填
  else if (s.saved && SNIPE_FIELDS.every((id) => !$(`#${id}`).value.trim())) {
    // 首次使用 / 刚切换发射台：按该发射台保存的参数回填，并写回本地，刷新后不会变回另一个发射台的值
    fillSnipeForm(s.saved);
    saveSnipeForm();
  }
  const tagOf = (x) => (x?.venue === 'v3' ? 'V3' : 'V2');
  // 标题行只放「开没开、今天几个、花了多少、几点到期」；钱包清单放到悬停提示和下面的状态行
  const walletsOf = (x) => (x.arm.wallets || []).map((w) => `${walletNameOf(w.id)}${w.active ? '' : '（已移出）'}`).join('、') || walletNameOf(x.arm.walletId);
  const one = (x) => (x?.arm
    ? `${tagOf(x)} ${x.standby ? '待命（等 V3 启用）' : '运行中'} · 今天 ${x.today}/${x.arm.maxPerDay} 个 · 已花 ${x.arm.spentBnb}/${x.arm.totalBnb} BNB · ${whenText(x.arm.expiresAt)} 到期`
    : `${tagOf(x)} 关闭`);
  const sum = $('#snipeSummary');
  sum.textContent = a || state.snipeOther?.arm
    ? `（${[one(s), state.snipeOther ? one(state.snipeOther) : null].filter(Boolean).join(' ｜ ')}）`
    : '（默认关闭 · 需手动点「预授权并开始」）';
  sum.title = [s, state.snipeOther].filter((x) => x?.arm).map((x) => `${tagOf(x)} 钱包：${walletsOf(x)}`).join('\n');
  $('#btnSnipeDisarm').disabled = !a;
  const ws = s.wss;
  const wsText = ws
    ? `${ws.connected ? '✅ 已连接' : wssStateText(ws.state)}${ws.connected && ws.rttMs != null ? ` · 延迟 ${ws.rttMs}ms` : ''} · ${ws.subscriptions} 个功能在用${!ws.connected && ws.detail ? ` · ${ws.detail}` : ''}`
    : '—';
  if (renderKeepScroll($('#snipeStatus'), h`
    ${a ? h`<div class="row"><span class="muted">狙击钱包</span><span>${walletsOf(s)}</span></div>` : ''}
    <div class="row"><span class="muted">新币推送（WSS，全项目共用一条）</span><span>${wsText}</span></div>
    ${a ? h`<div class="row"><span class="muted">监听</span><span>${s.source || '—'}</span></div>` : ''}
    ${s.fast ? snipeFastHtml(s) : ''}
    ${a && s.modes && s.arm?.newMode?.enabled ? h`<div class="row"><span class="muted">官方新玩法</span><span>${s.modes.adminOk === false ? h`<span class="warn-text">税收处理合约已不归官方登记合约，暂不按新玩法处理</span>` : (s.modes.types || []).length ? s.modes.types.map((t) => `${t.type}（已发 ${t.bound} 个${t.bound >= s.arm.newMode.max ? '，名额已满' : `，还能狙 ${s.arm.newMode.max - t.bound} 个`}）`).join('；') : '还没读到登记表'} · 新玩法预算已花 ${s.arm.modeSpentBnb || '0'} / ${s.arm.newMode.totalBnb} BNB</span></div>` : ''}
    ${s.events.length ? evTableHtml(s.events, { limit: 30 }) : h`<p class="muted">暂无事件</p>`}`)) wireEvAddrs($('#snipeStatus'));
}

/** 极速通道预热状态：每个钱包、每种报价币按「每币买入金额」够买几次（库存和授权取小） */
function snipeFastHtml(s) {
  const per = Number(s.arm?.maxPerTokenBnb || 0);
  const WBNB_LC = '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c';
  const list = [];
  for (const w of s.fast.wallets || []) {
    for (const q of w.quotes) {
      const bal = Number(q.balance);
      const allow = q.unlimited ? Infinity : Number(q.allowance);
      const rate = Number(q.rate || 0); // 1 枚值多少 BNB
      const usableBnb = Math.min(bal, allow) * rate;
      const times = per > 0 && rate > 0 ? Math.floor(usableBnb / per) : 0;
      list.push({ w, q, bal, allow, rate, usableBnb, times, empty: bal < 1e-12 });
    }
  }
  // 能极速的排前面，其次按库存价值；没库存的收起来（只显示个数），表格只留有用的行
  list.sort((a, b) => b.times - a.times || b.usableBnb - a.usableBnb);
  const shown = list.filter((x) => !x.empty || x.q.quote === WBNB_LC);
  const emptyNames = [...new Set(list.filter((x) => x.empty && x.q.quote !== WBNB_LC).map((x) => x.q.symbol || short(x.q.quote)))];
  const multi = (s.fast.wallets || []).length > 1;
  const allowText = (x) => (x.q.unlimited ? h`<span class="pill pill-amber" title="无上限授权：发射台可以转走这个报价币的全部余额">无上限</span>` : x.allow >= x.bal && x.bal > 0 ? h`<span class="muted">≥ 库存</span>` : fmt(x.allow, 4));
  const status = (x) => (x.times > 0
    ? h`<span class="pill pill-green">✔ 可极速 ${x.times} 次</span>`
    : h`<span class="pill pill-muted" title="${x.rate ? '' : '还没拿到这个报价币的 BNB 价格'}">${x.empty ? '没库存' : x.allow < x.bal ? '授权不够' : '库存不够一笔'}</span>`);
  const ready = list.filter((x) => x.times > 0).length;
  const rows = shown.map((x) => h`<tr>
    ${multi ? h`<td>${walletNameOf(x.w.id)}</td>` : ''}
    <td><b>${x.q.symbol || '?'}</b> ${x.q.quote === WBNB_LC ? '' : caHtml(x.q.quote)}</td>
    <td class="right mono">${fmt(x.bal, 4)}</td>
    <td class="right mono">${x.rate ? `≈ ${fmt(x.usableBnb, 4)} BNB` : '—'}</td>
    <td class="right">${allowText(x)}</td>
    <td>${status(x)}</td></tr>`);
  return h`<details class="snipe-fast" open><summary>极速通道：${ready ? `${ready} 种报价币可以一笔买完` : '没有可以一笔买完的报价币'}
      <span class="muted">（每币 ${per || '—'} BNB · 预热于 ${s.fast.at ? new Date(s.fast.at).toLocaleTimeString('zh-CN', { hour12: false }) : '—'}）</span></summary>
    ${shown.length ? h`<table class="table snipe-fast-table"><thead><tr>${multi ? h`<th>钱包</th>` : ''}<th>报价币</th><th class="right">库存</th><th class="right">折合</th><th class="right">授权</th><th>能不能极速</th></tr></thead><tbody>${rows}</tbody></table>` : h`<p class="muted">还没有可用的报价币库存。</p>`}
    ${emptyNames.length ? h`<p class="muted">没库存（遇到这些报价币计价的币会跳过）：${emptyNames.join('、')}</p>` : ''}
    <p class="hint">「可极速 N 次」= 按每币 ${per || '—'} BNB 算，这个报价币的库存还够买几个币（一笔买完）。备货在「资金与授权 → 报价币库存」。</p>
  </details>`;
}

const SNIPE_VENUE_KEY = 'walletui:snipeVenue';
const snipeVenue = () => $('#snipeVenue')?.value || 'v2';

async function loadSnipe() {
  try {
    const venue = snipeVenue();
    const [s, other] = await Promise.all([
      api(`/api/gangsnipe?venue=${venue}`),
      api(`/api/gangsnipe?venue=${venue === 'v2' ? 'v3' : 'v2'}`).catch(() => null),
    ]);
    state.snipeOther = other;
    renderSnipe(s);
  } catch { $('#snipeSummary').textContent = '（后端是旧版本：重启 webui 后可用）'; }
}

async function snipeArm() {
  const c = snipeConfig();
  if (!c.walletIds.length) return toast('请至少勾选一个狙击钱包', true);
  let ls;
  try { ls = await Promise.all(c.walletIds.map((id) => api(`/api/limits?walletId=${encodeURIComponent(id)}`))); } catch (err) { return toast(err.message, true); }
  const l = ls[0];
  const multi = c.walletIds.length > 1;
  const walletName = c.walletIds.map((id, i) => `${walletNameOf(id)}（今天已花 ${ls[i].spentToday} BNB）`).join('、');
  const venue = snipeVenue();
  const v3 = venue === 'v3';
  const v3Pad = state.v3?.enabled && state.v3?.config?.pad;
  // V3 的非 BNB 底池要有报价币库存 + 对 LaunchpadV3 的授权，否则这类币会被「没库存，跳过」。
  // 只读检查每个钱包的 gang V3 库存 / 授权，写进确认框提醒（不改任何东西；读不到不影响预授权）
  let v3Stock = null;
  if (v3 && c.includeNonWbnb) {
    try {
      const invs = await Promise.all(c.walletIds.map((id) => api(`/api/inventory?walletId=${encodeURIComponent(id)}`)));
      v3Stock = c.walletIds.map((id, i) => {
        const rows = (invs[i].rows || []).filter((x) => x.platform === 'gangv3' && !x.error);
        // 就绪 = 有库存且授权额度不少于库存（额度不足时极速通道照样走不了）
        const big = (v) => { try { return BigInt(v || '0'); } catch { return 0n; } };
        const ready = rows.filter((x) => big(x.balance) > 0n && big(x.allowance) >= big(x.balance)).map((x) => x.symbol);
        return { name: walletNameOf(id), total: rows.length, ready };
      });
    } catch { v3Stock = null; }
  }
  const v3StockText = v3Stock
    ? v3Stock.map((s) => `${s.name}：${s.ready.length ? `就绪 ${s.ready.join('、')}` : s.total ? '库存里有 V3 报价币，但没有「有余额且已授权」的' : '库存列表里还没有 gang V3 报价币'}`).join('；')
      + (v3Stock.some((s) => !s.ready.length) && c.skipNoStock ? '。没就绪的，遇到对应报价币的币会被「没库存，跳过」：到「资金与授权 → 报价币库存」添加并「同步授权」' : '')
    : '未能读取（不影响预授权）';
  const ok = await confirmDialog(v3 ? '预授权 gang V3 税收币狙击' : '预授权 gang 内盘狙击', [
    ['链 / 发射台', v3
      ? `BSC（56）· gang LaunchpadV3 ${v3Pad || '（尚未启用：先待命，你在 gang V3 区确认启用后自动开始监听）'}`
      : 'BSC（56）· gang LaunchpadV2 0x1B8F…966E'],
    ...(v3 ? [['V3 附加', '买入金额已含 1% 手续费和该币买税；未审计合约单笔上限 0.1 BNB；WBNB 报价经 GangRouter 一笔完成']] : []),
    ...(v3 && c.includeNonWbnb ? [['V3 非 BNB 底池库存', v3StockText]] : []),
    [multi ? `钱包（${c.walletIds.length} 个）` : '钱包', walletName],
    ['买入', multi
      ? '预授权之后新创建的每个币，每个钱包各买满 1%，并行下单（所有报价币；没有库存时经 Pancake 智能路由换报价币；每个钱包都按「别的钱包先成交」多留金额，多付的合约会退回）'
      : '预授权之后新创建的每个币，买满 1%（所有报价币；没有库存时经 Pancake 智能路由换报价币）'],
    c.amountMode === 'fixed'
      ? ['每币买入', `固定 ${c.maxPerTokenBnb} BNB 等值${multi ? ' / 每个钱包' : ''}（不按曲线报价；超过 1% 持仓上限的部分合约会退回）`]
      : ['单币最多', `${c.maxPerTokenBnb} BNB 等值${multi ? ' / 每个钱包' : ''}（买满 1% 不够时按这个上限买）`],
    ...(v3 ? [] : [['极速通道', '报价币库存和对 LaunchpadV2 的授权都够时，本地算好一笔 buy 直接预览 + 广播（仍过币安预览、单笔 / 每日上限）；不够时走普通流程（先换币 / 授权）']]),
    ['总预算 / 每天最多', `${c.totalBnb} BNB${multi ? '（所有钱包合计）' : ''} / ${c.maxPerDay} 个币`],
    ...(multi ? [['余额不足', '只停掉余额不足的那个钱包，其它钱包继续；全部停掉才整体解除']] : []),
    ...(v3 ? [] : [['税币', c.includeTaxed ? '狙' : '不狙（有税轨的跳过）']]),
    ['底池', `${$('#snipePool').selectedOptions[0]?.textContent || '全部'}：${$('#snipePoolHint')?.textContent || ''}`],
    ['没库存时', c.skipNoStock ? '直接跳过（只走极速通道，一笔买完）' : '临时换报价币 / 授权（多 1~2 笔交易，慢 2~3 秒）'],
    ['gasLimit', c.gasLimit ? `固定 ${c.gasLimit}（会触发毕业建池的那一笔会被跳过）` : '自动（币安估算）'],
    ['买入后自动卖出', c.autoSell.enabled ? `开：买入广播后 ${c.autoSell.delaySec} 秒卖出这次买到的 ${c.autoSell.percent}%，最少收回按 ${c.autoSell.slippageBps / 100}% 滑点算，不再逐笔确认` : '关'],
    ['不狙的底池', (state.snipeDeny || []).length ? h`${state.snipeDeny.map((x, i) => h`${i ? '、' : ''}${x.symbol} ${caHtml(x.address)}`)}` : '无'],
    ['同一创建者', `最多狙 ${c.creatorMax} 个，之后他发的币不再狙`],
    ['同一 symbol', c.symbolMax > 0 ? `只狙前 ${c.symbolMax} 个（大小写 / 全角不同算同一个），之后同名的跳过` : '不限'],
    ...(v3 ? [
      ['V3 买税 / 卖税', `买税 ≤ ${c.maxBuyTaxBps / 100}% · 卖税 ≤ ${c.maxSellTaxBps / 100}%${c.maxBuyTaxBps >= 500 && c.maxSellTaxBps >= 500 ? '（5% 是合约上限，等于不限）' : ''}；税只在毕业后的 Pancake 池里收，高于上限的币直接跳过`],
      ['V3 分红比例', c.minDividendBps > 0 ? `≥ ${c.minDividendBps / 100}%（税收里分给持币人的比例，低于它的币跳过）` : '不限'],
      ['V3 官方新玩法', c.newMode?.enabled
        ? `识别：税收接收地址是官方登记的模块（回购销毁等）→ 不套用底池开关、不狙名单、买税 / 卖税 / 分红、每天上限、同一创建者限制；同一玩法按官方登记顺序只狙前 ${c.newMode.max} 个。用独立预算：每个钱包每币 ${c.newMode.perTokenBnb} BNB 等值、合计 ${c.newMode.totalBnb} BNB（不占普通币的预算）。全局单笔 / 每日上限、V3 单笔 0.1 BNB、同一 symbol、没库存跳过 照旧`
        : '关（新玩法的币和普通币一样过滤）'],
    ] : []),
    ['滑点', `${c.slippageBps / 100}%`],
    ['换报价币', `冲击 ≤ ${c.maxImpactBps / 100}% · 损耗 ≤ ${c.maxLossBps / 100}%（超过就跳过这个币）`],
    ['全局上限', `单笔 ${l.maxBuyBnb} BNB · 每个钱包每日 ${l.dailyBnb} BNB（所有功能共用）`],
    ['有效期', `${c.hours} 小时`],
  ], '确认后，新币一出现就自动买入，不再逐笔确认。内盘新币风险极高（可能归零）；多步买入（换币 → 授权 → 买入）中途停止时已完成的步骤不会回滚。修改参数、到期、解除都会立即失效；服务重启后按原到期时间自动恢复（设置里可关闭）。');
  if (!ok) return;
  try {
    const r = await api('/api/gangsnipe/arm', 'POST', { venue, config: c, confirm: 'ARM' });
    toast(r.standby ? 'V3 狙击已预授权，正在待命：在 gang V3 区确认启用后自动开始' : '内盘狙击已开启');
    await loadSnipe();
  } catch (err) { toast(err.message, true); }
}

async function snipeDisarm() {
  try { await api('/api/gangsnipe/disarm', 'POST', { venue: snipeVenue() }); toast('已解除'); await loadSnipe(); } catch (err) { toast(err.message, true); }
}

/** 修改任意参数即解除（预授权按确认时的参数生效） */
function onSnipeEdit() {
  if (state.snipe?.armed) snipeDisarm();
}

/* ---------- 一键转移：非 BNB 代币 → 白名单地址（确认一次，逐笔执行） ---------- */
const XFER_TARGET_KEY = 'walletui:xferTarget';
const XFER_SEL_KEY = 'walletui:xferSelected';

/** 地址显示：首 8 位 … 尾 6 位 + 完整地址，方便逐字核对 */
const addrText = (a) => `${a.slice(0, 8)} … ${a.slice(-6)}（完整：${a}）`;

function readXferSel() {
  try { return new Set(JSON.parse(localStorage.getItem(XFER_SEL_KEY) || '[]')); } catch { return new Set(); }
}
function saveXferSel(set) {
  try { localStorage.setItem(XFER_SEL_KEY, JSON.stringify([...set].slice(-200))); } catch { /* ignore */ }
}

async function loadXferTargets() {
  const sel = $('#xferTarget');
  if (!sel) return;
  try {
    const list = await api('/api/transfer/targets');
    state.xferTargets = list;
    let saved = '';
    try { saved = localStorage.getItem(XFER_TARGET_KEY) || ''; } catch { /* ignore */ }
    sel.innerHTML = list.length
      ? h`${list.map((t) => h`<option value="${t.id}">${t.name} · ${t.address.slice(0, 8)}…${t.address.slice(-6)}</option>`)}`
      : h`<option value="">（还没有白名单地址：先在下方添加）</option>`;
    if (list.some((t) => t.id === saved)) sel.value = saved;
    $('#xferSummary').textContent = `（白名单 ${list.length} 个）`;
    // 发射后自动转移的收款地址下拉：同一份白名单
    const ax = $('#axTarget');
    if (ax) {
      const keep = ax.value || axSaved().target;
      ax.innerHTML = sel.innerHTML;
      if (list.some((t) => t.id === keep)) ax.value = keep;
    }
  } catch { $('#xferSummary').textContent = '（后端是旧版本：重启 webui 后可用）'; }
}

/* ---------- 发射后自动转移（quick/autoxfer.mjs，docs/AUTOMATION_RULES.md 规则 3 第七个例外） ---------- */
const AX_KEY = 'walletui:autoXfer'; // 复选框 / 钱包 / 收款地址（文本框走 FORM_FIELDS）
const AX_PLATFORM_LABEL = { v2: 'gang V2', v3: 'gang V3', fair: 'gang 打新' };

function axSaved() {
  try { return JSON.parse(localStorage.getItem(AX_KEY) || '{}') || {}; } catch { return {}; }
}
function axSave() {
  const s = {
    wallets: $$('#axWallets input[type=checkbox]:checked').map((c) => c.value),
    v2: $('#axV2').checked, v3: $('#axV3').checked, fair: $('#axFair').checked, autoAdd: $('#axAutoAdd').checked,
    target: $('#axTarget').value,
  };
  try { localStorage.setItem(AX_KEY, JSON.stringify(s)); } catch { /* ignore */ }
}

function axFillForm() {
  const s = axSaved();
  const picked = new Set(s.wallets || [$('#quickWallet')?.value].filter(Boolean));
  $('#axWallets').innerHTML = h`${(state.wallets || []).map((w) => h`<label class="chip" style="cursor:pointer"><input type="checkbox" value="${w.id}" ${picked.has(w.id) ? h`checked` : ''} /> ${w.name}</label>`)}`;
  $$('#axWallets input').forEach((c) => { c.onchange = axSave; });
  $('#axV2').checked = s.v2 !== false; // 默认只勾 V2（主网在用）
  $('#axV3').checked = s.v3 === true;
  $('#axFair').checked = s.fair === true;
  $('#axAutoAdd').checked = s.autoAdd !== false;
}

/** 表单 → 策略 */
function axConfig() {
  const pct = (id) => { const v = $(id).value.trim(); return v === '' ? 100 : Number(v); };
  return {
    walletIds: $$('#axWallets input[type=checkbox]:checked').map((c) => c.value),
    targetId: $('#axTarget').value,
    platforms: {
      v2: { enabled: $('#axV2').checked, percent: pct('#axV2Pct') },
      v3: { enabled: $('#axV3').checked, percent: pct('#axV3Pct') },
      fair: { enabled: $('#axFair').checked, percent: pct('#axFairPct'), keepHold: $('#axFairMode').value !== 'all' },
    },
    autoAdd: $('#axAutoAdd').checked,
    hours: Number($('#axHours').value.trim() || 168),
  };
}
const axTokensInput = () => [...new Set($('#axTokens').value.split(/[,，\s]+/).filter((a) => /^0x[0-9a-fA-F]{40}$/.test(a)).map((a) => a.toLowerCase()))];

async function loadAutoXfer() {
  if (!$('#axWallets').children.length) axFillForm();
  let s;
  try { s = await api('/api/autoxfer'); } catch { $('#axStatus').innerHTML = h`<p class="muted">后端是旧版本：重启 webui 后可用</p>`; return; }
  renderAutoXfer(s);
}

function renderAutoXfer(s) {
  const a = s.arm;
  $('#btnAxDisarm').disabled = !a;
  $('#autoXferSummary').textContent = a
    ? `（已开启 → ${a.target.name} · 监控 ${s.tokens.length} 个 · 已转 ${a.doneCount} 笔 · 到 ${new Date(a.expiresAt).toLocaleString('zh-CN', { hour12: false })}）`
    : '（未开启）';
  const statusPill = (t) => (/已全部转走/.test(t) ? 'pill-green' : /等发射|待检查/.test(t) ? 'pill-muted' : 'pill-amber');
  renderKeepScroll($('#axStatus'), h`
    ${a ? h`<div class="row"><span class="muted">发现发射</span><span>${s.source}${s.wsConnected ? '' : '（WSS 未连接）'}</span></div>` : ''}
    ${s.tokens.length ? h`<div class="row"><span class="muted">监控 ${s.tokens.length} 个 · 买入 / 卖出后所选钱包合计少于 ${s.minKeepTokens != null ? Number(s.minKeepTokens).toLocaleString('zh-CN') : '50 万'} 枚会自动移出</span><button class="ghost" id="btnAxClear">全部移出</button></div>` : ''}
    ${s.tokens.length ? h`<table class="table"><thead><tr><th>代币</th><th>平台</th><th>来源</th><th>状态</th><th></th></tr></thead><tbody>
      ${s.tokens.map((t) => h`<tr><td><b>${t.symbol || '?'}</b> ${caHtml(t.token)}</td><td>${AX_PLATFORM_LABEL[t.platform] || '—'}</td><td>${t.source === 'auto' ? '自动加入' : '手动'}</td>
        <td><span class="pill ${statusPill(t.status || '')}">${t.status || '—'}</span></td><td><button class="ghost" data-ax-remove="${t.token}">移出</button></td></tr>`)}
      </tbody></table>` : (a ? h`<p class="muted">监控列表为空：所选钱包目前没有持有中、未发射的 gang 代币。之后一买入就会自动加入，也可以手动加 CA</p>` : '')}
    ${s.events.length ? evTableHtml(s.events, { limit: 20 }) : ''}`);
  wireEvAddrs($('#axStatus'));
  $$('#axStatus [data-ax-remove]').forEach((b) => {
    b.onclick = async () => {
      try { renderAutoXfer(await api('/api/autoxfer/token', 'POST', { token: b.dataset.axRemove, add: false })); toast('已移出监控'); } catch (err) { toast(err.message, true); }
    };
  });
  const clr = $('#btnAxClear');
  if (clr) {
    clr.onclick = async () => {
      const ok = await confirmDialog('全部移出监控', [['会移出', `${s.tokens.length} 个代币`]],
        '移出后这些代币发射时不会再自动转走；预授权本身保留，之后买入的代币仍会按「买入即加入」加入。');
      if (!ok) return;
      try { renderAutoXfer(await api('/api/autoxfer/tokens/clear', 'POST', {})); toast('已全部移出监控'); } catch (err) { toast(err.message, true); }
    };
  }
}

async function axArm() {
  const c = axConfig();
  const target = (state.xferTargets || []).find((t) => t.id === c.targetId);
  if (!target) return toast('请先在「一键转移」里添加并选择白名单收款地址', true);
  if (!c.walletIds.length) return toast('请至少勾选一个钱包', true);
  const on = ['v2', 'v3', 'fair'].filter((p) => c.platforms[p].enabled);
  if (!on.length) return toast('至少勾选一个平台', true);
  const tokens = axTokensInput();
  const ok = await confirmDialog('确认预授权：发射后自动转移', [
    ['钱包', c.walletIds.map(walletNameOf).join('、')],
    ['收款地址', `${target.name} · ${target.address}`],
    ...on.map((p) => [AX_PLATFORM_LABEL[p], `${c.platforms[p].percent}%${p === 'fair' ? (c.platforms.fair.keepHold ? '（只转超出出局线的部分，保留持有奖励）' : '（全部转走，会永久失去持有奖励）') : ''}`]),
    ['买入即加入', c.autoAdd ? '已持有未发射的 gang 代币立即加入；之后买到的一买入就加入；发射时检测到持有的也转' : '不自动加入，只转手动加入的'],
    ['手动加入', tokens.length ? tokens.map(short).join('、') : '（无）'],
    ['有效期', `${c.hours} 小时（到 ${new Date(Date.now() + c.hours * 3600e3).toLocaleString('zh-CN', { hour12: false })}）`],
  ], `确认后，监控列表里的代币一发射，就从上面的钱包把代币转到 ${target.address}（请逐字核对首尾 6 位：${target.address.slice(0, 8)} … ${target.address.slice(-6)}），不再逐笔确认。链上转账不可撤销；不带 BNB；每个钱包每个币只转一次；被币安风控挂起的需要你在 App 确认。改参数要重新预授权。`);
  if (!ok) return;
  try {
    renderAutoXfer(await api('/api/autoxfer/arm', 'POST', { config: c, tokens, confirm: 'ARM' }));
    toast('已开启：发射后自动转移');
    loadAutomation();
  } catch (err) { toast(err.message, true); }
}

async function axAddTokens() {
  const tokens = axTokensInput();
  if (!tokens.length) return toast('请在文本框里填代币 CA', true);
  const s = await api('/api/autoxfer').catch(() => null);
  if (!s?.arm) return toast('还没有预授权：点「预授权并开始」会把这些 CA 一起加入', true);
  const ok = await confirmDialog('加入「发射后自动转移」监控', [
    ['代币', tokens.join('\n')],
    ['发射后转到', `${s.arm.target.name} · ${s.arm.target.address}`],
  ], '加入后这些代币一发射就会按已预授权的策略自动转走。');
  if (!ok) return;
  for (const t of tokens) {
    try { renderAutoXfer(await api('/api/autoxfer/token', 'POST', { token: t, add: true, confirm: 'ADD' })); } catch (err) { toast(`${short(t)}：${err.message}`, true); }
  }
}

async function axDisarm() {
  try { renderAutoXfer(await api('/api/autoxfer/disarm', 'POST', {})); toast('已解除：发射后自动转移'); loadAutomation(); } catch (err) { toast(err.message, true); }
}

async function xferAddTarget() {
  const address = $('#xferNewAddr').value.trim();
  const name = $('#xferNewName').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return toast('请填写有效的地址（0x + 40 位 hex）', true);
  let chk;
  try { chk = await api('/api/transfer/check', 'POST', { address }); } catch (err) { return toast(err.message, true); }
  if (chk.fatal) return toast(chk.fatal, true);
  const ok = await confirmDialog('添加白名单地址', [
    ['名称', name || '未命名'],
    ['链', 'BSC（56）'],
    ['地址', addrText(chk.address)],
    ['类型', chk.isContract ? '合约地址' : '普通地址（EOA）'],
  ], `${chk.warnings.join(' ')} 加入后，「一键转移」可以把代币转到这个地址。请逐字核对首尾 6 位和中间部分，不要使用从转账记录里复制的地址。`);
  if (!ok) return;
  try {
    await api('/api/transfer/targets', 'POST', { name, address: chk.address, confirm: 'ADD_TARGET' });
    $('#xferNewAddr').value = '';
    $('#xferNewName').value = '';
    toast('已加入白名单');
    await loadXferTargets();
  } catch (err) { toast(err.message, true); }
}

async function xferDelTarget() {
  const id = $('#xferTarget').value;
  const t = (state.xferTargets || []).find((x) => x.id === id);
  if (!t) return toast('没有选中的白名单地址', true);
  const ok = await confirmDialog('删除白名单地址', [['名称', t.name], ['地址', addrText(t.address)]], '删除后不能再一键转移到这个地址（链上资产不受影响）。');
  if (!ok) return;
  try { await api(`/api/transfer/targets/${encodeURIComponent(id)}`, 'DELETE'); toast('已删除'); await loadXferTargets(); } catch (err) { toast(err.message, true); }
}

async function xferLoad(refresh = true) {
  const walletId = $('#quickWallet')?.value;
  if (!walletId) return toast('请先选择钱包', true);
  const box = $('#xferTable');
  box.innerHTML = '<p class="muted">读取中…（从币安钱包余额取候选，逐个链上核实）</p>';
  const extra = $('#xferExtra').value.split(/[,，\s]+/).filter((a) => /^0x[0-9a-fA-F]{40}$/.test(a));
  try {
    const r = await api('/api/transfer/holdings', 'POST', { walletId, refresh, extra });
    state.xfer = r;
    const sel = readXferSel();
    box.innerHTML = h`${r.balanceError ? h`<p class="warn">读取币安余额失败：${r.balanceError}（可在「补充代币 CA」里手动填）</p>` : ''}
      ${r.rows.length ? h`<table class="table"><thead><tr><th></th><th>代币</th><th>持仓</th><th>状态</th><th class="right">估值</th></tr></thead><tbody>
      ${r.rows.map((x, i) => h`<tr class="${x.locked ? 'muted' : ''}">
        <td><input type="checkbox" data-xfer="${i}" ${x.locked ? 'disabled' : ''} ${!x.locked && (sel.has(x.token.toLowerCase()) || (!sel.size && x.gang)) ? 'checked' : ''} /></td>
        <td class="mono">${x.symbol} ${caHtml(x.token)}</td><td class="mono">${x.balanceText}</td><td>${x.status}</td>
        <td class="right">${x.usdValue != null ? `$${fmt(Number(x.usdValue), 2)}` : '—'}</td></tr>`)}
      </tbody></table>` : h`<p class="muted">没有找到非 BNB 代币持仓</p>`}`;
    $$('#xferTable [data-xfer]').forEach((c) => {
      c.onchange = () => {
        const s = readXferSel();
        const t = r.rows[Number(c.dataset.xfer)].token.toLowerCase();
        if (c.checked) s.add(t); else s.delete(t);
        saveXferSel(s);
      };
    });
  } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; }
}

async function xferGo() {
  const walletId = $('#quickWallet').value;
  const targetId = $('#xferTarget').value;
  const target = (state.xferTargets || []).find((t) => t.id === targetId);
  if (!walletId) return toast('请先选择钱包', true);
  if (!target) return toast('请先选择（或添加）一个白名单收款地址', true);
  const rows = state.xfer?.rows || [];
  const picked = [...$$('#xferTable [data-xfer]')].filter((c) => c.checked).map((c) => rows[Number(c.dataset.xfer)]).filter(Boolean);
  if (!picked.length) return toast('请先读取并勾选要转移的代币', true);
  const pct = Number($('#xferPct').value);
  const btn = $('#btnXferGo');
  setBusy(btn, true, '生成计划…');
  let r;
  try {
    r = await api('/api/transfer/plan', 'POST', { walletId, targetId, items: picked.map((x) => ({ token: x.token, percent: pct })) });
  } catch (err) {
    setBusy(btn, false);
    return toast(err.message, true);
  }
  setBusy(btn, false);
  if (!r.oneClick) return toast(r.steps[0]?.error || '第一笔模拟未通过', true);
  const p = r.plan;
  const walletName = (state.wallets || []).find((w) => w.id === walletId)?.name || walletId;
  const rowsOut = [
    ['链', 'BSC（56）'],
    ['从', `${walletName} · ${r.from}`],
    ['收款（白名单）', `${p.target.name} · ${addrText(p.target.address)}`],
    ...p.items.map((it, i) => [`第 ${i + 1} 笔`, `${it.amountText} ${it.symbol}（${it.percent}%）· 合约 ${it.token}`]),
    ...(p.skipped || []).map((s) => ['跳过', h`${s.symbol || caHtml(s.token)}：${s.reason}`]),
  ];
  const ok = await confirmDialog(`确认一键转移 ${p.items.length} 笔`, rowsOut,
    `${(p.warnings || []).join(' ')} 确认后服务端依次执行以上 ${p.items.length} 笔转账（每笔经币安预览，收款地址和数量与确认时不一致就停止），链上不可撤销。请再核对一次收款地址首尾 6 位：${p.target.address.slice(0, 8)} … ${p.target.address.slice(-6)}。`);
  if (!ok) return;
  let job;
  try {
    job = await api('/api/quick/oneclick', 'POST', { walletId, bundleId: r.oneClick.bundleId, confirm: 'ONECLICK' });
  } catch (err) { return toast(err.message, true); }
  const box = $('#xferJob');
  box.hidden = false;
  const started = Date.now();
  const render = () => {
    const stateText = { running: '执行中…', done: '✅ 全部完成', failed: '⛔ 已停止' }[job.state] || job.state;
    box.innerHTML = h`<div class="row"><span class="muted">一键转移 → ${p.target.name}</span><span><b>${stateText}</b> · ${((Date.now() - started) / 1000).toFixed(1)} 秒</span></div>
      ${job.error ? h`<p class="err">${job.error}</p>` : ''}
      ${(job.steps || []).map((s) => h`<div class="row"><span>${s.label} · ${stepStatusText(s.status)}</span><span>${s.txHash ? txLinkHtml('56', s.txHash) : '—'}</span></div>`)}`;
  };
  render();
  while (job.state === 'running' && Date.now() - started < 200000) {
    await new Promise((res) => setTimeout(res, 800));
    try { job = await api(`/api/quick/oneclick/${encodeURIComponent(job.id)}`); } catch { /* 短暂失败继续轮询 */ }
    render();
  }
  xferLoad(true);
}

/** 执行日志里中断的一键任务（服务重启前没跑完）：提示人工核对，已完成的步骤不会回滚 */
async function loadQuickUnfinished() {
  const box = $('#quickUnfinished');
  if (!box) return;
  try {
    const list = await api('/api/quick/unfinished');
    if (!list.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    const jobs = list.filter((j) => !j.orphan).length;
    const orphans = list.length - jobs;
    box.innerHTML = h`<p class="warn">服务重启前有 ${jobs ? `${jobs} 个一键任务没跑完` : ''}${jobs && orphans ? '、' : ''}${orphans ? `${orphans} 笔交易在广播途中中断（可能已上链，也可能没发出）` : ''}。已完成的步骤不会回滚（例如换到的报价币留在钱包里），请到区块浏览器按钱包地址核对后手动处理：</p>
      ${list.map((j) => h`<div class="row"><span>${new Date(j.startedAt).toLocaleString('zh-CN', { hour12: false })} · ${walletNameOf(j.walletId)} · ${BUY_PLATFORM_LABEL[j.platform] || j.platform} · ${caHtml(j.token)}${j.orphan && j.valueWei !== '0' ? ` · ${weiToHuman(j.valueWei)} BNB` : ''}</span><span>${j.steps.map((s) => h`${quickKindLabel(s.kind)}（${stepStatusText(s.status)}） ${s.txHash ? txLinkHtml('56', s.txHash) : ''} `)}</span></div>`)}`;
  } catch { /* 读不到日志不影响交易 */ }
}

const QUICK_ONECLICK_KEY = 'walletui:quickOneClick';
const QUICK_CA_INPUTS = ['#quickToken', '#quickTokenFour', '#quickTokenGang', '#quickTokenFlap'];

/** 当前生效的 CA 输入框（只有一个有内容）：返回 { el, platform } */
function quickActiveCa() {
  for (const sel of QUICK_CA_INPUTS) {
    const el = $(sel);
    if (el && el.value.trim()) return { el, platform: el.dataset.platform || 'auto' };
  }
  return null;
}

function markQuickActive() {
  const a = quickActiveCa();
  for (const sel of QUICK_CA_INPUTS) $(sel)?.classList.toggle('quick-ca-active', Boolean(a && a.el === $(sel)));
}

/** 在一个 CA 框里输入 → 清空其它框（下单只认一个框的内容） */
function onQuickCaInput(e) {
  for (const sel of QUICK_CA_INPUTS) {
    const el = $(sel);
    if (el && el !== e.target && el.value) { el.value = ''; saveField(el.id); }
  }
  markQuickActive();
  clearQuickPlan();
  state.quickDetect = null;
  $('#quickDetect').hidden = true;
  $('#quickBuyUnit').textContent = 'BNB';
  const addr = quickActiveCa()?.el.value.trim() || '';
  renderQuickDetectLine(/^0x[0-9a-fA-F]{40}$/.test(addr) ? { pending: true } : null);
  renderQuickSellHold();
  scheduleQuickWarm();
}

/** 卖出盒标题：当前钱包持有多少（来自交易台右侧的 GMGN 持仓，没读到就不显示） */
function renderQuickSellHold() {
  const el = $('#quickSellHold');
  if (!el) return;
  const addr = (quickActiveCa()?.el.value.trim() || '').toLowerCase();
  const x = addr && (state.deskHold || []).find((r) => String(r.token || '').toLowerCase() === addr);
  el.textContent = x ? `（持有 ${compactNum(x.balance)} · ${usdFmt(x.usdValue)}）` : '';
}

function compactNum(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  const a = Math.abs(n);
  if (a >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (a >= 1e3) return `${(n / 1e3).toFixed(2)}K`;
  return String(Number(n.toPrecision(4)));
}

/** 粘贴 / 输入完整 CA 后 300ms 预热（只读）：识别平台、发现池子，点「买入」时少等几秒 */
function scheduleQuickWarm() {
  clearTimeout(state.quickWarmTimer);
  state.quickWarmTimer = setTimeout(async () => {
    const a = quickActiveCa();
    const walletId = $('#quickWallet')?.value;
    const address = a?.el.value.trim();
    if (!a || !walletId || !/^0x[0-9a-fA-F]{40}$/.test(address || '')) return;
    const key = `${a.platform}:${address.toLowerCase()}:${walletId}`;
    if (state.quickWarmed === key && state.quickDetect) return;
    state.quickWarmed = key;
    try {
      const r = await api('/api/quick/warm', 'POST', { address, platform: a.platform, walletId });
      // 期间换了 CA / 钱包：结果作废
      if (quickActiveCa()?.el.value.trim().toLowerCase() !== address.toLowerCase() || $('#quickWallet').value !== walletId) return;
      if (r.detect) {
        if (!state.quickDetect) state.quickDetect = { address: address.toLowerCase(), r: r.detect };
        renderQuickDetect(r.detect);
      } else renderQuickDetectLine(null); // 后端旧版本：不返回识别结果
    } catch (err) {
      renderQuickDetectLine({ error: err.message });
    }
  }, 300);
}

function clearQuickPlan() {
  state.quick = null;
  const box = $('#quickPlan');
  if (box) box.innerHTML = '';
}

function renderQuickPresets() {
  const raw = $('#quickPresets').value.trim() || QUICK_DEFAULT_PRESETS;
  const list = raw.split(/[,，\s]+/).filter((v) => /^\d+(\.\d+)?$/.test(v)).slice(0, 6);
  $('#quickBuyPresets').innerHTML = h`${list.map((v) => h`<button type="button" class="chip chip-btn" data-quick-buy="${v}">${v}</button>`)}`;
  $$('#quickBuyPresets [data-quick-buy]').forEach((b) => {
    b.onclick = () => {
      $('#quickBuyAmount').value = b.dataset.quickBuy;
      saveField('quickBuyAmount');
      quickBuyClick();
    };
  });
}

const QUICK_MAX_SLIP_BPS = 5000;

/** 快捷交易的滑点（bps）：下拉选项，或「自定义」输入的百分比（0.01~50，最多两位小数） */
function quickSlipBps() {
  const v = $('#quickSlip').value;
  if (v !== 'custom') return Number(v);
  const s = $('#quickSlipCustom').value.trim().replace(/%$/, '');
  if (!/^\d{1,2}(\.\d{1,2})?$/.test(s)) throw new Error('自定义滑点请填 0.01~50 之间的百分比（最多两位小数），例如 15 或 2.5');
  const bps = Math.round(Number(s) * 100);
  if (bps < 1 || bps > QUICK_MAX_SLIP_BPS) throw new Error('自定义滑点需要在 0.01%~50% 之间');
  return bps;
}

function syncQuickSlipCustom() {
  $('#quickSlipCustomWrap').hidden = $('#quickSlip').value !== 'custom';
}

function quickTarget() {
  const a = quickActiveCa();
  if (!a) throw new Error('请在其中一个 CA 输入框里填地址');
  const address = a.el.value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) throw new Error('请输入有效的地址（0x + 40 位 hex）');
  const walletId = $('#quickWallet').value;
  if (!walletId) throw new Error('请先选择一个钱包');
  return { address, walletId, platform: a.platform, slippageBps: quickSlipBps() };
}

/** 识别结果里当前平台的付款单位（买入金额的单位） */
function quickPayUnit() {
  const d = state.quickDetect?.r;
  if (!d) return 'BNB';
  const p = quickActiveCa()?.platform || 'auto';
  const id = p === 'auto' ? d.recommended : p;
  return d.candidates.find((c) => c.id === id)?.payUnit || 'BNB';
}

function renderQuickDetect(r) {
  const box = $('#quickDetect');
  box.hidden = false;
  if (!r.candidates.length) {
    box.innerHTML = h`<p class="err">没有识别到任何平台：不是 Four / gang / Flap 地址，PancakeSwap 上也没有可用池子。</p>${warnsHtml(r.errors)}`;
    return;
  }
  box.innerHTML = h`
    <div class="row"><span class="muted">代币</span><span class="mono">${r.symbol || '?'} ${caHtml(r.address)}</span></div>
    ${r.candidates.map((c) => h`
      <div class="row">
        <span>${c.id === r.recommended ? '⭐ ' : ''}${c.label}</span>
        <span><span class="pill ${c.tradable ? 'pill-green' : 'pill-muted'}">${c.tradable ? '可交易' : '不可交易'}</span> ${c.phase} · 付 ${c.payUnit}</span>
      </div>
      ${notesHtml(c.notes)}`)}
    ${r.recommended ? h`<p class="muted">推荐：${r.candidates.find((c) => c.id === r.recommended).label}（平台选「自动识别」时使用）</p>` : h`<p class="err">当前没有可交易的平台</p>`}
    ${r.errors?.length ? h`<details><summary>部分平台探测出错</summary>${notesHtml(r.errors)}</details>` : ''}`;
  $('#quickBuyUnit').textContent = quickPayUnit();
  renderQuickDetectLine(r);
}

/** CA 框下面一行：识别：⭐ 平台 · 阶段 · 第一条说明（报价币 / 进度）；明细在「更多」里 */
function renderQuickDetectLine(r) {
  const el = $('#quickDetectLine');
  if (!el) return;
  if (!r) { el.textContent = '识别：粘贴 CA 后自动识别平台'; el.title = ''; return; }
  if (r.pending) { el.textContent = '识别中…'; return; }
  if (r.error) { el.innerHTML = h`识别：<span class="warn-text">${r.error}</span>`; return; }
  const c = (r.candidates || []).find((x) => x.id === r.recommended);
  if (!c) { el.innerHTML = h`识别：<span class="warn-text">没有可交易的平台</span>${r.symbol ? ` · ${r.symbol}` : ''}`; return; }
  const parts = [`⭐ ${c.label}`, r.symbol, c.phase, ...(c.notes || []).slice(0, 1)].filter(Boolean);
  el.textContent = `识别：${parts.join(' · ')}`;
  el.title = [...parts, ...(c.notes || []).slice(1)].join('\n');
}

async function quickDetect() {
  const btn = $('#btnQuickDetect');
  let t;
  try { t = quickTarget(); } catch (err) { return toast(err.message, true); }
  setBusy(btn, true, '识别中…');
  try {
    const r = await api('/api/quick/detect', 'POST', { address: t.address, walletId: t.walletId });
    state.quickDetect = { address: t.address.toLowerCase(), r };
    renderQuickDetect(r);
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function quickPlan(side, { silent = false } = {}) {
  state.quickMulti = null;
  const btn = side === 'buy' ? $('#btnQuickBuy') : $('#btnQuickSell');
  let body;
  try {
    const t = quickTarget();
    const raw = (side === 'buy' ? $('#quickBuyAmount') : $('#quickSellAmount')).value.trim();
    if (!raw) throw new Error(side === 'buy' ? '请填写或点选买入数量' : '请填写卖出数量或比例（如 50%）');
    body = { ...t, side };
    if (side === 'sell' && /%\s*$/.test(raw)) body.percent = raw.replace(/%\s*$/, '').trim();
    else body.amount = raw;
  } catch (err) {
    return toast(err.message, true);
  }
  await quickRequestPlan(body, btn, silent);
}

async function quickRequestPlan(body, btn, silent = false) {
  setBusy(btn, true, '报价中…');
  const box = $('#quickPlan');
  if (!silent) box.innerHTML = '<p class="muted">报价中…（识别平台、发现池子、选路、模拟真实到账，约 3~8 秒）</p>';
  try {
    const r = await api('/api/quick/plan', 'POST', body);
    state.quick = { req: body, data: r, done: new Set(), hashes: {} };
    // 计划里带回了识别结果：顺手刷新识别卡片
    state.quickDetect = { address: body.address.toLowerCase(), r: { ...(state.quickDetect?.r || {}), address: body.address, symbol: r.plan.symbol, candidates: r.plan.candidates, recommended: r.plan.platform, errors: [] } };
    renderQuickDetect(state.quickDetect.r);
    renderQuickPlan();
    // 卖出：报价出来直接弹一次确认，确认后服务端自动执行全部步骤（授权 → 卖出 → 解包），不再逐笔确认
    if (body.side === 'sell' && !silent && r.oneClick) quickOneClick();

  } catch (err) {
    box.innerHTML = h`<p class="err">${err.message}</p>`;
    toast(err.message, true);
    pushQuickRecent({ ok: false, text: `${short(body.address)} ${body.side === 'sell' ? '卖出' : '买入'}报价未通过：${err.message}` });
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- 交易台「最近任务」：本机最近 5 条下单结果（只存在浏览器 localStorage） ---------- */
const QUICK_RECENT_KEY = 'walletui:quickRecent';
function pushQuickRecent(item) {
  let list = [];
  try { list = JSON.parse(localStorage.getItem(QUICK_RECENT_KEY) || '[]'); } catch { list = []; }
  if (!Array.isArray(list)) list = [];
  list.unshift({ ...item, at: Date.now() });
  try { localStorage.setItem(QUICK_RECENT_KEY, JSON.stringify(list.slice(0, 5))); } catch { /* ignore */ }
  renderQuickRecent();
}
function renderQuickRecent() {
  const box = $('#quickRecent');
  if (!box) return;
  let list = [];
  try { list = JSON.parse(localStorage.getItem(QUICK_RECENT_KEY) || '[]'); } catch { list = []; }
  if (!Array.isArray(list) || !list.length) { box.innerHTML = h`<span class="muted">最近任务：暂无</span>`; return; }
  box.innerHTML = h`<b>最近任务：</b>${list.slice(0, 3).map((x) => h`<div class="rt" title="${new Date(x.at).toLocaleString('zh-CN', { hour12: false })} ${x.text}">${x.ok ? '✅' : '⛔'} ${x.text}${x.tx ? h` ${txLinkHtml('56', x.tx)}` : ''}</div>`)}`;
}

/* ---------- 钱包锁定（币安风控挂起时，所有新交易都会被 API_351716 拒绝）---------- */
const LOCK_POLL_MS = 10000;
async function loadWalletLock(walletId = $('#quickWallet')?.value, { fresh = false } = {}) {
  if (!walletId) return null;
  let s;
  try { s = await api(`/api/w/${encodeURIComponent(walletId)}/lock${fresh ? '?fresh=1' : ''}`); } catch { return null; }
  state.walletLock = { ...(state.walletLock || {}), [walletId]: s };
  renderWalletLock();
  clearTimeout(state.lockTimer);
  // 锁着就每 10 秒再查一次，解锁后自动消失（只轮询当前钱包）
  if (s.locked && walletId === $('#quickWallet')?.value) state.lockTimer = setTimeout(() => loadWalletLock(walletId, { fresh: true }), LOCK_POLL_MS);
  return s;
}
function renderWalletLock() {
  const box = $('#quickLock');
  if (!box) return;
  const wid = $('#quickWallet')?.value;
  const s = state.walletLock?.[wid];
  box.hidden = !s?.locked;
  if (!s?.locked) { box.innerHTML = ''; return; }
  box.innerHTML = h`<b>⚠ ${walletNameOf(wid)} 被币安锁定</b>：${addrTextHtml(s.message || '有一笔交易在等币安 App 确认')}
    <div class="wallet-lock-act"><span class="muted">每 10 秒自动检查，解锁后这条提示会消失</span> <button type="button" class="ghost" id="btnLockRecheck">现在检查</button></div>`;
  $('#btnLockRecheck').onclick = () => loadWalletLock(wid, { fresh: true });
}

/* ---------- 买入记录：最近 3 天买过的币（按代币合并 + 当前余额），点一行选中该币去卖出 ---------- */
const BUYS_EMPTY_KEY = 'walletui:quickBuysShowEmpty';
const BUY_PLATFORM_LABEL = { gang: 'gang V2', gangv3: 'gang V3', fair: '打新', four: 'Four', flap: 'Flap', flaptax: 'Flap 税币', dex: '外盘' };
async function loadBuyRecords() {
  const box = $('#quickBuys');
  const walletId = $('#quickWallet')?.value;
  if (!box || !walletId) return;
  try {
    const r = await api(`/api/buys?walletId=${encodeURIComponent(walletId)}`);
    state.buyRecords = { walletId, rows: r.rows || [] };
  } catch (err) {
    box.innerHTML = h`<p class="err">${/not found/.test(err.message) ? '后端是旧版本：重启 webui 后可用' : err.message}</p>`;
    return;
  }
  renderBuyRecords();
}
function renderBuyRecords() {
  const box = $('#quickBuys');
  const b = state.buyRecords;
  if (!box || !b || b.walletId !== $('#quickWallet')?.value) return;
  const showEmpty = $('#quickBuysShowEmpty')?.checked;
  const held = (x) => x.balance == null || x.balance !== '0';
  const rows = b.rows.filter((x) => showEmpty || held(x));
  const hiddenN = b.rows.length - rows.length;
  $('#quickBuysSummary').textContent = `（${walletNameOf(b.walletId)} · 最近 3 天 ${b.rows.length} 个币${hiddenN ? `，${hiddenN} 个已卖完（已隐藏）` : ''} · 点一行选中该币，去卖出）`;
  if (!rows.length) { box.innerHTML = h`<p class="muted">${b.rows.length ? '买过的币都已卖完' : '最近 3 天这个钱包没有买入记录'}</p>`; return; }
  const cur = (quickActiveCa()?.el.value.trim() || '').toLowerCase();
  box.innerHTML = h`<table class="table quick-buys-table"><thead><tr><th>代币</th><th>平台 / 来源</th><th class="right">买入</th><th class="right">当前持有</th><th>最后买入</th><th></th></tr></thead><tbody>
    ${rows.map((x, i) => h`<tr class="${x.token.toLowerCase() === cur ? 'sel' : ''} ${held(x) ? '' : 'buy-empty'}" data-buy-pick="${i}" title="点击选中，填入下单框">
      <td><b>${x.symbol}</b> ${caHtml(x.token)}</td>
      <td>${BUY_PLATFORM_LABEL[x.platform] || x.platform || '—'} <span class="muted">· ${x.src}</span></td>
      <td class="right mono">${x.count > 1 ? `${x.count} 次 · ` : ''}${Number(x.spentBnb) ? `${Number(x.spentBnb).toFixed(4)} BNB` : h`<span class="muted" title="用报价币库存付款，没有直接花 BNB">报价币</span>`}</td>
      <td class="right mono">${x.balanceText == null ? '读取失败' : held(x) ? x.balanceText : '已卖完'}</td>
      <td class="mono">${new Date(x.lastAt).toLocaleString('zh-CN', { hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}${x.txHash ? h` ${txLinkHtml('56', x.txHash, '↗')}` : ''}</td>
      <td><button type="button" class="ghost" data-buy-sell="${i}">${held(x) ? '去卖出' : '选中'}</button></td>
    </tr>`)}
  </tbody></table>`;
  const pick = (x) => {
    const inp = $('#quickToken');
    if (!inp) return;
    inp.value = x.token;
    saveField('quickToken');
    onQuickCaInput({ target: inp });
    if (held(x)) { $('#quickSellAmount').value = '100%'; saveField('quickSellAmount'); }
    $$('#quickBuys tr.sel').forEach((t) => t.classList.remove('sel'));
    box.querySelector(`[data-buy-pick="${rows.indexOf(x)}"]`)?.classList.add('sel');
    inp.scrollIntoView({ behavior: 'smooth', block: 'center' });
    toast(`已选中 ${x.symbol}${held(x) ? '，卖出数量已填 100%，确认后点「卖出」' : ''}`);
  };
  box.querySelectorAll('[data-buy-pick]').forEach((tr) => { tr.onclick = () => pick(rows[Number(tr.dataset.buyPick)]); });
}

/* ---------- 狙击看板：每笔狙击是第几个买进去的（链上名次）+ 汇总，只读 ---------- */
function fillSboardWallets() {
  const sel = $('#sboardWallet');
  if (!sel) return;
  const cur = sel.value || readFormState().sboardWallet || '';
  sel.innerHTML = h`<option value="">全部钱包</option>${(state.wallets || []).map((w) => h`<option value="${w.id}">${w.name || w.id}</option>`)}`;
  if ([...sel.options].some((o) => o.value === cur)) sel.value = cur;
}

async function loadSnipeBoard() {
  const box = $('#sboardTable');
  if (!box) return;
  fillSboardWallets();
  const seq = (state.sboardSeq = (state.sboardSeq || 0) + 1);
  if (!state.sboard) box.innerHTML = h`<span class="muted">读取中（第一次要逐笔查链上，可能要几秒）…</span>`;
  $('#sboardSummary').textContent = '（读取中…）';
  try {
    const q = new URLSearchParams({ days: $('#sboardDays').value || '3' });
    if ($('#sboardWallet').value) q.set('walletId', $('#sboardWallet').value);
    if ($('#sboardSrc').value) q.set('src', $('#sboardSrc').value);
    const r = await api(`/api/snipeboard?${q}`);
    if (seq !== state.sboardSeq) return; // 期间又改了筛选：以最新一次为准
    state.sboard = r;
  } catch (err) {
    if (seq !== state.sboardSeq) return;
    $('#sboardSummary').textContent = '';
    box.innerHTML = h`<p class="err">${/not found/.test(err.message) ? '后端是旧版本：重启 webui 后可用' : err.message}</p>`;
    return;
  }
  renderSnipeBoard();
}

/** 名次徽标：第 1 金色、前 3 绿、前 10 黄、其它灰 */
function rankBadgeHtml(c) {
  if (!c || c.state !== 'ok') return h`<span class="muted">—</span>`;
  if (c.rank == null) return h`<span class="muted" title="${c.why || '没在买家里找到这个钱包'}">未知</span>`;
  const cls = c.rank === 1 ? 'rk-1' : c.rank <= 3 ? 'rk-3' : c.rank <= 10 ? 'rk-10' : 'rk-n';
  const tip = `第 ${c.rank} 个买家（前面 ${c.buyersBefore} 个地址、${c.buysBefore} 笔买入；同一块里排在你前面 ${c.sameBlockBefore} 笔）`
    + `；截至你那一块共 ${c.totalBuyers} 个买家${c.devBuy ? '；发币人创建时自买，已排除' : ''}`;
  return h`<span class="rank-badge ${cls}" title="${tip}">${c.rank === 1 ? '🥇 ' : c.rank === 2 ? '🥈 ' : c.rank === 3 ? '🥉 ' : ''}第 ${c.rank}</span><span class="muted rank-of"> · 截至该块 ${c.totalBuyers} 人</span>`;
}

function sboardResultHtml(r) {
  const c = r.chain;
  const link = r.txHash ? h` ${txLinkHtml('56', r.txHash, '↗')}` : '';
  if (c?.state === 'ok') return h`<span class="auth-badge auth-ok">成功</span>${link}`;
  if (c?.state === 'failed') return h`<span class="auth-badge auth-none" title="交易上链但执行失败（多半是被抢先买满或超出滑点）">链上失败</span>${link}`;
  if (c?.state === 'pending') return h`<span class="auth-badge auth-low">等待上链</span>${link}`;
  if (c?.state === 'error') return h`<span class="auth-badge auth-low" title="${c.why || ''}">读取失败</span>${link}`;
  if (r.state === 'running') return h`<span class="auth-badge auth-low">进行中</span>`;
  if (r.state === 'appconfirm') return h`<span class="auth-badge auth-low" title="广播后没拿到交易哈希：一般是被币安风控挂起，要去 App 确认">没有哈希</span>`;
  return h`<span class="auth-badge auth-na" title="一键任务失败，买入那一步没有发出">没发出</span>`;
}

function renderSnipeBoard() {
  const d = state.sboard;
  const box = $('#sboardTable');
  if (!d || !box) return;
  const s = d.summary;
  const pct = (n) => (s.ranked ? `${Math.round((n / s.ranked) * 100)}%` : '—');
  $('#sboardSummary').textContent = `（最近 ${d.days} 天 ${s.total} 笔 · 成功 ${s.ok}${s.ranked ? ` · 第 1 名 ${s.first} 次` : ''}）`;
  const tiles = [
    ['狙击笔数', s.total, `成功 ${s.ok} · 链上失败 ${s.failed} · 没发出 ${s.notSent}${s.pending ? ` · 等待 ${s.pending}` : ''}`],
    ['第 1 名', s.first, `占有名次的 ${pct(s.first)}`],
    ['前 3 名', s.top3, `占 ${pct(s.top3)} · 前 10 名 ${s.top10}`],
    ['平均名次', s.avgRank ?? '—', s.medianRank != null ? `中位数 第 ${s.medianRank}` : '还没有算出名次的'],
    ['创建后上链', s.medianBlocks != null ? `${s.medianBlocks} 块` : '—', '中位数（BSC 约 0.45 秒一块）'],
    ['花费合计', `${Number(weiToHuman(s.spentWei)).toFixed(4)} BNB`, '链上成功的买入，BNB 等值（Four 为估算）'],
  ];
  const dist = [['第 1', s.dist.r1, 'rk-1'], ['2~3', s.dist.r2_3, 'rk-3'], ['4~10', s.dist.r4_10, 'rk-10'], ['11+', s.dist.r11, 'rk-n']];
  $('#sboardStats').innerHTML = h`<div class="sboard-tiles">${tiles.map(([k, v, sub]) => h`<div class="sboard-tile"><div class="k">${k}</div><div class="v mono">${v}</div><div class="sub muted">${sub}</div></div>`)}</div>
    ${s.ranked ? h`<div class="sboard-dist" title="名次分布（只算链上成功且找到名次的）">${dist.filter(([, n]) => n > 0).map(([k, n, cls]) => h`<span class="seg ${cls}" style="flex:${n}">${k}：${n}</span>`)}</div>` : ''}`;
  if (!d.rows.length) { box.innerHTML = h`<p class="muted">这段时间没有狙击买入记录</p>`; return; }
  const when = (at) => new Date(at).toLocaleString('zh-CN', { hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  box.innerHTML = h`<div class="ev-scroll sboard-scroll"><table class="table sboard-table"><thead><tr>
      <th>时间</th><th>代币</th><th>来源 · 钱包</th><th>名次</th><th>速度</th><th class="right">花费</th><th>结果</th>
    </tr></thead><tbody>
    ${d.rows.map((r) => {
    const c = r.chain;
    const speed = c?.state === 'ok' && c.blocksAfter != null
      ? h`创建后 <b>${c.blocksAfter}</b> 块${c.msAfter != null ? h` · ${(c.msAfter / 1000).toFixed(2)} 秒` : ''}${c.sameBlockBefore ? h`<span class="muted"> · 同块前面 ${c.sameBlockBefore} 笔</span>` : ''}`
      : h`<span class="muted">${r.ms != null ? `发现→执行 ${r.ms}ms` : '—'}</span>`;
    return h`<tr class="${c?.state === 'ok' ? '' : 'buy-empty'}">
      <td class="mono">${when(r.at)}</td>
      <td><b>${r.symbol || '?'}</b> ${caHtml(r.token)}</td>
      <td>${SBOARD_SRC_LABEL[r.src] || r.src}${r.fast ? h` <span class="muted">极速</span>` : ''} <span class="muted">· ${walletNameOf(r.walletId)}</span></td>
      <td>${rankBadgeHtml(c)}${c?.devBuy ? h` <span class="muted" title="发币人在创建交易里自买，不计入名次">(+发币人)</span>` : ''}</td>
      <td>${speed}</td>
      <td class="right mono">${r.spendWei ? Number(weiToHuman(r.spendWei)).toFixed(4) : '—'}</td>
      <td>${sboardResultHtml(r)}</td>
    </tr>`;
  })}
    </tbody></table></div>`;
}
const SBOARD_SRC_LABEL = { V2: 'gang V2', V3: 'gang V3', Four: 'Four' };

/* ---------- 一键买入：确认一次整笔计划 + 上限，服务端自动逐步执行 ---------- */

function quickTimingText(t) {
  if (!t) return '';
  const parts = [];
  if (t.detectMs != null) parts.push(`识别 ${t.detectMs}ms`);
  if (t.planMs != null) parts.push(`报价 ${t.planMs}ms`);
  if (t.previewMs != null) parts.push(`币安预览 ${t.previewMs}ms`);
  if (t.totalMs != null) parts.push(`合计 ${t.totalMs}ms`);
  return parts.join(' · ');
}

/** 钱包已知被锁：再问一次币安（可能刚解锁），仍锁着就提示原因、不下单（下了只会被 351716 拒绝） */
async function blockedByLock(walletId) {
  if (!state.walletLock?.[walletId]?.locked) return false;
  const s = await loadWalletLock(walletId, { fresh: true });
  if (!s?.locked) return false;
  toast(s.message || '钱包被币安锁定：有一笔交易在等 App 确认', true);
  return true;
}

async function quickOneClick() {
  const q = state.quick;
  if (!q) return;
  if (await blockedByLock(q.data?.walletId)) return;
  const oc = q.data.oneClick;
  // undefined = 后端是旧版本（没有一键买入）；null = 新后端，但第一步预览没通过或超出上限
  if (oc === undefined) return toast('后端服务还是旧版本，不支持一键买入：请关闭 webui 窗口，重新运行 webui\\start.cmd 后刷新页面', true);
  if (!oc) return toast(q.data.oneClickBlocked || '第一步模拟未通过，不能一键买入（看下方步骤的失败原因）', true);
  const p = q.data.plan;
  const walletName = (state.wallets || []).find((w) => w.id === q.data.walletId)?.name || q.data.walletId;
  const steps = q.data.steps;
  const sell = q.req?.side === 'sell';
  const rows = [
    ['方向', sell ? '卖出' : '买入'],
    ['平台', p.platformLabel],
    ['钱包', h`${walletName} · ${caHtml(q.data.from)}`],
    ['扣取', p.pay.text],
    ['预计收到', `${p.receive.expected} ${p.receive.symbol}`],
    ['最少收到', `${p.receive.min} ${p.receive.symbol}`],
    ['路由', p.route],
    ['冲击 / 税', quickImpactText(p)],
    ...steps.map((s, i) => [`第 ${i + 1} 步`, `${quickKindLabel(s.kind)} · ${s.label}`]),
    ['上限 · BNB 合计', `${weiToHuman(oc.bounds.maxValueWei)} BNB`],
    ...oc.bounds.approvals.map((a) => ['上限 · 授权', approvalBoundHtml(a, steps)]),
    ['上限 · 价格', '每步重新报价后「最少收到」不得低于本次确认值，否则自动停止'],
  ];
  // 第一步在生成计划时已经过币安预览：requireConfirmation=true 表示这一步会被风控挂起、要去 App 确认，挂起期间钱包所有交易都会被拒
  const pv0 = steps[0]?.preview;
  const hold = pv0?.requireConfirmation === true;
  if (hold) rows.unshift(['⚠ 币安风控', `第 1 步（${quickKindLabel(steps[0].kind)}）币安预判要在 App 里确认。确认之前这个钱包的所有交易（包括狙击）都会被拒绝`]);
  const ok = await confirmDialog(sell ? '确认一键卖出' : '确认一键买入', rows,
    `确认后服务端会自动依次执行以上 ${steps.length} 步（每步都经币安预览模拟），不再逐笔确认；任何一步超出上限或模拟失败都会立即停止，已完成的步骤不会回滚（${sell ? '例如授权已经上链' : '例如已换到的报价币会留在钱包'}）。`
    + `${hold ? '这一笔广播后请马上打开币安 App → Agentic Wallet 确认，确认上链前不要重复点击（重试只会被拒绝）。' : sell ? '币安把这笔判为高风险时会挂起等你在 App 确认，挂起期间钱包所有交易都会被拒绝，后续步骤停止。' : ''}计划 2 分钟内有效。`);
  if (!ok) return;
  let job;
  q.clickedAt = Date.now(); // 确认后开始计时（确认框停留时间不算）
  try {
    job = await api('/api/quick/oneclick', 'POST', { walletId: q.data.walletId, bundleId: oc.bundleId, confirm: 'ONECLICK' });
  } catch (err) {
    return toast(err.message, true);
  }
  q.done = new Set(steps.map((_, i) => i)); // 手动按钮全部禁用，避免和自动执行抢同一个 requestId
  renderQuickPlan();
  await followQuickJob(job, q);
}

function renderQuickJob(job, q) {
  let box = $('#quickJob');
  if (!box) {
    box = document.createElement('div');
    box.id = 'quickJob';
    box.className = 'quote-box';
    $('#quickPlan').prepend(box);
  }
  const sellJob = q.req?.side === 'sell';
  const stateText = { running: '执行中…', done: sellJob ? '✅ 卖出完成' : '✅ 买入完成', failed: '⛔ 已停止' }[job.state] || job.state;
  const ms = (v) => (v == null ? '—' : `${v}ms`);
  const sec = (v) => `${(v / 1000).toFixed(1)} 秒`;
  // 用时：从点击到最后一笔上链（报价 + 币安预览 + 执行）；执行中显示已用时间
  const end = q.finishedAt || Date.now();
  const wall = q.clickedAt ? end - q.clickedAt : null;
  const planMs = q.data.timing?.totalMs ?? null;
  const timeLine = [
    wall != null ? `${job.state === 'running' ? '已用' : '总用时'} ${sec(wall)}` : null,
    planMs != null ? `报价 + 预览 ${sec(planMs)}` : null,
    job.totalMs != null ? `执行 ${sec(job.totalMs)}` : null,
  ].filter(Boolean).join(' · ');
  box.innerHTML = h`
    <div class="row"><span class="muted">${sellJob ? '一键卖出' : '一键买入'}</span><span><b>${stateText}</b></span></div>
    ${timeLine ? h`<div class="row"><span class="muted">用时</span><span><b>${timeLine}</b></span></div>` : ''}
    ${job.error ? h`<p class="err">${job.error}</p>` : ''}
    <table class="table"><thead><tr><th>步骤</th><th>状态</th><th>预览</th><th>广播</th><th>上链</th><th>重新报价</th><th>交易</th></tr></thead><tbody>
      ${(job.steps || []).map((s) => h`<tr><td>${quickKindLabel(s.kind)}${s.pipelined ? '（并行）' : ''}</td><td>${stepStatusText(s.status)}</td><td>${ms(s.previewMs)}</td><td>${ms(s.executeMs)}</td><td>${ms(s.confirmMs)}</td><td>${ms(s.replanMs)}</td><td>${s.txHash ? txLinkHtml('56', s.txHash) : '—'}</td></tr>`)}
    </tbody></table>
    <p class="quick-timing">报价阶段明细：${quickTimingText(q.data.timing)}</p>`;
}

/**
 * 确认框里的授权上限：服务端只给 token / spender / 原始数量（最小单位，可能不是 18 位小数，也可能是无上限）。
 * 优先用计划里对应授权步骤的说明（带 symbol、数量和授权对象名），无上限直接写「无上限」，不显示 78 位数字。
 */
function approvalBoundHtml(a, steps = []) {
  let amt = 0n;
  try { amt = BigInt(a.amount || '0'); } catch { /* 当 0 */ }
  const step = steps.find((s) => s.kind === 'approve' && String(s.to || '').toLowerCase() === String(a.token || '').toLowerCase());
  const who = h`<span class="muted">（授权给 ${caHtml(a.spender)}）</span>`;
  if (amt >= INV_UNLIMITED) return h`<b class="warn-text">无上限</b> ${caHtml(a.token)} ${who}`;
  if (step?.label) return h`${step.label} ${who}`;
  return h`${weiToHuman(a.amount)} ${caHtml(a.token)}（只授权本次数量）${who}`;
}

function quickImpactText(p) {
  const parts = [];
  if (p.impactBps != null) parts.push(`价格冲击 ${(p.impactBps / 100).toFixed(2)}%`);
  if (p.lossBps != null) parts.push(`实测税/损耗 ${(p.lossBps / 100).toFixed(2)}%`);
  return parts.join(' · ') || '—';
}

function renderQuickPlan() {
  const q = state.quick;
  if (!q) return;
  const { plan: p, steps } = q.data;
  const slip = `${Number(q.req.slippageBps) / 100}%`;
  const highSlip = Number(q.req.slippageBps) >= 2000;
  const n = steps.length;
  $('#quickPlan').innerHTML = h`
    <div class="quote-box">
      <div class="row"><span class="muted">平台</span><span>${p.platformLabel}</span></div>
      <div class="row"><span class="muted">方向 / 代币</span><span class="mono">${p.side === 'buy' ? '买入' : '卖出'} · ${p.symbol} ${caHtml(p.token)}</span></div>
      <div class="quick-sum">
        <div class="box"><span class="muted">扣取</span><b>${p.pay.text}</b></div>
        <div class="box"><span class="muted">预计收到</span><b>${p.receive.expected} ${p.receive.symbol}</b>
          <span class="muted">最少收到 ${p.receive.min} ${p.receive.symbol}（滑点 ${slip}）</span></div>
      </div>
      <div class="row"><span class="muted">路由</span><span>${p.route}</span></div>
      <div class="row"><span class="muted">冲击 / 税</span><span>${quickImpactText(p)}</span></div>
      ${p.alternatives?.length > 1 ? h`
        <details><summary>候选路由（${p.alternatives.length} 条，已按模拟到账选最优）</summary>
          <table class="table"><tbody>${p.alternatives.map((a) => h`<tr><td>${a.chosen ? '✅ ' : ''}${a.route}</td><td class="right mono">${a.outText}</td></tr>`)}</tbody></table>
        </details>` : ''}
      ${p.note ? h`<p class="warn">${p.note}</p>` : ''}
      ${highSlip ? h`<p class="warn">滑点 ${slip} 很高：最少收到只有预计的 ${100 - Number(q.req.slippageBps) / 100}%，被夹或价格剧烈波动时可能按接近这个下限成交。</p>` : ''}
      ${warnsHtml(p.warnings)}
      ${p.checks?.length ? h`<details><summary>校验项</summary>${checksTableHtml(p.checks)}</details>` : ''}
      ${q.data.timing ? h`<p class="quick-timing">耗时：${quickTimingText(q.data.timing)}</p>` : ''}
      ${q.data.oneClick && n > 1 && !q.data.job ? h`<div class="actions"><button class="primary" id="btnQuickOneClickRun">一键执行全部 ${n} 步（确认一次）</button></div>` : ''}
    </div>
    ${steps.map((st, i) => {
      const done = q.done.has(i);
      const ready = !done && (i === 0 || q.done.has(i - 1));
      const previewed = Boolean(st.preview);
      const pill = done ? h`<span class="pill pill-green">已执行</span>`
        : previewed ? h`<span class="pill ${st.ok ? 'pill-green' : 'pill-red'}">${st.ok ? '模拟通过' : '模拟失败'}</span>`
          : st.error ? h`<span class="pill pill-red">预览失败</span>`
            : h`<span class="pill pill-muted">待上一步上链</span>`;
      return h`
        <div class="step">
          <div class="step-head">
            <span class="step-label">${n > 1 ? `第 ${i + 1}/${n} 步 · ` : ''}${quickKindLabel(st.kind)}</span>${pill}
          </div>
          <div class="muted">${st.label}</div>
          ${st.error ? h`<p class="err">${previewed ? '模拟失败：' : ''}${st.error}</p>` : ''}
          ${q.hashes[i] ? h`<div class="row"><span class="muted">交易</span>${txLinkHtml('56', q.hashes[i])}</div>` : ''}
          <div class="actions">
            <button class="${st.kind === 'approve' ? 'primary' : 'danger'}" data-quick-step="${i}" ${ready && (!previewed || st.ok) ? '' : 'disabled'}>${previewed ? '确认并执行' : '预览并执行'}</button>
          </div>
        </div>`;
    })}`;
  $$('#quickPlan button[data-quick-step]').forEach((b) => { b.onclick = () => quickExec(Number(b.dataset.quickStep)); });
  const run = $('#btnQuickOneClickRun');
  if (run) run.onclick = () => quickOneClick();
}

function quickKindLabel(kind) {
  return {
    approve: '授权', swap: '兑换', buy: '买入', sell: '卖出', wrap: '包装 BNB', unwrap: '解包 WBNB',
    mint: '打新', withdraw: '撤出', refund: '退款', claim: '领取奖励', transfer: '转账',
  }[kind] || kind;
}

/** 等交易上链（以 Date.now() 截止时间为准轮询回执，不累计 sleep） */
async function quickWaitReceipt(hash) {
  const deadline = Date.now() + QUICK_RECEIPT_WAIT_MS;
  while (Date.now() < deadline) {
    try {
      const r = await api(`/api/quick/receipt?hash=${hash}`);
      if (r.status !== 'pending') return r.status;
    } catch { /* 网络抖动：继续等 */ }
    await new Promise((res) => setTimeout(res, Math.min(QUICK_RECEIPT_POLL_MS, Math.max(0, deadline - Date.now()))));
  }
  return 'timeout';
}

async function quickPreviewStep(i) {
  const q = state.quick;
  const st = q.data.steps[i];
  const r = await api(`/api/w/${q.data.walletId}/preview`, 'POST', {
    chainId: '56', from: q.data.from, to: st.to, value: st.value, inputData: st.inputData,
  });
  st.preview = r.preview;
  st.ok = previewExecutable(r.preview, '56');
  st.error = st.ok ? '' : previewSummary(r.preview, '56').rows[0][1];
  renderQuickPlan();
  return st.ok;
}

async function quickExec(i) {
  const q = state.quick;
  const st = q?.data?.steps?.[i];
  if (!st) return;
  const p = q.data.plan;
  const btn = $$('#quickPlan button[data-quick-step]')[i];
  setBusy(btn, true, '预览中…');
  try {
    if (!st.preview && !(await quickPreviewStep(i))) return toast(`模拟失败：${st.error}`, true);
  } catch (err) {
    setBusy(btn, false);
    return toast(err.message, true);
  }
  setBusy(btn, false);
  const sum = previewSummary(st.preview, '56');
  const n = q.data.steps.length;
  const walletName = (state.wallets || []).find((w) => w.id === q.data.walletId)?.name || q.data.walletId;
  const rows = [
    ['平台', p.platformLabel],
    ['钱包', h`${walletName} · ${caHtml(q.data.from)}`],
    ['本步', `${n > 1 ? `${i + 1}/${n} · ` : ''}${st.label}`],
  ];
  if (st.kind !== 'approve') {
    rows.push(
      [n > 1 ? '整笔扣取' : '扣取', p.pay.text],
      ['预计收到', `${p.receive.expected} ${p.receive.symbol}`],
      ['最少收到', `${p.receive.min} ${p.receive.symbol}`],
      ['路由', p.route],
      ['冲击 / 税', quickImpactText(p)],
    );
  }
  rows.push(...sum.rows.map(([k, v]) => [`链上模拟 · ${k}`, v]));
  const warn = [
    ...(p.fairOut ? [p.fairOut] : []), // 卖出会跌破打新出局线：永久失去持有奖励
    st.kind === 'approve' ? '这是一笔授权交易（只授权本次数量）。上链后会自动继续下一步。' : '确认后立即广播，链上不可撤销。',
    ...sum.warns,
  ].join(' ');
  const ok = await confirmDialog(st.kind === 'approve' ? '确认授权' : '确认交易', rows, warn);
  if (!ok) return;

  setBusy(btn, true, '广播中…');
  try {
    const { result, needsAppConfirm } = await api(`/api/w/${q.data.walletId}/execute`, 'POST', { requestId: st.preview.requestId, confirm: 'EXECUTE' });
    q.done.add(i);
    q.hashes[i] = result.txHash;
    if (needsAppConfirm) {
      // 币安风控挂起（gang 卖出等）：交易还没广播，需要用户在币安 App 里确认
      renderQuickPlan();
      toast('这笔交易被币安风控挂起，要在币安 App → Agentic Wallet 里确认。确认之前这个钱包的所有交易（包括狙击）都会被拒绝；确认上链后再点一次「卖出 / 买入」继续下一步', true);
      loadWalletLock(q.data.walletId, { fresh: true });
      return;
    }
    toastTx(`${quickKindLabel(st.kind)}已提交`, '56', result.txHash);
    renderQuickPlan();
    scheduleRefresh();
    const last = i === n - 1;
    if (last) refreshGmgnSoon(); // 手动卖出 / 买入的最后一步：持仓面板开着就刷新
    if (last && !st.replan) return;
    if (!result.txHash) return toast('未拿到交易哈希，无法等待上链；请在交易历史确认后重新生成计划', true);
    // 后续步骤依赖这一步的链上结果：等上链后再继续
    const status = await quickWaitReceipt(result.txHash);
    if (state.quick !== q) return; // 期间用户改了参数 / 重新报价
    if (status !== 'success') return toast(status === 'failed' ? '上一步交易链上失败，已停止后续步骤' : '等待上链超时，请在交易历史确认后重新生成计划', true);
    if (st.replan) {
      toast(`${quickKindLabel(st.kind)}已上链，正在按最新链上状态重新报价…`);
      // next：例如换币后改用「已换到的报价币数量」继续，避免按新价格再换一次
      await quickRequestPlan({ ...q.req, ...(st.next || {}) }, q.req.side === 'buy' ? $('#btnQuickBuy') : $('#btnQuickSell'), true);
    } else {
      await quickPreviewStep(i + 1);
      toast(`第 ${i + 1} 步已上链，请确认第 ${i + 2} 步`);
    }
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

/* ---------- gang V3：核验 → 确认启用（默认关闭，只读监控只提示不启用） ---------- */

function v3ChecksHtml(result) {
  if (!result?.checks) return '';
  return h`<table class="table"><tbody>${result.checks.map((c) => h`
    <tr><td>${c.ok ? '✅' : c.fatal ? '❌' : '⚠️'} ${c.name}</td><td class="mono">${caHtml(String(c.detail))}</td></tr>`)}</tbody></table>`;
}

function renderV3Status(s) {
  state.v3 = s;
  const box = $('#v3Status');
  if (!box) return;
  const discOn = s.discovery?.v3 !== false; // 旧后端没有这个字段：按开启处理
  const live = s.live;
  const statusText = s.enabled
    ? (live?.ok ? '已启用，复核通过' : '已启用，但最近一次复核未通过：已暂停 V3 交易')
    : '未启用';
  box.innerHTML = h`
    <div class="row"><span class="muted">状态</span><span>${statusText}</span></div>
    ${s.config ? h`<div class="row"><span class="muted">已配置</span><span class="mono">pad ${caHtml(s.config.pad)} · router ${caHtml(s.config.router)} · 来源 ${s.config.source || '—'}</span></div>` : ''}
    <div class="row"><span class="muted">单笔买入上限</span><span>${s.maxBuyBnb} BNB（未审计合约）</span></div>
    ${discOn ? h`<div class="row"><span class="muted">主网监控</span><span>${s.watch.lastCheck ? `上次 ${new Date(s.watch.lastCheck).toLocaleTimeString()}` : '尚未检查'}${s.watch.apiConfigured === false ? ' · gang.fun 显示 V3 未配置' : s.watch.apiConfigured ? ' · gang.fun 已开放 V3 接口' : ''}${s.watch.lastError ? ` · 出错：${s.watch.lastError}` : ''}</span></div>
    ${s.candidate ? h`
      <div class="row"><span class="muted">发现候选</span><span class="mono">pad ${caHtml(s.candidate.pad)} · router ${caHtml(s.candidate.router)}（${s.candidate.result.ok ? '核验通过' : '核验未通过'}）</span></div>
      <div class="actions"><button class="ghost" id="btnV3UseCandidate">填入候选地址</button></div>` : h`<div class="row"><span class="muted">候选</span><span>官方尚未公布主网地址</span></div>`}
    <div class="row"><span class="muted">链上监听（WSS）</span><span>${v3WssText(s.wss)}</span></div>` : h`
    <div class="row"><span class="muted">部署发现</span><span>已关闭（不订阅接线事件、不查官方仓库）</span></div>
    ${s.config ? h`<div class="row"><span class="muted">新币订阅（狙击用）</span><span class="mono">LaunchpadV3 ${caHtml(s.config.pad)} 的 Created 事件</span></div>` : ''}`}
    ${live && !live.ok ? v3ChecksHtml(live) : ''}`;
  $('#v3DiscHint').hidden = !discOn;
  $('#v3DiscOffHint').hidden = discOn;
  $('#btnV3Check').hidden = !discOn;
  // 已启用时输入框以生效配置为准（以前点过「填入」的候选地址会残留在输入框里，核验它会误报未通过）
  if (s.enabled && s.config && ($('#v3Pad').value !== s.config.pad || $('#v3Router').value !== s.config.router)) {
    $('#v3Pad').value = s.config.pad;
    $('#v3Router').value = s.config.router;
    saveField('v3Pad');
    saveField('v3Router');
    invalidateV3Verify();
  }
  const use = $('#btnV3UseCandidate');
  if (use) {
    use.onclick = () => {
      $('#v3Pad').value = s.candidate.pad;
      $('#v3Router').value = s.candidate.router;
      state.v3Source = s.candidate.source;
      invalidateV3Verify();
    };
  }
  $('#btnV3Disable').disabled = !s.enabled;
  renderV3ChainCands(s.chainCandidates || []);
  if (!s.enabled) autoFillDeployment('v3', s);
}

function v3WssText(w) {
  if (!w) return '—';
  const label = { open: '已连接，订阅中', connecting: '连接中…', error: '异常', off: '未开启', idle: '启动中', closed: '已停止' }[w.state] || w.state;
  return `${label}${w.lastBlock ? ` · 已补查到区块 ${w.lastBlock}（之后实时推送）` : ''}${w.detail ? ` · ${w.detail}` : ''}`;
}

/** 链上发现的部署：只用于提醒和辅助核对，填入后仍需官方来源一致或你声明已核对 */
function renderV3ChainCands(list) {
  const box = $('#v3ChainCands');
  if (!box) return;
  if (!list.length) { box.innerHTML = ''; return; }
  box.innerHTML = h`
    <h3 style="font-size:13px;margin:14px 0 6px">链上发现的 V3 部署（${list.length}）</h3>
    ${list.map((c, i) => h`
      <div class="step">
        <div class="step-head">
          <span class="step-label mono">${c.pad}</span>
          <span class="pill ${c.official ? 'pill-green' : 'pill-amber'}">${c.official ? '与官方来源一致' : '未经官方确认'}</span>
        </div>
        <div class="row"><span class="muted">路由</span><span class="mono">${c.router || '等待 RouterSet'}</span></div>
        ${c.otherRouters?.length ? h`<div class="row"><span class="muted">其它白名单路由（非 GangRouter，不参与交易）</span><span class="mono">${c.otherRouters.map(short).join(' · ')}</span></div>` : ''}
        <div class="row"><span class="muted">首次发现</span><span>区块 ${c.firstBlock} · 发起钱包 ${caHtml(c.sender || '—')} · owner ${caHtml(c.owner || '—')}</span></div>
        <div class="row"><span class="muted">事件</span><span>${c.events.map((e) => e.name).join(' → ')}</span></div>
        <div class="row"><span class="muted">核验</span><span>${c.result ? (c.result.ok ? '通过' : '未通过 / 接线未完成') : '进行中'}</span></div>
        ${c.result && !c.result.ok ? h`<details><summary>核验详情</summary>${v3ChecksHtml(c.result)}</details>` : ''}
        <div class="actions"><button class="ghost" data-v3-cand="${i}" ${c.router ? '' : 'disabled'}>填入（启用前须核对官方地址）</button></div>
      </div>`)}`;
  $$('#v3ChainCands [data-v3-cand]').forEach((b) => {
    b.onclick = () => {
      const c = list[Number(b.dataset.v3Cand)];
      $('#v3Pad').value = c.pad;
      $('#v3Router').value = c.router;
      state.v3Source = 'chain';
      invalidateV3Verify();
    };
  });
}

/* ---------- gang V3 发现提醒：顶部横幅 + 铃声（Web Audio 合成，无外部资源） ---------- */

const V3_ACK_KEY = 'walletui:v3AlertAcked';
const V3_POLL_MS = 15000;
const BELL_REPEAT_MS = 4000;
const BELL_MAX_MS = 10 * 60 * 1000;
const bell = { ctx: null, timer: null, until: 0, title: document.title, flip: false };

const v3AlertKey = (a) => `${a.level}|${a.text}`;

function readV3Acked() {
  try { return new Set(JSON.parse(localStorage.getItem(V3_ACK_KEY) || '[]')); } catch { return new Set(); }
}

function audioCtx() {
  if (!bell.ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (AC) bell.ctx = new AC();
  }
  return bell.ctx;
}

/** 浏览器要求用户交互后才能出声：任意点击 / 按键时解锁 */
function unlockAudio() {
  const c = audioCtx();
  if (c && c.state === 'suspended') return c.resume().catch(() => {});
  return Promise.resolve();
}

function ringOnce() {
  const c = audioCtx();
  if (!c || c.state !== 'running') return false;
  const t0 = c.currentTime;
  [[988, 0], [784, 0.2], [988, 0.4], [784, 0.6]].forEach(([freq, dt]) => {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = 'triangle';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0 + dt);
    g.gain.exponentialRampToValueAtTime(0.5, t0 + dt + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dt + 0.18);
    o.connect(g).connect(c.destination);
    o.start(t0 + dt);
    o.stop(t0 + dt + 0.2);
  });
  return true;
}

/* ---------- 狙中提示音：狙击买入成功时响一段明显的「上行琶音」，和 V3 发现的铃声区分开 ---------- */
const WIN_SOUND_KEY = 'walletui:winSound';
// 成功事件：gang V2 / V3 买入上链（done）、Four 买入（bought）、自动打新已发出（mint，带交易哈希）。重启前的历史记录不算
const isWinEvent = (e) => !/重启前记录/.test(e.text || '')
  && ((['V2', 'V3'].includes(e.src) && e.type === 'done') || (e.src === 'Four' && e.type === 'bought') || (e.src === '打新' && e.type === 'mint' && e.txHash));
const winKey = (e) => `${e.src}|${e.at}|${e.type}|${e.token || ''}`;
const winSoundOn = () => FULL && $('#winSound')?.checked !== false; // 轻量版没有提示音（也就不在后台标签页里继续轮询）

/** 一段约 1.4 秒的上行琶音（C6 E6 G6 C7 再加高音和弦），音量比 V3 铃声大，连响两遍 */
function ringWin() {
  const c = audioCtx();
  if (!c || c.state !== 'running') return false;
  const t0 = c.currentTime;
  const notes = [[1047, 0], [1319, 0.1], [1568, 0.2], [2093, 0.3], [1568, 0.7], [2093, 0.8], [2637, 0.9]];
  for (const [freq, dt] of notes) {
    for (const [type, vol] of [['square', 0.16], ['triangle', 0.5]]) { // 方波加一点「亮度」，三角波撑起音量
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, t0 + dt);
      g.gain.exponentialRampToValueAtTime(vol, t0 + dt + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dt + (dt >= 0.9 ? 0.5 : 0.16));
      o.connect(g).connect(c.destination);
      o.start(t0 + dt);
      o.stop(t0 + dt + (dt >= 0.9 ? 0.52 : 0.18));
    }
  }
  return true;
}

/** 一次狙中：响两遍、标题闪 20 秒、toast；页面在后台时再弹系统通知 */
function announceWin(list) {
  const first = list[0];
  const text = list.length > 1 ? `${list.length} 笔狙击成功：${list.map((e) => `${e.src} ${e.text}`).join('；')}` : `${first.src} 狙击成功：${first.text}`;
  toast(`🎯 ${text}`);
  if (winSoundOn()) {
    const played = ringWin();
    setTimeout(() => ringWin(), 1700);
    if (!played) toast('狙中了，但浏览器还没允许播放声音：在页面上随便点一下，之后就能响', true);
  }
  const base = bell.title;
  let n = 0;
  clearInterval(state.winTitleTimer);
  const deadline = Date.now() + 20000; // 以绝对时间截止
  state.winTitleTimer = setInterval(() => {
    n += 1;
    if (Date.now() > deadline) { clearInterval(state.winTitleTimer); document.title = base; return; }
    document.title = n % 2 ? '🎯 狙中了！' : base;
  }, 700);
  if (document.hidden && winSoundOn() && 'Notification' in window && Notification.permission === 'granted') {
    try { new Notification('🎯 狙击成功', { body: text.slice(0, 180), tag: winKey(first) }); } catch { /* 部分浏览器不支持 */ }
  }
}

/** 每次刷新自动化状态时调用：只对「上次刷新之后新出现」的成功事件响（第一次加载只记下来，不响） */
function checkWins(events) {
  const seen = state.winSeen;
  const wins = (events || []).filter(isWinEvent);
  if (!seen) { state.winSeen = new Set(wins.map(winKey)); return; }
  const fresh = wins.filter((e) => !seen.has(winKey(e)));
  for (const e of wins) seen.add(winKey(e));
  if (seen.size > 500) state.winSeen = new Set(wins.map(winKey)); // 防止无限增长
  if (fresh.length) {
    announceWin(fresh);
    // 狙中后看板跟着更新（等几秒让交易上链、名次算得出来）
    if (state.view === 'snipe' && $('#sboardBox')?.open) setTimeout(loadSnipeBoard, 6000);
  }
}

function startBell() {
  if (bell.timer) return;
  bell.until = Date.now() + BELL_MAX_MS; // 以绝对时间截止，最多响 10 分钟
  const tick = () => {
    if (Date.now() > bell.until) { stopBell(); return; }
    const played = ringOnce();
    bell.flip = !bell.flip;
    document.title = bell.flip ? '🔔 gang V3 有新发现' : bell.title;
    const hint = $('#v3AlertHint');
    if (hint) hint.hidden = played;
  };
  tick();
  bell.timer = setInterval(tick, BELL_REPEAT_MS);
}

function stopBell() {
  clearInterval(bell.timer);
  bell.timer = null;
  document.title = bell.title;
}

function showV3Alert(fresh) {
  const latest = fresh[0];
  $('#v3AlertText').innerHTML = h`<b>${{ official: '官方来源', confirm: '需要去币安 App 确认', identity: '⚠ 钱包登录账号变了' }[latest.level] || '链上发现'}</b>：${latest.text}${fresh.length > 1 ? `（另有 ${fresh.length - 1} 条）` : ''}
    <span class="muted" id="v3AlertHint" hidden>（点一下页面任意位置即可播放铃声）</span>`;
  $('#v3Alert').hidden = false;
  state.v3Fresh = fresh;
  startBell();
}

function ackV3Alert() {
  const acked = readV3Acked();
  for (const a of state.v3Fresh || []) acked.add(v3AlertKey(a));
  try { localStorage.setItem(V3_ACK_KEY, JSON.stringify([...acked].slice(-100))); } catch { /* ignore */ }
  state.v3Fresh = [];
  $('#v3Alert').hidden = true;
  stopBell();
}

async function pollV3Alerts() {
  let s;
  try { s = await api('/api/gangv3/status'); } catch { return; }
  // 轻量版只用这里的提醒通道（例如登录账号变了的告警），不加载打新 / 狙击 / V3 发射台面板
  if (FULL && $('#view-quick')?.classList.contains('active')) {
    renderV3Status(s);
    loadFairStatus();
    if (state.fairAuto?.armed || $('#fairAutoBox')?.open) loadFairAuto();
    if (state.snipe?.armed || $('#snipeBox')?.open) loadSnipe();
  } else state.v3 = s;
  const acked = readV3Acked();
  const fresh = (s.alerts || []).filter((a) => !acked.has(v3AlertKey(a)));
  if (fresh.length) showV3Alert(fresh);
}

async function loadV3Status() {
  try { renderV3Status(await api('/api/gangv3/status')); } catch (err) { toast(err.message, true); }
}

function invalidateV3Verify() {
  state.v3Verified = null;
  $('#btnV3Enable').disabled = true;
  $('#v3Checks').innerHTML = '';
}

function v3Inputs() {
  const pad = $('#v3Pad').value.trim();
  const router = $('#v3Router').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(pad) || !/^0x[0-9a-fA-F]{40}$/.test(router)) throw new Error('请填写有效的 LaunchpadV3 与 GangRouter 地址');
  return { pad, router };
}

async function v3Verify() {
  let inp;
  try { inp = v3Inputs(); } catch (err) { return toast(err.message, true); }
  const btn = $('#btnV3Verify');
  setBusy(btn, true, '核验中…');
  try {
    const r = await api('/api/gangv3/verify', 'POST', inp);
    state.v3Verified = r.ok ? { ...inp } : null;
    $('#v3Checks').innerHTML = h`${r.ok ? h`<p class="muted">核验通过。启用前请再核对地址来源是否为 gang.fun 官方。</p>` : h`<p class="err">核验未通过（❌ 项），不能启用。</p>`}${v3ChecksHtml(r)}`;
    $('#btnV3Enable').disabled = !r.ok;
  } catch (err) {
    toast(err.message, true);
  } finally {
    setBusy(btn, false);
  }
}

async function v3Enable() {
  let inp;
  try { inp = v3Inputs(); } catch (err) { return toast(err.message, true); }
  if (!state.v3Verified || state.v3Verified.pad !== inp.pad || state.v3Verified.router !== inp.router) return toast('地址变了，请先重新核验', true);
  const c = state.v3?.candidate;
  const official = Boolean(c && c.pad.toLowerCase() === inp.pad.toLowerCase() && c.router.toLowerCase() === inp.router.toLowerCase());
  const ok = await confirmDialog(official ? '启用 gang V3 交易' : '启用 gang V3 交易（未与官方来源对上）', [
    ['LaunchpadV3', inp.pad],
    ['GangRouter', inp.router],
    ['地址来源', official ? '官方仓库 gangfun/gang-launchpad 主网配置（一致）' : (state.v3Source === 'chain' ? '链上发现（未经官方确认）' : '手动填写')],
    ['单笔买入上限', `${state.v3?.maxBuyBnb || '0.1'} BNB`],
  ], `${official ? '' : '这组地址没有和官方来源对上。V3 合约开源，任何人都能原样部署一套，链上核验同样会通过。点「确认」即表示你已从 gang.fun 官方渠道（官网 / @gangdotfun）逐字核对过这两个地址。'}gang V3 合约尚未经过外部审计；owner 可冻结内盘（毕业前无法卖出）。启用后每笔交易仍需你单独确认。`);
  if (!ok) return;
  try {
    renderV3Status(await api('/api/gangv3/enable', 'POST', { ...inp, attest: !official, confirm: 'ENABLE' }));
    toast('gang V3 已启用');
  } catch (err) {
    toast(err.message, true);
  }
}

async function v3Disable() {
  try { renderV3Status(await api('/api/gangv3/disable', 'POST', {})); toast('gang V3 已停用'); } catch (err) { toast(err.message, true); }
}

async function v3CheckNow() {
  const btn = $('#btnV3Check');
  setBusy(btn, true, '检查中…');
  try { renderV3Status(await api('/api/gangv3/check', 'POST', {})); } catch (err) { toast(err.message, true); } finally { setBusy(btn, false); }
}

/* ---------- gang 打新：核验 → 确认启用；打新 / 撤出 / 退款 / 领取都先出计划，确认后一键执行 ---------- */

function renderFairStatus(s) {
  state.fair = s;
  const box = $('#fairStatus');
  if (!box) return;
  const live = s.live;
  const statusText = s.enabled ? (live?.ok ? '已启用，复核通过' : '已启用，但最近一次复核未通过：已暂停打新') : '未启用';
  box.innerHTML = h`
    <div class="row"><span class="muted">状态</span><span>${statusText}</span></div>
    ${s.config ? h`<div class="row"><span class="muted">已配置</span><span class="mono">pad ${caHtml(s.config.pad)} · router ${caHtml(s.config.router)} · 来源 ${s.config.source || '—'}</span></div>` : ''}
    <div class="row"><span class="muted">主网监控</span><span>${s.watch.lastCheck ? `上次 ${new Date(s.watch.lastCheck).toLocaleTimeString()}` : '尚未检查'}${s.watch.lastError ? ` · 出错：${s.watch.lastError}` : ''} · 链上监听与 V3 共用 WSS</span></div>
    ${s.candidate ? h`
      <div class="row"><span class="muted">官方候选</span><span class="mono">pad ${caHtml(s.candidate.pad)} · router ${caHtml(s.candidate.router)}（${s.candidate.result.ok ? '核验通过' : '核验未通过'}）</span></div>
      <div class="actions"><button class="ghost" id="btnFairUseCandidate">填入官方地址</button></div>` : h`<div class="row"><span class="muted">候选</span><span>官方尚未公布主网地址</span></div>`}
    ${(s.chainCandidates || []).map((c) => h`<div class="row"><span class="muted">链上发现（未经官方确认）</span><span class="mono">${caHtml(c.pad)} · router ${c.router ? caHtml(c.router) : '等待 RouterSet'}${c.otherRouters?.length ? ` · 其它白名单路由 ${c.otherRouters.map(short).join(' / ')}（不参与交易）` : ''}</span></div>`)}
    ${live && !live.ok ? v3ChecksHtml(live) : ''}`;
  const use = $('#btnFairUseCandidate');
  if (use) {
    use.onclick = () => {
      $('#fairPad').value = s.candidate.pad;
      $('#fairRouter').value = s.candidate.router;
      saveField('fairPad'); saveField('fairRouter');
      invalidateFairVerify();
    };
  }
  $('#btnFairDisable').disabled = !s.enabled;
  if (!s.enabled) autoFillDeployment('fair', s);
}

/**
 * 检测到地址后自动填入并自动做一次只读核验（启用仍要你点「确认启用」）：
 * - 官方来源（GitHub 官方 CLI 主网配置）：直接填入，覆盖手填的值；
 * - 链上发现（可能是仿冒部署）：只在输入框为空、且没有官方候选时填入，确认框会标明「未经官方确认」。
 * 每个候选每次打开页面只自动填一次，你改掉之后不会再被覆盖。
 */
function autoFillDeployment(kind, s) {
  const ids = kind === 'fair' ? { pad: '#fairPad', router: '#fairRouter' } : { pad: '#v3Pad', router: '#v3Router' };
  const chainCand = (s.chainCandidates || []).find((c) => c.router);
  const cand = s.candidate ? { ...s.candidate, from: 'official' } : chainCand ? { ...chainCand, from: 'chain' } : null;
  if (!cand) return;
  const key = `${kind}:${cand.pad}:${cand.router}`.toLowerCase();
  state.autoFilled ??= new Set();
  if (state.autoFilled.has(key)) return;
  const padEl = $(ids.pad);
  const routerEl = $(ids.router);
  const empty = !padEl.value.trim() && !routerEl.value.trim();
  const same = padEl.value.trim().toLowerCase() === cand.pad.toLowerCase() && routerEl.value.trim().toLowerCase() === cand.router.toLowerCase();
  if (cand.from === 'chain' && !empty) return;
  state.autoFilled.add(key);
  if (!same) {
    padEl.value = cand.pad;
    routerEl.value = cand.router;
    saveField(padEl.id); saveField(routerEl.id);
    if (kind === 'v3') { state.v3Source = cand.from === 'chain' ? 'chain' : cand.source; invalidateV3Verify(); } else invalidateFairVerify();
    toast(`${kind === 'fair' ? 'gang 打新' : 'gang V3'}：已自动填入${cand.from === 'official' ? '官方' : '链上发现（未经官方确认）的'}地址，正在核验…`);
  }
  if (kind === 'fair') fairVerify(); else v3Verify();
}

/* ---------- 自动打新（预授权） ---------- */

function fairAutoConfig() {
  return {
    shares: ($('#fairAutoShares').value.trim() || 'max').toLowerCase(),
    maxPerSaleBnb: $('#fairAutoPerSale').value.trim(),
    totalBnb: $('#fairAutoTotal').value.trim(),
    maxSales: Number($('#fairAutoMaxSales').value.trim()),
    maxMintFeeBps: Number($('#fairAutoMintFee').value),
    maxExitFeeBps: Number($('#fairAutoExitFee').value),
    hours: Number($('#fairAutoHours').value.trim() || '4'),
  };
}

function renderFairAuto(s) {
  state.fairAuto = s;
  const a = s.arm;
  $('#fairAutoSummary').textContent = a ? `（${s.standby ? '待命：等打新启用' : '运行中'} · 已打 ${s.done}/${a.maxSales} 个 · 已花 ${s.spentBnb}/${a.totalBnb} BNB · ${whenText(a.expiresAt)} 到期）` : '（未开启）';
  // 仅在已预授权时用后端值回填表单，避免覆盖你正在填的参数
  if (a) {
    $('#fairAutoShares').value = String(a.shares);
    $('#fairAutoPerSale').value = a.maxPerSaleBnb;
    $('#fairAutoTotal').value = a.totalBnb;
    $('#fairAutoMaxSales').value = String(a.maxSales);
    $('#fairAutoMintFee').value = String(a.maxMintFeeBps);
    $('#fairAutoExitFee').value = String(a.maxExitFeeBps);
  }
  $('#btnFairAutoDisarm').disabled = !a;
  if (renderKeepScroll($('#fairAutoStatus'), h`
    ${a ? h`<div class="row"><span class="muted">监听</span><span>${s.source || '—'}${s.wsConnected ? ' · WSS 已连接' : ''}</span></div>
      <div class="row"><span class="muted">钱包</span><span>${walletNameOf(a.walletId)} · ${caHtml(a.wallet)}</span></div>` : ''}
    ${s.events.length ? evTableHtml(s.events, { limit: 20 }) : ''}`)) wireEvAddrs($('#fairAutoStatus'));
}

async function loadFairAuto() {
  try { renderFairAuto(await api('/api/fair/auto')); } catch { /* 旧后端 */ }
}

async function fairAutoArm() {
  const walletId = $('#quickWallet').value;
  if (!walletId) return toast('请先选择钱包', true);
  const c = fairAutoConfig();
  let l;
  try { l = await api(`/api/limits?walletId=${encodeURIComponent(walletId)}`); } catch (err) { return toast(err.message, true); }
  const walletName = (state.wallets || []).find((w) => w.id === walletId)?.name || walletId;
  const ok = await confirmDialog('预授权自动打新', [
    ['链', 'BSC（56）'],
    ['钱包', walletName],
    ['打新核心', state.fair?.enabled ? (state.fair.config?.pad || '—') : '还没启用：先待命，发现可信部署自动启用（或你手动启用）后自动开始'],
    ['只打', '预授权之后新创建、BNB 计价、有 Agent 准入的 sale（GangRouter 一笔完成）'],
    ['每个 sale 份数', c.shares === 'max' ? '尽量多（不超过 sale 上限与单个 sale 预算）' : `${c.shares} 份`],
    ['每个 sale 最多花', `${c.maxPerSaleBnb} BNB`],
    ['总预算 / 最多个数', `${c.totalBnb} BNB / ${c.maxSales} 个`],
    ['费率上限', `打新费 ≤ ${c.maxMintFeeBps / 100}% · 撤出费 ≤ ${c.maxExitFeeBps / 100}%`],
    ['全局上限', `单笔 ${l.maxBuyBnb} BNB · 每日 ${l.dailyBnb} BNB（今天已花 ${l.spentToday} BNB）`],
    ['有效期', `${c.hours} 小时`],
  ], '确认后，符合条件的新 sale 会被自动打新，不再逐笔确认。打新合约未经外部审计；打到的代币发射前锁定，撤出要扣撤出费且打新费不退。修改参数、到期、解除都会立即失效；服务重启后按原到期时间自动恢复（设置里可关闭）。');
  if (!ok) return;
  try {
    renderFairAuto(await api('/api/fair/auto/arm', 'POST', { walletId, config: c, confirm: 'ARM' }));
    toast('自动打新已开启');
  } catch (err) { toast(err.message, true); }
}

async function fairAutoDisarm() {
  try { renderFairAuto(await api('/api/fair/auto/disarm', 'POST', {})); toast('自动打新已解除'); } catch (err) { toast(err.message, true); }
}

/** 修改任意参数即解除（预授权是按确认时的参数生效的） */
function onFairAutoEdit() {
  if (state.fairAuto?.armed) fairAutoDisarm();
}

/* ---------- 浏览器插件配对（extension/）：生成配对密钥只显示一次；插件只能调用快捷交易接口 ---------- */
async function loadExtension() {
  const el = $('#extState');
  if (!el) return;
  $('#extBaseUrl').textContent = location.origin;
  try {
    const s = await api('/api/extension');
    el.textContent = s.paired ? `已配对 · 密钥 ${s.keyHint}` : '未配对';
    el.title = s.origins.join('\n');
    if (s.paired && !$('#extId').value) $('#extId').value = (s.origins[0] || '').replace('chrome-extension://', '');
    $('#btnExtRevoke').disabled = !s.paired;
  } catch { el.textContent = '后端是旧版本：重启 webui 后可用'; }
}

async function pairExtension() {
  const id = $('#extId').value.trim().replace(/^chrome-extension:\/\//, '').replace(/\/.*$/, '');
  if (!/^[a-p]{32}$/.test(id)) return toast('插件 ID 应该是 32 位小写字母（a~p），在插件设置页顶部可以复制', true);
  const ok = await confirmDialog('生成插件配对密钥', [
    ['插件', `chrome-extension://${id}`],
    ['插件能做什么', '识别 CA、报价、买入（直接买入已开启时直接买，否则先弹确认）、卖出（先确认）、查看钱包列表 / 上限 / 持仓'],
    ['插件不能做什么', '改设置 / 上限 / 预授权、转账、授权库存、合约调用、狙击'],
    ['旧密钥', '立即失效（同一时间只配对一个插件）'],
  ], '密钥只显示这一次，等同于这个控制台的快捷交易权限：只填到你自己的浏览器插件里，不要发给别人。');
  if (!ok) return;
  try {
    const r = await api('/api/extension/pair', 'POST', { extensionId: id, confirm: 'PAIR' });
    const box = $('#extKeyBox');
    box.hidden = false;
    box.innerHTML = h`<div class="row"><span class="muted">控制台地址</span><span class="mono">${location.origin}</span></div>
      <div class="row"><span class="muted">配对密钥</span><span class="mono ext-key">${r.key}</span></div>
      <div class="actions"><button type="button" class="primary" id="btnExtCopy">复制密钥</button></div>
      <p class="hint">填到插件设置页后点「测试连接」。关掉这个页面后密钥不会再显示，丢了就重新生成。</p>`;
    $('#btnExtCopy').onclick = async () => { try { await navigator.clipboard.writeText(r.key); toast('密钥已复制'); } catch { toast('复制失败，请手动选中复制', true); } };
    loadExtension();
  } catch (err) { toast(err.message, true); }
}

async function revokeExtension() {
  const ok = await confirmDialog('取消插件配对', [['影响', '插件立即不能再下单，需要重新生成密钥才能使用']], '');
  if (!ok) return;
  try { await api('/api/extension/revoke', 'POST', {}); $('#extKeyBox').hidden = true; toast('已取消配对'); loadExtension(); } catch (err) { toast(err.message, true); }
}

/* ---------- 新部署发现开关 / 后台任务清单 ---------- */
async function loadDiscovery() {
  try { renderDiscovery(await api('/api/discovery')); } catch { /* 旧后端 */ }
}
function renderDiscovery(d) {
  $('#discV3').checked = d.v3;
  $('#discFair').checked = d.fair;
  $('#discAuto').checked = d.autoEnable;
  const off = !d.v3 && !d.fair;
  $('#discState').textContent = off ? '已全部暂停（不订阅、不轮询）' : `${[d.v3 && 'V3', d.fair && '打新'].filter(Boolean).join(' + ')} 发现中${d.autoEnable ? ' · 可信时自动启用' : ' · 只提醒'}`;
}

async function loadBackground() {
  const box = $('#bgTasks');
  let r;
  try { r = await api('/api/system/background'); } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; return; }
  const on = (x) => h`<span class="pill ${x ? 'pill-green' : 'pill-muted'}">${x ? '● 运行中' : '○ 未运行'}</span>`;
  box.innerHTML = h`
    <h3 style="font-size:13px;margin:6px 0">WSS 订阅（${r.wss.connected ? `已连接${r.wss.rttMs != null ? ` · ${r.wss.rttMs}ms` : ''}` : '未连接'} · ${r.wss.subs.length} 个）</h3>
    ${r.wss.subs.length ? h`<table class="table"><thead><tr><th>用途</th><th>类型</th><th>合约</th><th>开始于</th></tr></thead><tbody>
      ${r.wss.subs.map((s) => h`<tr><td>${s.label}</td><td class="mono">${s.kind}${s.topics ? ` · ${s.topics} 个事件` : ''}</td><td class="mono" title="${s.address || ''}">${s.address ? caHtml(s.address) : '不限地址'}</td><td class="mono">${s.since ? evTime(s.since) : '—'}</td></tr>`)}
    </tbody></table>` : h`<p class="muted">没有订阅</p>`}
    ${wssRaceHtml(r.wss)}
    ${r.publicRpc ? h`<h3 style="font-size:13px;margin:14px 0 6px">非即时读取 → BSC 公共节点（不耗付费积分）</h3>
    <p class="muted" style="margin:0">${r.publicRpc.enabled ? h`本次启动以来：公共节点完成 <b>${r.publicRpc.public}</b> 次，回落到付费节点 <b>${r.publicRpc.fallback}</b> 次${Object.keys(r.publicRpc.byReason || {}).length ? `（${Object.entries(r.publicRpc.byReason).map(([k, v]) => `${k} ×${v}`).join('，')}）` : ''}。
      狙击 / 下单 / 报价 / 等回执仍走设置页的付费节点。` : '已关闭（环境变量 PUBLIC_RPC_56=off）'}</p>` : ''}
    <h3 style="font-size:13px;margin:14px 0 6px">服务端定时 HTTP 请求</h3>
    <table class="table"><thead><tr><th>任务</th><th>请求什么</th><th>多久一次</th><th>状态</th><th>为什么要</th></tr></thead><tbody>
      ${r.http.map((x) => h`<tr class="${x.active ? '' : 'muted'}"><td>${x.name}</td><td>${x.target}</td><td class="mono">${x.every}</td><td>${on(x.active)}</td><td class="muted">${x.why}</td></tr>`)}
    </tbody></table>
    <h3 style="font-size:13px;margin:14px 0 6px">网页打开时的轮询（每个打开的标签页各一份）</h3>
    <table class="table"><tbody>${r.browser.map((x) => h`<tr><td>${x.name}</td><td class="mono">${x.api}</td><td class="mono">${x.every}</td></tr>`)}</tbody></table>`;
}

async function loadFairStatus() {
  try { renderFairStatus(await api('/api/fair/status')); } catch { /* 旧后端没有这个接口 */ }
}

function invalidateFairVerify() {
  state.fairVerified = null;
  $('#btnFairEnable').disabled = true;
  $('#fairChecks').innerHTML = '';
}

function fairInputs() {
  const pad = $('#fairPad').value.trim();
  const router = $('#fairRouter').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(pad) || !/^0x[0-9a-fA-F]{40}$/.test(router)) throw new Error('请填写有效的 FairMintPad 与 GangRouter 地址');
  return { pad, router };
}

async function fairVerify() {
  let inp;
  try { inp = fairInputs(); } catch (err) { return toast(err.message, true); }
  const btn = $('#btnFairVerify');
  setBusy(btn, true, '核验中…');
  try {
    const r = await api('/api/fair/verify', 'POST', inp);
    state.fairVerified = r.ok ? { ...inp } : null;
    $('#fairChecks').innerHTML = h`${r.ok ? h`<p class="muted">核验通过。启用前请再核对地址来源是否为 gang.fun 官方。</p>` : h`<p class="err">核验未通过（❌ 项），不能启用。</p>`}${v3ChecksHtml(r)}`;
    $('#btnFairEnable').disabled = !r.ok;
  } catch (err) { toast(err.message, true); } finally { setBusy(btn, false); }
}

async function fairEnable() {
  let inp;
  try { inp = fairInputs(); } catch (err) { return toast(err.message, true); }
  if (!state.fairVerified || state.fairVerified.pad !== inp.pad || state.fairVerified.router !== inp.router) return toast('地址变了，请先重新核验', true);
  const c = state.fair?.candidate;
  const official = Boolean(c && c.pad.toLowerCase() === inp.pad.toLowerCase() && c.router.toLowerCase() === inp.router.toLowerCase());
  const ok = await confirmDialog(official ? '启用 gang 打新' : '启用 gang 打新（未与官方来源对上）', [
    ['FairMintPad', inp.pad],
    ['GangRouter', inp.router],
    ['地址来源', official ? '官方仓库 gangfun/gang-launchpad 打新主网配置（一致）' : '手动填写 / 链上发现'],
    ['买入上限', '打新计入「买入上限」的单笔 / 每日上限'],
  ], `${official ? '' : '这组地址没有和官方来源对上。合约开源，任何人都能原样部署一套，链上核验同样会通过。点「确认」即表示你已从 gang.fun 官方渠道逐字核对过这两个地址。'}打新合约尚未经过外部审计；owner 可冻结撤出 / 发射。启用后每笔操作仍需你单独确认。`);
  if (!ok) return;
  try {
    renderFairStatus(await api('/api/fair/enable', 'POST', { ...inp, attest: !official, confirm: 'ENABLE' }));
    toast('gang 打新已启用');
    fairList();
  } catch (err) { toast(err.message, true); }
}

async function fairDisable() {
  try { renderFairStatus(await api('/api/fair/disable', 'POST', {})); toast('gang 打新已停用'); } catch (err) { toast(err.message, true); }
}

async function fairCheckNow() {
  const btn = $('#btnFairCheck');
  setBusy(btn, true, '检查中…');
  try { renderFairStatus(await api('/api/fair/check', 'POST', {})); } catch (err) { toast(err.message, true); } finally { setBusy(btn, false); }
}

const fairLeft = (sec) => (sec > 3600 ? `${(sec / 3600).toFixed(1)} 小时` : `${Math.ceil(sec / 60)} 分钟`);

async function fairList() {
  const box = $('#fairSales');
  const walletId = $('#quickWallet')?.value || '';
  if (!state.fair?.enabled) { box.innerHTML = ''; return; }
  box.innerHTML = '<p class="muted">读取中…</p>';
  try {
    const r = await api(`/api/fair/sales?walletId=${encodeURIComponent(walletId)}`);
    box.innerHTML = h`<p class="muted">共 ${r.total} 个 sale，显示最近 ${r.rows.length} 个</p>
      <table class="table"><thead><tr><th>代币</th><th>状态</th><th>进度</th><th>每份</th><th>上限</th><th>我的份数</th><th>剩余</th><th></th></tr></thead><tbody>
      ${r.rows.map((x, i) => (x.error ? h`<tr><td class="mono">${caHtml(x.token)}</td><td colspan="7" class="warn">${x.error}</td></tr>` : h`<tr>
        <td class="mono">${x.symbol} ${caHtml(x.token)}</td><td>${x.statusText}</td><td>${x.sold}/${x.totalShares}</td>
        <td class="mono">${x.sharePriceText} ${x.quoteSymbol}</td><td>${x.capShares} 份</td><td>${x.myShares || '—'}</td>
        <td>${x.status === 'minting' ? fairLeft(x.secondsLeft) : '—'}</td>
        <td><button class="ghost" data-fair-pick="${i}">选择</button></td></tr>`))}
      </tbody></table>`;
    $$('#fairSales [data-fair-pick]').forEach((b) => {
      b.onclick = () => { $('#fairToken').value = r.rows[Number(b.dataset.fairPick)].token; saveField('fairToken'); fairInfo(); };
    });
  } catch (err) { box.innerHTML = h`<p class="err">${err.message}</p>`; }
}

function fairTokenInput() {
  const token = $('#fairToken').value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(token)) throw new Error('请填写 sale 的代币 CA');
  const walletId = $('#quickWallet').value;
  if (!walletId) throw new Error('请先选择钱包');
  return { token, walletId };
}

async function fairInfo() {
  let t;
  try { t = fairTokenInput(); } catch (err) { return toast(err.message, true); }
  const box = $('#fairDetail');
  try {
    const { sale: s, position: p } = await api(`/api/fair/sale?token=${t.token}&walletId=${encodeURIComponent(t.walletId)}`);
    state.fairSale = { s, p };
    const pct = (bps) => `${bps / 100}%`;
    box.hidden = false;
    box.innerHTML = h`
      <div class="row"><span class="muted">代币</span><span class="mono">${s.symbol} ${s.token}</span></div>
      <div class="row"><span class="muted">状态 / 进度</span><span>${s.statusText} · ${s.sold}/${s.totalShares} 份${s.status === 'minting' ? ` · 剩余 ${fairLeft(s.secondsLeft)}` : ''}</span></div>
      <div class="row"><span class="muted">每份 / 募集</span><span class="mono">${s.sharePriceText} ${s.quoteSymbol} · 共 ${s.raiseText} ${s.quoteSymbol}</span></div>
      <div class="row"><span class="muted">规则</span><span>单地址 ${s.capShares} 份 · 打新费 ${pct(s.mintFeeBps)} · 撤出费 ${pct(s.exitFeeBps)} · 出局线 ${pct(s.holdBps)}${s.gate ? ' · 需 Agent ID' : ' · 无准入（不能走路由）'}</span></div>
      ${p ? h`<div class="row"><span class="muted">我的份数</span><span>${p.shares} 份（${p.baselineText} 枚，已付打新费 ${p.feePaidText}）</span></div>` : ''}
      ${p?.reward ? h`
        <div class="row"><span class="muted">持有奖励</span><span>${p.reward === 'out' ? '⛔ 已出局（永久）' : `✅ 有资格 · 占奖励池 ${p.poolSharePct}%`}</span></div>
        <div class="row"><span class="muted">持仓 / 出局线</span><span class="mono">${p.balanceText} / ${p.holdLineText}（最多可卖 ${p.sellableBeforeOutText} 仍保留资格）</span></div>
        <div class="row"><span class="muted">待领奖励</span><span class="mono">${p.pendingText} ${s.quoteSymbol}</span></div>` : ''}`;
  } catch (err) { box.hidden = false; box.innerHTML = h`<p class="err">${err.message}</p>`; }
}

function fairMax() {
  const x = state.fairSale;
  if (!x) return toast('先点「查看」读取 sale', true);
  const room = Math.max(0, Math.min(x.s.capShares - (x.p?.shares || 0), x.s.totalShares - x.s.sold));
  $('#fairShares').value = String(room);
  saveField('fairShares');
}

const FAIR_PARTIAL_KEY = 'walletui:fairPartial';
const FAIR_TITLES = { mint: '确认打新', withdraw: '确认撤出', refund: '确认退款', claim: '确认领取奖励' };

async function fairAction(action, btn) {
  let t;
  try { t = fairTokenInput(); } catch (err) { return toast(err.message, true); }
  const shares = $('#fairShares').value.trim();
  if ((action === 'mint' || action === 'withdraw') && !/^\d+$/.test(shares)) return toast('请填写份数（整数）', true);
  setBusy(btn, true, '生成中…');
  let r;
  try {
    r = await api('/api/fair/plan', 'POST', { ...t, action, shares, allowPartial: $('#fairPartial').checked });
  } catch (err) {
    setBusy(btn, false);
    return toast(err.message, true);
  }
  setBusy(btn, false);
  if (!r.oneClick) return toast(r.steps[0]?.error || '第一步模拟未通过', true);
  const p = r.plan;
  const walletName = (state.wallets || []).find((w) => w.id === t.walletId)?.name || t.walletId;
  const rows = [
    ['链', 'BSC（56）'],
    ['钱包', h`${walletName} · ${caHtml(r.from)}`],
    ['代币', `${p.symbol} ${p.token}`],
    ['支付', p.pay.text],
    ['收到', p.receive.expected],
    ['路径', p.route],
    ...r.steps.map((s, i) => [`第 ${i + 1} 步`, `${quickKindLabel(s.kind)} · ${s.label}`]),
    ...(r.oneClick.bounds.approvals || []).map((a) => ['授权', h`${weiToHuman(a.amount)} → ${caHtml(a.spender)}（只授权本次数量）`]),
  ];
  const ok = await confirmDialog(FAIR_TITLES[action], rows, (p.warnings || []).join(' '));
  if (!ok) return;
  let job;
  try {
    job = await api('/api/quick/oneclick', 'POST', { walletId: t.walletId, bundleId: r.oneClick.bundleId, confirm: 'ONECLICK' });
  } catch (err) { return toast(err.message, true); }
  const box = $('#fairJob');
  box.hidden = false;
  const started = Date.now();
  const render = () => {
    const stateText = { running: '执行中…', done: '✅ 完成', failed: '⛔ 已停止' }[job.state] || job.state;
    box.innerHTML = h`<div class="row"><span class="muted">${FAIR_TITLES[action].replace('确认', '')}</span><span><b>${stateText}</b> · ${((Date.now() - started) / 1000).toFixed(1)} 秒</span></div>
      ${job.error ? h`<p class="err">${job.error}</p>` : ''}
      ${(job.steps || []).map((s) => h`<div class="row"><span>${quickKindLabel(s.kind)} · ${s.status}</span><span>${s.txHash ? txLinkHtml('56', s.txHash) : '—'}</span></div>`)}`;
  };
  render();
  while (job.state === 'running' && Date.now() - started < 200000) {
    await new Promise((res) => setTimeout(res, 700));
    try { job = await api(`/api/quick/oneclick/${encodeURIComponent(job.id)}`); } catch { /* 短暂失败继续轮询 */ }
    render();
  }
  fairInfo();
  loadLimits();
}

/* ---------- wiring ---------- */

function toggleFlapFields() {
  const op = $('#flapOp').value;
  $('#flapAmountWrap').hidden = op !== 'buy';
  $('#flapBpsWrap').hidden = op !== 'sell';
}

function wire() {
  // 轻量版裁掉了狙击 / 打新 / 发射台的元素：这里找不到的元素绑到占位元素上（见 $w），其余照常
  // 全量版不用占位：元素都在，拼错的 id 照常报错，方便发现绑定失败
  const $ = FULL ? (sel) => document.querySelector(sel) : $w; // eslint-disable-line no-shadow
  $('#wEvm').onclick = () => copyAddr('#wEvm');
  $('#wSol').onclick = () => copyAddr('#wSol');

  $$('.tab').forEach((tab) => {
    tab.onclick = () => {
      const v = tab.dataset.view;
      $$('.tab').forEach((t) => t.classList.toggle('active', t === tab));
      $$('.nav-group').forEach((g) => { g.classList.toggle('active', g.contains(tab)); g.classList.remove('open'); });
      $$('.view').forEach((x) => x.classList.toggle('active', x.id === `view-${v}`));
      history.replaceState(null, '', `#${v}`);
      state.view = v;
      if (v === 'history') loadHistory();
      if (v === 'settings') { loadSettings().catch(() => {}); loadBackground(); loadExtension(); }
      if (v === 'modules') loadModules();
      if (v === 'wallets') loadWalletAdmin();
      if (v === 'send') loadAddressBook();
      if (v === 'ai') loadAiHint();
      if (v === 'four') loadFour();
      if (v === 'quick') { loadQuick(); loadDeskHoldings(); loadAutomation(); }
      // 新页面（2026-10-27 布局重排）：各页只负责调用原来的加载函数，元素 id 都没变
      if (v === 'snipe') { loadSnipe(); loadV3Status(); loadSnipeStock(); if ($('#sboardBox')?.open) loadSnipeBoard(); }
      if (v === 'fairauto') { loadFairStatus(); loadFairAuto(); }
      if (v === 'holdings') { fillGmgnWallets(); loadGmgnStatus().then(() => loadGmgn()); loadXferTargets().then(loadAutoXfer); if (!state.xfer) xferLoad(false); }
      if (v === 'funds') { loadLimits(); loadArm(); loadInventory(); fillApproveWallets(); }
      if (v === 'launch') { loadDiscovery(); loadV3Status(); loadFairStatus().then(() => { if (state.fair?.enabled) fairList(); }); }
    };
  });
  // 发现开关：改了立即生效（服务端状态，不存 localStorage——页面只回显服务端当前值）
  for (const [id, key] of [['discV3', 'v3'], ['discFair', 'fair'], ['discAuto', 'autoEnable']]) {
    $(`#${id}`).onchange = async (e) => {
      try { renderDiscovery(await api('/api/discovery', 'POST', { [key]: e.target.checked })); toast('已保存，立即生效'); } catch (err) { toast(err.message, true); loadDiscovery(); }
    };
  }
  $('#btnBgRefresh').onclick = loadBackground;
  // 下拉分组：点按钮开 / 关，点别处关闭
  $$('.nav-group-btn').forEach((b) => {
    b.onclick = (e) => {
      e.stopPropagation();
      const g = b.closest('.nav-group');
      const was = g.classList.contains('open');
      $$('.nav-group').forEach((x) => x.classList.remove('open'));
      g.classList.toggle('open', !was);
    };
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.nav-group')) $$('.nav-group').forEach((x) => x.classList.remove('open')); });
  // 页内跳转链接：<button data-goto="holdings">
  document.addEventListener('click', (e) => {
    const g = e.target.closest('[data-goto]');
    if (g) gotoView(g.dataset.goto);
  });
  $('#btnKillAll').onclick = killAll;
  // 公网部署才有登录：显示「退出」
  if (document.querySelector('meta[name="auth-mode"]')?.content === 'public') {
    $('#btnLogout').hidden = false;
    $('#btnLogout').onclick = async () => {
      try { await fetch('/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' } }); } catch { /* 无论如何回登录页 */ }
      location.assign('/login');
    };
  }
  $('#btnDeskHoldRefresh').onclick = () => loadDeskHoldings();

  $('#tradeChain').onchange = () => {
    // 换链后合约地址不通用：清空已选代币，回到该链默认（原生币 → USDT）
    state.trade = { from: null, to: null };
    invalidateQuote();
    refreshTradeTokens().then(saveTokenSel);
  };
  $('#fromTokenBtn').onclick = () => chooseTradeToken('from');
  $('#toTokenBtn').onclick = () => chooseTradeToken('to');
  $('#btnFlip').onclick = flipTrade;
  $$('[data-pct]').forEach((b) => { b.onclick = () => setTradePercent(Number(b.dataset.pct)); });
  $$('[data-slip]').forEach((b) => {
    b.onclick = () => {
      $('#tradeSlippage').value = b.dataset.slip;
      saveField('tradeSlippage');
      syncSlippageButtons();
      invalidateQuote();
    };
  });
  $('#sendTokenBtn').onclick = chooseSendToken;
  $('#btnSendMax').onclick = () => {
    const v = amountByPercent($('#sendChain').value, state.send.token, 100);
    if (!v || v === '0') return toast('余额不足（原生币会预留 gas）', true);
    $('#sendAmount').value = v;
    saveField('sendAmount');
  };

  $('#btnQuote').onclick = getQuote;
  $('#btnSwap').onclick = doSwap;
  $('#btnSend').onclick = doSend;
  $('#btnAddrSave').onclick = saveAddress;
  $('#btnAddrDelete').onclick = deleteAddress;
  $('#addrBookSelect').onchange = (e) => {
    const entry = state.addresses.find((x) => x.id === e.target.value);
    if (!entry) return;
    $('#sendRecipient').value = entry.address;
    if (entry.chainId && entry.chainId !== $('#sendChain').value) applySendChain(entry.chainId);
    saveField('sendRecipient');
  };
  $('#sendChain').onchange = (e) => applySendChain(e.target.value);

  // 兑换数量变化 → 旧报价失效（代币 / 滑点 / 链的变化在各自处理函数里失效）
  $('#tradeAmount').addEventListener('input', (e) => { sanitizeAmountInput(e.target); invalidateQuote(); });
  $('#sendAmount').addEventListener('input', (e) => sanitizeAmountInput(e.target));

  // 合约调用参数变化 → 旧 preview 失效
  for (const id of ['#ccTo', '#ccValue', '#ccData']) $(id).addEventListener('input', invalidateCallPreview);
  $('#ccChain').addEventListener('change', invalidateCallPreview);

  $('#useBatchWallets').addEventListener('change', updateBatchHint);

  for (const id of FORM_FIELDS) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.addEventListener('change', () => saveField(id));
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.addEventListener('input', () => saveField(id));
    }
  }
  $('#btnPreview').onclick = previewCall;
  $('#btnExecute').onclick = executeCall;
  $('#btnRefreshSummary').onclick = () => loadSummary().catch((e) => toast(e.message, true));
  $('#btnRefreshBalance').onclick = loadBalance;
  $('#btnRefreshHistory').onclick = loadHistory;

  $('#flapOp').onchange = toggleFlapFields;
  $('#btnFlapPlan').onclick = () => flapPlan();

  $('#btnAiParse').onclick = aiParse;
  $('#btnAiSaveModule').onclick = saveCurrentModule;
  $('#btnModulesRefresh').onclick = loadModules;
  $('#btnModulesExport').onclick = exportModules;
  $('#btnModulesImport').onclick = () => $('#modulesFile').click();
  $('#modulesFile').onchange = (e) => { if (e.target.files[0]) importModules(e.target.files[0]); };
  $('#btnMetricsRefresh').onclick = loadMetrics;
  $$('.period-btn').forEach((b) => {
    b.onclick = () => {
      state.metricsPeriod = b.dataset.period;
      try { localStorage.setItem('walletui:metricsPeriod', state.metricsPeriod); } catch { /* ignore */ }
      loadMetrics();
    };
  });
  $('#btnWalletRefresh').onclick = loadWalletAdmin;
  $('#btnWalletAdd').onclick = addWallet;
  $('#loginClose').onclick = () => $('#loginDialog').close();
  $('#btnAiClear').onclick = () => {
    // 连同步骤与已生成的 preview 一起清掉，避免清空后仍能点到旧计划的「执行」
    $('#aiText').value = '';
    saveField('aiText');
    $('#aiResult').hidden = true;
    $('#aiChecks').innerHTML = '';
    $('#aiSteps').innerHTML = '';
    $('#aiLatency').textContent = '';
    $('#btnAiSaveModule').disabled = true;
    state.agent = null;
    state.agentResult = null;
  };

  $('#btnRpcSave').onclick = saveRpc;
  $$('[data-test-chain]').forEach((b) => {
    b.onclick = () => testRpc(b.dataset.testChain);
  });
  $('#btnAiSave').onclick = saveAi;
  $('#btnAiKeyClear').onclick = clearAiKey;
  $('#btnTestWss').onclick = testWssNode;
  $('#btnClearWss').onclick = clearWssNode;
  $('#setWssDual').onchange = toggleWssDual;
  $$('[data-clear-chain]').forEach((b) => { b.onclick = () => clearRpcNode(b.dataset.clearChain); });
  $$('[data-add-alt]').forEach((b) => { b.onclick = () => addAltNode(b.dataset.addAlt); });

  $('#btnFourSaveCfg').onclick = saveFourConfig;
  $('#btnFourStart').onclick = fourStart;
  $('#btnFourStop').onclick = fourStop;
  $('#btnFourArm').onclick = fourArm;
  $('#btnFourDisarm').onclick = fourDisarm;
  $('#btnFourDry').onclick = fourDryRun;
  $('#btnFourInspect').onclick = fourInspect;
  $('#btnFourPlan').onclick = fourTradePlan;
  $('#btnFourHoldings').onclick = loadFourHoldings;
  $('#fourTradeSide').onchange = () => {
    // 卖出不需要「买入按」；置灰避免误解（值仍保留，切回买入可用）
    const sell = $('#fourTradeSide').value === 'sell';
    $('#fourTradeMode').disabled = sell;
    $('#fourTradeMode').closest('label')?.classList.toggle('muted', sell);
  };
  $('#fourTradeSide').onchange();
  $('#btnFourClearLog').onclick = clearFourLog;
  $('#btnApprovePreview').onclick = approvePreview;
  $('#btnApproveExec').onclick = approveExec;

  // 快捷交易：参数一变，旧计划（含已 preview 的 requestId）立即作废，防止按旧报价执行
  $('#btnQuickDetect').onclick = quickDetect;
  $('#btnQuickBuy').onclick = () => quickBuyClick();
  $('#btnArm').onclick = armQuick;
  $('#btnDisarm').onclick = disarmQuick;
  // 「服务重启后自动恢复预授权」：以服务端设置为准（不进 localStorage，避免两台机器 / 两个浏览器不一致）
  $('#resumeArms').onchange = async (e) => {
    const want = e.target.checked;
    try {
      await api('/api/automation/resume', 'POST', { enabled: want });
      toast(want ? '已开启：服务重启后自动恢复预授权' : '已关闭：服务重启后预授权全部失效');
    } catch (err) { e.target.checked = !want; toast(err.message, true); }
    loadResumeSetting();
  };
  loadResumeSetting();
  $('#autoApprove').onchange = toggleAutoApprove;
  loadAutoApprove();
  $('#quickWallet').addEventListener('change', loadArm);
  // 买入记录 + 钱包锁定：跟着顶部钱包走
  $('#quickWallet').addEventListener('change', () => { loadWalletLock(); loadBuyRecords(); });
  try { $('#quickBuysShowEmpty').checked = localStorage.getItem(BUYS_EMPTY_KEY) === '1'; } catch { /* ignore */ }
  $('#quickBuysShowEmpty').addEventListener('change', (e) => {
    try { localStorage.setItem(BUYS_EMPTY_KEY, e.target.checked ? '1' : '0'); } catch { /* ignore */ }
    renderBuyRecords();
  });
  $('#btnQuickBuysRefresh').onclick = loadBuyRecords;
  $('#quickBuysBox').addEventListener('toggle', () => { if ($('#quickBuysBox').open) loadBuyRecords(); });
  $('#btnQuickSell').onclick = () => quickPlan('sell');
  $$('[data-quick-sell]').forEach((b) => {
    b.onclick = () => {
      $('#quickSellAmount').value = b.dataset.quickSell;
      saveField('quickSellAmount');
      quickPlan('sell');
    };
  });
  for (const sel of QUICK_CA_INPUTS) $(sel).addEventListener('input', onQuickCaInput);
  $('#quickOneClick').addEventListener('change', (e) => {
    try { localStorage.setItem(QUICK_ONECLICK_KEY, e.target.checked ? '1' : '0'); } catch { /* ignore */ }
    if (state.quick) renderQuickPlan();
  });
  $('#quickSlip').addEventListener('change', () => { syncQuickSlipCustom(); clearQuickPlan(); });
  $('#quickSlipCustom').addEventListener('input', clearQuickPlan);
  $('#quickBuyAmount').addEventListener('input', clearQuickPlan);
  $('#quickSellAmount').addEventListener('input', clearQuickPlan);
  $('#quickPresets').addEventListener('change', renderQuickPresets);

  $('#btnLimitsSave').onclick = saveLimits;
  try { const v = localStorage.getItem(SNIPE_VENUE_KEY); if (v === 'v2' || v === 'v3') $('#snipeVenue').value = v; } catch { /* ignore */ }
  $('#snipeVenue').addEventListener('change', () => {
    try { localStorage.setItem(SNIPE_VENUE_KEY, snipeVenue()); } catch { /* ignore */ }
    loadSnipeForm(snipeVenue()); // V2 / V3 各有一份参数：换成新发射台那份（没存过就由 renderSnipe 用后端值回填）
    loadSnipe();
  });
  try { state.gmgnTab = localStorage.getItem(GMGN_TAB_KEY) || 'holdings'; } catch { state.gmgnTab = 'holdings'; }
  $$('#gmgnBox [data-gmgn-tab]').forEach((b) => { b.onclick = () => loadGmgn(b.dataset.gmgnTab); });
  $('#btnGmgnRefresh').onclick = () => loadGmgn();
  try { const v = localStorage.getItem(GMGN_HIDE_SMALL_KEY); if (v != null) $('#gmgnHideSmall').checked = v === '1'; } catch { /* ignore */ }
  $('#gmgnHideSmall').addEventListener('change', () => {
    try { localStorage.setItem(GMGN_HIDE_SMALL_KEY, $('#gmgnHideSmall').checked ? '1' : '0'); } catch { /* ignore */ }
    loadGmgn();
  });
  $('#btnGmgnSaveKey').onclick = gmgnSaveKey;
  $('#btnGmgnKeygen').onclick = gmgnKeygen;
  $('#gmgnBox').addEventListener('toggle', () => { if ($('#gmgnBox').open) { fillGmgnWallets(); loadGmgnStatus().then(() => loadGmgn()); } });
  $('#gmgnWallet').addEventListener('change', () => { try { localStorage.setItem(GMGN_WALLET_KEY, $('#gmgnWallet').value); } catch { /* ignore */ } loadGmgn(); });
  $('#gmgnAddress').addEventListener('change', () => loadGmgn());
  $('#btnSnipeArm').onclick = snipeArm;
  $('#btnSnipeDisarm').onclick = snipeDisarm;
  $('#btnSnipeCopyV2').onclick = snipeCopyV2;
  $('#btnSnipeModes').onclick = () => loadSnipeModes(true);
  $('#snipeBox').addEventListener('toggle', () => { if ($('#snipeBox').open) loadSnipe(); });
  for (const id of SNIPE_FIELDS) { $(`#${id}`).addEventListener('input', () => { saveSnipeForm(); onSnipeEdit(); }); }
  $('#snipeAmountMode').addEventListener('change', () => { syncSnipeAmountLabel(); saveSnipeForm(); onSnipeEdit(); });
  $('#snipeGasMode').addEventListener('change', () => { syncGasMode('snipe'); saveSnipeForm(); onSnipeEdit(); });
  $('#fourGasMode').addEventListener('change', () => syncGasMode('four'));
  if (FULL) restoreSnipeFilters();
  for (const id of ['#snipeTaxed', '#snipePool', '#snipeSkipNoStock', '#snipeAutoSell', '#snipeNewMode']) $(id).addEventListener('change', () => { saveSnipeFilters(); onSnipeEdit(); syncSnipePoolHint(); });
  if (FULL) syncSnipePoolHint();
  $('#btnSnipeDenyAdd').onclick = snipeDenyAdd;
  $('#btnSnipeStock').onclick = loadSnipeStock;
  $('#btnExtPair').onclick = pairExtension;
  $('#btnExtRevoke').onclick = revokeExtension;
  // 狙击看板：改筛选 / 刷新 / 展开时重新读
  for (const id of ['#sboardDays', '#sboardWallet', '#sboardSrc']) $(id).addEventListener('change', loadSnipeBoard);
  $('#btnSboardRefresh').onclick = loadSnipeBoard;
  $('#sboardBox').addEventListener('toggle', () => { if ($('#sboardBox').open && state.view === 'snipe') loadSnipeBoard(); });
  $('#snipeDenyInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); snipeDenyAdd(); } });
  $('#btnXferLoad').onclick = () => xferLoad(true);
  $('#btnXferGo').onclick = xferGo;
  $('#btnXferAddTarget').onclick = xferAddTarget;
  $('#btnXferDelTarget').onclick = xferDelTarget;
  $('#btnAxArm').onclick = axArm;
  $('#btnAxAdd').onclick = axAddTokens;
  $('#btnAxDisarm').onclick = axDisarm;
  for (const id of ['#axV2', '#axV3', '#axFair', '#axAutoAdd', '#axTarget']) $(id).addEventListener('change', axSave);
  $('#autoXferBox').addEventListener('toggle', () => { if ($('#autoXferBox').open) loadXferTargets().then(loadAutoXfer); });
  $('#xferTarget').addEventListener('change', () => { try { localStorage.setItem(XFER_TARGET_KEY, $('#xferTarget').value); } catch { /* ignore */ } });
  $('#xferBox').addEventListener('toggle', () => { if ($('#xferBox').open) { loadXferTargets(); if (!state.xfer) xferLoad(false); } });
  $('#quickWallet').addEventListener('change', () => { state.xfer = null; if ($('#xferBox').open) xferLoad(false); });
  $('#btnInvAdd').onclick = invAdd;
  $('#btnInvCap').onclick = invSaveCap;
  $('#btnInvRefresh').onclick = loadInventory;
  $('#btnInvApprove').onclick = () => invApproveLoad('approve');
  $('#btnInvRevokeAll').onclick = () => invApproveLoad('revoke');
  // 选中格子后的操作面板（读当前选中的「报价币 × 平台」）
  $('#btnInvStock').onclick = (e) => { const x = invSelRow(); if (x) invPlan(x, 'stock', e.currentTarget); };
  $('#btnInvSync').onclick = (e) => { const x = invSelRow(); if (x) invPlan(x, 'sync', e.currentTarget); };
  $('#btnInvRevoke').onclick = (e) => { const x = invSelRow(); if (x) invPlan(x, 'revoke', e.currentTarget); };
  $('#btnInvRemove').onclick = () => { const x = invSelRow(); if (x) invRemove(x); };
  $('#invHelpLink').onclick = (e) => {
    e.preventDefault();
    const help = $('#invHelp');
    help.hidden = !help.hidden;
    e.currentTarget.textContent = help.hidden ? '展开说明' : '收起说明';
  };
  renderInvPanel();
  $('#quickWallet').addEventListener('change', loadInventory);
  $('#invBox').addEventListener('toggle', () => { if ($('#invBox').open) loadInventory(); });
  $('#routeBox').addEventListener('toggle', () => { if ($('#routeBox').open) loadRoutes(); });
  $('#btnRouteRefresh').onclick = loadRoutes;
  $('#btnRouteImport').onclick = importRoutes;
  $('#routeTable').onclick = (e) => {
    const b = e.target.closest('[data-route-act]');
    if (b) routeAction(b.dataset.routeAct, b.dataset.pair, b.dataset.path);
  };
  $('#quickWallet').addEventListener('change', loadLimits);
  $('#btnV3Check').onclick = v3CheckNow;
  $('#btnV3Verify').onclick = v3Verify;
  $('#btnFairCheck').onclick = fairCheckNow;
  $('#btnFairVerify').onclick = fairVerify;
  $('#btnFairEnable').onclick = fairEnable;
  $('#btnFairDisable').onclick = fairDisable;
  $('#fairPad').addEventListener('input', invalidateFairVerify);
  $('#fairRouter').addEventListener('input', invalidateFairVerify);
  $('#btnFairList').onclick = fairList;
  $('#btnFairInfo').onclick = fairInfo;
  $('#btnFairMax').onclick = fairMax;
  $('#btnFairMint').onclick = () => fairAction('mint', $('#btnFairMint'));
  $('#btnFairWithdraw').onclick = () => fairAction('withdraw', $('#btnFairWithdraw'));
  $('#btnFairRefund').onclick = () => fairAction('refund', $('#btnFairRefund'));
  $('#btnFairClaim').onclick = () => fairAction('claim', $('#btnFairClaim'));
  // 复选框单独用 localStorage key 持久化（项目前端约定）
  try { $('#fairPartial').checked = localStorage.getItem(FAIR_PARTIAL_KEY) === '1'; } catch { /* ignore */ }
  $('#fairPartial').addEventListener('change', () => { try { localStorage.setItem(FAIR_PARTIAL_KEY, $('#fairPartial').checked ? '1' : '0'); } catch { /* ignore */ } });
  $('#btnFairAutoArm').onclick = fairAutoArm;
  $('#btnFairAutoDisarm').onclick = fairAutoDisarm;
  $('#fairAutoBox').addEventListener('toggle', () => { if ($('#fairAutoBox').open) loadFairAuto(); });
  for (const id of ['fairAutoShares', 'fairAutoPerSale', 'fairAutoTotal', 'fairAutoMaxSales', 'fairAutoMintFee', 'fairAutoExitFee', 'fairAutoHours']) {
    $(`#${id}`).addEventListener('input', onFairAutoEdit);
    $(`#${id}`).addEventListener('change', onFairAutoEdit);
  }
  $('#quickWallet').addEventListener('change', () => { if (state.fairAuto?.armed && state.fairAuto.arm.walletId !== $('#quickWallet').value) toast('自动打新仍在用预授权时的钱包运行；要换钱包请先解除', true); });
  $('#btnV3Enable').onclick = v3Enable;
  $('#btnV3Disable').onclick = v3Disable;
  $('#btnV3Bell').onclick = () => unlockAudio().then(() => { if (!ringOnce()) toast('浏览器没有允许播放声音，请检查标签页是否静音', true); });
  $('#btnV3AlertAck').onclick = () => { unlockAudio(); ackV3Alert(); };
  $('#btnV3AlertView').onclick = () => {
    unlockAudio();
    gotoView('launch'); // gang V3 在「发射台」页
    $('#v3Status')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  // 狙中提示音开关（默认开，存本机）；开启时顺便申请系统通知权限（页面在后台时用）
  try { $('#winSound').checked = localStorage.getItem(WIN_SOUND_KEY) !== '0'; } catch { /* ignore */ }
  $('#winSound').addEventListener('change', (e) => {
    try { localStorage.setItem(WIN_SOUND_KEY, e.target.checked ? '1' : '0'); } catch { /* ignore */ }
    if (e.target.checked) {
      unlockAudio().then(() => ringWin());
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
    }
  });
  $('#btnWinTest').onclick = () => unlockAudio().then(() => {
    if (!ringWin()) return toast('浏览器没有允许播放声音，请检查标签页是否静音', true);
    setTimeout(() => ringWin(), 1700);
    if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
  });
  document.addEventListener('pointerdown', unlockAudio);
  document.addEventListener('keydown', unlockAudio);
  for (const id of ['#v3Pad', '#v3Router']) {
    $(id).addEventListener('input', () => { state.v3Source = null; invalidateV3Verify(); });
  }
}

async function boot() {
  wireCopy();
  wire();
  fillChainSelects();
  restoreFormState();
  toggleFlapFields();
  loadAiHint();
  loadAddressBook();
  try {
    state.wallets = await api('/api/wallets');
    renderWalletTabs();
    restoreSelectedWallets();
    let lastWallet = null;
    try { lastWallet = localStorage.getItem('walletui:lastWallet'); } catch { /* ignore */ }
    const startId = state.wallets.some((w) => w.id === lastWallet) ? lastWallet : state.wallets[0].id;
    await selectWallet(startId);
    fillQuickWallets(); // 状态条上的「操作钱包」不管停在哪个页面都要有选项
    const initial = location.hash.slice(1);
    const tab = initial && document.querySelector(`.tab[data-view="${initial}"]`);
    (tab || document.querySelector('.tab[data-view="quick"]')).click(); // 默认打开交易台
    loadAutomation();
  } catch (err) {
    toast(`初始化失败：${err.message}`, true);
  }
}

boot();

setInterval(() => {
  if (state.active) loadMetrics().catch(() => {});
}, 30000);

// gang V3 发现提醒：不论在哪个标签页都轮询（服务端 WSS 实时发现，网页 15 秒内响铃）
pollV3Alerts();
setInterval(pollV3Alerts, V3_POLL_MS);

// 全局状态条：每 4 秒刷新一次（只读内存状态，很轻）；页面在后台时跳过
// 开着狙中提示音时页面在后台也照常刷新（否则切到别的标签页就听不到；浏览器对后台标签的定时器会降频，最慢约 1 分钟一次）
setInterval(() => { if (!document.hidden || winSoundOn()) loadAutomation(); }, 4000);

// 后端代码更新了但服务没重启：顶部提示（之前出现过页面是新的、后端还是旧的）
async function checkServerStale() {
  try {
    const v = await api('/api/version');
    let bar = $('#staleBar');
    if (v.stale && !bar) {
      bar = document.createElement('div');
      bar.id = 'staleBar';
      bar.className = 'v3-alert';
      bar.innerHTML = h`<span class="v3-alert-icon">⚠️</span><div class="v3-alert-text">后端代码已更新，但服务还在跑旧版本：请关闭 webui 窗口后重新运行 <span class="mono">webui\\start.cmd</span>，再刷新页面。</div>`;
      document.body.prepend(bar);
    }
  } catch { /* 旧版本服务没有 /api/version：无法判断，忽略 */ }
}
checkServerStale();
setInterval(checkServerStale, 60000);
