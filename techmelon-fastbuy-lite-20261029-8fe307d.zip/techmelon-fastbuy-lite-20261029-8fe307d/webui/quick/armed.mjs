/**
 * 一键买入「预授权」（arm）：用户对一份策略确认一次，之后在有效期内点金额直接买入，不再逐笔弹确认框。
 *
 * 规则（docs/AUTOMATION_RULES.md 硬性规则 3 的例外，同 Four 狙击的 arm）：
 * - 必须先设好「单笔上限」和「每日上限」（都 > 0），预授权按当时的上限生效；
 * - 策略：钱包、单笔上限、最大滑点、有效期（默认 4 小时，最长 24 小时）；
 * - 每笔直接买入仍然走完整链路：计划 → 币安预览 → 一键执行上限复核（步骤 / BNB / 授权 / 最少收到）→ 每日上限；
 * - 解除条件：修改上限、到期、手动解除、服务重启（只存在内存里）。
 * - 只支持买入；卖出仍逐笔确认。
 */
import { getLimits, toWei, fromWei } from '../limits.mjs';
import { journal } from '../journal.mjs';
import { MAX_SLIPPAGE_BPS } from '../agent/guard.mjs';
import { saveArm, clearArm, limitsSig } from '../arms.mjs';

const DEFAULT_HOURS = 4;
const MAX_HOURS = 24;
const arms = new Map(); // walletId → 策略

export function armStatus(walletId) {
  const a = arms.get(walletId);
  if (!a) return { armed: false };
  if (Date.now() > a.expiresAt) { arms.delete(walletId); clearArm(`direct:${walletId}`); journal('arm.expired', { walletId }); return { armed: false, expired: true }; }
  return { armed: true, ...publicArm(a) };
}

/** 有没有任何钱包开着（且未过期的）直接买入预授权（服务「是否在用」判断用） */
export function anyArmed() {
  const now = Date.now();
  for (const a of arms.values()) if (now <= a.expiresAt) return true;
  return false;
}

function publicArm(a) {
  return {
    walletId: a.walletId, maxBuyBnb: fromWei(a.maxBuyWei), dailyBnb: fromWei(a.dailyWei), maxSlippageBps: a.maxSlippageBps,
    armedAt: new Date(a.armedAt).toISOString(), expiresAt: new Date(a.expiresAt).toISOString(),
  };
}

export async function arm({ walletId, maxSlippageBps, hours }) {
  const limits = await getLimits();
  const maxBuyWei = toWei(limits.maxBuyBnb);
  const dailyWei = toWei(limits.dailyBnb);
  if (maxBuyWei === 0n || dailyWei === 0n) {
    throw new Error('开启直接买入前，必须先在「买入上限」里设好单笔上限和每日上限（都要大于 0）');
  }
  const slip = Number(maxSlippageBps);
  if (!Number.isInteger(slip) || slip <= 0 || slip > MAX_SLIPPAGE_BPS) throw new Error(`最大滑点需要在 0.01%~${MAX_SLIPPAGE_BPS / 100}% 之间`);
  const h = hours == null ? DEFAULT_HOURS : Number(hours);
  if (!(h > 0 && h <= MAX_HOURS)) throw new Error(`有效期需要在 0~${MAX_HOURS} 小时之间`);
  const now = Date.now();
  const a = { walletId, maxBuyWei, dailyWei, maxSlippageBps: slip, armedAt: now, expiresAt: now + h * 3600 * 1000 };
  arms.set(walletId, a);
  saveArm(`direct:${walletId}`, { walletId, maxSlippageBps: slip, armedAt: now, expiresAt: a.expiresAt, limits: limitsSig(limits) }); // 异步落盘，不阻塞
  journal('arm.on', { walletId, maxBuyBnb: fromWei(maxBuyWei), dailyBnb: fromWei(dailyWei), maxSlippageBps: slip, hours: h });
  return armStatus(walletId);
}

/** 服务重启后恢复（见 arms.mjs）：不顺延有效期；上限变过就不恢复。返回恢复结果说明 */
export async function resumeDirect(saved) {
  const limits = await getLimits();
  if (Date.now() > saved.expiresAt) return { ok: false, why: '已过期' };
  if (saved.limits !== limitsSig(limits)) return { ok: false, why: '买入上限已改过' };
  const slip = Number(saved.maxSlippageBps);
  if (!Number.isInteger(slip) || slip <= 0 || slip > MAX_SLIPPAGE_BPS) return { ok: false, why: '滑点无效' };
  arms.set(saved.walletId, {
    walletId: saved.walletId, maxBuyWei: toWei(limits.maxBuyBnb), dailyWei: toWei(limits.dailyBnb),
    maxSlippageBps: slip, armedAt: saved.armedAt, expiresAt: saved.expiresAt,
  });
  journal('arm.resume', { walletId: saved.walletId, expiresAt: new Date(saved.expiresAt).toISOString() });
  return { ok: true };
}

export function disarm(walletId, reason = 'manual') {
  if (arms.delete(walletId)) journal('arm.off', { walletId, reason });
  clearArm(`direct:${walletId}`);
  return { armed: false };
}

/** 上限一改，所有钱包的预授权立即失效（预授权是按当时的上限确认的） */
export function disarmAll(reason) {
  for (const id of [...arms.keys()]) disarm(id, reason);
}

/** 直接买入前的检查：已预授权、未过期、金额 / 滑点在策略内 */
export function assertArmed(walletId, { amountWei, slippageBps }) {
  const s = armStatus(walletId);
  if (!s.armed) throw new Error(s.expired ? '直接买入的预授权已到期，请重新开启' : '该钱包没有开启直接买入（需要先预授权一次）');
  const a = arms.get(walletId);
  if (amountWei > a.maxBuyWei) throw new Error(`金额超过预授权的单笔上限 ${fromWei(a.maxBuyWei)} BNB`);
  if (Number(slippageBps) > a.maxSlippageBps) throw new Error(`滑点 ${Number(slippageBps) / 100}% 超过预授权的最大滑点 ${a.maxSlippageBps / 100}%`);
}
