/**
 * 直连币安 Agentic Wallet 接口：contract-call preview / execute 不再每次 spawn 一个 baw 进程。
 *
 * 请求与 baw CLI（@binance/agentic-wallet 1.11.0，dist/index.js 里的 E.request）完全一致：
 *   - 同一个地址 https://www.binance.com + 同一组接口（只开放下面 ENDPOINTS 白名单里的几个）；
 *   - 同一组请求头（agentClientId / agentClientMac / agentClientType=AGENT_CLI / 版本号取 CLI 自己的 package.json）；
 *   - 同一份会话：读各钱包目录下的 session.json，按 CLI 的算法解密（aes-256-gcm，密钥由本机 MAC 派生）。
 * 与 CLI 的差别只有两点：
 *   1. 进程常驻 + HTTPS 长连接（省掉 node 启动约 0.25 秒和 TLS 握手约 0.2 秒，每次调用都省）；
 *   2. 只读不写：不改 session.json、不采纳响应里轮换的 Cookie（CLI 普通命令也只放在内存里、进程结束即丢），
 *      会话失效时不清除本地会话（交给用户用 wrapper 重新登录）。
 *
 * 错误分三类（err.stage），调用方据此决定能不能退回 CLI：
 *   - 'local'  ：请求还没发出去（会话读不到 / 解密失败 / 未登录）→ 可以安全地退回 CLI；
 *   - 'network'：请求可能已经到了币安（超时 / 断线 / 非 2xx / 响应不是 JSON）→ execute 必须按「可能已广播」处理，绝不重试；
 *   - 'api'    ：币安明确返回了错误码（模拟失败、余额不足、会话失效等）→ 是真实答复，不重试。
 */
import https from 'node:https';
import os from 'node:os';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import { createDecipheriv, pbkdf2Sync, randomBytes } from 'node:crypto';
import { CLI_ENTRY } from './wallets.mjs';

const HOST = 'www.binance.com';
const ENDPOINTS = {
  preview: '/bapi/defi/v1/public/wallet-direct/agent-wallet/contract-call/preview',
  execute: '/bapi/defi/v1/public/wallet-direct/agent-wallet/contract-call/execute',
  authQuery: '/bapi/defi/v1/public/wallet-direct/agent-wallet/login/query', // 只读：自检用
};
const PING_PATH = '/bapi/defi/v1/public/wallet-direct/mgmt/agent/networks/active'; // 公开接口，不带会话，只用来保活连接
const PING_MS = 15000;
const IDLE_MS = 20000; // 空闲连接 20 秒就本地关掉（比服务端先关），避免复用到已被对端关闭的连接（execute 会被误判为「可能已广播」）
const OK_CODE = '000000';
const SESSION_INVALID = '100001005';
// 常见错误码的中文提示（351808 实测：会话登录的账号和 from 地址对不上时也是这个码，2026-10-27 两个钱包扫码登反）
const API_HINTS = {
  [SESSION_INVALID]: '（登录已失效：用对应 wrapper 重新登录）',
  351808: '（参数被拒：最常见是该钱包登录的币安账号和发送地址对不上，检查是否扫错了码）',
};

// 与 CLI 相同的本地加密参数
const ALGO = 'aes-256-gcm';
const IV_LEN = 16;
const TAG_LEN = 16;
const KEY_LEN = 32;
const ITER = 100000;
const SALT_PREFIX = 'baw-agentic-wallet-v1';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// timeout：空闲 socket 超时后 Agent 会销毁它；进行中的请求另有 req.setTimeout 覆盖。保活 ping 每 15 秒一次，主连接一直是热的
const agent = new https.Agent({ keepAlive: true, keepAliveMsecs: 10000, maxSockets: 16, timeout: IDLE_MS });

class DirectError extends Error {
  constructor(stage, message, extra = {}) {
    super(message);
    this.stage = stage;
    Object.assign(this, extra);
  }
}

/** CLI 的 qn()：第一个非内部、IPv4、MAC 不全 0 的网卡 MAC；都没有时用系统用户名 */
function instanceId() {
  if (process.env.BINANCE_INSTANCE_ID) return process.env.BINANCE_INSTANCE_ID;
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list ?? []) {
      if (!n.internal && n.family === 'IPv4' && n.mac !== '00:00:00:00:00:00') return n.mac;
    }
  }
  return os.userInfo().username;
}

let keyCache = null; // { id, key }：PBKDF2 10 万次约 60ms，只算一次（网卡变了才重算）
function localKey() {
  const id = instanceId();
  if (keyCache?.id !== id) keyCache = { id, key: pbkdf2Sync(id, `${SALT_PREFIX}:${id}`, ITER, KEY_LEN, 'sha256') };
  return keyCache.key;
}

function decrypt(b64) {
  try {
    const buf = Buffer.from(b64, 'base64');
    const d = createDecipheriv(ALGO, localKey(), buf.subarray(0, IV_LEN));
    d.setAuthTag(buf.subarray(-TAG_LEN));
    return Buffer.concat([d.update(buf.subarray(IV_LEN, -TAG_LEN)), d.final()]).toString('utf8');
  } catch {
    return null;
  }
}

const isEncrypted = (s) => typeof s === 'string' && s.length >= 44 && /^[A-Za-z0-9+/]+=*$/.test(s);

/** 每个钱包目录的会话缓存：session.json 修改时间变了（重新登录）就重读 */
const sessions = new Map();

async function loadSession(walletDir) {
  const file = path.join(walletDir, 'session.json');
  let st;
  try { st = await stat(file); } catch { throw new DirectError('local', '没有找到会话文件（未登录）'); }
  const hit = sessions.get(file);
  if (hit && hit.mtimeMs === st.mtimeMs) return hit;
  let data;
  try { data = JSON.parse(await readFile(file, 'utf8')); } catch { throw new DirectError('local', '会话文件读取失败'); }
  const clientId = UUID_RE.test(data.clientId || '') ? data.clientId : (isEncrypted(data.clientId) ? decrypt(data.clientId) : null);
  if (!clientId) throw new DirectError('local', '客户端 ID 解密失败（网卡可能变了）');
  const sessionId = isEncrypted(data.sessionId) ? decrypt(data.sessionId) : null;
  if (!sessionId) throw new DirectError('local', '会话解密失败或未登录');
  const s = { mtimeMs: st.mtimeMs, clientId, sessionId };
  sessions.set(file, s);
  return s;
}

let cliVersion = null;
/** CLI 自己的版本号（请求头要带）；读不到就不直连（按 local 处理，退回 CLI），不瞎填 */
function version() {
  if (!cliVersion) {
    let v = null;
    try { v = JSON.parse(readFileSync(path.join(path.dirname(CLI_ENTRY), '..', 'package.json'), 'utf8')).version; } catch { /* 下面报错 */ }
    if (!/^\d+\.\d+\.\d+/.test(String(v || ''))) throw new DirectError('local', '读不到 baw CLI 的版本号（CLI 路径变了？）');
    cliVersion = String(v).split('-')[0];
  }
  return cliVersion;
}

function headers({ clientId, sessionId }) {
  const intl = Intl.DateTimeFormat().resolvedOptions();
  const plat = os.platform();
  const sys = plat === 'darwin' ? 'macOS' : plat === 'win32' ? 'Windows' : plat === 'linux' ? 'Linux' : plat;
  return {
    'Content-Type': 'application/json',
    agentClientId: clientId,
    agentClientSystem: `${sys} ${os.release()}`,
    agentClientMac: instanceId(),
    'bnc-uuid': clientId,
    'x-trace-id': randomBytes(16).toString('hex'),
    device_name: os.hostname(),
    system_lang: intl.locale,
    timezone: intl.timeZone,
    system_version: `${os.type()} ${plat} ${os.release()}`,
    version_code: version(),
    clientVersion: version(),
    agentClientType: 'AGENT_CLI',
    agentClientVersion: version(),
    Cookie: `agentSessionId=${sessionId}`,
  };
}

/** 一次 HTTPS 请求（长连接）。返回 { status, text } */
function send(method, pathname, hdrs, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = https.request({ host: HOST, path: pathname, method, headers: hdrs, agent }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', (d) => { text += d; });
      res.on('end', () => resolve({ status: res.statusCode, text }));
      res.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout after ${timeoutMs}ms`)));
    req.on('error', reject);
    if (body !== undefined) req.write(body);
    req.end();
  });
}

let pingTimer = null;
/** 保活：每 25 秒请求一次公开接口，让到币安的 TLS 连接一直是热的（不带会话、不带钱包信息） */
export function keepWarm(isBusy = () => true) {
  if (pingTimer) return;
  // isBusy()：有自动化在跑或最近有人在用页面 / 插件时才保活；闲置时不发（下单前第一笔多一次握手，约 0.1~0.3 秒）
  const ping = () => { if (isBusy()) send('GET', PING_PATH, { 'Content-Type': 'application/json' }, undefined, 10000).catch(() => {}); };
  ping();
  pingTimer = setInterval(ping, PING_MS);
  pingTimer.unref?.();
  try { localKey(); } catch { /* 首次调用时再报 */ }
}

/**
 * 调用白名单内的接口，返回响应里的 data（与 `baw ... --json` 输出的 data 字段相同）。
 * @param {string} walletDir 钱包目录的绝对路径（profiles/<id>）
 * @param {'preview'|'execute'|'authQuery'} name
 */
export async function directCall(walletDir, name, body, { timeoutMs = 60000 } = {}) {
  const pathname = ENDPOINTS[name];
  if (!pathname) throw new DirectError('local', `不支持的接口：${name}`);
  const session = await loadSession(walletDir);
  const hdrs = headers(session); // 在发请求之前求值：这里出错（如读不到版本号）属于 local，可以安全退回 CLI
  const method = name === 'authQuery' ? 'GET' : 'POST';
  const payload = body === undefined ? undefined : JSON.stringify(body);
  const started = Date.now();
  let res;
  try {
    res = await send(method, pathname, hdrs, payload, timeoutMs);
  } catch (err) {
    throw new DirectError('network', `直连币安失败：${err.message}`, { ms: Date.now() - started });
  }
  const ms = Date.now() - started;
  if (res.status < 200 || res.status >= 300) throw new DirectError('network', `直连币安 HTTP ${res.status}`, { ms });
  let y;
  try { y = JSON.parse(res.text); } catch { throw new DirectError('network', '币安返回的不是 JSON', { ms }); }
  if (y.code !== OK_CODE) {
    const hint = API_HINTS[y.code] || '';
    throw new DirectError('api', `[API_${y.code}] ${y.message || '未知错误'}${hint}`, { ms, apiCode: y.code });
  }
  return { data: y.data, ms };
}

export { DirectError };
