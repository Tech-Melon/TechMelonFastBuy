# 快捷交易（多平台）

webui「快捷交易」标签页（`#quick`）：输入代币 CA（Flap 填 market 地址）→ 自动识别平台 → 点金额 → 看清「扣取 / 收到 / 路由」→ 确认一次即广播。

## 平台与识别

| 平台 id | 识别方式 | 可交易条件 | 买入金额单位 |
|---|---|---|---|
| `gangv3` | 已启用且核验通过的 LaunchpadV3 上 `curves(ca)` 已登记 | 未毕业；已毕业交给 `dex` | BNB（默认关闭，见下文） |
| `four` | `OpenFourCore.tokens(ca).exists` | 阶段 Trading 且未暂停；Migrated 交给 `dex` | 计价币（BNB / BNCB / NVDAB） |
| `gang` | `token.launchpad() == LaunchpadV2` 且 `curves(ca)` 已注册 | 未毕业；已毕业交给 `dex`（带上曲线报价币） | BNB（先经智能路由换成报价币） |
| `flap` | `Factory.isMarket(addr)`（输入是 market 地址） | PHASE=1 | 市场计价币；卖出只支持按比例 |
| `dex` | 代币与中转币 / 平台报价币之间有 Pancake 池子 | 有流动性 | BNB |

「自动识别」的推荐顺序：可交易的内盘平台 > 外盘 `dex`。

### 识别缓存（三层）

| 层 | 位置 | 内容 | 有效期 / 容量 |
|---|---|---|---|
| 整体结果 | 服务端内存（`registry.mjs`，按 CA + 钱包） | 完整识别结果 | 20 秒；有平台出错不缓存 |
| 平台归属 | 服务端 `quick/detectcache.mjs`，落盘 `webui/detect-cache.json`（600，gitignore，不同步） | 属于哪些内盘平台、报价币、是否 Flap market、symbol / decimals | 属于内盘 7 天、不属于 10 分钟；最多 3000 条，按最近使用淘汰 |
| 插件 | `chrome.storage.local` 的 `detectCache2`（按 CA + 钱包） | 识别结果 | 可交易 5 分钟直接用、24 小时内先显示再后台复查；不可交易 30 分钟；最多 500 条 |

命中归属缓存时只问归属平台（读最新阶段 / 能否交易）和外盘（报价币已知，两路并行），不再探其它平台、不读代币信息：
实测一次识别的 HTTP 请求从 7 次降到 2 次。会变的状态（曲线中 / 已毕业、Agent 门槛、池子）每次照样读链。
归属平台这次不认这个地址时，记录作废、改走全量识别；有任何平台出错、或属于内盘却读不到 symbol 时不写入。
**新增平台**：启用状态会变的平台实现 `epoch()`（如 gang V3 返回已启用部署地址或 `'off'`），签名变了旧记录不再使用。

## 外盘智能路由（`webui/quick/router.mjs`）

外盘交易全部走 Pancake **SmartRouter** `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 的 `multicall`，V2 和 V3 混合的多跳在**一笔交易**里完成。

1. **发现池子**。中转币只用白名单（WBNB / USDT / USDC / USD1 / U），再加上平台声明的报价币（如 oANT、BNCB），不从链上任意扩展。
   - 在这些币两两之间查 V2 pair 和 V3 pool（0.01% / 0.05% / 0.25% / 1%）。
   - 用 `token0/token1` 复核池子身份，防止「幽灵池」。
2. **选路**。按真实金额逐跳报价，最多 3 跳，每个节点保留输出最多的路径。
   - V2 用储备在本地计算，V3 用 QuoterV2。
3. **模拟真实到账**。前 3 条候选路径以钱包身份做 `eth_call` 模拟（含转账税），选模拟到账最多的一条。
4. **冲击检查**。用同一路径、1/1000 的金额算出边际价。价格冲击超过 10%（`QUICK_MAX_IMPACT_BPS`）时直接拒绝。实测损耗超过 20% 时视为疑似貔貅，也拒绝。
5. **下限**。`minOut = 模拟到账 × (1 − 滑点)`，只校验最后一段。
   - 中间段输出到路由器自身（`ADDRESS_THIS`），下一段 `amountIn=0`，表示使用路由器余额。
   - 卖出成 BNB 时，下限放在 `unwrapWETH9` 上。
6. **广播前复核**。`assertRouterTx` 解码 calldata，逐项检查：
   - 目标合约是 SmartRouter。
   - 只含 `exactInput` / `swapExactTokensForTokens` / `unwrapWETH9` 三种调用。
   - 中间收款人只能是路由器自身，最终收款人是本钱包。
   - 路径里的代币都在白名单内，金额和下限与计划一致。

**为什么要这样做**：以 gang 毕业代币「蚂蚁」为例，报价币 oANT 和 WBNB 之间的 V2 池只有约 1 美元。普通 V2 路由（包括旧版 gang 买入）会选 WBNB→oANT 这条路。实测 0.1 BNB 只能换到约 4,500 个，智能路由能换到约 66 万个，差约 150 倍。

**缓存与预热**（`webui/quick/warm.mjs`）：
- 平台报价币（gang curves / Four Core 登记的、库存里的）与中转币之间的池子地址缓存 30 分钟，其它币对 5 分钟。
- 服务启动时预热库存里的报价币，之后每 20 分钟强制刷新一次。
- 粘贴 CA 后的 2 分钟内，每 10 秒在后台重读一次储备（储备缓存只有 15 秒）。
- 选路时，两个中转币之间、且都不是起点或终点的池子不读储备（剪枝规则下用不上）。
- 实测：粘贴后隔 16 秒再点买入，报价从 2.7s 降到 1.2s。

**RPC 限速**：路由模块自带每秒 40 次请求的限速（`QUICK_RPC_RATE`），节点返回限流时等下一秒重试。只要有请求最终失败就报错，不会在残缺数据上选路。

## 路由记录与固定路由（`webui/quick/routebook.mjs`）

- **记录**：`routeSwap` 生成交易时按 calldata 登记路径；`doExecute` 拿到 txHash 后在后台等回执，按「币对（输入 → 输出）+ 池子路径」累计成功 / 失败和平台。
  数据存 `webui/routes.json`（600，gitignore，不随代码同步）。历史成交第一次启动时从执行日志导入：用 `execute.done` 发往 SmartRouter 的 txHash 读链上 calldata 还原路径，按回执判断成败。也可以在页面上手动再导入。
- **固定**：在「资金与授权 → 路由记录」里，只能固定成功过的路径。固定后 `routeSwap` 跳过 `discoverPools` / `findRoutes`，只沿这条路径重读 V2 储备、报价，并模拟真实到账；路由文字前加 📌。`estimateOut` 也优先用固定路径。
- **会变的情况**：如果固定路径报价为 0、V2 池子没了储备、模拟失败，或者路径上的代币不在本次白名单里，这一笔会自动改用完整搜索，并在确认框里提示。连续 3 次（`PIN_MAX_FAILS`）不通就暂停固定，页面上显示原因，可以「恢复」。
  固定期间每小时在后台完整搜索一次。池子报价比固定路径多 0.5% 以上时会在页面上提示，不会自动换。
- **不放宽护栏**：价格冲击、损耗上限、`assertRouterTx` 复核、一键执行上限都照常生效。
- **接口**：`GET /api/routes`、`POST /api/routes/pin {pair, pathKey}`、`/api/routes/unpin {pair}`、`/api/routes/resume {pair}`、`POST /api/routes/import`。

## CA 输入框与一键买入

**四个 CA 输入框**：自动识别 / Four / gang / Flap market。填其中一个时，其它框会被清空，下单只认有内容的那个框。
- 填对应平台的框时，跳过全平台识别，只做一次链上核验，确认地址确实属于这个平台（实测约 0.1 秒）。填错框会直接报错，不会被当成该平台去下单。
- 已毕业的代币要走外盘，请用「自动识别」框。

**一键买入**（`webui/quick/oneclick.mjs`，对应 docs/AUTOMATION_RULES.md 规则 3 的第二个例外）：
1. `/api/quick/plan` 在生成买入计划、并且第一步 preview 通过后，会记录一个 bundle（2 分钟内有效，只能用一次）及其上限：
   - 步骤类型
   - 步骤数
   - BNB 合计
   - 交互合约
   - 授权（代币、对象、额度）
   - 最少收到
2. 前端确认框列出全部步骤和上限。用户确认后调用 `/api/quick/oneclick`（`confirm=ONECLICK`），服务端在后台按顺序执行：preview → execute → 每 700ms 查一次回执 → 若该步需要重新报价，则重新报价 → 用 `checkStep` 复核下一步。
3. 任何一步超出上限、模拟失败、链上失败或总耗时超过 3 分钟，执行都会停止。已完成的步骤不会回滚。
4. 前端轮询 `/api/quick/oneclick/:id`，展示每一步的耗时（预览、广播、上链、重新报价），以及报价阶段的耗时（识别、报价、币安预览）。

## 买入后自动授权（`webui/quick/autoapprove.mjs`）

docs/AUTOMATION_RULES.md 规则 3 第九个例外。「资金与授权」页开关（`config.autoApprove`，默认关，打开要确认一次）。
- **触发**：`startQuickJob` 的 `onDone`（oneclick.mjs 任务结束回调），只处理 `state = done` 的买入；卖出、库存备货（platform=inventory）不处理。
  同一钱包同一个币在途时不重复发。
- **授权对象**：按当前阶段识别（`detectAll` 的 recommended）：four → Four Core，gang → LaunchpadV2，gangv3 → 已启用的 LaunchpadV3，
  flaptax → Flap Portal，dex → Pancake SmartRouter；flap 曲线不需要授权。与各平台卖出计划里的 approve spender 一致，
  所以授权够了以后卖出计划就只有 sell（各平台都是 allowance ≥ 卖出数量时不生成 approve 步骤）。
- **额度**：链上当前持有数量（买入刚上链读到 0 时按绝对时间最多等 6 秒）；现有授权 ≥ 余额就不发。不做无上限授权。
- **执行**：`assertAutoApproveTx` 复核 → `previewStep` → 预览要 App 确认（requireConfirmation）就不执行 → `doExecute`（value 0）。
  日志 `autoapprove.done / skip / fail / hold / setting`；`GET /api/quick/autoapprove` 返回开关和最近 40 条。
- **接口**：`GET/POST /api/quick/autoapprove`（POST 打开时要 `confirm=AUTO_APPROVE`），不在插件的 EXT_ROUTES 里。
- **评测**：`node webui\eval\autoapprove.mjs`（复核篡改 + 任务过滤 + 只读联网算出 gang V3 / 外盘的授权，16 项）。

## 买入上限与直接买入（免确认）

**买入上限**（`webui/limits.mjs`，保存在 config.json 的 `limits` 里，填 0 表示不限）：
- **单笔上限**：在 `/api/quick/plan` 生成买入计划时检查，所有步骤附带的 BNB 合计不能超过它。
- **每日上限**：每个钱包每天的额度，在 `doExecute` 每次广播前检查，所有功能共用。
  - 当天已用量从 journal.jsonl 统计，服务重启不清零。
  - 正在广播的金额也会先计入，两笔并发不能同时绕过上限。

**直接买入**（`webui/quick/armed.mjs`）：
- **开启（预授权）**：`POST /api/quick/arm`，参数 `confirm=ARM`。
  - 开启前必须先设好单笔和每日上限，两项都大于 0。
  - 开启时确认的策略包括：钱包、当时的上限、最大滑点，有效期默认 4 小时，最长 24 小时。
- **下单**：开启后用 `POST /api/quick/autobuy`，服务端先确认这个钱包已开启、未过期、金额和滑点都在策略范围内，再按一键买入的同一条链路执行：生成计划 → 币安预览 → `checkStep` 上限复核 → 每日上限检查。
- **自动失效**：修改上限、到期、手动解除，任一发生都会让预授权失效。服务重启后按原到期时间自动恢复（上限没改过才恢复；「资金与授权」可关闭，见 docs/AUTOMATION_RULES.md「重启恢复」）。
- **范围**：只用于买入。被币安风控挂起的交易仍然需要在 App 里确认。

## 报价币库存 + 常驻授权（`webui/quick/inventory.mjs`）

目的：内盘买入一笔完成。gang 非 BNB 报价（SPCXB、oANT…）原来要 换币 → 授权 → 买入 3 笔，Four 的 BNCB / NVDAB 要 授权 → 买入 2 笔。
提前备好报价币、并把授权额度设成「等于库存」后，都只剩买入 1 笔。

- **授权对象白名单**：gang LaunchpadV2 `0x1B8F…966E`（硬编码，不可升级，owner 为 EOA）、Four Core `0xebe7…27f3`（硬编码，UUPS 可升级，owner 为合约）、当前已启用并核验通过的 gang LaunchpadV3（动态，未审计）。
  Flap 的授权对象是每个 market，常驻授权没有意义，不支持。
- **备货 / 同步授权**：授权额度 = min(备货后的保底库存, 上限折合的报价币数量)。授权对象被攻击 / 恶意升级时，最多损失这份库存。
- **批量预授权（无上限，2026-10-27 用户要求）**：`approvalCandidates` 列出候选（gang 最近 3 天 Created 事件里当过报价币的 + 库存列表里的），
  勾选后 `planUnlimited` 生成 `approve(spender, 2^256-1)`，确认一次逐笔执行。只允许白名单 spender 与已知报价币；不需要先持有代币。
  已经无上限的跳过；之后「备货」不会把无上限缩回库存量。风险：授权对象可以转走这些代币的全部余额（含以后转入的），不用时点「撤销」。
- **gang V3 的授权（2026-10-28）**：授权对象 = 已启用且核验通过的 LaunchpadV3（`SPENDERS.gangv3`，不写死）。WBNB 底池直接付 BNB，不需要授权；
  非 WBNB 底池（GANG / NVDAB / BNCB…）要有报价币库存 + 对 V3 pad 的授权，狙击的极速通道才能一笔买完，否则「没库存，跳过」。
  V2 和 V3 的授权是两笔不同的授权，库存列表里同一个报价币会有 gang 和 gang V3 两行。
  - `v3QuoteIndex()`：扫已启用 V3 pad 的 `Created`（`quote` 是第 3 个 indexed 参数），统计 V3 用过的报价币（来源地址固定，伪造不了；换部署自动重扫）。
  - 候选 `approvalCandidates` 同时列 gang（V2）和 gang V3 行；`planUnlimited` / `planRevokeMany` 对 V3 的「已知报价币」= 在 V3 索引里或已在库存列表，WBNB 与任意地址一律拒绝（`isKnownQuote`）。
  - `addFromCa` 填报价币地址时，如果它在 V3 索引里，会**同时**登记 gang 和 gang V3；只在 V3 用过的报价币只登记 gang V3。
  - 想只授权库存量而不是无上限：把 V3 行加进库存后用「同步授权」（额度 = 库存量，受 `capBnb` 限制）。V3 合约未审计，优先用这个。
- **库存总览：授权矩阵（2026-10-28 重做）**：`GET /api/inventory` 除了已登记的条目，还会**自动带上 gang V3 用过的非 WBNB 报价币**（`auto: true`，不用手动添加；
  返回 `spenders` 列出当前有授权对象的平台）。前端按「报价币 × 平台（gang V2 / gang V3 / Four）」画矩阵，每格一个徽标：
  `● 已授权`（额度 ≥ 库存，绿）· `◐ 不足`（额度 < 库存，橙）· `○ 未授权`（灰虚线）· `⚠ 无上限`（红）· `—`（该平台不用这个币）。顶部每个平台一张汇总卡：
  就绪（有库存且额度 ≥ 库存）/ 待授权（有库存、额度 < 库存）/ 无上限各是哪些币。点格子选中「报价币 × 平台」，下方面板才出现备货并授权 / 同步授权 / 撤销 / 移除（按状态启用）。
  `resolveEntry`：自动列出的 V3 行没登记也能「同步授权 / 撤销」（授权对象仍是官方 V3 pad；WBNB、任意地址、V2 未登记币仍被拒绝）。
  对自动行生成「备货 / 同步授权」计划时会**登记进库存列表**（与批量预授权一致）：V3 报价币索引只在内存里、重启只回扫 3 天，不登记的话这笔授权可能从总览消失、也撤销不了。
  V3 报价币索引换部署时整个换成新对象，进行中的旧扫描不会写进新索引。
  V3 狙击引擎的预热（`warmOnce`）也自动覆盖 `v3QuotesCached()` 里的 V3 报价币，不再因「这个报价币还没预热」跳过。
- **批量撤销（2026-10-28）**：「批量撤销授权」按钮 → `GET /api/inventory/candidates`（服务端返回全部候选，最多 40 个，顺序：已登记 → V3 索引 → V2 索引；所有授权路径都会登记，所以截断不会漏掉有额度的）→ 前端只列授权额度 > 0 的 → 勾选 →
  `POST /api/inventory/plan {action: 'revoke-all', items}` → `planRevokeMany` 生成 `approve(spender, 0)`，已是 0 的跳过 → 确认一次逐笔执行（每笔币安预览，`oneclick` 的授权上限复核照常）。
  只改授权额度，不动代币和库存列表。
- **V3 狙击预授权的提醒**：预授权确认框（发射台选 V3 且开着「狙非 BNB 底池」时）会只读列出每个钱包「有余额且已授权」的 V3 报价币，没有就提示去备货 / 同步授权。只提醒，不替你授权。
- **gang 报价币索引**（`gangQuoteIndex`）：LaunchpadV2 没有报价币白名单的只读函数，用最近 3 天的 Created 事件统计（来源地址固定，伪造不了），之后增量扫；
  添加报价币时也可以直接填报价币本身的地址（如 GANG `0x0c63…B405`），在索引里就接受。
- **库存上限**：每种报价币 `inventory.capBnb`（默认 1 BNB 等值，config.json）。备货时「现有库存折合 BNB + 本次备货 BNB」超过上限直接拒绝。
- **报价币来源**：只能用代币 CA 添加（从 LaunchpadV2.curves / Core.tokens 读出报价币），或直接填 Four 的 BNCB / NVDAB；不接受任意代币。
- **备货 / 同步授权 / 撤销**：生成计划并 preview 第一步 → 确认框展示链、钱包、报价币、花费、路由、滑点、授权对象和额度变化 → 走一键执行（每步币安预览）。
  备货的步骤顺序是「授权 → 换币 / 包装」（授权不依赖余额）。
- **买入时**：gang 计划发现钱包里的报价币 ≥ 这笔 BNB 的池子估值，就直接用库存买（`spec.inventory`），授权够则只有买入一步；
  授权不够时补一笔「只授权本次数量」的授权（会把常驻授权用掉，之后点「同步授权」恢复）。
- **上限口径**：备货的换币带 BNB，照常计入每日上限；用库存买入不带 BNB，按折合 BNB（`bnbEquivWei`）计入单笔上限和直接买入的预授权策略，不重复计入每日上限。
  Four 非 BNB 计价的买入也按池子估值折合 BNB 检查单笔上限，估不出时（有单笔上限的情况下）拒绝。
- **接口**：`GET /api/inventory?walletId=`、`POST /api/inventory/add {ca}`、`/remove {platform, token}`、`/cap {capBnb}`、
  `/plan {walletId, platform, token, action: stock|revoke|revoke-all|unlimited, amountBnb, slippageBps, items}`（返回 `oneClick.bundleId`，确认后调 `/api/quick/oneclick`）、
  `GET /api/inventory/candidates?walletId=`（批量预授权候选）。

## 确认与执行流程

- `/api/quick/plan` 生成计划，并在服务端 preview 第一步，经 baw 模拟。确认框里展示：
  - 扣取金额、预计收到、最少收到。
  - 路由、价格冲击和税。
  - baw 模拟出的余额变化。
- 买入（BNB → 代币）只有**一笔交易、一次确认**。
- 卖出时如果授权不足，先授权**本次卖出数量**（不做无限授权）。用 eth_call 状态覆盖临时把「钱包 → spender」的授权设成本次数量
  （`quick/simoverride.mjs`，按代币探测授权映射的存储槽位并缓存；2026-10-28 实测 Flap 税币在 52 号槽、gang V2 / V3 代币在 1 号槽），
  以钱包身份模拟真实卖出，计划直接给出「授权 → 卖出」两步，**确认一次**，授权上链后执行卖出，不再重新报价。适用于 gang V2、gang V3、Flap 税币和外盘（SmartRouter）。
  找不到槽位的非常规代币才退回旧流程（只授权一步，上链后再点一次卖出）。以前外盘和 V3 只给一步授权、上链后重新报价，
  一键执行会被「步骤数超过确认时的 1 步」拦下，授权成功却卖不出去。
- 卖出计划都带 `receive.minRaw`：一键执行的「最少收到」下限复核对卖出同样生效。
- **Agent ID 门槛（卖出同样要求，2026-10-28 链上实测）**：gang V2 / V3 曲线卖出没有 Agent ID 会 `NotAgent`；Flap 税币有 `nftGate` 时会 `NFTGatedOnly`。
  Flap 的门槛有两种：币安 Agent ID（`0x60B9…022F`），或发币人指定的其它 ERC-721 合集（如 `0x3c6e…7777` 用 `0xB29F…308F`），计划和识别里写明是哪一种。毕业后的外盘交易不受门槛限制。
- **币安风控挂起 → 钱包锁定**：一笔交易被挂起（没有 txHash）后，确认 / 拒绝 / 过期之前，币安会用 `API_351716` 拒绝这个钱包的**所有**新交易（不只是同一个合约）。
  服务端把 351716 翻译成说明；`GET /api/w/:id/lock` 用 `wallet tx-lock` 查锁定状态，交易台显示横幅、锁定时拦住下单。
- 多笔交易的平台按顺序执行：
  - gang 买入可能是「换报价币 → 授权 → 买入」。
  - Flap 的 ERC20 计价是「授权 → 买入」。
  - 每一笔都要等上一笔上链（轮询回执）后再 preview。
- 改动任何参数（CA、钱包、平台、滑点、数量），旧计划会立即作废。

## gang.fun V3（`webui/quick/gangv3.mjs`）

V3 = LaunchpadV3（税收接收地址代币）+ GangRouter（无状态路由）。截至 2026-10-26，主网**未部署**：官方说要等外部审计。代码在 `gangfun/gang-launchpad` 的 main 分支，测试网已有部署。

**内置部署（2026-10-29 起）**：官方主网 LaunchpadV3 `0x15CFD2dc8278Fb87a1783ef42111618E20874365` + GangRouter `0xE040445690Aa56C8b68B7f7038C7b2562B5079C4`
固定为 `BUILTIN_V3`。`config.json` 没有 `gangV3` 时直接用它（轻量版没有发射台页面也能交易 V3 币）；手动停用（`enabled: false`）后不再使用；
启用了别的地址则以配置为准。`v3Config()` 返回当前生效的那组，`activeDeployment()` 照常链上复核（10 分钟一次），复核不过就不交易。

**安全设计**：
- **只和一组地址交互**：内置部署或「已启用」的那一组。
- **地址来源**：手动填写，或监控从官方仓库 `skill/gang-cli/src/v3.js` 的 mainnet 配置里取到的候选。外部内容只当数据，只从中提取地址。
- **链上核验**：下面任意一项不通过就不能启用（fatal）：
  - 两个地址都有合约代码；
  - 费率常量：手续费 1%、平台抽成 0.5%、税率 1–5%；
  - 单地址 1% 上限、总量、15 BNB 毕业线；
  - `wbnb()` 是官方 WBNB；
  - Agent 准入开启，且用的是官方 Agent ID 合约；
  - migrator 已接好；
  - `pad.routers(router) == true`、`router.v3() == pad`、`router.wbnb()` 正确。

  owner 不是多签合约时只给警告，不阻止启用（V2 的 owner 也是普通钱包）。
- **启用**：需要用户在确认框里确认（`confirm=ENABLE`），服务端启用时会再核验一次。
- **复核**：启用后每 10 分钟复核一次。失败就立即停止 V3 交易；配置会保留，状态显示为异常。
- **代币归属**：只看 `pad.curves(token)` 有没有登记，不信任代币自报的 `launchpad()`。
- **买入**：
  - WBNB 报价的币用 `GangRouter.v3BuyBNB`，一笔完成；买到上限时多付的部分以 BNB 退回。
  - USDT 等其它报价币：智能路由换成报价币 → 只授权本次数量给 pad → `pad.buy`，共 2–3 笔。
- **卖出**：
  - 只能本人直接调 `pad.sell`（毕业前代币锁定）。
  - 先只授权本次数量，授权上链后重新模拟。
  - WBNB 报价的币卖出后，附一步可选的 unwrap。
- **每笔交易都会先模拟**：以钱包身份 `eth_call` 拿到真实到手数量，按滑点算下限；价格冲击超过 10% 就拒绝。
- **广播前解码 calldata 复核**：目标合约、函数、代币、数量、下限都要和计划一致；授权只能给 pad，而且只授权本次数量。
- **单笔买入上限**：0.1 BNB，可用 `QUICK_GANG_V3_MAX_BNB` 调整。
- **毕业后**：交给外盘智能路由，报价币作为中转币；外盘 1–5% 的税由模拟实测。

**主网发现与提醒**：

- **链上实时发现**：服务端用 QuickNode WSS 执行 `eth_subscribe logs`。订阅不限定地址，只按以下 4 个 V3 事件签名过滤。
  - 订阅的事件：`RouterSet` / `MigratorSet` / `AgentGateUpdated` / `TaxConfigured`。
  - 误报情况：订阅前实测，主网最近 9000 块内这 4 个事件一条都没有。
  - 补查：服务启动和断线重连时，用 HTTP 补查最近约 6 小时的日志。
  - 防刷有两层：
    1. 发事件的合约必须读得出 V3 的特征常量：平台抽成 0.5%、毕业线 15 BNB、税率上限 5%。
    2. 候选最多保留 20 个。
  - 收到 `RouterSet` 后记录路由地址。之后每来一个接线事件就重新做一次链上核验，接线完成后会再提醒一次。
- **官方来源**：每 10 分钟查一次 GitHub 上官方 CLI 的主网配置。
- **网页提醒**：
  - 网页无论停在哪个标签页，都每 15 秒轮询一次 `/api/gangv3/status`。
  - 出现新提醒时，页面顶部弹出横幅，同时响铃。铃声用 Web Audio 合成，每 4 秒响一次，最多响 10 分钟，标签页标题会闪烁。
  - 点「我知道了」后停止，已确认的提醒记在 localStorage。
  - 浏览器规定页面有过点击或按键后才能出声，可以先点一下「试听铃声」。
- **启用规则**：
  - 地址和官方来源一致时，直接按正常流程启用。
  - 不一致或官方还没公布时，确认框会明确警告「仿冒部署也能通过核验」。点确认等于声明已从官方渠道逐字核对过，服务端以 `attest=true` 记录来源为「manual」。
  - 链上发现的候选只能「填入」输入框，不能一键启用。

**已知风险**（来自官方审计说明，无法在客户端消除）：
- 合约未经外部审计。
- owner 撤掉 PlatformFeeBucket 的 operator 后，内盘买卖会 revert，毕业前没有退出路径。
- Agent ID 被收回后，毕业前卖不掉（K-16）。
- keeper 大约每小时一次性卖出外盘税，会形成抛压。
- 分红部分存进 DividendVault 后，owner 能转走（审计 §4.2）。
- 打新（FairMint）暂不接入：它的出局规则按余额永久判定（K-3），误操作造成的损失不可挽回。

**评测**：`node webui\eval\gangv3.mjs` 离线测试篡改检测、地址解析和曲线复算；加 `--testnet` 会对测试网的官方部署做只读核验，并模拟买入和卖出。

## gang 打新（`webui/quick/fairmint.mjs`）

FairMintPad：一半代币分 10,000 份按同一价格打，打满当场发射到 Pancake V2（开盘价 = 打新价），截止没打满全额退。
截至 2026-10-27 主网**未部署**（官方 CLI `fair.js` 的 mainnet pad 为 null），测试网有官方部署。

- **启用**：与 gang V3 相同，默认关闭；手填或用官方候选（每 10 分钟查 `skill/gang-cli/src/fair.js`），链上核验通过 + `confirm=ENABLE` 才启用，启用后每 10 分钟复核。
  核验项（fatal）：两个地址有代码；总份数 10,000、每份 5 万枚；打新 / 撤出费 1–5%；单地址 0.1–0.5%；出局线 30–80%；募集 5–50 BNB；
  `wbnb()` 官方；Agent 准入开启且用官方 Agent ID；migrator、taxHandler、dividendVault 已接；`pad.routers(router)`、`router.fair() == pad`、`router.wbnb()`。owner 不是合约只警告。
- **链上发现**：复用 V3 的 WSS 订阅（同签名的 RouterSet / MigratorSet / AgentGateUpdated），不是 V3 时按打新特征常量判断，命中就提醒（只提醒，不能一键启用）。
- **sale 列表**：直接读 `pad.allTokens` 倒序，不依赖 gang.fun 服务端。
- **打新**：BNB 计价且有准入 → `GangRouter.fairMintBNB` 一笔；其它 →（WBNB 不够先包装）→ 只授权本次数量给 pad → `pad.mint`。
  `minShares` 默认等于本次可打份数（被别人截断就失败，不按更少份数成交），可勾选「接受更少份数」。计入单笔 / 每日买入上限。
- **撤出 / 退款 / 领取**：都先模拟；撤出写明撤出费和不退的打新费；领取只能调该核心的 `dividendVault.claim`。
- **出局线保护**：快捷交易卖出已发射的打新代币时，若卖后持仓低于出局线，计划和确认框里会有「永久失去持有奖励」的警告，并给出最多可卖数量。
- **执行**：`/api/fair/plan` 出计划并 preview 第一步 → 前端确认 → `/api/quick/oneclick`（每步币安预览）。
- **自动填入**：网页每 15 秒刷新状态。发现官方地址时自动填入 pad / router 并做一次只读核验；
  链上发现的地址（可能是仿冒部署）只在输入框为空、且没有官方地址时填入。启用仍要手动点「确认启用」。gang V3 同样适用。
- **WSS 复用**：V3 监控、打新监控、自动打新共用 `gangv3.mjs` 里的同一条 WSS 连接（`subscribeChainLogs` 在这条连接上追加订阅）。
  Four 狙击开着时会另开一条连接（同一个节点 URL）。
- **自动打新**（`webui/quick/fairauto.mjs`，docs/AUTOMATION_RULES.md 规则 3 第四个例外）：
  - 预授权一份策略：份数（整数或 max）、每个 sale 最多花多少、总预算、最多几个、打新费 / 撤出费上限、有效期 ≤ 24 小时。
  - 只打预授权之后新创建、BNB 计价、有 Agent 准入的 sale，走 GangRouter 一笔，剩余份数不足时接受更少份数。
  - 发现新 sale：订阅 pad 的 `Created` 事件（topic `0x4a80c7c9…`，已用测试网真实日志核对），另每 3 秒用 HTTP 读 `tokenCount` 兜底。
  - 多个 sale 串行处理，按顺序扣预算。每笔都走：计划模拟 → calldata 复核 → 单笔上限 → 币安预览 → 每日上限。
  - 改参数、到期、解除、修改买入上限、停用打新都会立即失效；服务重启后按原到期时间与已花预算自动恢复（见 docs/AUTOMATION_RULES.md「重启恢复」）。
- **评测**：`node webui\eval\fairmint.mjs [--testnet]`（离线篡改复核 + 自动打新策略校验 + 测试网只读核验 / 模拟，39 项）。

## 一键转移（`webui/quick/transfer.mjs`）

用途：gang 代币迁移（毕业）后，把它们连同其它非 BNB 代币一次转到自己的地址。docs/AUTOMATION_RULES.md 规则 3 第五个例外。

- **白名单地址**（config.json `transferTargets`，最多 20 个）：新增要在确认框里确认（`confirm=ADD_TARGET`），删除也要确认。
  新增前检查：零地址 / 销毁地址拒绝；合约地址警告；与本机钱包或已有白名单「前 4 位和后 4 位相同、中间不同」时警告疑似地址投毒。
- **可转代币**：候选来自币安钱包余额（跳过原生 BNB），也可以补充 CA，逐个链上读余额。gang LaunchpadV2 代币标出是否已迁移，未毕业的锁转账、不能勾选。
- **计划**：按比例（100% / 50% / 25%）算数量，以钱包身份 `eth_call` 模拟 `transfer`。revert 或返回 false 的排除并写明原因；一次最多 20 笔。
- **执行**：确认框列出每一笔和完整收款地址，确认后走一键执行。每笔广播前，`checkStep` 解码 `transfer`：代币、收款人必须与确认时一致，数量不能更多，否则停止。
- **评测**：`node webui\eval\transfer.mjs`（17 项）。

## 发射后自动转移（`webui/quick/autoxfer.mjs`）

docs/AUTOMATION_RULES.md 规则 3 第七个例外：预授权一份策略后，监控列表里的 gang 代币一发射就自动转到白名单地址（发现发射、复核规则见 docs/AUTOMATION_RULES.md）。

- **余额过少自动移出**：所选钱包买入 / 卖出监控列表里的代币之后，读一次这些钱包的合计余额，少于 50 万枚
  （环境变量 `AUTOXFER_MIN_TOKENS`，默认 500000）就移出监控，事件里写明剩多少。不做定时余额检查。
  - 触发：一键任务（交易台 / 插件 / 狙击普通流程）结束且完成，等 1.5 秒读；狙击极速买入 / 自动卖出 / 自动打新只是广播了，等 8 秒读。
  - 买入后读到合计为 0 不移出（交易可能还没上链）；卖出后少于下限（含卖光）就移出。别的钱包、失败的任务不触发。
  - 日志 `autoxfer.dust`；移出后再次买入仍会按「买入即加入」加回来（加回来后照样检查）。
- **全部移出**：监控列表上方「全部移出」（确认框），`POST /api/autoxfer/tokens/clear`。只清空列表，预授权保留。
- **评测**：`node webui\eval\autoxfer.mjs`（33 项：策略校验、真实已毕业代币的完整转移流程（假广播）、买入即加入、全部移出、余额过少自动移出）。

## gang 内盘狙击（`webui/quick/gangsnipe.mjs`）

LaunchpadV2 每发一个新币就买入 1%（单地址上限 1000 万枚）。docs/AUTOMATION_RULES.md 规则 3 第六个例外。

- **主网实测（2026-10-27，近 1 天 48 个新币）**：
  - 报价币分布：WBNB 17 个、BNCB 9、GANG 6、FXIon 5、SPCXB 3，其余各 1–2 个；有税轨 31 个。
  - 最快的机器人在创建后 +3~5 块买入。
  - 新币买满 1% 约 0.048 BNB；已卖出 10–27% 时约 0.06–0.09 BNB。
- **发现**：
  - 在共享 WSS 上订阅 `Created`（topic `0xd23a4470…`，日志来源固定为 LaunchpadV2 地址）。
  - 另每 3 秒用 HTTP 读 `tokenCount` 兜底。
  - WSS 推送比 HTTP 节点同步得快：读 `curves` 得到空记录时，按绝对截止时间每 150ms 重读，最多 3 秒（2026-10-27 实测 0x06bf4F88… 创建 1.5 秒后仍读到空记录被误跳过）。
  - 不用 gang.fun API：官方 CLI 的 `watch` 最短 10 秒轮询，列表接口按 track 区分，不适合抢时间。
- **金额**：
  - 按 `_prepBuy` 的曲线公式算出「买满 1% 要多少报价币」（含 1% 手续费），折成 BNB 后多给 8%，不超过单币上限和剩余总预算。
  - 多付的部分合约会截断退回；换币路径下多出来的报价币留在钱包里。
- **换报价币**：
  - 冲击 / 损耗上限只能收紧（`routeSwap` 的 `maxImpactBps` / `maxLossBps` 取 `min`），默认 3% / 5%，超过就跳过这个币。
  - 已有报价币库存时直接用库存。建议给 WBNB、GANG、BNCB 备货并做常驻授权，这样买入只需 1 笔。
- **过滤**：
  - `includeTaxed`（狙税币：V2 有税轨 / V3 买税 > 0）、`includeNonWbnb`（狙底池不是 WBNB 的币），默认都开；`quoteDeny` 不狙的底池（报价币地址，≤ 30 个）。判断在 `filterReason`。
  - 同一创建者被狙满 `creatorMax`（默认 2）个后不再狙。
  - 同一 symbol 只狙前 `symbolMax` 个（界面默认 2，0 = 不限；`normSymbol` 归一化大小写 / 全角 / 空白）。计数从 `gangsnipe.buy` 日志的 `symbol` 字段重建（2026-10-27 之前的记录没有这个字段，不计入）。
  - V3 全是税收币（买税 ≥ 1%），`includeTaxed` 对 V3 固定为 true。前端参数按发射台各存一份（localStorage `walletui:snipeForm:v2|v3`）。
  - **V3 专属过滤**（`maxBuyTaxBps` / `maxSellTaxBps` / `minDividendBps`，判断在 `filterReason`，只在 `curve.sellTaxBps` 存在时生效，V2 不读）：
    买税上限、卖税上限（bps，0~500，500 = 合约上限 = 不限，0 = 只狙免税币）；最低分红比例（bps，0~10000，0 = 不限；税收里分给持币人的比例，其余归税收接收地址）。
    数据来自 `pad.curves(token)` 的 `buyTaxBps` / `sellTaxBps` / `dividendBps`，税率创建时定下、之后不变。旧配置和旧的落盘预授权没有这三项，按不限处理。
    **界面默认值**（2026-10-28 用户指定）：买税 ≤ 3%、卖税 ≤ 3%、分红 100%（`DEFAULTS` 与 `app.js` 的 `snipeConfig` 留空回退一致）。
    免税币（0%/0%，`dividendBps` 恒为 0）会被「分红 100%」挡掉。2026-10-28 实测主网 47 个 V3 币：买卖税 1% 且分红 100% 的 13 个通过。
    税只在毕业后的 Pancake 池里收，内盘曲线阶段买卖只收 1% 手续费，所以这组过滤保护的是毕业后的出货成本。
  - 每天最多 `maxPerDay`（默认 30）个；计数从 `gangsnipe.buy` 日志重建。
  - 总预算 `totalBnb`（默认 3）用完自动解除。
- **执行**：`buildQuickPlan` → `startQuickJob`（与直接买入同一条链路），任务在后台跑，不阻塞下一个币。结果写进事件日志。
  - gang 计划里的「授权」步骤不再触发重新报价：授权上链后直接预览原来的买入交易（quoteIn 和最少收到不变，价格超出滑点时预览失败）。
    2026-10-27 实测：之前 5 次狙击里 3 次因「授权后重新报价、最少收到低于确认值」没买成。
  - 买入步骤没发出去的任务记 `gangsnipe.unbought`：只发过授权的退回预算；这个币所有钱包都没买到时退回每天 / 创建者 / symbol 名额。
- **多钱包**（`walletIds`，1~5 个，界面默认只勾一个；旧配置的 `walletId` 按单个钱包读）：
  - 同一个币各钱包并行各买 1%（`Promise.allSettled`，一个失败不影响其它）。
  - 每个钱包都按「其它钱包先成交」算金额（`worstCaseQuote`），多付的合约会退回。
  - 单币上限按每个钱包算；总预算是所有钱包合计，扣预算与检查之间没有 await，并行也不会超；每天几个 / 同一创建者几个按「币」计。
  - 某个钱包余额不够只移出它（日志 `gangsnipe.drop`），全部移出才整体解除。
- **V3 发射台**（`engines.v3`，配置键 `gangSnipeV3`，日志 `gangsnipe3.*`）：
  - 与 V2 共用一套引擎（`makeEngine(venue)`），监听 V3 pad 的 `Created`（topic `0x416fe98c…fdb63`），买入走 `planV3Buy`（一笔 `v3BuyBNB`）。
  - 单币上限再取 `min(V3_MAX_BUY_WEI)`；1% 金额按买入税折算。
  - V3 未启用时预授权进入「待命」，每 10 秒检查一次；用户在「gang V3」区点「确认启用」后自动开始。待命同样受 24 小时有效期约束；服务重启后自动恢复（仍在待命则继续待命）。
  - 测试网只能做只读演练（baw 不支持测试网签名）：发现 → 曲线 → 1% 金额 → `planV3Buy` 模拟。非 WBNB 报价币换币路径只能主网验证。
- **固定金额**（`amountMode: 'fixed'`）：不按曲线算 1%，每币直接买「单币上限」这么多 BNB 等值（超过 1% 持仓上限的部分合约退回）。
- **极速通道（V2）**：
  - 预热（每 4 秒）：每个钱包的 BNB、各报价币（WBNB + 库存里的 gang 报价币 + 见过的报价币）的余额与对 LaunchpadV2 的授权；非 WBNB 报价币的 BNB 价格每 15 秒刷新。
  - 新币出现：symbol 从 Created 事件解出；`curves` / `walletRoom` 走推送日志的同一条 WSS（`hubRequest`，800ms 超时退回 HTTP）。
  - 库存和授权都 ≥ 这笔要付的报价币时：本地算 `buy(token, quoteIn, minTokens)`（与 `planGang` 逐位一致，2026-10-27 核对），单笔上限 → 扣预算 → 币安预览 → `doExecute(equivWei)`，按回执记 done / fail。
  - 不够时记一条 `slow` 提示并走普通流程。每日上限对库存买入按 BNB 等值（`equivWei`）计，重建计数也认这个字段。
- **评测**：`node webui\eval\gangsnipe.mjs`（48 项离线）。

## 多钱包同时买入（快捷交易）

- 「钱包」下拉框是主钱包（卖出、库存、上限显示都用它）；「同时买入」里勾选其它钱包一起买，勾选存 localStorage `walletui:quickBuyWallets`。
- 没勾「直接买入」：各钱包并行 `/api/quick/plan`（各自报价 + 币安预览）→ 一个确认框列出每个钱包的扣取 / 预计收到 / 上限 → 并行 `/api/quick/oneclick`。
- 勾了「直接买入」：没开启的钱包一次确认、逐个 arm，然后并行 `/api/quick/autobuy`。
- 后端没有新增路径：每个钱包仍各自过单笔上限、每日上限、预授权策略。

## 直连下单（`webui/bawdirect.mjs`）

- `doPreview` / `doExecute` 经 `contractCall` 直连 `contract-call/preview|execute`，请求与 CLI 1.11.0 一致；常驻 HTTPS 长连接，每 25 秒请求一次公开接口保活。
- 实测（2026-10-26）：preview 直连约 0.33 s，CLI 约 1.0 s，返回字段与模拟结论逐项一致；login/query 直连 0.15~0.26 s，CLI 0.76~0.94 s。
- 退回 CLI：会话读不到 / 解密失败（请求没发出）时 preview 和 execute 都退回；网络异常只有 preview 退回，execute 按「可能已广播」处理，绝不重发。日志 `direct.fallback`。
- 关闭：`config.json` 设 `"bawDirect": false`。

## GMGN 持仓（`webui/gmgn.mjs`）

- 官方 OpenAPI，免费档漏桶 5 单位 / 5 秒，本地按 4 单位 / 秒限速；429 时按 `reset_at` 等待；结果缓存 20 秒。
- 持仓（权重 2，需签名）、交易记录 / 统计（权重 3）。签名串 `{subPath}:{排序后的 query}:{body}:{timestamp}`，Ed25519，base64。
- 设置：「钱包持仓 → GMGN API 设置」→ 生成签名密钥 → 到 https://gmgn.ai/ai 上传公钥 → 粘贴 API Key 保存。仅支持 IPv4 出口。
- 持仓参数：不传 `hide_airdrop`（GMGN 把转入 / 经聚合器换来的币算空投，传了会藏掉 BNCB / NVDAB / WBNB，实测 4 条 vs 网站 9 条）；持仓按 `usd_value` 降序，历史仓位按最近活跃。
- 刷新：面板里每次点击（打开、切标签、刷新、换钱包）都带 `fresh=1` 跳过本地 20 秒缓存；买入 / 卖出完成后面板开着会在 4 秒后自动刷新（GMGN 入库有几秒延迟）。
- 头像（`webui/logos.mjs`）：gmgn.ai 的图片有 Cloudflare 校验，服务端取不到（403）。改用两个来源，经 `/api/token-logo` 代理（主机白名单 `bin.bnbstatic.com` / `cdn.gang.fun`，跳转后复核主机，只认 PNG/JPEG/GIF/WebP，≤ 1MB）：
  币安钱包公开持仓接口的 `icon`；gang 代币 Created 事件里的 `logoURI`（按 GMGN 的创建时间估区块范围查事件）。两处都没有的显示首字母。
- 评测：`node webui\eval\gmgn.mjs`（5 项）。

## WSS 共享连接（`webui/wsshub.mjs`）

全项目只开一条 BSC WSS 连接，以下模块的订阅都登记在 hub 上：

- Four 狙击（`TokenCreated` + `newHeads`）
- gang V3 / 打新发现（4 个接线事件）
- 自动打新（打新 `Created`）
- gang 内盘狙击（LaunchpadV2 `Created`）

行为：

- 设置页修改 WSS 节点后，订阅自动迁移到新连接。
- 断线重连后，`onHubReconnect` 回调各模块，用 HTTP 补查断线期间的日志。
- 设置页的「测试 WSS」仍是一次性的临时连接。

## 接入新平台

1. 新建 `webui/quick/platforms/<id>.mjs`，导出：

   ```js
   export default {
     id, label, addressKind: 'token' | 'market',
     async detect(address, { wallet, extras }) { /* null 或 { match, tradable, phase, payUnit, graduated?, extras?, notes? } */ },
     async plan({ wallet, address, side, amount, percent, slippageBps, extras }) { /* 统一计划，见 registry.mjs 顶部注释 */ },
   };
   ```

2. 加进 `webui/quick/registry.mjs` 的 `PLATFORMS` 数组。数组顺序就是自动识别的优先级。
3. 已毕业的代币在 `detect` 里返回 `graduated: true, extras: [报价币]`，外盘路由就会把报价币当作可用的中转币。
4. 计划里的交易必须由本模块构造。需要授权的步骤只授权本次数量；授权之后如果需要重新模拟，就设置 `replan: true`。
5. 前端和后端路由都不需要改。

## 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/quick/platforms` | 平台列表 |
| POST | `/api/quick/detect` | `{ walletId, address }` → 各平台识别结果 + 推荐平台 |
| POST | `/api/quick/plan` | `{ walletId, address, platform, side, amount \| percent, slippageBps }` → 计划 + 第一步 preview |
| GET | `/api/quick/receipt?hash=` | 交易回执状态（pending / success / failed） |

广播仍然只走 `/api/w/:id/execute`（需要 `confirm=EXECUTE`，requestId 一次性、10 分钟过期）。

## 评测

- `node webui\eval\quick.mjs`：离线测试 calldata 构造和篡改检测。
