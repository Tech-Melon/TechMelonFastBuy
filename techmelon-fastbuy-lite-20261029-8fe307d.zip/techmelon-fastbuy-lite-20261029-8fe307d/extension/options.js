// 插件设置页：插件 ID、控制台地址 + 配对密钥、弹出方式、不加载的网站
const $ = (s) => document.querySelector(s);
const DEFAULTS = { baseUrl: 'http://127.0.0.1:8790', extKey: '', autoOpen: true, watchClipboard: true, sellNoConfirm: true };
const DEFAULT_BLOCK = ['x.com', 'twitter.com']; // 与 content.js / popup.js / background.js 一致

function setState(el, text, ok) {
  el.textContent = text;
  el.className = ok == null ? '' : ok ? 'ok' : 'err';
}

/** 控制台地址：只允许 http://127.0.0.1 / localhost（本机）或 https（自建服务器） */
function normalizeBase(raw) {
  const s = String(raw || '').trim().replace(/\/+$/, '');
  let u;
  try { u = new URL(s); } catch { throw new Error('控制台地址格式不对，例如 http://127.0.0.1:8790'); }
  const local = u.protocol === 'http:' && (u.hostname === '127.0.0.1' || u.hostname === 'localhost');
  if (!local && u.protocol !== 'https:') throw new Error('只支持 http://127.0.0.1 / localhost 或 https:// 地址');
  if (u.pathname !== '/' || u.search || u.hash || u.username || u.password) throw new Error('只填协议 + 域名 + 端口，不要带路径');
  return u.origin;
}

async function load() {
  $('#extId').textContent = chrome.runtime.id;
  const s = { ...DEFAULTS, ...(await chrome.storage.local.get(Object.keys(DEFAULTS))) };
  $('#baseUrl').value = s.baseUrl;
  $('#extKey').value = s.extKey;
  $('#autoOpen').checked = s.autoOpen !== false;
  $('#watchClipboard').checked = s.watchClipboard !== false;
  $('#sellNoConfirm').checked = s.sellNoConfirm !== false;
  const { blockSites } = await chrome.storage.local.get('blockSites');
  $('#blockSites').value = (Array.isArray(blockSites) ? blockSites : DEFAULT_BLOCK).join('\n');
}

/** 「不加载的网站」一行：可以粘网址（https://x.com/home）或 *.x.com，统一成小写域名；不像域名的返回 null */
function normSite(line) {
  let s = String(line || '').trim().toLowerCase();
  if (!s) return '';
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').split(/[/?#]/)[0].replace(/:\d+$/, '').replace(/^\*\./, '').replace(/^\.+|\.+$/g, '');
  return /^(?:[a-z0-9-]+\.)+[a-z0-9-]{2,}$|^localhost$/.test(s) ? s : null;
}

$('#btnSaveBlock').onclick = async () => {
  const lines = $('#blockSites').value.split(/[\n,，;；\s]+/);
  const bad = [];
  const list = [];
  for (const l of lines) {
    const d = normSite(l);
    if (d === null) bad.push(l.trim());
    else if (d && !list.includes(d)) list.push(d);
  }
  if (bad.length) return setState($('#blockState'), `看不懂的域名：${bad.slice(0, 3).join('、')}`, false);
  await chrome.storage.local.set({ blockSites: list });
  $('#blockSites').value = list.join('\n');
  setState($('#blockState'), `已保存 ${list.length} 个（已打开的网页立即生效）`, true);
};

$('#btnCopyId').onclick = async () => {
  try { await navigator.clipboard.writeText(chrome.runtime.id); setState($('#testState'), '插件 ID 已复制', true); } catch { /* 手动选中 */ }
};

$('#btnSave').onclick = async () => {
  const st = $('#testState');
  let baseUrl;
  try { baseUrl = normalizeBase($('#baseUrl').value || DEFAULTS.baseUrl); } catch (err) { return setState(st, err.message, false); }
  const extKey = $('#extKey').value.trim();
  if (!/^[0-9a-f]{64}$/.test(extKey)) return setState(st, '配对密钥应该是 64 位十六进制（控制台生成后复制过来）', false);
  // 自建服务器（https）：要先拿到访问这个网站的权限，后台才能请求它
  if (baseUrl.startsWith('https://')) {
    const granted = await chrome.permissions.request({ origins: [`${baseUrl}/*`] }).catch(() => false);
    if (!granted) return setState(st, '没有得到访问这个网站的权限，插件连不上它', false);
  }
  await chrome.storage.local.set({ baseUrl, extKey });
  setState(st, '测试中…');
  const r = await chrome.runtime.sendMessage({ type: 'api', path: '/api/wallets' });
  if (!r?.ok) return setState(st, `连接失败：${r?.error || '未知错误'}`, false);
  setState(st, `✅ 已连接，读到 ${r.data.length} 个钱包`, true);
};

$('#btnSaveOpts').onclick = async () => {
  await chrome.storage.local.set({ autoOpen: $('#autoOpen').checked, watchClipboard: $('#watchClipboard').checked, sellNoConfirm: $('#sellNoConfirm').checked });
  setState($('#optsState'), '已保存（已打开的网页立即生效）', true);
};

load();
