import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const FILE = path.join(__dirname, 'wallets.json');

// 首次启动（没有 wallets.json）时的钱包列表：空，由用户在「系统 → 钱包」页添加（每个钱包一个 profiles/wallet-N 目录）
const SEED = [];

let cache = null;

async function load() {
  if (cache) return cache;
  try {
    const list = JSON.parse(await readFile(FILE, 'utf8'));
    cache = Array.isArray(list) ? list : [];
  } catch {
    cache = SEED.map((w) => ({ ...w, createdAt: new Date().toISOString() }));
    await persist(cache);
  }
  return cache;
}

async function persist(list) {
  cache = list;
  await writeFile(FILE, JSON.stringify(list, null, 2), 'utf8');
}

export async function listWallets() {
  return load();
}

export async function getWallet(id) {
  const list = await load();
  return list.find((w) => w.id === id) || null;
}

export async function createWallet(name) {
  const list = await load();
  const clean = String(name || '').trim().slice(0, 40);
  if (!clean) throw new Error('钱包名字不能为空');
  if (list.some((w) => w.name === clean)) throw new Error('同名钱包已存在');

  let n = 1;
  const dirs = new Set(list.map((w) => w.dir));
  while (dirs.has(`profiles/wallet-${n}`)) n += 1;
  const dir = `profiles/wallet-${n}`;
  await mkdir(path.join(ROOT, dir), { recursive: true });

  const wallet = {
    id: `wallet-${n}`,
    name: clean,
    dir,
    createdAt: new Date().toISOString(),
  };
  list.push(wallet);
  await persist(list);
  return wallet;
}

export async function setLastStatus(id, status) {
  const list = await load();
  const wallet = list.find((w) => w.id === id);
  if (!wallet) return;
  wallet.lastStatus = { status, at: Date.now() };
  await persist(list);
}

export async function setWalletAddresses(id, addresses) {
  const list = await load();
  const wallet = list.find((w) => w.id === id);
  if (!wallet || !Array.isArray(addresses) || !addresses.length) return;
  wallet.addresses = addresses;
  wallet.evm = addresses.find((a) => a.chainName === 'Ethereum')?.address
    || addresses.find((a) => a.address?.startsWith('0x'))?.address
    || wallet.evm;
  await persist(list);
}

export async function deleteWallet(id) {
  const list = await load();
  const wallet = list.find((w) => w.id === id);
  if (!wallet) throw new Error('钱包不存在');
  const next = list.filter((w) => w.id !== id);
  await persist(next);

  // 删除本地会话目录（不影响链上资产与币安账户）
  try {
    await rm(path.join(ROOT, wallet.dir), { recursive: true, force: true });
  } catch { /* 目录可能已不存在 */ }

  return { removed: wallet.name };
}

export const CLI_ENTRY = path.join(ROOT, '.tmp', 'baw-cli', 'node_modules', '@binance', 'agentic-wallet', 'dist', 'index.js');
export { ROOT };
