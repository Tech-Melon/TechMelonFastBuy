import { encodeFunctionData, decodeFunctionResult, parseAbi } from 'viem';
import { rpc } from './config.mjs';
import { assertSlippageBps } from './agent/guard.mjs';

export const FLAP = {
  portal: '0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062',
  factory: '0xC55820f24015bE7c4f18949D9e1363A3609B300e',
  reader: '0x18Aa6C93f1887a243fdc348C9A77F5136555174a',
  agentId: '0x60B9262456dE011F7d15a54CdD8c48bAaa8B022F',
};

const portalAbi = parseAbi([
  'function buy(address market,uint256 minShares) payable returns (uint256)',
  'function buyWithQuote(address market,uint256 grossQuote,uint256 minShares) returns (uint256)',
  'function sellBps(address market,uint256 bps,uint256 minOut) returns (uint256)',
  'function claim(address market) returns (uint256)',
  'function quoteBuy(address market,address wallet,uint256 grossWei) view returns (uint256 acceptedGross,uint256 fee,uint256 refund,uint256 shares)',
]);

const factoryAbi = parseAbi([
  'function isMarket(address) view returns (bool)',
  'function probeOfMarket(address) view returns (address)',
]);

const probeAbi = parseAbi([
  'function assetProbe()',
  'function buyCapacityProbe()',
  'function buyPlanProbe(uint256 grossWei,uint256 slippageBps)',
  'function positionProbe()',
  'function sellPlanCustomProbe(uint256 bps,uint256 slippageBps)',
  'function quoteFundingProbe(uint256 grossRaw)',
  'function actionStatusProbe()',
  'function claimableProbe()',
  'function launchRouteProbe()',
  'function marketProbe()',
  'function market() view returns (address)',
]);

const erc20Abi = parseAbi(['function approve(address spender,uint256 amount) returns (bool)']);

async function call(to, data, from) {
  const tx = { to, data };
  if (from) tx.from = from;
  try {
    return await rpc('eth_call', [tx, 'latest']);
  } catch (err) {
    err.revertData = err.data || err.revertData;
    throw err;
  }
}

async function callProbe(probe, functionName, args = [], from) {
  const data = encodeFunctionData({ abi: probeAbi, functionName, args });
  try {
    await call(probe, data, from);
    throw new Error(`probe ${functionName} did not revert; unexpected`);
  } catch (err) {
    if (err.code === -32000 || err.code === 3 || err.revertData) {
      const text = decodeErrorString(err.revertData || '');
      if (!text) throw new Error(`probe ${functionName}: unreadable revert payload`);
      return parseFields(text);
    }
    throw err;
  }
}

function decodeErrorString(hex) {
  if (!hex || !hex.startsWith('0x08c379a0')) return null;
  const d = hex.slice(10);
  const off = Number(BigInt(`0x${d.slice(0, 64)}`)) * 2;
  const len = Number(BigInt(`0x${d.slice(off, off + 64)}`)) * 2;
  return Buffer.from(d.slice(off + 64, off + 64 + len), 'hex').toString('utf8');
}

function parseFields(text) {
  if (!text.endsWith('END')) throw new Error(`probe reading not terminated by ;END: ${text.slice(0, 120)}`);
  const out = {};
  for (const part of text.replace(/;END;?$/, '').split(';').filter(Boolean)) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i)] = part.slice(i + 1);
  }
  return out;
}

export function parseUnits(value, decimals = 18) {
  const s = String(value).trim();
  if (!/^\d+(\.\d*)?$/.test(s)) throw new Error(`金额格式不正确: ${value}`);
  const [whole, frac = ''] = s.split('.');
  if (frac.length > decimals) throw new Error(`小数位超过 ${decimals} 位，拒绝四舍五入`);
  const padded = (frac + '0'.repeat(decimals)).slice(0, decimals);
  return (BigInt(whole) * 10n ** BigInt(decimals) + BigInt(padded || '0')).toString();
}

function human(raw, decimals = 18) {
  const s = BigInt(raw).toString().padStart(decimals + 1, '0');
  const whole = s.slice(0, -decimals);
  const frac = s.slice(-decimals).replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole;
}

function same(a, b) {
  return String(a).toLowerCase() === String(b).toLowerCase();
}

/**
 * op: buy | sell | claim | query
 * 返回 plan，其中 steps 按顺序执行（approve → buy）。
 */
export async function planFlap({ wallet, market, op = 'buy', amount, bps, slippageBps = 0, expect = {} }) {
  if (!/^0x[0-9a-fA-F]{40}$/.test(market)) throw new Error('market 地址格式不正确');
  if (!/^0x[0-9a-fA-F]{40}$/.test(wallet)) throw new Error('wallet 地址格式不正确');
  if (op === 'buy' || op === 'sell') slippageBps = assertSlippageBps(slippageBps);

  const checks = [];
  const warnings = [];

  const [isMarket, probe] = await Promise.all([
    call(FLAP.factory, encodeFunctionData({ abi: factoryAbi, functionName: 'isMarket', args: [market] })).then((raw) => decodeFunctionResult({ abi: factoryAbi, functionName: 'isMarket', data: raw })),
    call(FLAP.factory, encodeFunctionData({ abi: factoryAbi, functionName: 'probeOfMarket', args: [market] })).then((raw) => decodeFunctionResult({ abi: factoryAbi, functionName: 'probeOfMarket', data: raw })),
  ]);
  checks.push({ name: 'Factory.isMarket', ok: Boolean(isMarket), detail: String(isMarket) });
  if (!isMarket) throw new Error('Factory.isMarket = false：该地址不是注册的 Market');
  checks.push({ name: 'probeOfMarket', ok: true, detail: probe });

  if (expect.probe && !same(probe, expect.probe)) {
    checks.push({ name: 'Probe 与 CONFIG 一致', ok: false, detail: `链上 ${probe} ≠ CONFIG ${expect.probe}` });
    warnings.push('CONFIG.PROBE 与链上 Factory 记录不一致，请以链上为准并重新复制 CONFIG');
  }

  let probeMarket = null;
  const [asset, capacity, marketBack] = await Promise.all([
    callProbe(probe, 'assetProbe', [], wallet),
    callProbe(probe, 'buyCapacityProbe', [], wallet),
    call(probe, encodeFunctionData({ abi: probeAbi, functionName: 'market' })).catch(() => null),
  ]);
  if (marketBack) {
    try {
      probeMarket = decodeFunctionResult({ abi: probeAbi, functionName: 'market', data: marketBack });
      checks.push({ name: 'Probe.market()', ok: same(probeMarket, market), detail: probeMarket });
    } catch (err) {
      checks.push({ name: 'Probe.market()', ok: false, detail: err.message });
    }
  } else {
    checks.push({ name: 'Probe.market()', ok: false, detail: 'unavailable' });
  }

  const quoteToken = asset.QUOTE;
  const isErc20 = quoteToken && !/^0x0{40}$/i.test(quoteToken);
  const decimals = Number(asset.DECIMALS || 18);

  checks.push({ name: 'assetProbe.MARKET', ok: same(asset.MARKET, market), detail: asset.MARKET });
  checks.push({ name: 'assetProbe.QUOTE', ok: !expect.quote || same(quoteToken, expect.quote), detail: quoteToken });
  checks.push({ name: 'assetProbe.DECIMALS', ok: !expect.decimals || String(decimals) === String(expect.decimals), detail: String(decimals) });
  if (checks.some((c) => !c.ok)) warnings.push('assetProbe 与 CONFIG 存在不一致项，继续前请人工确认');

  // Probe 与 Market 必须互相指认、报价资产格式必须合法：任何一项不满足都不生成交易（只读 query 例外）
  const fatal = [];
  if (probeMarket && !same(probeMarket, market)) fatal.push(`Probe.market()=${probeMarket} ≠ ${market}`);
  if (!same(asset.MARKET, market)) fatal.push(`assetProbe.MARKET=${asset.MARKET} ≠ ${market}`);
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(quoteToken || ''))) fatal.push(`assetProbe.QUOTE 非法：${quoteToken}`);
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) fatal.push(`assetProbe.DECIMALS 非法：${asset.DECIMALS}`);
  if (fatal.length && op !== 'query') throw new Error(`链上 Probe 校验失败，拒绝生成交易：${fatal.join('；')}`);
  if (fatal.length) warnings.push(...fatal);

  const base = { market, probe, wallet, quoteToken, isErc20, decimals, checks, warnings };

  if (op === 'query') {
    const [status, position, marketInfo, claimable, route] = await Promise.all([
      callProbe(probe, 'actionStatusProbe', [], wallet),
      callProbe(probe, 'positionProbe', [], wallet),
      callProbe(probe, 'marketProbe', [], wallet),
      callProbe(probe, 'claimableProbe', [], wallet),
      callProbe(probe, 'launchRouteProbe', [], wallet),
    ]);
    // 份额是 18 位精度的 Market 内部账本；可领取按 18 位（与 claim 分支一致）
    const toHuman = (raw, dec = 18) => {
      try { return human(raw, dec); } catch { return String(raw ?? '—'); }
    };
    return {
      ...base,
      op,
      phase: capacity.PHASE,
      summary: {
        heldSharesHuman: toHuman(position.HELD_SHARES),
        roomSharesHuman: toHuman(capacity.ROOM_SHARES),
        sellOk: position.SELL_OK === '1',
        claimableHuman: toHuman(claimable.CLAIM_RAW),
      },
      probes: { asset, status, position, market: marketInfo, claimable, route, capacity },
      steps: [],
    };
  }

  if (op === 'claim') {
    const [status, claimable, route] = await Promise.all([
      callProbe(probe, 'actionStatusProbe', [], wallet),
      callProbe(probe, 'claimableProbe', [], wallet),
      callProbe(probe, 'launchRouteProbe', [], wallet),
    ]);
    const phase = status.PHASE;
    if (phase !== '3') throw new Error(`PHASE=${phase}，尚未发射，不能 claim`);
    if (status.CLAIM_OK !== '1' || claimable.STATE !== 'READY' || BigInt(claimable.CLAIM_RAW || '0') === 0n) {
      throw new Error(`claim 不可用：CLAIM_OK=${status.CLAIM_OK};STATE=${claimable.STATE};CLAIM_RAW=${claimable.CLAIM_RAW}`);
    }
    const token = status.TOKEN;
    if (route.TOKEN && !same(route.TOKEN, token)) warnings.push('actionStatus.TOKEN 与 launchRoute.TOKEN 不一致');
    const inputData = encodeFunctionData({ abi: portalAbi, functionName: 'claim', args: [market] });
    return {
      ...base,
      op,
      phase,
      token,
      claimable: claimable.CLAIM_RAW,
      claimableHuman: human(claimable.CLAIM_RAW, 18),
      probes: { asset, status, claimable, route },
      steps: [{ label: 'claim', tx: { to: FLAP.portal, value: '0', inputData } }],
    };
  }

  if (op === 'buy') {
    if (capacity.PHASE !== '1') throw new Error(`PHASE=${capacity.PHASE}，当前不可买入`);
    if (capacity.ID !== '1') throw new Error('该钱包没有 Agent ID，买入会被拒绝');
    const grossRaw = parseUnits(amount, decimals);
    if (BigInt(grossRaw) <= 0n) throw new Error('买入金额必须大于 0');

    const [quoteRaw, plan, fundingResult] = await Promise.all([
      call(FLAP.portal, encodeFunctionData({
        abi: portalAbi, functionName: 'quoteBuy', args: [market, wallet, grossRaw],
      })),
      callProbe(probe, 'buyPlanProbe', [grossRaw, BigInt(slippageBps)], wallet),
      isErc20
        ? callProbe(probe, 'quoteFundingProbe', [grossRaw], wallet).catch((err) => ({ __error: err.message }))
        : Promise.resolve(null),
    ]);
    const [acceptedGross, fee, refund, shares] = decodeFunctionResult({
      abi: portalAbi, functionName: 'quoteBuy', data: quoteRaw,
    });

    if (plan.RULES_OK !== '1') warnings.push('buyPlanProbe: RULES_OK=0，当前规则下这笔买入会被拒');

    const minShares = BigInt(plan.MIN_SHARES);
    const steps = [];

    if (isErc20) {
      const funding = fundingResult || {};
      if (funding.__error) throw new Error(`quoteFundingProbe 失败：${funding.__error}`);
      checks.push({ name: 'BALANCE_OK', ok: funding.BALANCE_OK === '1', detail: funding.BALANCE_OK });
      checks.push({ name: 'ALLOWANCE_OK', ok: funding.ALLOWANCE_OK === '1', detail: funding.ALLOWANCE_OK });
      if (funding.BALANCE_OK !== '1') throw new Error(`BNCB 余额不足（需 ${human(grossRaw, decimals)}）|quote=${quoteToken}|need=${human(grossRaw, decimals)}`);
      if (funding.ALLOWANCE_OK !== '1') {
        steps.push({
          label: `approve ${human(grossRaw, decimals)} → Market`,
          tx: {
            to: quoteToken,
            value: '0',
            inputData: encodeFunctionData({
              abi: erc20Abi, functionName: 'approve', args: [market, BigInt(grossRaw)],
            }),
          },
        });
      }
      steps.push({
        label: 'buyWithQuote',
        tx: {
          to: FLAP.portal,
          value: '0',
          inputData: encodeFunctionData({
            abi: portalAbi, functionName: 'buyWithQuote', args: [market, BigInt(grossRaw), minShares],
          }),
        },
      });
    } else {
      steps.push({
        label: 'buy',
        tx: {
          to: FLAP.portal,
          value: grossRaw,
          inputData: encodeFunctionData({ abi: portalAbi, functionName: 'buy', args: [market, minShares] }),
        },
      });
    }

    return {
      ...base,
      op,
      phase: capacity.PHASE,
      capacity,
      quote: {
        grossRaw, grossHuman: human(grossRaw, decimals),
        acceptedRaw: acceptedGross.toString(), acceptedHuman: human(acceptedGross, decimals),
        feeRaw: fee.toString(), feeHuman: human(fee, decimals),
        refundRaw: refund.toString(), shares: shares.toString(), sharesHuman: human(shares),
        minShares: minShares.toString(), slipBps: slippageBps,
      },
      steps,
      probes: { asset, capacity, plan },
    };
  }

  if (op === 'sell') {
    const position = await callProbe(probe, 'positionProbe', [], wallet);
    if (position.PHASE !== '1') throw new Error(`PHASE=${position.PHASE}，当前不可卖出`);
    if (BigInt(position.HELD_SHARES) === 0n) throw new Error('该钱包在此市场没有份额');
    if (position.SELL_OK !== '1') throw new Error(`SELL_OK=0（PHASE=${position.PHASE}），当前不能卖出`);
    if (!(bps >= 1 && bps <= 10000)) throw new Error('卖出比例 bps 必须在 1..10000');

    const sellPlan = await callProbe(probe, 'sellPlanCustomProbe', [BigInt(bps), BigInt(slippageBps)], wallet);
    const minOut = BigInt(sellPlan.MIN_RAW);
    const step = {
      label: 'sellBps',
      tx: {
        to: FLAP.portal,
        value: '0',
        inputData: encodeFunctionData({ abi: portalAbi, functionName: 'sellBps', args: [market, BigInt(bps), minOut] }),
      },
    };
    return {
      ...base,
      op,
      phase: position.PHASE,
      position,
      quote: {
        bps, shares: sellPlan.SHARES, sharesHuman: human(sellPlan.SHARES),
        outRaw: sellPlan.OUT_RAW, outHuman: human(sellPlan.OUT_RAW, decimals),
        minOut: minOut.toString(), slipBps: slippageBps,
      },
      steps: [step],
      probes: { asset, position, sellPlan },
    };
  }

  throw new Error(`不支持的 op: ${op}`);
}

export async function planFromPrompt(config, operation, params) {
  return { config, operation, params };
}
