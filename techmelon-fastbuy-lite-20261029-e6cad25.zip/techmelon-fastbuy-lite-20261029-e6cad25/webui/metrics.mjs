import { readFile, writeFile } from 'node:fs/promises';

const FILE = new URL('./metrics.json', import.meta.url);
const startedAt = Date.now();
const MAX_AGE_MS = 35 * 24 * 3600 * 1000;

let buckets = {};
let loaded = false;
let saveTimer = null;
let dirty = false;

const recent = {
  rpc: [],
  cli: [],
  llm: [],
};

function hourKey(ts = Date.now()) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}T${String(d.getHours()).padStart(2, '0')}`;
}

async function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  try {
    const parsed = JSON.parse(await readFile(FILE, 'utf8'));
    buckets = parsed.buckets || {};
    const cutoff = Date.now() - MAX_AGE_MS;
    for (const [key, value] of Object.entries(buckets)) {
      if (!value?.t || value.t < cutoff) delete buckets[key];
    }
  } catch {
    buckets = {};
  }
}

function emptyBucket(ts) {
  return {
    t: Math.floor(ts / 3600000) * 3600000,
    rpc: { count: 0, errors: 0, ms: 0, byMethod: {}, byNode: {}, byHost: {}, byTask: {} },
    cli: { count: 0, errors: 0, ms: 0, byCmd: {} },
    llm: { calls: 0, errors: 0, ms: 0, tokens: 0 },
    lat: { last: 0, sum: 0, count: 0 },
  };
}

function bucket() {
  const ts = Date.now();
  const key = hourKey(ts);
  if (!buckets[key]) buckets[key] = emptyBucket(ts);
  return buckets[key];
}

function scheduleSave() {
  dirty = true;
  if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null;
    if (!dirty) return;
    dirty = false;
    try {
      await writeFile(FILE, JSON.stringify({ buckets }), 'utf8');
    } catch { /* 忽略磁盘错误 */ }
  }, 2000);
}

/**
 * tier：paid = 交易用的主节点（计入 rpc.count / 延迟 / 方法分布，看额度用）；bg = 后台节点（NodeReal 等）；public = 免费公共节点。
 * 三类都计入 rpc.byNode（每类的次数 / 失败 / 方法分布），设置页「RPC 调用统计」据此显示各节点承担了多少。
 */
export function recordRpc(method, ms, ok, tier = 'paid', { host = null, task = null } = {}) {
  ensureLoaded();
  const b = bucket();
  if (!b.rpc.byNode) b.rpc.byNode = {};
  const n = b.rpc.byNode[tier] || (b.rpc.byNode[tier] = { count: 0, errors: 0, byMethod: {} });
  n.count += 1;
  if (!ok) n.errors += 1;
  n.byMethod[method] = (n.byMethod[method] || 0) + 1;
  // 按节点主机（QuickNode / NodeReal / 公共节点…，含主节点失败后切到的备用）和后台任务名计数：查「哪个节点的额度被谁用掉了」
  if (host) {
    if (!b.rpc.byHost) b.rpc.byHost = {};
    b.rpc.byHost[host] = (b.rpc.byHost[host] || 0) + 1;
  }
  if (task) {
    if (!b.rpc.byTask) b.rpc.byTask = {};
    const t = b.rpc.byTask[task] || (b.rpc.byTask[task] = {});
    t[tier] = (t[tier] || 0) + 1;
  }
  if (tier !== 'paid') { scheduleSave(); return; }
  b.rpc.count += 1;
  b.rpc.ms += ms;
  if (!ok) b.rpc.errors += 1;
  b.rpc.byMethod[method] = (b.rpc.byMethod[method] || 0) + 1;
  b.lat.last = ms;
  b.lat.sum += ms;
  b.lat.count += 1;
  recent.rpc.push({ method, ms, ok, at: Date.now() });
  if (recent.rpc.length > 60) recent.rpc.shift();
  scheduleSave();
}

export function recordCli(cmd, ms, ok) {
  ensureLoaded();
  const b = bucket();
  b.cli.count += 1;
  b.cli.ms += ms;
  if (!ok) b.cli.errors += 1;
  b.cli.byCmd[cmd] = (b.cli.byCmd[cmd] || 0) + 1;
  recent.cli.push({ cmd, ms, ok, at: Date.now() });
  if (recent.cli.length > 60) recent.cli.shift();
  scheduleSave();
}

export function recordLlm(ms, ok, tokens = 0) {
  ensureLoaded();
  const b = bucket();
  b.llm.calls += 1;
  b.llm.ms += ms;
  if (!ok) b.llm.errors += 1;
  b.llm.tokens += tokens;
  recent.llm.push({ ms, ok, tokens, at: Date.now() });
  if (recent.llm.length > 40) recent.llm.shift();
  scheduleSave();
}

const PERIODS = {
  '1h': 3600 * 1000,
  '24h': 24 * 3600 * 1000,
  '7d': 7 * 24 * 3600 * 1000,
  all: Number.MAX_SAFE_INTEGER,
};

export async function metricsSnapshot(period = 'all') {
  await ensureLoaded();
  const span = PERIODS[period] ?? PERIODS.all;
  const cutoff = Date.now() - span;

  const total = emptyBucket(Date.now());
  total.t = 0;
  let lastLatency = 0;
  let latestT = 0;

  for (const [key, b] of Object.entries(buckets)) {
    if (!b?.t || b.t < cutoff) continue;
    total.rpc.count += b.rpc.count;
    total.rpc.errors += b.rpc.errors;
    total.rpc.ms += b.rpc.ms;
    for (const [k, v] of Object.entries(b.rpc.byMethod || {})) {
      total.rpc.byMethod[k] = (total.rpc.byMethod[k] || 0) + v;
    }
    for (const [tier, n] of Object.entries(b.rpc.byNode || {})) {
      const t = total.rpc.byNode[tier] || (total.rpc.byNode[tier] = { count: 0, errors: 0, byMethod: {} });
      t.count += n.count;
      t.errors += n.errors;
      for (const [k, v] of Object.entries(n.byMethod || {})) t.byMethod[k] = (t.byMethod[k] || 0) + v;
    }
    for (const [h, v] of Object.entries(b.rpc.byHost || {})) total.rpc.byHost[h] = (total.rpc.byHost[h] || 0) + v;
    for (const [k, tiers] of Object.entries(b.rpc.byTask || {})) {
      const t = total.rpc.byTask[k] || (total.rpc.byTask[k] = {});
      for (const [tier, v] of Object.entries(tiers)) t[tier] = (t[tier] || 0) + v;
    }
    total.cli.count += b.cli.count;
    total.cli.errors += b.cli.errors;
    total.cli.ms += b.cli.ms;
    for (const [k, v] of Object.entries(b.cli.byCmd || {})) {
      total.cli.byCmd[k] = (total.cli.byCmd[k] || 0) + v;
    }
    total.llm.calls += b.llm.calls;
    total.llm.errors += b.llm.errors;
    total.llm.ms += b.llm.ms;
    total.llm.tokens += b.llm.tokens;
    if (b.t >= latestT && b.lat?.last) {
      latestT = b.t;
      lastLatency = b.lat.last;
    }
  }

  return {
    period,
    uptimeMs: Date.now() - startedAt,
    rpc: {
      count: total.rpc.count,
      errors: total.rpc.errors,
      avgMs: total.rpc.count ? Math.round(total.rpc.ms / total.rpc.count) : 0,
      byMethod: total.rpc.byMethod,
      byNode: total.rpc.byNode,
      byHost: total.rpc.byHost,
      byTask: total.rpc.byTask,
      recent: recent.rpc.slice(-20).reverse(),
      lastMs: lastLatency,
    },
    cli: {
      count: total.cli.count,
      errors: total.cli.errors,
      avgMs: total.cli.count ? Math.round(total.cli.ms / total.cli.count) : 0,
      byCmd: total.cli.byCmd,
      recent: recent.cli.slice(-20).reverse(),
    },
    llm: {
      calls: total.llm.calls,
      errors: total.llm.errors,
      avgMs: total.llm.calls ? Math.round(total.llm.ms / total.llm.calls) : 0,
      tokens: total.llm.tokens,
      recent: recent.llm.slice(-10).reverse(),
    },
  };
}
