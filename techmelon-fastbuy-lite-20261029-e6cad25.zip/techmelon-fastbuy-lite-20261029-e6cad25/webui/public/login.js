// 登录页：拦下表单提交改用 fetch（POST /auth/login，JSON），成功后整页跳回控制台。
// 浏览器保存密码：Chrome / Edge 先用 Credential Management API 明确存一次；其它浏览器靠「表单提交后跳转」的识别逻辑。
const form = document.getElementById('loginForm');
const pw = document.getElementById('pw');
const btn = document.getElementById('go');
const err = document.getElementById('err');

async function rememberPassword() {
  try {
    if (window.PasswordCredential && navigator.credentials?.store) {
      await navigator.credentials.store(new window.PasswordCredential(form));
    }
  } catch { /* 用户拒绝保存 / 浏览器不支持：不影响登录 */ }
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!pw.value) { err.textContent = '请输入密码'; return; }
  btn.disabled = true;
  err.textContent = '';
  try {
    const res = await fetch('/auth/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ password: pw.value }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok && data.ok) {
      await rememberPassword();
      location.replace('/');
      return;
    }
    err.textContent = data.error || `登录失败（HTTP ${res.status}）`;
    pw.select();
  } catch {
    err.textContent = '网络错误，请重试';
  } finally {
    btn.disabled = false;
  }
});
