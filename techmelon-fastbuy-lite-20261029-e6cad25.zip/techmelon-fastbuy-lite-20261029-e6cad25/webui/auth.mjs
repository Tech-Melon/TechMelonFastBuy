/**
 * 公网部署的登录闸门（参照 gmgn-toolkit 的 sniper/auth.py）。
 *
 * 只有设置了 PUBLIC_ORIGIN（例如 https://wallet.example.com）才启用；本机 Windows 直接运行时完全不生效，行为与以前一致。
 * 启用后，经 Nginx 进来的每个请求依次过：
 *   1. 客户端 IP 白名单（ALLOWED_CLIENT_IPS / ALLOWED_CLIENT_IPS_FILE）—— 名单为空时一律拒绝（fail-closed）；
 *   2. 登录会话（HttpOnly + Secure + SameSite=Strict cookie，7 天绝对过期，绑定 UA 指纹）；
 *   3. 原有的 Host / Origin / API 令牌校验（server.mjs 的 assertApiRequest，不变）。
 * 登录：同一 IP 10 分钟内失败 3 次封禁 1 小时；密码只存 scrypt 哈希（ADMIN_PASSWORD_HASH），校验用异步 scrypt，不阻塞事件循环。
 * 真实 IP 只信任来自本机 Nginx（TRUSTED_PROXY_IPS）的 X-Real-IP；Nginx 只信任 Cloudflare 网段的 CF-Connecting-IP。
 * 服务器上本机直连（Host 为 127.0.0.1:端口、且没有任何代理头）视为本机脚本，沿用原来的 API 令牌机制。
 */
import { scrypt, randomBytes, timingSafeEqual, createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { injectCacheBusters } from './static_cache.mjs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const COOKIE = 'aibot_session';
const SESSION_MAX_AGE_S = 7 * 24 * 3600;
const MAX_SESSIONS = 50;
const MAX_ATTEMPTS = 3;
const ATTEMPT_WINDOW_MS = 600 * 1000;
const BAN_MS = 3600 * 1000;
const MAX_IP_RECORDS = 5000;
const MAX_LOGIN_BODY = 4096;

function parseOrigin(raw) {
  const s = String(raw || '').trim().replace(/\/+$/, '');
  if (!s) return null;
  const u = new URL(s);
  if (u.protocol !== 'https:' || u.pathname !== '/' || u.search || u.hash) throw new Error(`PUBLIC_ORIGIN 必须是 https://域名 形式：${s}`);
  return { origin: u.origin, host: u.host };
}

const PUBLIC = parseOrigin(process.env.PUBLIC_ORIGIN);
export const authEnabled = Boolean(PUBLIC);
export const publicOrigin = PUBLIC?.origin || null;
export const publicHost = PUBLIC?.host || null;

/** 解析 CIDR 列表成 BlockList（支持 IPv4 / IPv6、单个 IP 不带前缀） */
function buildList(entries, label) {
  const list = new net.BlockList();
  let n = 0;
  for (const raw of entries) {
    const item = raw.replace(/#.*/, '').trim();
    if (!item) continue;
    const [addr, bits] = item.split('/');
    const type = net.isIP(addr) === 6 ? 'ipv6' : net.isIP(addr) === 4 ? 'ipv4' : null;
    if (!type) { console.warn(`[auth] 忽略无效的 ${label} 条目：${item}`); continue; }
    const prefix = bits === undefined ? (type === 'ipv4' ? 32 : 128) : Number(bits);
    if (!Number.isInteger(prefix) || prefix < 0 || prefix > (type === 'ipv4' ? 32 : 128)) { console.warn(`[auth] 忽略无效的 ${label} 前缀：${item}`); continue; }
    list.addSubnet(addr, prefix, type);
    n += 1;
  }
  return { list, n };
}

function readAllowEntries() {
  const out = String(process.env.ALLOWED_CLIENT_IPS || '').split(',');
  const file = process.env.ALLOWED_CLIENT_IPS_FILE;
  if (file) {
    try { out.push(...readFileSync(file, 'utf8').split(/\r?\n/)); } catch (err) { console.warn(`[auth] 读不到白名单文件 ${file}：${err.message}（按空名单处理，全部拒绝）`); }
  }
  return out;
}

const ALLOW = buildList(readAllowEntries(), 'ALLOWED_CLIENT_IPS');
const PROXIES = buildList(String(process.env.TRUSTED_PROXY_IPS || '127.0.0.1/32,::1/128').split(','), 'TRUSTED_PROXY_IPS');
const PASSWORD_HASH = String(process.env.ADMIN_PASSWORD_HASH || '').trim();

if (authEnabled) {
  console.log(`[auth] 公网模式：${publicOrigin} · 白名单 ${ALLOW.n} 条${ALLOW.n ? '' : '（为空：全部拒绝）'} · ${PASSWORD_HASH ? '已设置登录密码' : '未设置登录密码（无法登录）'}`);
}

const normIp = (ip) => String(ip || '').replace(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/, '$1');
const ipType = (ip) => (net.isIP(ip) === 6 ? 'ipv6' : net.isIP(ip) === 4 ? 'ipv4' : null);
const inList = (l, ip) => { const t = ipType(ip); return Boolean(t) && l.list.check(ip, t); };

/** 真实客户端 IP：只有对端是受信代理（本机 Nginx）时才读 X-Real-IP */
function clientIp(req) {
  const peer = normIp(req.socket.remoteAddress);
  if (!inList(PROXIES, peer)) return peer;
  const real = normIp(String(req.headers['x-real-ip'] || '').split(',')[0].trim());
  return ipType(real) ? real : peer;
}

const hasProxyHeaders = (req) => Boolean(req.headers['x-real-ip'] || req.headers['x-forwarded-for'] || req.headers['cf-connecting-ip']);

// ---- 会话：内存 + 落盘（webui/sessions.json，600）。服务重启 / 更新代码后不用重新输密码 ----
// 文件里只存 cookie 值的 SHA-256（拿到文件也伪造不出 cookie），连同到期时间和 UA 指纹；改密码时整个文件作废（见 pwTag）。
const SESSIONS_FILE = process.env.SESSIONS_FILE || path.join(__dirname, 'sessions.json');
const sidHash = (sid) => createHash('sha256').update(sid).digest('hex');
const pwTag = createHash('sha256').update(`pw\0${PASSWORD_HASH}`).digest('hex').slice(0, 16);
const sessions = new Map(); // sha256(sid) -> { exp, fp }
if (authEnabled) {
  try {
    const d = JSON.parse(readFileSync(SESSIONS_FILE, 'utf8'));
    if (d.pwTag === pwTag && d.sessions && typeof d.sessions === 'object') {
      const t = Date.now();
      for (const [k, v] of Object.entries(d.sessions)) if (/^[0-9a-f]{64}$/.test(k) && v.exp > t && typeof v.fp === 'string') sessions.set(k, { exp: v.exp, fp: v.fp });
    }
  } catch { /* 没有文件 / 损坏：大家重新登录一次 */ }
}
let saving = Promise.resolve();
function persistSessions() {
  if (!authEnabled) return;
  const body = JSON.stringify({ pwTag, sessions: Object.fromEntries(sessions) });
  saving = saving.then(async () => {
    const tmp = `${SESSIONS_FILE}.${process.pid}.tmp`;
    try {
      await writeFile(tmp, body, { encoding: 'utf8', mode: 0o600 });
      await rename(tmp, SESSIONS_FILE);
    } catch (err) { console.warn(`[auth] 保存登录会话失败：${err.message}`); }
  });
}
const fingerprint = (req) => createHash('sha256').update(`allowlisted\0${req.headers['user-agent'] || ''}`).digest('hex');

function readCookie(req, name) {
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return null;
}

function sessionOf(req) {
  const sid = readCookie(req, COOKIE);
  if (!sid || !/^[A-Za-z0-9_-]{43}$/.test(sid)) return null;
  const key = sidHash(sid);
  const s = sessions.get(key);
  if (!s) return null;
  if (Date.now() > s.exp) { sessions.delete(key); persistSessions(); return null; }
  const fp = fingerprint(req);
  if (fp.length !== s.fp.length || !timingSafeEqual(Buffer.from(fp), Buffer.from(s.fp))) return null;
  return { key, ...s };
}

function createSession(req) {
  const now = Date.now();
  for (const [k, v] of sessions) if (now > v.exp) sessions.delete(k);
  while (sessions.size >= MAX_SESSIONS) sessions.delete(sessions.keys().next().value);
  const sid = randomBytes(32).toString('base64url');
  sessions.set(sidHash(sid), { exp: now + SESSION_MAX_AGE_S * 1000, fp: fingerprint(req) });
  persistSessions();
  return sid;
}

// ---- 登录失败限流 ----
const attempts = new Map(); // ip -> { count, first, bannedUntil }

function banRemaining(ip) {
  const r = attempts.get(ip);
  if (!r) return 0;
  const now = Date.now();
  if (r.bannedUntil > now) return Math.ceil((r.bannedUntil - now) / 1000);
  if (now - r.first > ATTEMPT_WINDOW_MS) attempts.delete(ip);
  return 0;
}

function recordFailure(ip) {
  const now = Date.now();
  if (attempts.size >= MAX_IP_RECORDS) attempts.delete(attempts.keys().next().value);
  const r = attempts.get(ip);
  if (!r || now - r.first > ATTEMPT_WINDOW_MS) { attempts.set(ip, { count: 1, first: now, bannedUntil: 0 }); return 0; }
  r.count += 1;
  if (r.count >= MAX_ATTEMPTS) {
    r.bannedUntil = now + BAN_MS;
    console.warn(`[auth] IP ${ip} 连续 ${r.count} 次登录失败，封禁 ${BAN_MS / 1000} 秒`);
    return BAN_MS / 1000;
  }
  return 0;
}

/** ADMIN_PASSWORD_HASH = scrypt:N:r:p:<salt b64>:<hash b64>（生成方法见部署文档「公网部署」；用冒号分隔，避免 systemd 环境文件里 $ 的歧义） */
function verifyPassword(password) {
  return new Promise((resolve) => {
    const m = PASSWORD_HASH.match(/^scrypt:(\d+):(\d+):(\d+):([A-Za-z0-9+/=]+):([A-Za-z0-9+/=]+)$/);
    if (!m || typeof password !== 'string' || !password || password.length > 256) return resolve(false);
    const [N, r, p] = [Number(m[1]), Number(m[2]), Number(m[3])];
    const salt = Buffer.from(m[4], 'base64');
    const want = Buffer.from(m[5], 'base64');
    scrypt(password, salt, want.length, { N, r, p, maxmem: 256 * N * r }, (err, got) => {
      resolve(!err && got.length === want.length && timingSafeEqual(got, want));
    });
  });
}

// ---- 响应 ----
const BASE_HEADERS = {
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
  'strict-transport-security': 'max-age=31536000; includeSubDomains',
  'cache-control': 'no-store',
};
// form-action 'self'：登录页是标准表单（浏览器密码管理器要求），提交由 login.js 拦下改用 fetch；仍只允许提交到本站
const LOGIN_CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";

function sendJson(res, status, body, extra = {}) {
  res.writeHead(status, { ...BASE_HEADERS, 'content-type': 'application/json; charset=utf-8', ...extra });
  res.end(JSON.stringify(body));
}
function sendText(res, status, text, extra = {}) {
  res.writeHead(status, { ...BASE_HEADERS, 'content-type': 'text/plain; charset=utf-8', ...extra });
  res.end(text);
}

function readSmallJson(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
      if (raw.length > MAX_LOGIN_BODY) { reject(new Error('body too large')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('invalid json')); } });
    req.on('error', reject);
  });
}

const sameOrigin = (req) => req.headers.origin === publicOrigin && (!req.headers['sec-fetch-site'] || req.headers['sec-fetch-site'] === 'same-origin');

async function handleLogin(req, res, ip) {
  if (!sameOrigin(req)) return sendJson(res, 403, { ok: false, error: '跨站请求已拒绝' });
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (type !== 'application/json') return sendJson(res, 415, { ok: false, error: 'content-type must be application/json' });
  const wait = banRemaining(ip);
  if (wait) return sendJson(res, 429, { ok: false, error: `登录失败次数过多，请 ${Math.ceil(wait / 60)} 分钟后再试` }, { 'retry-after': String(wait) });
  let body;
  try { body = await readSmallJson(req); } catch { return sendJson(res, 400, { ok: false, error: '请求格式错误' }); }
  if (!PASSWORD_HASH) return sendJson(res, 503, { ok: false, error: '服务器还没设置登录密码（设置环境变量 ADMIN_PASSWORD_HASH 后重启）' });
  if (!(await verifyPassword(body.password))) {
    const banned = recordFailure(ip);
    return sendJson(res, 401, { ok: false, error: banned ? '密码错误次数过多，已封禁 1 小时' : '密码错误' });
  }
  attempts.delete(ip);
  const sid = createSession(req);
  console.log(`[auth] 登录成功：${ip}`);
  return sendJson(res, 200, { ok: true }, {
    'set-cookie': `${COOKIE}=${sid}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_MAX_AGE_S}`,
  });
}

function handleLogout(req, res) {
  if (!sameOrigin(req)) return sendJson(res, 403, { ok: false, error: '跨站请求已拒绝' });
  const s = sessionOf(req);
  if (s) { sessions.delete(s.key); persistSessions(); }
  return sendJson(res, 200, { ok: true }, { 'set-cookie': `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
}

async function serveLoginAsset(res, file, type) {
  try {
    let body = await readFile(path.join(__dirname, 'public', file));
    if (file.endsWith('.html')) body = Buffer.from(await injectCacheBusters(body.toString('utf8'), path.join(__dirname, 'public')), 'utf8'); // login.js 带内容哈希
    res.writeHead(200, { ...BASE_HEADERS, 'content-type': type, 'content-security-policy': LOGIN_CSP });
    res.end(body);
  } catch {
    sendText(res, 404, 'not found');
  }
}

/**
 * 请求闸门。返回 true = 已经响应（拦下或处理了登录），调用方直接 return；false = 放行给原来的处理逻辑。
 * @param {{ localHosts: Set<string> }} opts 本机直连允许的 Host（127.0.0.1:端口 / localhost:端口）
 */
export async function authGate(req, res, url, { localHosts, extension = null }) {
  if (!authEnabled) return false;
  const host = String(req.headers.host || '');
  // 服务器本机脚本直连（不经 Nginx）：沿用 API 令牌机制
  if (localHosts.has(host) && !hasProxyHeaders(req) && inList(PROXIES, normIp(req.socket.remoteAddress))) return false;
  if (host !== publicHost) { sendText(res, 421, 'host not allowed'); return true; }

  const ip = clientIp(req);
  if (!inList(ALLOW, ip)) {
    console.warn(`[auth] 拒绝白名单外 IP：${ip} ${req.method} ${url.pathname}`);
    sendText(res, 403, '访问已拒绝');
    return true;
  }

  const p = url.pathname;
  if (req.method === 'GET' && (p === '/login' || p === '/login.html')) { await serveLoginAsset(res, 'login.html', 'text/html; charset=utf-8'); return true; }
  if (req.method === 'GET' && p === '/login.js') { await serveLoginAsset(res, 'login.js', 'text/javascript; charset=utf-8'); return true; }
  // 产品头像：登录页 / 浏览器标签图标要用，静态图片、不含任何数据
  if (req.method === 'GET' && p === '/logo.svg') { await serveLoginAsset(res, 'logo.svg', 'image/svg+xml'); return true; }
  if (req.method === 'POST' && p === '/auth/login') { await handleLogin(req, res, ip); return true; }
  if (req.method === 'POST' && p === '/auth/logout') { handleLogout(req, res); return true; }

  // 浏览器插件（带 x-ext-key，见 server.mjs extensionCheck）：插件带不了 SameSite=Strict 的登录 cookie，靠配对密钥；
  // IP 白名单照样要过（上面已经检查）。密钥不对时直接说原因，不回「登录已过期」误导人
  const e = p.startsWith('/api/') ? extension?.(req, url) : null;
  if (e) {
    if (e.ok) return false;
    sendJson(res, 403, { ok: false, error: e.why });
    return true;
  }

  if (sessionOf(req)) return false;
  if (p.startsWith('/api/')) {
    sendJson(res, 401, { ok: false, error: '登录已过期，请重新登录', login: true }, { 'x-auth-required': '1' });
  } else {
    res.writeHead(302, { ...BASE_HEADERS, location: '/login' });
    res.end();
  }
  return true;
}

/** 公网模式额外的安全头（HSTS），合并进页面与静态资源响应 */
export const extraSecurityHeaders = authEnabled ? { 'strict-transport-security': BASE_HEADERS['strict-transport-security'] } : {};
