import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';

const FILE = new URL('./addressbook.json', import.meta.url);

async function load() {
  try {
    const list = JSON.parse(await readFile(FILE, 'utf8'));
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

async function persist(list) {
  await writeFile(FILE, JSON.stringify(list, null, 2), 'utf8');
}

export async function listAddresses() {
  const list = await load();
  return list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
}

export async function addAddress({ name, address, chainId }) {
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) throw new Error('地址格式不正确');
  const list = await load();
  if (list.some((x) => x.address.toLowerCase() === address.toLowerCase() && String(x.chainId) === String(chainId))) {
    throw new Error('该地址已在地址簿中');
  }
  const entry = {
    id: randomUUID(),
    name: String(name || '').trim().slice(0, 40) || '未命名',
    address,
    chainId: String(chainId || '56'),
    createdAt: new Date().toISOString(),
  };
  list.push(entry);
  await persist(list);
  return entry;
}

export async function removeAddress(id) {
  const list = await load();
  const next = list.filter((x) => x.id !== id);
  await persist(next);
  return { removed: list.length - next.length };
}
