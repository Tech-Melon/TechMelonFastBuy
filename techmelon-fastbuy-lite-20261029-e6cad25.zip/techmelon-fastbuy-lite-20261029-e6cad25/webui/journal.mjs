/**
 * 执行日志（只追加 JSONL）：每笔 execute、一键买入任务的每次状态变化都写一行，服务重启不丢。
 * 用途：重启后找出「执行到一半」的一键任务（例如已换币未买入），以及事后核对每笔广播。
 * 不记录任何凭据：只有钱包 id、合约地址、金额、calldata 选择器、交易哈希。
 * 文件：webui/journal.jsonl（已在 .gitignore 中忽略）。超过 5MB 时轮转成 journal.1.jsonl。
 */
import { appendFile, readFile, stat, rename } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

// JOURNAL_FILE 只给评测用（写到临时文件，不污染真实执行日志）
const FILE = process.env.JOURNAL_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), 'journal.jsonl');
const DIR = path.dirname(FILE);
const MAX_BYTES = 5 * 1024 * 1024;
// 轮转保留 3 代（journal.1 最新 … journal.3 最旧）：一天内轮转两次也不会丢当天的执行记录（每日上限 / 狙击名额靠它重建）
const KEEP = 3;
const rotated = (i) => path.join(DIR, `journal.${i}.jsonl`);

let chain = Promise.resolve(); // 串行写，避免并发追加交错

async function rotate() {
  for (let i = KEEP - 1; i >= 1; i -= 1) await rename(rotated(i), rotated(i + 1)).catch(() => {});
  await rename(FILE, rotated(1)).catch(() => {});
}

const listeners = new Set();
/** 订阅新写入的日志行（同进程内，写盘前同步回调；例：买入后立即加入「发射后自动转移」监控）。返回取消函数 */
export function onJournal(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function journal(type, data) {
  const row = { at: new Date().toISOString(), type, ...data };
  for (const fn of listeners) { try { fn(row); } catch { /* 监听者出错不影响写日志 */ } }
  const line = `${JSON.stringify(row)}\n`;
  chain = chain.then(async () => {
    try {
      const s = await stat(FILE).catch(() => null);
      if (s && s.size > MAX_BYTES) await rotate();
      await appendFile(FILE, line, 'utf8');
    } catch (err) {
      console.warn(`[journal] 写入失败：${err.message}`);
    }
  });
  return chain;
}

/** 读最近 limit 行；withRotated 时先读轮转出去的 journal.1.jsonl（统计当天花费不能因轮转丢记录） */
export async function readJournal(limit = 300, { withRotated = false } = {}) {
  await chain; // 等正在写的行落盘
  let raw = '';
  if (withRotated) {
    for (let i = KEEP; i >= 1; i -= 1) raw += `${await readFile(rotated(i), 'utf8').catch(() => '')}\n`; // 从旧到新
  }
  raw += await readFile(FILE, 'utf8').catch(() => '');
  if (!raw.trim()) return [];
  const lines = raw.trim().split('\n');
  return (Number.isFinite(limit) ? lines.slice(-limit) : lines).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}

export const PROCESS_STARTED = Date.now();

/**
 * 广播中断的单笔交易：上次运行写了 execute.begin，却没有 execute.done / execute.error（服务在广播途中被杀 / 崩溃）。
 * 交易可能已经上链，也可能没发出去：极速狙击、Four、自动打新的单笔广播不在一键任务里，靠这个提示人工核对。
 * 只看本进程启动之前的记录（本进程正在广播的不算），最近 3 天。
 */
export async function orphanExecutes() {
  const rows = await readJournal(5000, { withRotated: true });
  const since = PROCESS_STARTED - 3 * 86400 * 1000;
  const open = new Map();
  for (const r of rows) {
    if (!r.requestId) continue;
    const t = Date.parse(r.at);
    if (r.type === 'execute.begin' && t < PROCESS_STARTED && t > since) open.set(r.requestId, r);
    else if (r.type === 'execute.done' || r.type === 'execute.error') open.delete(r.requestId);
  }
  return [...open.values()].map((r) => ({
    jobId: `exec:${r.requestId}`, orphan: true, walletId: r.walletId, startedAt: r.at, token: r.to, platform: '单笔广播（服务中断，结果未知）',
    steps: [{ kind: r.selector || 'execute', status: '去区块浏览器按钱包地址核对', txHash: null }], valueWei: r.value || '0',
  }));
}

/** 未完成的一键任务：有 oneclick.start，但没有 oneclick.end */
export async function unfinishedJobs() {
  const rows = await readJournal(2000);
  const jobs = new Map();
  for (const r of rows) {
    if (!r.jobId) continue;
    if (r.type === 'oneclick.start') jobs.set(r.jobId, { jobId: r.jobId, walletId: r.walletId, startedAt: r.at, token: r.token, platform: r.platform, steps: [] });
    else if (r.type === 'oneclick.step' && jobs.has(r.jobId)) jobs.get(r.jobId).steps.push({ kind: r.kind, txHash: r.txHash, status: r.status });
    else if (r.type === 'oneclick.end') jobs.delete(r.jobId);
  }
  return [...jobs.values()];
}
