/**
 * 极简 JSON-RPC over WebSocket（Node 22+ 内置 WebSocket，无额外依赖）。
 * - eth_subscribe 订阅 newHeads / logs，断线后指数退避重连并自动重新订阅
 * - 心跳：每 15 秒 eth_blockNumber，超时视为断线
 * - URL 含节点令牌：日志与错误信息里只出现 maskUrl 后的值
 */
import { maskUrl } from '../config.mjs';

const REQUEST_TIMEOUT_MS = 8000;
const HEARTBEAT_MS = 15000;

export class WsRpc {
  /**
   * @param {string} url wss 地址
   * @param {{ onStatus?: Function, onReconnect?: Function }} hooks
   */
  constructor(url, hooks = {}) {
    this.url = url;
    this.hooks = hooks;
    this.ws = null;
    this.nextId = 1;
    this.pending = new Map();
    this.subs = []; // { params, handler, subId }
    this.closed = false;
    this.backoff = 1000;
    this.connectedAt = 0;
    this.lastRttMs = null;
  }

  get masked() { return maskUrl(this.url); }

  get connected() { return this.ws?.readyState === WebSocket.OPEN; }

  start() {
    this.closed = false;
    this.#open();
  }

  stop() {
    this.closed = true;
    clearInterval(this.heartbeat);
    clearTimeout(this.retryTimer);
    try { this.ws?.close(); } catch { /* 已关闭 */ }
    this.#failPending(new Error('WSS 已停止'));
  }

  /** 订阅（重连后自动恢复）。返回取消函数 */
  subscribe(params, handler) {
    const sub = { params, handler, subId: null };
    this.subs.push(sub);
    if (this.connected) this.#doSubscribe(sub).catch((e) => this.#status('error', `订阅失败：${e.message}`));
    return () => {
      this.subs = this.subs.filter((s) => s !== sub);
      if (sub.subId && this.connected) this.request('eth_unsubscribe', [sub.subId]).catch(() => {});
    };
  }

  request(method, params = []) {
    if (!this.connected) return Promise.reject(new Error('WSS 未连接'));
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`WSS 请求超时：${method}`));
      }, REQUEST_TIMEOUT_MS);
      this.pending.set(id, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ jsonrpc: '2.0', id, method, params }));
    });
  }

  #status(state, detail) {
    this.hooks.onStatus?.({ state, detail, url: this.masked, at: Date.now() });
  }

  #open() {
    if (this.closed) return;
    this.#status('connecting', '');
    let ws;
    try {
      ws = new WebSocket(this.url);
    } catch (err) {
      this.#status('error', `无法创建连接：${err.message}`);
      this.#scheduleRetry();
      return;
    }
    this.ws = ws;
    ws.onopen = async () => {
      this.backoff = 1000;
      this.connectedAt = Date.now();
      this.#status('open', '');
      for (const sub of this.subs) {
        try { await this.#doSubscribe(sub); } catch (e) { this.#status('error', `订阅失败：${e.message}`); }
      }
      clearInterval(this.heartbeat);
      this.heartbeat = setInterval(() => this.#ping(), HEARTBEAT_MS);
      this.hooks.onReconnect?.();
    };
    ws.onmessage = (ev) => this.#onMessage(ev.data);
    ws.onerror = () => { /* 细节在 onclose 处理；错误事件不含可用信息 */ };
    ws.onclose = (ev) => {
      clearInterval(this.heartbeat);
      for (const s of this.subs) s.subId = null;
      this.#failPending(new Error('WSS 连接已断开'));
      if (this.closed) { this.#status('closed', ''); return; }
      this.#status('error', `连接断开（code ${ev.code}），${Math.round(this.backoff / 1000)}s 后重连`);
      this.#scheduleRetry();
    };
  }

  #scheduleRetry() {
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.#open(), this.backoff);
    this.backoff = Math.min(this.backoff * 2, 30000);
  }

  async #ping() {
    const started = performance.now();
    try {
      await this.request('eth_blockNumber');
      this.lastRttMs = Math.round(performance.now() - started);
    } catch {
      // 心跳失败：主动断开，触发重连
      try { this.ws?.close(); } catch { /* ignore */ }
    }
  }

  async #doSubscribe(sub) {
    sub.subId = await this.request('eth_subscribe', sub.params);
  }

  #failPending(err) {
    for (const [id, p] of this.pending) {
      clearTimeout(p.timer);
      p.reject(err);
      this.pending.delete(id);
    }
  }

  #onMessage(raw) {
    let msg;
    try { msg = JSON.parse(typeof raw === 'string' ? raw : Buffer.from(raw).toString('utf8')); } catch { return; }
    if (msg.id != null && this.pending.has(msg.id)) {
      const p = this.pending.get(msg.id);
      this.pending.delete(msg.id);
      clearTimeout(p.timer);
      if (msg.error) p.reject(new Error(msg.error.message || 'rpc error'));
      else p.resolve(msg.result);
      return;
    }
    if (msg.method === 'eth_subscription' && msg.params) {
      const sub = this.subs.find((s) => s.subId === msg.params.subscription);
      if (sub) {
        try { sub.handler(msg.params.result); } catch (e) { this.#status('error', `事件处理异常：${e.message}`); }
      }
    }
  }
}

/** 设置页「测试」：连上、取区块号、测往返延迟，然后断开 */
export async function testWss(url) {
  const client = new WsRpc(url);
  const opened = new Promise((resolve, reject) => {
    client.hooks.onReconnect = resolve;
    client.hooks.onStatus = (s) => { if (s.state === 'error') reject(new Error(s.detail)); };
  });
  client.start();
  try {
    await Promise.race([opened, new Promise((_, rej) => setTimeout(() => rej(new Error('连接超时（8s）')), 8000))]);
    const started = performance.now();
    const block = Number(BigInt(await client.request('eth_blockNumber')));
    return { block, rttMs: Math.round(performance.now() - started) };
  } finally {
    client.stop();
  }
}
