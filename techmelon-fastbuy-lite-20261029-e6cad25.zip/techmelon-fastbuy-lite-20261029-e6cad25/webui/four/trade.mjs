/**
 * Four 内盘「手动交易」：按 CA 买入 / 卖出 Binance Agent ID Exclusive（preset 1778027615735）
 * 或任意 OpenFour 内盘代币。
 *
 * 约束（全部来自官方文档 + 2026-10-24 链上实测）：
 * - 内盘买/卖要求钱包持有 Agent ID（SPACE ID Agent ID，balanceOf > 0）。
 * - 单地址持仓上限 = 创建时 maxSupply × 1%；买入前必须按剩余额度裁剪，超了会被 clamp 或 revert。
 * - 毕业前代币锁定，只能经 Core 卖回，不能转给其它地址。
 * - preset 级白名单可能与 Agent ID 同时生效（文档未写），买不到时优先按「白名单」解释。
 *
 * 这里只做只读计算与 calldata 构造；preview / execute 一律由 server.mjs 的受控路径完成。
 */
import { formatUnits } from 'viem';
import {
  readTokenInfo,
  readCoreBrief,
  agentIdStatus,
  whitelistStatus,
  estimateBuy,
  estimateBuyExact,
  estimateSell,
  buildBuyTx,
  buildBuyExactTx,
  buildSellTx,
  buildApproveTx,
  buildApproveTokenTx,
  readAllowance,
  readErc20Balance,
  assertSniperTx,
  assertSellTx,
  assertApproveTx,
  assertApproveTokenTx,
  isNativeQuote,
  quoteKeyOf,
} from './openfour.mjs';

/** 单地址持仓上限：创建时 maxSupply 的 1%（分母不是实时 totalSupply） */
export const HOLD_CAP_BPS = 100n;

const fmt = (wei, digits = 6) => {
  const s = formatUnits(wei, 18);
  const [i, f = ''] = s.split('.');
  const cut = f.slice(0, digits).replace(/0+$/, '');
  return cut ? `${i}.${cut}` : i;
};
const pct = (bps) => `${(Number(bps) / 100).toFixed(2)}%`;

/** 代币是否属于 Agent 模式（按 preset + 标签双判） */
export function isAgentToken(info) {
  return info.presetId === '1778027615735' || String(info.tag || '') === 'token.tax.binance_agent';
}

/**
 * 读取代币可交易状态 + 该钱包的额度/资格。
 * 返回的 `checks` 是给 UI 直接展示的「能不能买」清单。
 */
export async function inspectToken(token, trader) {
  const info = await readTokenInfo(token);
  if (!info.exists) throw new Error('Core 未登记该代币（不是 OpenFour 代币）');
  const cap = (BigInt(info.maxSupply) * HOLD_CAP_BPS) / 10000n;
  const native = isNativeQuote(info.quoteAsset);
  const [balance, agent, wl, quoteBalance, quoteAllowance] = await Promise.all([
    readErc20Balance(token, trader).catch(() => null),
    agentIdStatus(trader).catch(() => null),
    whitelistStatus(info.presetId, [trader]).catch(() => null),
    native ? Promise.resolve(null) : readErc20Balance(info.quoteAsset, trader).catch(() => null),
    native ? Promise.resolve(null) : readAllowance(info.quoteAsset, trader).catch(() => null),
  ]);
  const held = balance ?? 0n;
  const room = cap > held ? cap - held : 0n;
  const listed = wl ? wl.listed[trader] !== false : null;

  const checks = [
    { ok: info.phase === 1, label: `阶段 ${info.phaseName}（需 Trading）` },
    { ok: !info.paused, label: info.paused ? '代币已暂停' : '未暂停' },
    { ok: agent ? agent.ok : null, label: agent ? (agent.ok ? `持有 Agent ID${agent.handle ? `（${agent.handle}）` : ''}` : '没有 Agent ID') : 'Agent ID 读取失败' },
    { ok: listed, label: wl ? (wl.enabled ? (listed ? '在 preset 白名单内' : '不在 preset 白名单内（内测名单）') : '该 preset 未开启白名单') : '白名单读取失败' },
    { ok: room > 0n, label: `1% 额度剩余 ${fmt(room)} 枚（上限 ${fmt(cap)}，已持 ${fmt(held)}）` },
  ];
  if (info.buyTaxBps != null) checks.push({ ok: true, label: `买税 ${pct(info.buyTaxBps)} / 卖税 ${pct(info.sellTaxBps ?? 0)}` });
  checks.push({ ok: true, label: info.antiSniperEnabled ? '反狙击费：开启（逐块衰减）' : '反狙击费：关闭' });
  if (isAgentToken(info)) {
    checks.push({ ok: true, label: 'Agent 模式转账锁：毕业前代币不可转出，只能经 Core 卖回' });
  }

  return {
    token,
    symbol: info.symbol,
    name: info.name,
    presetId: info.presetId,
    tag: info.tag,
    agentMode: isAgentToken(info),
    phase: info.phase,
    phaseName: info.phaseName,
    paused: info.paused,
    quoteAsset: info.quoteAsset,
    quoteKey: quoteKeyOf(info.quoteAsset),
    native,
    maxSupply: info.maxSupply.toString(),
    holdCap: cap.toString(),
    balance: held.toString(),
    room: room.toString(),
    agentOk: agent ? agent.ok : null,
    agentHandle: agent ? agent.handle : '',
    whitelist: wl ? { enabled: wl.enabled, listed } : null,
    buyTaxBps: info.buyTaxBps,
    sellTaxBps: info.sellTaxBps,
    rates: { founder: info.rateFounder, holder: info.rateHolder, burn: info.rateBurn, liquidity: info.rateLiquidity },
    antiSniper: info.antiSniperEnabled,
    quoteBalance: quoteBalance == null ? null : quoteBalance.toString(),
    quoteAllowance: quoteAllowance == null ? null : quoteAllowance.toString(),
    checks,
  };
}

/**
 * 生成买入计划（不广播、不修改状态）。
 * mode='amount'：按固定代币数量买（推荐，错误信息最准确）。
 * mode='quote' ：按预算买（buyByBudget）——白名单拦截时只会报 CoreErrBudgetNotExecutable，信息量差。
 */
export async function planBuy({ token, trader, mode, amountWei, slippageBps }) {
  const info = await readTokenInfo(token);
  if (!info.exists) throw new Error('Core 未登记该代币');
  if (info.paused) throw new Error('代币已暂停');
  if (info.phase !== 1) throw new Error(`阶段 ${info.phaseName} 不可交易（只能 Trading 阶段在内盘买卖）`);
  const native = isNativeQuote(info.quoteAsset);
  const cap = (BigInt(info.maxSupply) * HOLD_CAP_BPS) / 10000n;
  const held = await readErc20Balance(token, trader).catch(() => 0n);
  const room = cap > held ? cap - held : 0n;
  if (room === 0n) throw new Error(`该钱包已达 1% 持仓上限（${fmt(cap)} 枚），不能再买`);

  const slip = BigInt(Math.trunc(Number(slippageBps)));
  const unit = native ? 'BNB' : (quoteKeyOf(info.quoteAsset) || '计价币').toUpperCase();
  let tx;
  let summary;
  let maxPay;
  let amountOut;
  let approveTx = null;

  if (mode === 'amount') {
    const wanted = BigInt(amountWei);
    const amount = wanted > room ? room : wanted;
    const est = await estimateBuyExact(token, trader, amount);
    if (est.tokenAmount === 0n) throw new Error('当前不可买（估算 0）：可能是白名单/额度/阶段限制，详见下方检查项');
    amountOut = est.tokenAmount;
    maxPay = (est.userPays * (10000n + slip)) / 10000n;
    tx = buildBuyExactTx(token, amount, maxPay, native);
    summary = {
      mode,
      amount: amount.toString(),
      clamped: amount !== wanted,
      wanted: wanted.toString(),
      userPays: est.userPays.toString(),
      maxPay: maxPay.toString(),
      feeBps: est.feeBps,
      executionPrice: est.executionPrice.toString(),
      text: `${amount !== wanted ? `已按 1% 额度裁剪为 ${fmt(amount)} 枚；` : ''}买 ${fmt(amount)} 枚，预计付 ${fmt(est.userPays)} ${unit}，最多付 ${fmt(maxPay)} ${unit}${est.feeBps != null ? `（含费 ${pct(est.feeBps)}）` : ''}`,
    };
  } else {
    const budget = BigInt(amountWei);
    const est = await estimateBuy(token, trader, budget);
    if (est.tokenAmount === 0n) {
      throw new Error('预算买入不可成交（估算 0）。白名单拦截时预算路径只报 BudgetNotExecutable，建议改用「按数量」再试');
    }
    amountOut = est.tokenAmount;
    const minOut = (est.tokenAmount * (10000n - slip)) / 10000n;
    maxPay = budget;
    tx = buildBuyTx(token, budget, minOut, native);
    summary = {
      mode,
      amount: est.tokenAmount.toString(),
      clamped: est.tokenAmount > room,
      userPays: est.userPays.toString(),
      maxPay: budget.toString(),
      minAmountOut: minOut.toString(),
      feeBps: est.feeBps,
      executionPrice: est.executionPrice.toString(),
      text: `花 ≤${fmt(budget)} ${unit} 买约 ${fmt(est.tokenAmount)} 枚（保底 ${fmt(minOut)} 枚）${est.tokenAmount > room ? '；注意超出 1% 额度会被裁剪' : ''}`,
    };
  }

  // 1% 上限硬校验：数量不得超过剩余额度（estimate 正常会 clamp，这里再兜一层）
  if (amountOut > room) throw new Error(`本单 ${fmt(amountOut)} 枚超过剩余额度 ${fmt(room)} 枚`);

  assertSniperTx(tx, token, maxPay, native);

  // ERC20 计价：买入前要 authorize Core
  let note = null;
  if (!native) {
    const allow = await readAllowance(info.quoteAsset, trader).catch(() => 0n);
    if (allow < maxPay) {
      approveTx = buildApproveTx(info.quoteAsset, maxPay);
      assertApproveTx(approveTx, info.quoteAsset, maxPay);
      note = `计价币 ${unit} 授权不足（当前 ${fmt(allow)}），需先执行授权，再重新生成买入计划`;
    }
  }

  return {
    token, symbol: info.symbol, native, unit,
    quoteAsset: info.quoteAsset,
    amountOut: amountOut.toString(),
    summary,
    note,
    approveTx,
    tx,
  };
}

/** 生成卖出计划：必要时先 approve 代币给 Core，再 sell */
export async function planSell({ token, trader, amountWei, slippageBps }) {
  const info = await readTokenInfo(token);
  if (!info.exists) throw new Error('Core 未登记该代币');
  if (info.paused) throw new Error('代币已暂停');
  if (info.phase !== 1) throw new Error(`阶段 ${info.phaseName} 不可交易（毕业前的内盘卖出只支持 Trading）`);
  const amount = BigInt(amountWei);
  if (amount <= 0n) throw new Error('卖出数量必须大于 0');
  const balance = await readErc20Balance(token, trader).catch(() => 0n);
  if (balance < amount) throw new Error(`余额不足：持有 ${fmt(balance)} 枚，想卖 ${fmt(amount)} 枚`);

  const native = isNativeQuote(info.quoteAsset);
  const unit = native ? 'BNB' : (quoteKeyOf(info.quoteAsset) || '计价币').toUpperCase();
  const slip = BigInt(Math.trunc(Number(slippageBps)));
  const est = await estimateSell(token, trader, amount, 0n);
  if (est.tokenAmount === 0n) throw new Error('当前不可卖（估算 0）：可能已停售/阶段变化');
  const minReceive = (est.userReceives * (10000n - slip)) / 10000n;
  const tx = buildSellTx(token, amount, minReceive, 0n);
  assertSellTx(tx, token, amount);

  let approveTx = null;
  const allow = await readAllowance(token, trader).catch(() => 0n);
  if (allow < amount) {
    approveTx = buildApproveTokenTx(token, amount);
    assertApproveTokenTx(approveTx, token, amount);
  }

  return {
    token, symbol: info.symbol, native, unit,
    quoteAsset: info.quoteAsset,
    amount: amount.toString(),
    balance: balance.toString(),
    summary: {
      tokenAmount: est.tokenAmount.toString(),
      userReceives: est.userReceives.toString(),
      minReceive: minReceive.toString(),
      totalFee: est.totalFee.toString(),
      feeBps: est.feeBps,
      text: `卖 ${fmt(amount)} 枚，预计到手 ${fmt(est.userReceives)} ${unit}，保底 ${fmt(minReceive)} ${unit}${est.feeBps != null ? `（含税/费 ${pct(est.feeBps)}）` : ''}`,
    },
    note: approveTx ? `代币对 Core 的授权不足（当前 ${fmt(allow)}），需先执行授权，再重新生成卖出计划` : null,
    approveTx,
    tx,
  };
}

/**
 * 钱包持有的 Four（OpenFour Core 登记）代币列表，只读。
 * candidates：候选 CA（来自 baw 余额、狙击买入记录、前端补充），这里逐个链上核实：
 * Core.tokens(ca).exists → balanceOf(trader) > 0 → 阶段；可卖的再估算全部卖出能到手多少。
 * usdValue 由调用方从 baw 余额带入（可能为空）。
 */
export async function listHoldings({ trader, candidates }) {
  const seen = new Set();
  const list = [];
  for (const c of candidates) {
    const key = String(c.token).toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    list.push(c);
  }
  const rows = await Promise.all(list.map(async (c) => {
    try {
      const brief = await readCoreBrief(c.token);
      if (!brief.exists) return null;
      const balance = await readErc20Balance(brief.token, trader);
      if (balance <= 0n) return null;
      const native = isNativeQuote(brief.quoteAsset);
      const unit = native ? 'BNB' : (quoteKeyOf(brief.quoteAsset) || '计价币').toUpperCase();
      const sellable = brief.phase === 1 && !brief.paused;
      let receive = null;
      if (sellable) {
        const est = await estimateSell(brief.token, trader, balance, 0n).catch(() => null);
        if (est && est.tokenAmount > 0n) receive = est.userReceives;
      }
      return {
        token: brief.token,
        symbol: brief.symbol,
        name: brief.name,
        balance: balance.toString(),
        balanceText: formatUnits(balance, 18),
        phase: brief.phase,
        phaseName: brief.phaseName,
        paused: brief.paused,
        sellable,
        unit,
        receive: receive == null ? null : receive.toString(),
        receiveText: receive == null ? null : fmt(receive),
        usdValue: c.usdValue ?? null,
        source: c.source,
      };
    } catch {
      return null; // 单个代币读失败不影响整体列表
    }
  }));
  return rows.filter(Boolean)
    .sort((a, b) => (Number(b.usdValue) || 0) - (Number(a.usdValue) || 0));
}
