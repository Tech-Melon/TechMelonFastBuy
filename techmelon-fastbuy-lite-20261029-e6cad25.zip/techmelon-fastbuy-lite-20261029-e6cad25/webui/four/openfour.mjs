/**
 * Four.meme OpenFour 协议（BSC）：地址、最小 ABI、只读查询与买入 calldata 构造。
 * 地址与接口来源：https://github.com/four-meme-community/openfour-docs （2026-10 已链上核实）。
 * 所有读取都走 HTTP eth_call（config.mjs 的 BSC RPC），不签名、不广播。
 */
import {
  encodeFunctionData, decodeFunctionResult, decodeFunctionData, decodeEventLog, encodeAbiParameters,
  parseAbi, getAddress, toEventSelector, toFunctionSelector,
} from 'viem';
import { rpc } from '../config.mjs';

/** 代币数量（枚，可带小数，18 位精度）→ wei；用于「按固定数量买入」。支持 10m/1.5k 简写 */
export function tokensToWei(value) {
  let s = String(value ?? '').trim().toLowerCase().replace(/[, _]/g, '');
  let mult = 1n;
  const suffix = { k: 10n ** 3n, m: 10n ** 6n, b: 10n ** 9n };
  if (suffix[s.slice(-1)]) { mult = suffix[s.slice(-1)]; s = s.slice(0, -1); }
  if (!/^\d{1,15}(\.\d{1,18})?$/.test(s)) throw new Error(`代币数量格式不正确：${value}`);
  const [whole, frac = ''] = s.split('.');
  const base = BigInt(whole) * 10n ** 18n + BigInt((frac + '0'.repeat(18)).slice(0, 18));
  const wei = base * mult;
  if (wei <= 0n) throw new Error('代币数量必须大于 0');
  return wei;
}

export const OPENFOUR = {
  core: '0xebe7b6C1089D9F72aD07f34E36d898e44E5e27f3',
  tools: '0x97DA82f56FEF1A0B974587a48135fa9dA2A4E905',
  registry: '0x912CEf0C3aE9Ab6eB3Ec87cab69371cFb317Ab94',
  whitelist: '0x7b377Ad70A20556F4778C4CD878a68A7E7EFaBBc',
  wbnb: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  // SPACE ID Agent ID（ERC-721，symbol AI）：内盘交易的资格门槛，balanceOf > 0 即可买/卖
  agentId: '0x60B9262456dE011F7d15a54CdD8c48bAaa8B022F',
};

/** Binance Agent ID 专属模式 */
export const DEFAULT_PRESET = '1778027615735';

/**
 * 狙击按「底池(计价币)」分桶。Agent 模式不限制计价币，这里登记要打的三种底池。
 * native=true 走 BNB(msg.value)；否则 ERC20（approve + buy）。
 */
export const QUOTES = {
  wbnb: { addr: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', symbol: 'WBNB', native: true },
  bncb: { addr: '0x4902C5ebc598265Ed2212b559B042De8a5Eeec3f', symbol: 'BNCB', native: false },
  nvdab: { addr: '0x02Fca66C1D1aFB4E2A7884261eB00F63598a7436', symbol: 'NVDAB', native: false },
};

/** 计价币地址 → 桶 key（wbnb/bncb/nvdab），未登记返回 null */
export function quoteKeyOf(addr) {
  const a = String(addr).toLowerCase();
  for (const [k, v] of Object.entries(QUOTES)) if (v.addr.toLowerCase() === a) return k;
  return null;
}

/** 每个钱包内盘最多买总量 1%（交易模块 maxAmount） */
export const WALLET_CAP_BPS = 100n;

export const VAULT_PHASE = { 0: 'Created', 1: 'Trading', 2: 'MigratePending', 3: 'Migrated', 4: 'Terminal', 5: 'SoldOut' };

export const coreAbi = parseAbi([
  'event TokenCreated(uint256 requestId, uint256 indexed presetId, address indexed creator, address indexed token, string name, string symbol, uint256 maxSupply, uint256 saleAmount, uint256 raiseAmount, uint256 initialPrice, address quoteAsset, address vault, address curveModule, address tradeModule, address migrateModule, address customData, address tokenModule, string tokenMetaUri, uint256 flags, bytes encodedTags)',
  'function tokens(address) view returns (uint256 version, address creator, uint256 presetId, address token, string name, string symbol, uint256 maxSupply, uint256 saleAmount, uint256 raiseAmount, address quoteAsset, address vault, address curveModule, address tradeModule, address migrateModule, address tokenModule, address customData, uint256 createBlock, bool exists, bool paused, bool antiSniperEnabled)',
  'function buyByBudget(address token, uint256 maxQuotePayAmount, uint256 minAmountOut, uint256 options, bytes proof) payable',
  'function buy(address token, uint256 amount, uint256 maxQuotePayAmount, uint256 options, bytes proof) payable',
  'function sell(address token, uint256 amount, uint256 minQuoteRecvAmount, uint256 options, bytes proof)',
]);

const toolsAbi = parseAbi([
  'struct TradeEstimate { uint256 curveQuote; uint256 totalFee; uint256 userPays; uint256 userReceives; uint256 tokenAmount; uint256 executionPrice; }',
  'function estimateBuyByBudget(address token, address trader, uint256 maxQuotePayAmount, uint256 options, bytes proof) returns (TradeEstimate)',
  'function estimateBuy(address token, address trader, uint256 amount, uint256 options, bytes proof) returns (TradeEstimate)',
  'function estimateSell(address token, address trader, uint256 amount, uint256 options, bytes proof) returns (TradeEstimate)',
]);

/** 买入函数的 selector（供 assertSniperTx 校验；避免硬编码） */
export const BUY_SELECTORS = {
  budget: toFunctionSelector('buyByBudget(address,uint256,uint256,uint256,bytes)'),
  exact: toFunctionSelector('buy(address,uint256,uint256,uint256,bytes)'),
};

const tokenAbi = parseAbi([
  'function descriptor() view returns (bytes8 tagId, string tag, string version)',
  'function buyFeeRate() view returns (uint256)',
  'function sellFeeRate() view returns (uint256)',
  'function rateFounder() view returns (uint256)',
  'function rateHolder() view returns (uint256)',
  'function rateBurn() view returns (uint256)',
  'function rateLiquidity() view returns (uint256)',
]);

const vaultAbi = parseAbi(['function phase() view returns (uint8)']);

export const TOPICS = {
  tokenCreated: toEventSelector(coreAbi.find((x) => x.name === 'TokenCreated')),
};

// Agent ID 资格合约未开源：以下 selector 由字节码 + 实测确定（见 README「Four 狙击」）
// 该 gate 即官方文档所述「带 Agent ID 的币安 Agentic 钱包」内盘交易门槛
const WL_PRESET_ENABLED = '0x1d9cddf8'; // (uint256 presetId) → bool
const WL_IS_LISTED = '0x371befa6'; // (uint256 presetId, address user) → bool

/**
 * Binance Agent ID Exclusive 自定义错误选择器。
 * 前五条来源：官方 mechanisms/binance-agent-id-exclusive.md（2026-10-24）；
 * 0xa2dda494 文档未收录，由链上 trace 逆向确认（= BinanceAgentTradeErrNotWhitelisted），
 * 触发点是 preset 级白名单 0x7b37…aBBc 的 isListed(presetId, wallet) 返回 false。
 */
export const AGENT_ERRORS = {
  '0x96ea0b74': '该钱包没有 Agent ID（内盘仅限持有 Agent ID 的钱包交易）',
  '0xa2dda494': '该钱包不在本 preset 的白名单内（内测名单，与是否持有 Agent ID 无关）',
  '0x63d7653c': '创建者预购超过募资目标的 1.5%',
  '0xe8c402c1': '已达单地址 1% 持仓上限（精确买路径）',
  '0x687d0d11': '已达单地址 1% 持仓上限（交易守卫）',
  '0xa6708f30': '内盘转账被锁定（毕业前只能通过 Core 买/卖，不能转给其它地址）',
  '0xd15b1d74': '按预算买入当前无法成交（CoreErrBudgetNotExecutable；白名单拦截时也会报这个）',
};

/** 在任意字符串/hex 里匹配已知的 Agent 错误选择器，返回可读原因（找不到返回 null） */
export function decodeAgentError(s) {
  if (!s) return null;
  const hex = String(s).toLowerCase();
  for (const sel of Object.keys(AGENT_ERRORS)) if (hex.includes(sel.slice(2))) return AGENT_ERRORS[sel];
  return null;
}

/** Core 常见错误（官方 integration-guide §15），selector 由签名计算 */
const CORE_ERRORS = Object.fromEntries([
  ['CoreErrSlippage()', '滑点保护触发（价格已涨过 maxPay，需按最新价重估）'],
  ['CoreErrInsufficientNative()', 'BNB 付款不足'],
  ['CoreErrTradeMax()', '超过单笔/单地址最大可买'],
  ['CoreErrTradeMin()', '低于最小可买'],
  ['CoreErrBadPhase()', '阶段不可交易（可能已售罄/迁移）'],
  ['CoreErrTokenPaused()', '代币已暂停'],
  ['CoreErrBudgetNotExecutable()', '按预算买入无法成交'],
  ['CoreErrTradeRejected()', '交易模块拒绝'],
  ['CoreErrCurveRejected()', '曲线模块拒绝'],
].map(([sig, msg]) => [toFunctionSelector(sig), msg]));

/** 在最新块用 eth_call 重放一笔交易，返回可读的 revert 原因；能成功返回 null */
export async function explainRevert(tx, from) {
  try {
    await rpc('eth_call', [{ from, to: tx.to, value: `0x${BigInt(tx.value).toString(16)}`, data: tx.inputData }, 'latest']);
    return null;
  } catch (e) {
    const data = String((typeof e.data === 'string' ? e.data : e.data?.data) || '').toLowerCase();
    const agent = decodeAgentError(data);
    if (agent) return agent;
    const sel = data.slice(0, 10);
    return CORE_ERRORS[sel] || (sel.length === 10 ? `revert ${sel}` : e.message);
  }
}

export const presetTopic = (presetId) => `0x${BigInt(presetId).toString(16).padStart(64, '0')}`;

async function read(to, abi, functionName, args = [], from) {
  const tx = { to, data: encodeFunctionData({ abi, functionName, args }) };
  if (from) tx.from = from;
  const raw = await rpc('eth_call', [tx, 'latest']);
  return decodeFunctionResult({ abi, functionName, data: raw });
}

/** 解码 Core 的 TokenCreated 日志；不是该事件返回 null */
export function decodeTokenCreated(log) {
  if (!log?.topics?.length || String(log.topics[0]).toLowerCase() !== TOPICS.tokenCreated) return null;
  if (String(log.address).toLowerCase() !== OPENFOUR.core.toLowerCase()) return null;
  const { args } = decodeEventLog({ abi: coreAbi, data: log.data, topics: log.topics });
  return {
    token: getAddress(args.token),
    creator: getAddress(args.creator),
    presetId: args.presetId.toString(),
    name: args.name,
    symbol: args.symbol,
    quoteAsset: getAddress(args.quoteAsset),
    flags: args.flags.toString(),
    maxSupply: args.maxSupply.toString(),
    block: Number(BigInt(log.blockNumber)),
    txHash: log.transactionHash,
    logIndex: Number(BigInt(log.logIndex ?? 0)),
  };
}

/** 代币运行时信息：Core 配置 + 类型标签 + 税率（bps）+ 阶段 */
export async function readTokenInfo(token) {
  const c = await read(OPENFOUR.core, coreAbi, 'tokens', [token]);
  const info = {
    token: getAddress(token),
    exists: c[17],
    paused: c[18],
    antiSniperEnabled: c[19],
    creator: c[1],
    presetId: c[2].toString(),
    name: c[4],
    symbol: c[5],
    maxSupply: c[6].toString(),
    quoteAsset: c[9],
    vault: c[10],
    tradeModule: c[12],
    createBlock: Number(c[16]),
  };
  if (!info.exists) return info;
  const [desc, buyFee, sellFee, phase] = await Promise.all([
    read(token, tokenAbi, 'descriptor').catch(() => null),
    read(token, tokenAbi, 'buyFeeRate').catch(() => null),
    read(token, tokenAbi, 'sellFeeRate').catch(() => null),
    read(info.vault, vaultAbi, 'phase').catch(() => null),
  ]);
  info.tag = desc ? desc[1] : '';
  // 非税币（token.standard）没有税率 getter：视为 0；税币读不到税率则标记未知，由过滤器拒绝
  const taxed = info.tag.includes('tax');
  info.buyTaxBps = buyFee != null ? Number(buyFee) : (taxed ? null : 0);
  info.sellTaxBps = sellFee != null ? Number(sellFee) : (taxed ? null : 0);
  info.phase = phase == null ? null : Number(phase);
  info.phaseName = VAULT_PHASE[info.phase] || String(info.phase);
  // 税分配（权重，和为 100）：rateHolder=100 即「所有人分红」
  const [rFounder, rHolder, rBurn, rLiq] = await Promise.all([
    read(token, tokenAbi, 'rateFounder').catch(() => null),
    read(token, tokenAbi, 'rateHolder').catch(() => null),
    read(token, tokenAbi, 'rateBurn').catch(() => null),
    read(token, tokenAbi, 'rateLiquidity').catch(() => null),
  ]);
  info.rateFounder = rFounder == null ? null : Number(rFounder);
  info.rateHolder = rHolder == null ? null : Number(rHolder);
  info.rateBurn = rBurn == null ? null : Number(rBurn);
  info.rateLiquidity = rLiq == null ? null : Number(rLiq);
  // 所有税分给持币人（全员分红）：rateHolder=100 且其余为 0
  info.holderOnly = info.rateHolder === 100 && info.rateFounder === 0 && info.rateBurn === 0 && info.rateLiquidity === 0;
  return info;
}

/** 轻量读取（持仓列表用）：只读 Core 登记 + 阶段，约 2 次 eth_call；非 OpenFour 代币 exists=false */
export async function readCoreBrief(token) {
  const c = await read(OPENFOUR.core, coreAbi, 'tokens', [token]);
  const brief = {
    token: getAddress(token),
    exists: c[17],
    paused: c[18],
    presetId: c[2].toString(),
    name: c[4],
    symbol: c[5],
    quoteAsset: c[9],
    vault: c[10],
  };
  if (!brief.exists) return brief;
  const phase = await read(brief.vault, vaultAbi, 'phase').catch(() => null);
  brief.phase = phase == null ? null : Number(phase);
  brief.phaseName = VAULT_PHASE[brief.phase] || String(brief.phase);
  return brief;
}

/**
 * 白名单（preset 级，和 Agent ID 是两层不同的门槛）：
 * - presetEnabled(presetId)：该 preset 是否开启名单
 * - isListed(presetId, user)：地址是否在名单内
 * 未开启名单时，只要求钱包持有 Agent ID。
 */
export async function whitelistStatus(presetId, addresses) {
  const call = async (data) => BigInt(await rpc('eth_call', [{ to: OPENFOUR.whitelist, data }, 'latest'])) === 1n;
  const enabled = await call(WL_PRESET_ENABLED + encodeAbiParameters([{ type: 'uint256' }], [BigInt(presetId)]).slice(2));
  const entries = await Promise.all(addresses.map(async (a) => [a, enabled
    ? await call(WL_IS_LISTED + encodeAbiParameters([{ type: 'uint256' }, { type: 'address' }], [BigInt(presetId), a]).slice(2))
    : true]));
  return { enabled, listed: Object.fromEntries(entries) };
}

const agentAbi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function handleOf(address) view returns (string)',
]);

/** Agent ID 资格：ERC-721 余额 > 0 即可买/卖内盘（与钱包品牌无关，只看这枚 NFT） */
export async function agentIdStatus(address) {
  const owner = getAddress(address);
  const [bal, handle] = await Promise.all([
    read(OPENFOUR.agentId, agentAbi, 'balanceOf', [owner]).catch(() => null),
    read(OPENFOUR.agentId, agentAbi, 'handleOf', [owner]).catch(() => null),
  ]);
  const balance = bal == null ? null : BigInt(bal);
  return { balance, ok: balance != null && balance > 0n, handle: handle ? String(handle) : '' };
}

/** 按预算估算买入（Tools 是非 view 函数，用 eth_call 静态调用）；tokenAmount=0 表示当前不可买 */
export async function estimateBuy(token, trader, budgetWei) {
  const r = await read(OPENFOUR.tools, toolsAbi, 'estimateBuyByBudget', [token, trader, BigInt(budgetWei), 0n, '0x'], trader);
  return {
    curveQuote: r.curveQuote,
    totalFee: r.totalFee,
    userPays: r.userPays,
    tokenAmount: r.tokenAmount,
    executionPrice: r.executionPrice,
    // 总费用占实付比例：含协议费 + 内盘税 + 反狙击费
    feeBps: r.userPays > 0n ? Number((r.totalFee * 10000n) / r.userPays) : null,
  };
}

/** 按固定代币数量估算买入（Tools.estimateBuy，eth_call 静态调用）；tokenAmount=0 表示当前不可买 */
export async function estimateBuyExact(token, trader, amountWei) {
  const r = await read(OPENFOUR.tools, toolsAbi, 'estimateBuy', [token, trader, BigInt(amountWei), 0n, '0x'], trader);
  return {
    curveQuote: r.curveQuote,
    totalFee: r.totalFee,
    userPays: r.userPays,
    tokenAmount: r.tokenAmount,
    executionPrice: r.executionPrice,
    feeBps: r.userPays > 0n ? Number((r.totalFee * 10000n) / r.userPays) : null,
  };
}

/** 按预算买入：WBNB 计价直接用 msg.value 付 BNB，Core 内部包装；value = 预算上限 */
/** 计价币是否为原生 BNB（WBNB）——决定付款路径：是则发 msg.value，否则 ERC20 先 approve 再 buy */
export function isNativeQuote(quoteAsset) {
  return String(quoteAsset).toLowerCase() === OPENFOUR.wbnb.toLowerCase();
}

const erc20Abi = parseAbi([
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
]);

/** ERC20 计价时授权 Core 划扣计价币（内盘买入前置步骤） */
export function buildApproveTx(quoteAsset, amountWei) {
  return {
    to: getAddress(quoteAsset),
    value: '0',
    inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [OPENFOUR.core, BigInt(amountWei)] }),
  };
}

/** 读取计价币对 Core 的授权额度 / 余额 */
export async function readAllowance(quoteAsset, owner) {
  return BigInt(await read(getAddress(quoteAsset), erc20Abi, 'allowance', [owner, OPENFOUR.core]));
}
export async function readErc20Balance(tokenAddr, owner) {
  return BigInt(await read(getAddress(tokenAddr), erc20Abi, 'balanceOf', [owner]));
}

/** 按预算买入。native=WBNB 时发 msg.value；ERC20 计价时 value=0（须先 approve） */
export function buildBuyTx(token, budgetWei, minAmountOut, native = true) {
  return {
    to: OPENFOUR.core,
    value: native ? BigInt(budgetWei).toString() : '0',
    inputData: encodeFunctionData({
      abi: coreAbi, functionName: 'buyByBudget', args: [token, BigInt(budgetWei), BigInt(minAmountOut), 0n, '0x'],
    }),
  };
}

/** 按固定数量买入。native=WBNB 时 value=maxQuotePayWei（多余退回）；ERC20 计价时 value=0（须先 approve） */
export function buildBuyExactTx(token, amountWei, maxQuotePayWei, native = true) {
  return {
    to: OPENFOUR.core,
    value: native ? BigInt(maxQuotePayWei).toString() : '0',
    inputData: encodeFunctionData({
      abi: coreAbi, functionName: 'buy', args: [token, BigInt(amountWei), BigInt(maxQuotePayWei), 0n, '0x'],
    }),
  };
}

/**
 * 自动执行前的最后一道校验：解码 calldata，必须是本模块为该代币构造的 buy / buyByBudget，
 * calldata 里的 maxQuotePayAmount 不超上限；native 走 msg.value、ERC20 不得附带 BNB。
 */
export function assertSniperTx(tx, token, maxQuoteWei, native = true) {
  if (String(tx.to).toLowerCase() !== OPENFOUR.core.toLowerCase()) throw new Error('目标合约不是 OpenFourCore');
  let d;
  try { d = decodeFunctionData({ abi: coreAbi, data: tx.inputData }); }
  catch { throw new Error('calldata 不是 buy/buyByBudget（无法解码）'); }
  if (d.functionName !== 'buy' && d.functionName !== 'buyByBudget') throw new Error('calldata 不是 buy/buyByBudget');
  if (String(d.args[0]).toLowerCase() !== String(token).toLowerCase()) throw new Error('calldata 中的代币与事件不一致');
  const maxPay = d.functionName === 'buy' ? d.args[2] : d.args[1]; // buy(token,amount,maxPay) / buyByBudget(token,maxPay,minOut)
  if (BigInt(maxPay) > BigInt(maxQuoteWei)) throw new Error('花费超出单币上限');
  if (native) {
    if (BigInt(tx.value) !== BigInt(maxPay)) throw new Error('BNB value 与 maxQuotePay 不一致');
  } else if (BigInt(tx.value) !== 0n) {
    throw new Error('ERC20 计价不应附带 BNB');
  }
}

/** 授权交易校验：目标必须是计价币合约、approve 给 Core、额度不超上限 */
export function assertApproveTx(tx, quoteAsset, maxAmountWei) {
  if (String(tx.to).toLowerCase() !== String(quoteAsset).toLowerCase()) throw new Error('approve 目标不是计价币合约');
  let d;
  try { d = decodeFunctionData({ abi: erc20Abi, data: tx.inputData }); }
  catch { throw new Error('approve calldata 无法解码'); }
  if (d.functionName !== 'approve') throw new Error('不是 approve 调用');
  if (String(d.args[0]).toLowerCase() !== OPENFOUR.core.toLowerCase()) throw new Error('approve 的 spender 不是 Core');
  if (BigInt(d.args[1]) > BigInt(maxAmountWei)) throw new Error('approve 额度超出上限');
  if (BigInt(tx.value) !== 0n) throw new Error('approve 不应附带 BNB');
}

// ---------------- 内盘卖出（同样要 Agent ID；毕业前只能经 Core 卖回） ----------------

/** 卖出估算：tokenAmount 是「你能拿到的计价币数量」（已扣税/费）；options=0 时 WBNB 会解包成 BNB */
export async function estimateSell(token, trader, amountWei, options = 0n) {
  const r = await read(OPENFOUR.tools, toolsAbi, 'estimateSell', [token, trader, BigInt(amountWei), BigInt(options), '0x'], trader);
  return {
    curveQuote: r.curveQuote,
    totalFee: r.totalFee,
    userPays: r.userPays,
    userReceives: r.userReceives,
    tokenAmount: r.tokenAmount,
    executionPrice: r.executionPrice,
    feeBps: r.userReceives > 0n ? Number((r.totalFee * 10000n) / (r.userReceives + r.totalFee)) : null,
  };
}

/** 卖出代币给 Core，minQuoteRecv 为最少收到的计价币；options 透传（0=收原生 BNB） */
export function buildSellTx(token, amountWei, minQuoteRecvWei, options = 0n) {
  return {
    to: OPENFOUR.core,
    value: '0',
    inputData: encodeFunctionData({
      abi: coreAbi, functionName: 'sell', args: [token, BigInt(amountWei), BigInt(minQuoteRecvWei), BigInt(options), '0x'],
    }),
  };
}

/** 卖出前把代币授权给 Core */
export function buildApproveTokenTx(token, amountWei) {
  return {
    to: getAddress(token),
    value: '0',
    inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [OPENFOUR.core, BigInt(amountWei)] }),
  };
}

/** 卖出交易校验：目标 Core、calldata 是 sell、代币一致、数量不超、不附带 BNB */
export function assertSellTx(tx, token, amountWei) {
  if (String(tx.to).toLowerCase() !== OPENFOUR.core.toLowerCase()) throw new Error('目标合约不是 OpenFourCore');
  let d;
  try { d = decodeFunctionData({ abi: coreAbi, data: tx.inputData }); }
  catch { throw new Error('calldata 不是 sell（无法解码）'); }
  if (d.functionName !== 'sell') throw new Error('calldata 不是 sell');
  if (String(d.args[0]).toLowerCase() !== String(token).toLowerCase()) throw new Error('calldata 中的代币与目标不一致');
  if (BigInt(d.args[1]) !== BigInt(amountWei)) throw new Error('卖出数量与预期不一致');
  if (BigInt(d.args[1]) <= 0n) throw new Error('卖出数量必须大于 0');
  if (BigInt(tx.value) !== 0n) throw new Error('sell 不应附带 BNB');
}

/** 代币授权校验：目标是被卖代币、approve 给 Core、额度不超卖出数量 */
export function assertApproveTokenTx(tx, token, amountWei) {
  if (String(tx.to).toLowerCase() !== String(token).toLowerCase()) throw new Error('approve 目标不是被卖代币');
  let d;
  try { d = decodeFunctionData({ abi: erc20Abi, data: tx.inputData }); }
  catch { throw new Error('approve calldata 无法解码'); }
  if (d.functionName !== 'approve') throw new Error('不是 approve 调用');
  if (String(d.args[0]).toLowerCase() !== OPENFOUR.core.toLowerCase()) throw new Error('approve 的 spender 不是 Core');
  if (BigInt(d.args[1]) !== BigInt(amountWei)) throw new Error('approve 额度与卖出数量不一致');
  if (BigInt(tx.value) !== 0n) throw new Error('approve 不应附带 BNB');
}
