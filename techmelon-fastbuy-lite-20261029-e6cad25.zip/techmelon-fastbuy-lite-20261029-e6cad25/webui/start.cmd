@echo off
cd /d "%~dp0.."
rem Supervisor: restart the server 3s after an abnormal exit (WSS watch / V3 alerts must stay up).
rem Exit code 0 = normal stop, 98 = port already in use (another instance is running): do not restart.
:loop
node webui\server.mjs
set CODE=%ERRORLEVEL%
if "%CODE%"=="0" goto :eof
if "%CODE%"=="98" (
  echo [webui] port 8790 already in use - another instance is running, not restarting
  goto :eof
)
echo [webui] server exited with code %CODE%, restarting in 3s ...
timeout /t 3 /nobreak >nul
goto loop
