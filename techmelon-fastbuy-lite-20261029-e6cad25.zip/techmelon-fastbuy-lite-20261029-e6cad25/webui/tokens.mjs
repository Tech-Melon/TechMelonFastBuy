/**
 * 代币目录：每条链的「认证代币」+ 钱包持仓，供兑换 / 转账的代币选择器使用。
 *
 * 认证来源（任一满足即视为认证）：
 *   1. 本地预设（主流稳定币），首次使用时链上读 symbol/decimals 复核；
 *   2. Uniswap 官方默认代币列表 https://tokens.uniswap.org（覆盖 BSC/ETH/Base/Arbitrum/Polygon，持续维护）。
 * 钱包里有但不在以上来源的代币标记为「未认证」，前端会给出风险提示。
 */
import { encodeFunctionData, decodeFunctionResult, parseAbi } from 'viem';
import { rpcFor, chainRpcUrl, getConfig } from './config.mjs';
import { cacheGet, cacheSet, cacheInvalidate } from './cache.mjs';

export const NATIVE = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';
const ADDR = /^0x[0-9a-fA-F]{40}$/;

/** wrapped 只用于给原生币找图标 */
export const CHAIN_META = {
  56: { name: 'BSC', native: 'BNB', nativeName: 'BNB', wrapped: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c' },
  1: { name: 'Ethereum', native: 'ETH', nativeName: 'Ether', wrapped: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2' },
  8453: { name: 'Base', native: 'ETH', nativeName: 'Ether', wrapped: '0x4200000000000000000000000000000000000006' },
  42161: { name: 'Arbitrum', native: 'ETH', nativeName: 'Ether', wrapped: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1' },
  137: { name: 'Polygon', native: 'POL', nativeName: 'Polygon Ecosystem Token', wrapped: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270' },
};

/**
 * 主流稳定币预设（2026-10-24 链上核对过 symbol / decimals）。
 * 注意：同一个币在不同链上合约不同、精度也可能不同（BSC 上 USDT/USDC 是 18 位，其他链是 6 位）；
 * Arbitrum / Polygon 的 USDT 链上 symbol 已改为 USDT0。
 */
export const PRESETS = {
  56: [
    { symbol: 'USDT', name: 'Tether USD', address: '0x55d398326f99059fF775485246999027B3197955', decimals: 18 },
    { symbol: 'USDC', name: 'USD Coin', address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', decimals: 18 },
    { symbol: 'U', name: 'United Stables', address: '0xcE24439F2D9C6a2289F741120FE202248B666666', decimals: 18 },
    { symbol: 'USD1', name: 'World Liberty Financial USD', address: '0x8d0D000Ee44948FC98c9B98A4FA4921476f08B0d', decimals: 18 },
  ],
  1: [
    { symbol: 'USDT', name: 'Tether USD', address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6 },
    { symbol: 'USDC', name: 'USD Coin', address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', decimals: 6 },
  ],
  8453: [
    { symbol: 'USDC', name: 'USD Coin', address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', decimals: 6 },
  ],
  42161: [
    { symbol: 'USDT0', name: 'USD₮0', address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9', decimals: 6 },
    { symbol: 'USDC', name: 'USD Coin', address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831', decimals: 6 },
  ],
  137: [
    { symbol: 'USDT0', name: 'USDT0', address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6 },
    { symbol: 'USDC', name: 'USD Coin', address: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359', decimals: 6 },
  ],
};

const LIST_URL = 'https://tokens.uniswap.org';
/** 认证来源（顺序即优先级）：Uniswap 默认列表覆盖多链；PancakeSwap 默认列表补 BSC 的 CAKE/BTCB 等 */
const LIST_SOURCES = [
  { url: LIST_URL, label: 'Uniswap 列表' },
  { url: 'https://tokens.pancakeswap.finance/pancakeswap-default.json', label: 'PancakeSwap 列表' },
];
const LIST_TTL = 12 * 3600 * 1000;
const LIST_RETRY = 10 * 60 * 1000;
const erc20 = parseAbi([
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
]);

const list = { byChain: new Map(), at: 0, failedAt: 0, error: '', version: '', pending: null };

function cleanEntry(t) {
  if (!t || !ADDR.test(t.address) || !CHAIN_META[t.chainId]) return null;
  const decimals = Number(t.decimals);
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) return null;
  const symbol = String(t.symbol || '').slice(0, 20);
  if (!symbol) return null;
  const logo = typeof t.logoURI === 'string' ? t.logoURI : '';
  return {
    address: t.address,
    symbol,
    name: String(t.name || symbol).slice(0, 60),
    decimals,
    logoURI: /^(https:|ipfs:)\/\//.test(logo) ? logo : '',
  };
}

/** 拉取官方列表（12 小时缓存；失败沿用旧数据，10 分钟后再试，不阻塞页面） */
async function loadList() {
  const now = Date.now();
  if (list.byChain.size && now - list.at < LIST_TTL) return list.byChain;
  if (!list.byChain.size && list.failedAt && now - list.failedAt < LIST_RETRY) return list.byChain;
  if (list.pending) return list.pending;
  list.pending = (async () => {
    const fetchOne = async (src) => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);
      try {
        const res = await fetch(src.url, { signal: controller.signal, headers: { accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const payload = await res.json();
        if (!Array.isArray(payload.tokens)) throw new Error('列表格式不正确');
        return { src, payload };
      } catch (err) {
        return { src, error: err.name === 'AbortError' ? '请求超时' : err.message };
      } finally {
        clearTimeout(timer);
      }
    };
    const results = await Promise.all(LIST_SOURCES.map(fetchOne));
    const ok = results.filter((r) => r.payload);
    if (ok.length) {
      const next = new Map();
      for (const { src, payload } of ok) {
        for (const raw of payload.tokens) {
          const t = cleanEntry(raw);
          if (!t) continue;
          const chain = String(raw.chainId);
          if (!next.has(chain)) next.set(chain, new Map());
          const k = t.address.toLowerCase();
          if (!next.get(chain).has(k)) next.get(chain).set(k, { ...t, listName: src.label });
        }
      }
      list.byChain = next;
      list.at = Date.now();
      const v = ok.find((r) => r.src.url === LIST_URL)?.payload.version;
      list.version = v ? `${v.major}.${v.minor}.${v.patch}` : '';
    } else {
      list.failedAt = Date.now();
    }
    list.error = results.filter((r) => r.error).map((r) => `${r.src.label}：${r.error}`).join('；');
    list.pending = null;
    return list.byChain;
  })();
  return list.pending;
}

function listEntry(chainId, address) {
  return list.byChain.get(String(chainId))?.get(String(address).toLowerCase()) || null;
}

function presetEntry(chainId, address) {
  return (PRESETS[chainId] || []).find((t) => t.address.toLowerCase() === String(address).toLowerCase()) || null;
}

/** 预设代币的链上复核：decimals 必须与预设一致，否则不算认证 */
async function verifyPreset(chainId, t) {
  const key = `preset-check:${chainId}:${t.address.toLowerCase()}`;
  const cached = cacheGet(key);
  if (cached) return cached;
  if (!chainRpcUrl(chainId, await getConfig())) return { status: 'unchecked' };
  const read = async (fn) => decodeFunctionResult({
    abi: erc20,
    functionName: fn,
    data: await rpcFor(chainId, 'eth_call', [{ to: t.address, data: encodeFunctionData({ abi: erc20, functionName: fn }) }, 'latest']),
  });
  let result;
  try {
    const [symbol, decimals] = await Promise.all([read('symbol'), read('decimals')]);
    result = Number(decimals) === t.decimals
      ? { status: 'ok', symbol }
      : { status: 'mismatch', detail: `链上 decimals=${decimals}，预设 ${t.decimals}` };
    cacheSet(key, result, LIST_TTL);
  } catch (err) {
    // 节点暂时不可用不等于合约有问题：短缓存后重试
    result = { status: 'unchecked', detail: err.message };
    cacheSet(key, result, 60000);
  }
  return result;
}

/** 单个地址是否认证（官方列表或预设） */
export async function isVerified(chainId, address) {
  if (String(address).toLowerCase() === NATIVE) return true;
  await loadList();
  return Boolean(listEntry(chainId, address) || presetEntry(chainId, address));
}

/**
 * 某条链的代币目录。holdings 为 `wallet balance` 的原始数组（全链），这里按 chainId 过滤。
 * 排序：原生币 → 持仓（按 USD 价值）→ 预设稳定币 → 官方列表其余代币。
 */
export async function tokenCatalog(chainId, holdings = []) {
  const id = String(chainId);
  const meta = CHAIN_META[id];
  if (!meta) throw new Error(`不支持的链：${chainId}`);
  await loadList();

  const out = new Map();
  const put = (t) => {
    const k = t.address.toLowerCase();
    out.set(k, { ...(out.get(k) || {}), ...t });
  };

  put({
    address: NATIVE, symbol: meta.native, name: meta.nativeName, decimals: 18,
    native: true, verified: true, source: '原生币', hasLogo: Boolean(listEntry(id, meta.wrapped)?.logoURI),
  });

  const mine = holdings
    .filter((h) => String(h.binanceChainId) === id && ADDR.test(String(h.address)))
    .sort((a, b) => Number(b.value || 0) - Number(a.value || 0));
  for (const h of mine) {
    const addr = String(h.address).toLowerCase() === NATIVE ? NATIVE : h.address;
    const known = addr === NATIVE ? null : (presetEntry(id, addr) || listEntry(id, addr));
    put({
      address: addr,
      ...(addr === NATIVE ? {} : {
        symbol: known?.symbol || String(h.symbol || '?').slice(0, 20),
        name: known?.name || String(h.symbol || ''),
        decimals: known?.decimals ?? null,
        verified: Boolean(known),
        source: known ? (presetEntry(id, addr) ? '预设' : known.listName) : '钱包持仓',
        hasLogo: Boolean(listEntry(id, addr)?.logoURI),
      }),
      balance: String(h.balance ?? '0'),
      value: String(h.value ?? '0'),
      held: true,
    });
  }

  const checks = await Promise.all((PRESETS[id] || []).map((t) => verifyPreset(id, t)));
  (PRESETS[id] || []).forEach((t, i) => {
    const c = checks[i];
    put({
      ...t,
      verified: c.status !== 'mismatch',
      checkStatus: c.status,
      checkDetail: c.detail || '',
      source: '预设',
      hasLogo: Boolean(listEntry(id, t.address)?.logoURI),
    });
  });

  for (const t of list.byChain.get(id)?.values() || []) {
    if (out.has(t.address.toLowerCase())) continue;
    out.set(t.address.toLowerCase(), {
      address: t.address, symbol: t.symbol, name: t.name, decimals: t.decimals,
      verified: true, source: t.listName, hasLogo: Boolean(t.logoURI),
    });
  }

  return {
    chainId: id,
    chainName: meta.name,
    tokens: [...out.values()],
    list: { sources: LIST_SOURCES.map((s) => s.label), version: list.version, updatedAt: list.at || null, error: list.error },
  };
}

/* ---------- 图标：只代理官方列表里登记过的 logoURI，不接受任意 URL ---------- */

const MAX_LOGO_BYTES = 1024 * 1024; // gang 的 IPFS 原图常有 200KB+，放宽到 1MB（结果缓存 24 小时）

function sniffImage(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length > 6 && buf.subarray(0, 4).toString('ascii') === 'GIF8') return 'image/gif';
  if (buf.length > 12 && buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
  // SVG 可携带脚本，一律拒绝
  return null;
}

/*
 * 额外的图标来源（官方列表之外，比如持仓面板里的内盘币）：只能由服务端登记，前端不能传 URL。
 * 只接受 https + 白名单主机，跟随跳转后再校验一次主机（防 SSRF）。
 *   - bin.bnbstatic.com：币安钱包的代币图标（官方 skill query-address-info 的 icon 字段）
 *   - cdn.gang.fun：gang 代币创建时写在 Created 事件里的 logoURI
 * gmgn.ai 的图片有 Cloudflare 校验，服务端取不到（403），不用。
 */
const EXTRA_LOGO_HOSTS = new Set(['bin.bnbstatic.com', 'cdn.gang.fun']);
const extraLogos = new Map(); // `${chain}:${addr}` -> { url } | { resolve: async () => url }

const okLogoUrl = (u) => {
  try { const x = new URL(u); return x.protocol === 'https:' && EXTRA_LOGO_HOSTS.has(x.host); } catch { return false; }
};

/** 登记某个代币的图标来源：src 为 https URL，或一个返回 URL 的异步函数（用到时才解析，比如查链上事件） */
export function registerLogo(chainId, address, src) {
  if (!ADDR.test(String(address)) || !CHAIN_META[String(chainId)]) return;
  const k = `${chainId}:${String(address).toLowerCase()}`;
  if (extraLogos.has(k)) return;
  if (typeof src === 'function') extraLogos.set(k, { resolve: src });
  else if (okLogoUrl(src)) extraLogos.set(k, { url: src });
  else return;
  const key = `logo:${chainId}:${String(address).toLowerCase()}`;
  if (cacheGet(key)?.miss) cacheInvalidate(key); // 之前取不到的，换了来源后重试
}

async function extraLogoUrl(id, target) {
  const e = extraLogos.get(`${id}:${target.toLowerCase()}`);
  if (!e) return '';
  if (!e.url && e.resolve) {
    const u = await e.resolve().catch(() => '');
    e.url = okLogoUrl(u) ? u : '';
    delete e.resolve;
  }
  return e.url || '';
}

export async function tokenLogo(chainId, address) {
  const id = String(chainId);
  const meta = CHAIN_META[id];
  if (!meta || !ADDR.test(address)) return null;
  const target = address.toLowerCase() === NATIVE ? meta.wrapped : address;
  const key = `logo:${id}:${target.toLowerCase()}`;
  const cached = cacheGet(key);
  if (cached) return cached.miss ? null : cached;

  await loadList();
  let uri = listEntry(id, target)?.logoURI || '';
  let extra = false;
  if (!uri) { uri = await extraLogoUrl(id, target); extra = Boolean(uri); }
  if (uri.startsWith('ipfs://')) uri = `https://ipfs.io/ipfs/${uri.slice(7)}`;
  if (!uri.startsWith('https://')) {
    cacheSet(key, { miss: true }, LIST_TTL);
    return null;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(uri, { signal: controller.signal });
    if (!res.ok || !res.url.startsWith('https://')) throw new Error(`HTTP ${res.status}`);
    if (extra && !okLogoUrl(res.url)) throw new Error('图标跳转到了白名单外的主机');
    const len = Number(res.headers.get('content-length') || 0);
    if (len > MAX_LOGO_BYTES) throw new Error('图标过大');
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > MAX_LOGO_BYTES) throw new Error('图标过大');
    const type = sniffImage(buf);
    if (!type) throw new Error('不支持的图标格式');
    const value = { type, body: buf };
    cacheSet(key, value, 24 * 3600 * 1000);
    return value;
  } catch {
    cacheSet(key, { miss: true }, LIST_RETRY);
    return null;
  } finally {
    clearTimeout(timer);
  }
}
