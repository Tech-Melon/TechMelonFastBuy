// 离线单测（不连链）：node webui\eval\custom-args.mjs
// custom 参数解析：parse → encode → decode 往返一致；错误写法给出可读提示。不连链。
import { encodeFunctionData, decodeFunctionData, parseAbi } from 'viem';
import { parseCustom } from '../agent/custom.mjs';

const C = '0xEedfd95a85e0A22cDCA9BA96454933BE95373222';
const A1 = '0x1111111111111111111111111111111111111111';
const A2 = '0x2222222222222222222222222222222222222222';
let pass = 0;
let fail = 0;

function roundTrip(name, text, expected) {
  try {
    const s = parseCustom(text);
    const abi = parseAbi([`function ${s.signature}`]);
    const data = encodeFunctionData({ abi, functionName: s.functionName, args: s.args });
    const back = decodeFunctionData({ abi, data }).args;
    const norm = (v) => JSON.stringify(v, (_k, x) => (typeof x === 'bigint' ? x.toString() : typeof x === 'string' ? x.toLowerCase() : x));
    const ok = norm(back) === norm(expected);
    console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}  ${s.signature}`);
    if (!ok) console.log('   got ', norm(back), '\n   want', norm(expected));
    ok ? pass++ : fail++;
  } catch (err) {
    console.log(`FAIL  ${name}  异常：${err.message}`);
    fail++;
  }
}

function rejects(name, text, includes) {
  try {
    parseCustom(text);
    console.log(`FAIL  ${name}  应当报错但通过了`);
    fail++;
  } catch (err) {
    const ok = err.message.includes(includes);
    console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}  → ${err.message}`);
    ok ? pass++ : fail++;
  }
}

const head = (sig) => `合约：${C}\n调用 ${sig}，附带 0 BNB\n`;

roundTrip('string + uint256[] + address[]',
  head('register(string memory name, uint256[] calldata ids, address[] to)')
  + `name = "alice 你好, ok"\nids = [1, 2, 3]\nto = [${A1}，${A2}]`,
  ['alice 你好, ok', [1n, 2n, 3n], [A1, A2]]);

roundTrip('bytes32 + bytes + bool[2] + int256 负数',
  head('set(bytes32 key, bytes data, bool[2] flags, int256 delta)')
  + `key = 0x${'ab'.repeat(32)}\ndata = 0xdeadbeef\nflags = [true, false]\ndelta = -42`,
  [`0x${'ab'.repeat(32)}`, '0xdeadbeef', [true, false], -42n]);

roundTrip('嵌套数组 uint256[2][] + 空数组 + 中文引号',
  head('batch(uint256[2][] pairs, address[] empty, string memo)')
  + 'pairs = [[1, 2], [3, 4]]\nempty = []\nmemo = 「批量 测试」',
  [[[1n, 2n], [3n, 4n]], [], '批量 测试']);

roundTrip('string[] + bytes4',
  head('tag(string[] labels, bytes4 sel)')
  + 'labels = ["a,b", \'c\']\nsel = 0xa9059cbb',
  [['a,b', 'c'], '0xa9059cbb']);

rejects('string 不加引号', head('setName(string name)') + 'name = hello', '需要用引号');
rejects('bytes32 长度不对', head('set(bytes32 key)') + 'key = 0x1234', '正好 32 字节');
rejects('定长数组个数不对', head('set(uint256[3] xs)') + 'xs = [1, 2]', '正好 3 个');
rejects('uint8 溢出', head('set(uint8 x)') + 'x = 256', '超出 uint8');
rejects('uint 负数', head('set(uint256 x)') + 'x = -1', '非负');
rejects('数组缺逗号', head('set(uint256[] xs)') + 'xs = [1 2]', '逗号分隔');
rejects('缺少参数', head('set(uint256 x, address y)') + 'x = 1', '缺少参数 y');
rejects('tuple', head('set((uint256,address) p)') + 'p = 1', 'tuple');

// 内联「名=值」写法：类型按取值推断
roundTrip('内联 名=值 推断 address/uint/bool/string',
  `FairSlotLaunch ${C} 调 fillSlot(token=${A1}, n=3, ok=true, memo="a,b")，付 0.1 BNB`,
  [A1, 3n, true, 'a,b']);
rejects('内联 无法推断类型', `Foo ${C} 调 go(x=abc)，付 0 BNB`, '无法推断类型');

console.log(`\n${pass}/${pass + fail} passed`);
process.exitCode = fail ? 1 : 0;
