const CONFIG = `CONFIG
CHAIN_ID=56
FACTORY=0xC55820f24015bE7c4f18949D9e1363A3609B300e
PORTAL=0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062
READER=0x18Aa6C93f1887a243fdc348C9A77F5136555174a
MARKET=0x70604C50309092fCa6d91f3C3120039Aa261bcD9
POOL_TYPE=ERC20
QUOTE_TOKEN=0x4902C5ebc598265Ed2212b559B042De8a5Eeec3f
QUOTE_SYMBOL=BNCB
QUOTE_DECIMALS=18
TOKEN=null
PREDICTED_TOKEN=0xB83095aA0039952ec2AD4Ef3d3CF94d8A3CD7777
PAIR=null
PROBE=0xE8537Ff1F03a038c6eb15807C6dDD84753fc2a4F
WALLET=<confirm>`;

const USDT = '0x55d398326f99059fF775485246999027B3197955';
const BIBI = '0xEedfd95a85e0A22cDCA9BA96454933BE95373222';
const RECIPIENT = '0x1111111111111111111111111111111111111111';
const PUNK = '0x53c03c027F1AC5C9BedD08a4Ce5d1444Bf48ae7d';

/*
 * expect 字段：
 *   protocol / intent        解析结果
 *   plan: true|false         是否必须生成计划
 *   errorIncludes            planError 或接口错误必须包含该文本
 *   planOrErrorIncludes      依赖钱包链上状态的用例：要么生成计划，要么给出包含该文本的「正确拒绝」
 *   params                   spec.params 必须包含这些键值（字符串比较）
 *   steps                    计划步骤数
 */
export default [
  {
    name: 'flap-buy',
    text: `${CONFIG}\n\n买入 0.01 BNCB，滑点 5%。`,
    expect: { protocol: 'flap', intent: 'buy', params: { amount: '0.01', slippageBps: '500' }, planOrErrorIncludes: '余额不足' },
  },
  {
    name: 'flap-sell',
    text: `${CONFIG}\n\n卖出 50% 持仓，滑点 3%。`,
    expect: { protocol: 'flap', intent: 'sell', params: { bps: '5000', slippageBps: '300' }, planOrErrorIncludes: '没有份额' },
  },
  {
    name: 'flap-query',
    text: `${CONFIG}\n\n查一下我的持仓和份额。`,
    expect: { protocol: 'flap', intent: 'query', plan: true, steps: 0 },
  },
  {
    name: 'flap-claim',
    text: `${CONFIG}\n\n帮我领取。`,
    expect: { protocol: 'flap', intent: 'claim', planOrErrorIncludes: '不能 claim' },
  },
  {
    name: 'foundry-mint',
    text: `Mint 9 FOUNDRY Part NFT(s) on BNB Smart Chain (chainId 56).\nContract (Foundry): 0xa849300a3f97dBb2e6a8FBeb16F4f23189c27013\nMax 50 per transaction.\n先读 graduated() 不需要；以 Contract 为准。`,
    expect: { protocol: 'foundry', intent: 'mint', params: { quantity: '9' }, plan: true, steps: 1 },
  },
  {
    name: 'custom-bibi',
    text: `BSC 买入 $bibi。\n合约：${BIBI}\n先读 graduated()：如果是 true 停止。\n否则调用 buyWithBNBLimits(uint256 minTokens, uint256 minRefund)，附带 0.1 BNB，minTokens = 15437584849296094764190778，minRefund = 0\ngas limit 至少 740000。`,
    expect: { protocol: 'custom', intent: 'call', params: { valueBnb: '0.1' }, planOrErrorIncludes: 'graduated' },
  },
  {
    name: 'transfer-bnb',
    text: `帮我转账 0.01 BNB 给 ${RECIPIENT}`,
    expect: { protocol: 'transfer', intent: 'transfer', params: { token: 'BNB', amount: '0.01', to: RECIPIENT }, plan: true, steps: 1 },
  },
  {
    name: 'transfer-usdt',
    text: `send 10 USDT to ${RECIPIENT} on BSC`,
    expect: { protocol: 'transfer', intent: 'transfer', params: { token: 'USDT', amount: '10', to: RECIPIENT }, plan: true, steps: 1 },
  },
  {
    name: 'pancake-buy',
    text: `在 PancakeSwap 用 0.05 BNB 买入 ${USDT}，滑点 1%。`,
    expect: { protocol: 'pancakeswap', intent: 'buy', params: { amount: '0.05', slippageBps: '100', token: USDT }, plan: true, steps: 1 },
  },
  {
    name: 'pancake-sell',
    text: `在 PancakeSwap 卖出 100 个 0x55d398326f99059fF775485246999027B3197955 换成 BNB，滑点 2%。`,
    expect: { protocol: 'pancakeswap', intent: 'sell', params: { amount: '100', slippageBps: '200' }, plan: true },
  },
  {
    name: 'uniswap-buy',
    text: `在 Uniswap 用 0.1 ETH 买入 0xdAC17F958D2ee523a2206206994597C13D831ec7，滑点 1%。`,
    expect: { protocol: 'uniswap', intent: 'buy', params: { amount: '0.1', slippageBps: '100', chainId: '1' }, plan: true, steps: 1 },
  },
  {
    name: 'uniswap-sell',
    text: `在 Uniswap 卖出 50 个 0xdAC17F958D2ee523a2206206994597C13D831ec7 换成 ETH，滑点 3%。`,
    expect: { protocol: 'uniswap', intent: 'sell', params: { amount: '50', slippageBps: '300', chainId: '1' }, plan: true },
  },
  {
    name: 'pancake-no-slippage',
    text: `在 PancakeSwap 用 0.05 BNB 买入 ${USDT}。`,
    expect: { protocol: 'pancakeswap', intent: 'buy', plan: false, errorIncludes: '滑点' },
  },
  {
    name: 'transfer-missing-amount',
    text: `帮我转账 USDT 给 ${RECIPIENT}`,
    expect: { plan: false, errorIncludes: '数量' },
  },
  {
    name: 'custom-missing-gas',
    text: `合约：${BIBI}\n调用 buyWithBNBLimits(uint256 minTokens, uint256 minRefund)，附带 0.05 BNB，minTokens = 1，minRefund = 0`,
    expect: { protocol: 'custom', intent: 'call', params: { valueBnb: '0.05' }, plan: true, steps: 1 },
  },
  {
    name: 'custom-graduated-true',
    text: `合约：0xa849300a3f97dBb2e6a8FBeb16F4f23189c27013\n调用 buyWithBNBLimits(uint256 a, uint256 b)，附带 0.01 BNB，a = 1，b = 0\n先读 graduated()：true 就停止。`,
    expect: { plan: false, errorIncludes: '预检' },
  },
  {
    name: 'unknown-sushi',
    text: '在 SushiSwap 用 0.1 BNB 买入 0x55d398326f99059fF775485246999027B3197955，滑点 1%。',
    expect: { plan: false, errorIncludes: '未能确定' },
  },
  {
    name: 'unknown-no-request',
    text: '这是一段合约说明文档：合约地址 0xEedfd95a85e0A22cDCA9BA96454933BE95373222，包含 buy 和 sell 方法，没有别的了。',
    expect: { plan: false, errorIncludes: '未能确定' },
  },
  {
    name: 'flap-buy-no-amount',
    text: `${CONFIG}\n\n帮我买入 BNCB，滑点 5%。`,
    expect: { plan: false, errorIncludes: '金额' },
  },
  {
    // 「卖出 50%」必须按持仓比例，而不是卖 50 个代币
    name: 'pancake-sell-percent',
    text: `在 PancakeSwap 卖出 50% 的 ${USDT} 换成 BNB，滑点 2%。`,
    expect: { protocol: 'pancakeswap', intent: 'sell', params: { percent: '50', amount: '', slippageBps: '200' }, planOrErrorIncludes: '没有这个代币的持仓' },
  },
  {
    // 地址写在数量前面：不能把 0x… 开头的 0 当成数量
    name: 'pancake-sell-addr-first',
    text: `在 PancakeSwap 卖出 ${USDT} 100 个换成 BNB，滑点 2%。`,
    expect: { protocol: 'pancakeswap', intent: 'sell', params: { amount: '100' }, plan: true },
  },
  {
    name: 'pancake-en-slippage',
    text: `buy ${USDT} with 0.01 BNB on PancakeSwap, slippage 1%`,
    expect: { protocol: 'pancakeswap', intent: 'buy', params: { amount: '0.01', slippageBps: '100' }, plan: true },
  },
  {
    // 指令写了 Ethereum，不能悄悄生成 BSC 上的同名代币转账
    name: 'transfer-other-chain',
    text: `send 10 USDT to ${RECIPIENT} on Ethereum`,
    expect: { protocol: 'transfer', plan: false, errorIncludes: '只支持 BSC' },
  },
  {
    // 「必须为 true 才继续」：graduated() 当前为 false，必须停止
    name: 'custom-expect-true',
    text: `合约：${BIBI}\n先读 graduated()：必须为 true 才继续。\n调用 buyWithBNBLimits(uint256 minTokens, uint256 minRefund)，附带 0.01 BNB，minTokens = 1，minRefund = 0`,
    expect: { protocol: 'custom', plan: false, errorIncludes: '要求停止' },
  },
  {
    name: 'custom-address-arg',
    text: `合约：${USDT}\n调用 approve(address spender, uint256 amount)，附带 0 BNB，spender = ${RECIPIENT}，amount = 1`,
    expect: { protocol: 'custom', intent: 'call', plan: true, steps: 1 },
  },
  {
    // string / 数组 / bytes32 参数：能生成计划（只编码，不执行）
    name: 'custom-string-array',
    text: `合约：${BIBI}\n调用 batchTag(string memory memo, address[] to, uint256[] amounts, bytes32 ref)，附带 0 BNB\nmemo = "空投 第1批"\nto = [${RECIPIENT}, ${USDT}]\namounts = [1, 2]\nref = 0x${'00'.repeat(31)}01`,
    expect: { protocol: 'custom', intent: 'call', plan: true, steps: 1 },
  },
  {
    name: 'custom-unquoted-string',
    text: `合约：${BIBI}\n调用 setName(string name)，附带 0 BNB\nname = hello`,
    expect: { protocol: 'custom', plan: false, errorIncludes: '引号' },
  },
  {
    // 分步脚本：校验 bool → 读取 wei 作为 value → 调用。不能被归到 foundry
    name: 'scripted-agent-punk',
    text: `Mint 1 Agent Punk Id on BNB Chain (chain id 56) from my Agent ID wallet.\nContract: ${PUNK}\n1. Call hasAgentId(myWallet) and stop if it is false.\n2. Call quote(myWallet) to get the BNB (in wei) to send. My first mint is free.\n3. Call mint() sending exactly that BNB. It mints one Agent Punk Id to my wallet.\nSimulate first, then send, and report the transaction hash. Up to 10 per wallet, one per call.`,
    // 2026-10-24 已售罄（totalSupply = MAX_SUPPLY = 10000）：要么出计划，要么给出链上模拟的拒绝原因
    expect: { protocol: 'custom', intent: 'call', params: { mode: 'scripted' }, planOrErrorIncludes: '链上模拟失败' },
  },
  {
    name: 'scripted-check-fails',
    text: `Contract: ${PUNK}\n1. Call hasAgentId(myWallet) and stop if it is true.\n2. Call mint() sending 0 BNB.`,
    expect: { protocol: 'custom', plan: false, errorIncludes: '已停止' },
  },
  {
    name: 'scripted-mint-too-many',
    text: `Mint 3 Agent Punk Id.\nContract: ${PUNK}\n1. Call hasAgentId(myWallet) and stop if it is false.\n2. Call quote(myWallet) to get the BNB (in wei) to send.\n3. Call mint() sending exactly that BNB. One per call.`,
    expect: { protocol: 'custom', plan: false, errorIncludes: '每次只能 mint 1' },
  },
  {
    // 内联写法：地址后「调 fn(名=值)」+「付 X BNB」，类型按取值推断，并用字节码核对选择器
    name: 'custom-inline-moat',
    text: '用币安 Agentic Wallet（需 .ai Agent ID 通行证）在 MOAT 凑多多占席\n$MOAT\n: FairSlotLaunch 0x873e8ff7eba0863b2c4fc615b3c0cb33752f472e 调 fillSlot(token=0x350875b75be0fb9e6cb95a664879b0992c66c0a1)，付 0.1 BNB（每址 1 席；窗口期内不能卖席/取消；勿调 Soft Launchpad buy/sell）',
    expect: { protocol: 'custom', intent: 'call', params: { valueBnb: '0.1' }, plan: true, steps: 1 },
  },
  {
    // 推断出的签名在合约里不存在：拒绝，不发到错误的函数上
    name: 'custom-inline-wrong-sig',
    text: `FairSlotLaunch 0x873e8ff7eba0863b2c4fc615b3c0cb33752f472e 调 fillSlot(token=0x350875b75be0fb9e6cb95a664879b0992c66c0a1, n=1)，付 0.1 BNB`,
    expect: { protocol: 'custom', plan: false, errorIncludes: '在合约里不存在' },
  },
  {
    // 需要安装 / 运行第三方 CLI 的 skill 提示词：直接拒绝，不调用模型
    name: 'external-skill-trace',
    text: 'Use the TRACE skill at https://tracea.cc/agent/skill.md with Binance Agentic Wallet on BNB Chain. Use the current published TRACE CLI (0.4.2 or newer), verifying its official package checksum. Mint 10 TRACE Genesis NFTs for me (0.010 BNB mint payment, plus gas). Run trace-agent preflight, then trace-agent preview mint --quantity 10 without --agent-id.',
    expect: { plan: false, errorIncludes: '第三方 CLI' },
  },
  {
    name: 'external-skill-npm',
    text: '先 npm install -g some-mint-cli，然后用它 mint 1 个 NFT，付 0.01 BNB',
    expect: { plan: false, errorIncludes: '已拒绝' },
  },
  {
    // gang.fun 文档推荐说法；GANG 平台币不在 LaunchpadV2 曲线上，必须拒绝
    name: 'gang-natural-not-v2',
    text: '在 Gang 买 0.001 BNB 的 0x0c6302401aa5325C2E36F170f52C00B1d220B405，滑点 5%',
    expect: { protocol: 'gang', intent: 'buy', plan: false, errorIncludes: '不是 Gang 官方 LaunchpadV2' },
  },
  {
    // 内盘代币，报价币 GANG：Pancake 换 GANG → approve → buy
    name: 'gang-curve-quote-gang',
    text: '在 Gang 买 0.001 BNB 的 0xeaa00e0530ea3cfeb1f37a31c34b15d3abd29ebd，滑点 5%',
    expect: { protocol: 'gang', intent: 'buy', planOrErrorIncludes: '已毕业' },
  },
  {
    // 内盘代币，报价币 WBNB：包装而不是 Pancake 兑换（曾报 IDENTICAL_ADDRESSES）
    name: 'gang-curve-quote-wbnb',
    text: '在 Gang 买 0.001 BNB 的 0x2a74b13f92e5d6bbab9ccebcf8016fa90151b113，滑点 5%',
    expect: { protocol: 'gang', intent: 'buy', planOrErrorIncludes: '已毕业' },
  },
  {
    // 内盘卖出（钱包 2026-10-24 持有 XHDN）：approve → sell → unwrap，或在没有持仓时给出拒绝原因
    name: 'gang-sell-percent',
    text: '在 Gang 卖出 50% 的 0x1529464acf7364e76f0c6279d8f41876e6842ea4，滑点 5%',
    expect: { protocol: 'gang', intent: 'sell', params: { percent: '50' }, planOrErrorIncludes: '没有' },
  },
  {
    name: 'gang-sell-no-slippage',
    text: '在 Gang 卖出全部 0x1529464acf7364e76f0c6279d8f41876e6842ea4',
    expect: { protocol: 'gang', intent: 'sell', plan: false, errorIncludes: '滑点' },
  },
  {
    name: 'gang-cast-private-key',
    text: 'cast send 0x1B8F3f69DFa0a7F63d308C7EB0Fd38D8b099966E "buy(address,uint256,uint256)" 0x0c6302401aa5325C2E36F170f52C00B1d220B405 100000000000000000 0 --rpc-url $RPC --private-key $PRIVATE_KEY',
    expect: { plan: false, errorIncludes: '私钥' },
  },
  {
    name: 'gang-docs-cli',
    text: 'npm i -g @gangfun/cli，然后 gang preflight，再 gang buy --token 0x0c6302401aa5325C2E36F170f52C00B1d220B405 --bnb 0.05',
    expect: { plan: false, errorIncludes: '已拒绝' },
  },
  {
    name: 'fake-address',
    text: `在 PancakeSwap 用 0.05 BNB 买入 0x55d398326f99059fF775485246999027B319795，滑点 1%。`,
    expect: { plan: false },
  },
];
