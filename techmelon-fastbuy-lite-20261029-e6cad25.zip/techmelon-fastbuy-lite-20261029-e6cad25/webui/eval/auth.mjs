// 公网登录闸门评测：node eval/auth.mjs
// 只起一个临时 http 服务包住 authGate（不启动完整控制台、不碰钱包）。对端是 127.0.0.1 = 受信代理，用 X-Real-IP 模拟真实客户端。
import http from 'node:http';
import { scryptSync, randomBytes } from 'node:crypto';

const PASSWORD = 'test-pass-123';
const salt = randomBytes(16);
const N = 16384;
const hash = scryptSync(PASSWORD, salt, 32, { N, r: 8, p: 1, maxmem: 256 * N * 8 });
process.env.PUBLIC_ORIGIN = 'https://aibot.example.com';
process.env.ALLOWED_CLIENT_IPS = '203.0.113.10/32, 203.0.113.11, 2001:db8::/32';
process.env.TRUSTED_PROXY_IPS = '127.0.0.1/32,::1/128';
process.env.ADMIN_PASSWORD_HASH = `scrypt:${N}:8:1:${salt.toString('base64')}:${hash.toString('base64')}`;
const SESS_TMP = (await import('node:path')).join((await import('node:os')).tmpdir(), `walletui-sessions-eval-${process.pid}.json`);
process.env.SESSIONS_FILE = SESS_TMP; // 不碰真实的 webui/sessions.json

let { authGate, authEnabled, publicHost } = await import('../auth.mjs');
const PORT = 18000 + Math.floor(Math.random() * 1000);
const LOCAL = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (await authGate(req, res, url, { localHosts: LOCAL })) return;
  res.writeHead(200, { 'content-type': 'text/plain' });
  res.end(`passed ${url.pathname}`);
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

let pass = 0;
let fail = 0;
function check(name, cond, extra = '') {
  if (cond) pass += 1; else { fail += 1; console.log(`FAIL ${name} ${extra}`); }
}

const UA = 'Mozilla/5.0 eval';
function req(p, { method = 'GET', ip = '203.0.113.10', host = 'aibot.example.com', origin, body, cookie, ua = UA, proxy = true } = {}) {
  return new Promise((resolve, reject) => {
    const headers = { host, 'user-agent': ua };
    if (proxy && ip) headers['x-real-ip'] = ip;
    if (origin) headers.origin = origin;
    if (cookie) headers.cookie = cookie;
    let data;
    if (body !== undefined) { data = JSON.stringify(body); headers['content-type'] = 'application/json'; headers['content-length'] = Buffer.byteLength(data); }
    const r = http.request({ host: '127.0.0.1', port: PORT, path: p, method, headers }, (res) => {
      let text = '';
      res.on('data', (c) => { text += c; });
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text }));
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
const ORIGIN = 'https://aibot.example.com';

try {
  check('启用', authEnabled && publicHost === 'aibot.example.com');

  // 本机脚本直连（无代理头、Host 为 127.0.0.1:端口）：放行给原逻辑
  let r = await req('/api/version', { host: `127.0.0.1:${PORT}`, proxy: false });
  check('本机直连放行', r.status === 200 && r.text.startsWith('passed'), r.status);
  // 本机 Host 但带了代理头（经 Nginx 伪造 Host）：不能走本机通道
  r = await req('/api/version', { host: `127.0.0.1:${PORT}` });
  check('本机 Host + 代理头 → 421', r.status === 421, r.status);

  r = await req('/', { host: 'evil.example.com' });
  check('错误 Host → 421', r.status === 421, r.status);
  r = await req('/', { ip: '198.51.100.7' });
  check('白名单外 IP → 403', r.status === 403, r.status);
  r = await req('/', { ip: 'not-an-ip' });
  check('X-Real-IP 非法 → 按对端 127.0.0.1 判断，不在白名单 → 403', r.status === 403, r.status);
  r = await req('/', { ip: '2001:db8::5' });
  check('IPv6 白名单网段 → 未登录跳转', r.status === 302 && r.headers.location === '/login', r.status);

  r = await req('/');
  check('未登录页面 → 302 /login', r.status === 302 && r.headers.location === '/login', r.status);
  r = await req('/api/version');
  check('未登录 API → 401 + x-auth-required', r.status === 401 && r.headers['x-auth-required'] === '1', r.status);
  r = await req('/index.html');
  check('未登录直接取 index.html → 302', r.status === 302, r.status);
  r = await req('/login');
  check('登录页可访问', r.status === 200 && /管理密码/.test(r.text) && /form-action 'self'/.test(r.headers['content-security-policy'] || ''), r.status);
  check('登录页是标准密码表单（浏览器可保存密码）', /<form[^>]+id="loginForm"/.test(r.text) && /type="password"[^>]*autocomplete="current-password"/.test(r.text) && /autocomplete="username"/.test(r.text));
  r = await req('/login.js');
  check('登录脚本可访问', r.status === 200 && /auth\/login/.test(r.text), r.status);

  r = await req('/auth/login', { method: 'POST', body: { password: PASSWORD } });
  check('登录缺 Origin → 403', r.status === 403, r.status);
  r = await req('/auth/login', { method: 'POST', origin: 'https://evil.example.com', body: { password: PASSWORD } });
  check('登录跨站 Origin → 403', r.status === 403, r.status);

  // 失败 3 次封禁（203.0.113.11）
  for (let i = 1; i <= 3; i += 1) {
    r = await req('/auth/login', { method: 'POST', ip: '203.0.113.11', origin: ORIGIN, body: { password: `wrong${i}` } });
    check(`错误密码 ${i} → 401`, r.status === 401, r.status);
  }
  r = await req('/auth/login', { method: 'POST', ip: '203.0.113.11', origin: ORIGIN, body: { password: PASSWORD } });
  check('封禁期内正确密码也拒绝 → 429', r.status === 429, r.status);
  r = await req('/auth/login', { method: 'POST', origin: ORIGIN, body: { password: 123 } });
  check('非字符串密码 → 401', r.status === 401, r.status);

  r = await req('/auth/login', { method: 'POST', origin: ORIGIN, body: { password: PASSWORD } });
  const setCookie = String(r.headers['set-cookie'] || '');
  check('正确密码 → 200', r.status === 200, r.status);
  check('cookie 属性', /HttpOnly/.test(setCookie) && /Secure/.test(setCookie) && /SameSite=Strict/.test(setCookie) && /Path=\//.test(setCookie), setCookie);
  const cookie = setCookie.split(';')[0];

  r = await req('/', { cookie });
  check('已登录页面放行', r.status === 200 && r.text === 'passed /', r.status);
  r = await req('/api/version', { cookie });
  check('已登录 API 放行', r.status === 200, r.status);
  r = await req('/', { cookie, ua: 'other-agent' });
  check('换 UA → 会话无效', r.status === 302, r.status);
  r = await req('/', { cookie, ip: '198.51.100.7' });
  check('有 cookie 但 IP 不在白名单 → 403', r.status === 403, r.status);
  r = await req('/', { cookie: 'aibot_session=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA' });
  check('伪造 cookie → 302', r.status === 302, r.status);

  // 模拟服务重启：重新加载模块（新的内存 Map，从落盘文件恢复），同一个 cookie 仍然有效
  await new Promise((res) => setTimeout(res, 100));
  const { readFileSync } = await import('node:fs');
  const fileText = readFileSync(SESS_TMP, 'utf8');
  check('落盘文件里没有 cookie 明文', !fileText.includes(cookie.split('=')[1]));
  ({ authGate } = await import(`../auth.mjs?restart=${Date.now()}`));
  r = await req('/', { cookie });
  check('服务重启后登录会话仍有效', r.status === 200, r.status);

  r = await req('/auth/logout', { method: 'POST', cookie, origin: 'https://evil.example.com', body: {} });
  check('跨站登出 → 403', r.status === 403, r.status);
  r = await req('/auth/logout', { method: 'POST', cookie, origin: ORIGIN, body: {} });
  check('登出 → 200', r.status === 200, r.status);
  r = await req('/', { cookie });
  check('登出后会话失效', r.status === 302, r.status);
  await new Promise((res) => setTimeout(res, 100));
  ({ authGate } = await import(`../auth.mjs?restart2=${Date.now()}`));
  r = await req('/', { cookie });
  check('登出后再重启：会话不会被恢复', r.status === 302, r.status);
} finally {
  server.close();
  (await import('node:fs')).rmSync(SESS_TMP, { force: true });
}

console.log(`${pass} passed, ${fail} failed`);
process.exitCode = fail ? 1 : 0;
