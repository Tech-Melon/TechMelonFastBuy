// gang V3 接入评测：node webui\eval\gangv3.mjs [--testnet]
// 默认离线：calldata 复核（篡改必须被拒）、地址解析、本地曲线复算。
// --testnet：对 BSC 测试网的官方 V3 部署做只读核验 + 买入 / 卖出模拟（eth_call，不签名、不广播）。
import { encodeFunctionData, parseAbi } from 'viem';
import {
  assertV3BuyTx, assertV3PadTx, assertApprove, parseMainnetAddresses, verifyDeployment, planV3Buy, planV3Sell,
  gangRouterAbi, padAbi, MAX_BUY_WEI, localTokensOut,
} from '../quick/gangv3.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };
const rejects = (name, fn, includes) => {
  try { fn(); ok(name, false, '应当报错但通过了'); } catch (e) { ok(`${name} → ${e.message}`, e.message.includes(includes), e.message); }
};

const ROUTER = '0x3B497A335432f4A3f761063e44eb58D15F7fa57a';
const PAD = '0x5D5068d11Cc3c768dc0Cc8F460a5593F5b76ce83';
const TOKEN = '0xA5E0896051EaeD4639f005dC12EEF59DC9f966C0';
const OTHER = '0x0000000000000000000000000000000000001002';
const amountIn = 10n ** 16n;
const minOut = 12345n;
const buyTx = (o = {}) => ({
  to: ROUTER, value: String(o.value ?? amountIn),
  inputData: encodeFunctionData({ abi: gangRouterAbi, functionName: 'v3BuyBNB', args: [o.token ?? TOKEN, o.min ?? minOut, 2000000000n] }),
});
const ctxB = { router: ROUTER, token: TOKEN, amountIn, minOut };
let threw = null;
try { assertV3BuyTx(buyTx(), ctxB); } catch (e) { threw = e; }
ok('合法 v3BuyBNB 通过', !threw, threw?.message);
rejects('路由地址被换', () => assertV3BuyTx({ ...buyTx(), to: OTHER }, ctxB), 'GangRouter');
rejects('value 被改', () => assertV3BuyTx(buyTx({ value: 1n }), ctxB), 'value');
rejects('代币被换', () => assertV3BuyTx(buyTx({ token: OTHER }), ctxB), '代币');
rejects('下限被改成 0', () => assertV3BuyTx(buyTx({ min: 0n }), ctxB), '最少到手');
rejects('超过单笔上限', () => assertV3BuyTx(buyTx({ value: MAX_BUY_WEI + 1n }), { ...ctxB, amountIn: MAX_BUY_WEI + 1n }), '单笔上限');

const sellTx = (o = {}) => ({
  to: o.to ?? PAD, value: String(o.value ?? 0),
  inputData: encodeFunctionData({ abi: padAbi, functionName: o.fn ?? 'sell', args: [TOKEN, o.amount ?? 1000n, o.min ?? 10n] }),
});
const ctxS = { pad: PAD, fn: 'sell', token: TOKEN, amount: 1000n, minOut: 10n };
threw = null;
try { assertV3PadTx(sellTx(), ctxS); } catch (e) { threw = e; }
ok('合法 sell 通过', !threw, threw?.message);
rejects('sell 目标不是 pad', () => assertV3PadTx(sellTx({ to: OTHER }), ctxS), 'LaunchpadV3');
rejects('sell 附带 BNB', () => assertV3PadTx(sellTx({ value: 1 }), ctxS), '不应附带');
rejects('sell 数量被改', () => assertV3PadTx(sellTx({ amount: 999n }), ctxS), '数量');
rejects('sell 下限为 0', () => assertV3PadTx(sellTx({ min: 0n }), { ...ctxS, minOut: 0n }), '下限');
rejects('函数被换成 buy', () => assertV3PadTx(sellTx({ fn: 'buy' }), ctxS), 'calldata 不是 sell');

const erc20 = parseAbi(['function approve(address,uint256) returns (bool)']);
const appr = (spender, amt) => ({ to: TOKEN, value: '0', inputData: encodeFunctionData({ abi: erc20, functionName: 'approve', args: [spender, amt] }) });
threw = null;
try { assertApprove(appr(PAD, 1000n), { token: TOKEN, spender: PAD, amount: 1000n }); } catch (e) { threw = e; }
ok('只授权本次数量给 pad 通过', !threw, threw?.message);
rejects('授权给别人', () => assertApprove(appr(OTHER, 1000n), { token: TOKEN, spender: PAD, amount: 1000n }), 'LaunchpadV3');
rejects('无限授权', () => assertApprove(appr(PAD, 2n ** 256n - 1n), { token: TOKEN, spender: PAD, amount: 1000n }), '本次数量');

// 官方 CLI 源码解析：主网为 null 时不产出候选；填了地址才产出
const nullSrc = "mainnet: {\n    chainId: '56', pad: process.env.GANG_V3_PAD || null,\n    router: process.env.GANG_ROUTER || null,\n  },\n  testnet: {";
ok('主网未部署（null）→ 无候选', parseMainnetAddresses(nullSrc) === null);
const filled = nullSrc.replace("GANG_V3_PAD || null", `GANG_V3_PAD || '${PAD}'`).replace('GANG_ROUTER || null', `GANG_ROUTER || '${ROUTER}'`);
const parsed = parseMainnetAddresses(filled);
ok('主网填了地址 → 解析出 pad / router', parsed?.pad === PAD && parsed?.router === ROUTER, JSON.stringify(parsed));
ok('不会把测试网地址当主网', parseMainnetAddresses(`${nullSrc}\n    pad: process.env.GANG_V3_TESTNET_PAD || '${PAD}',\n    router: process.env.GANG_ROUTER_TESTNET || '${ROUTER}',\n  },`) === null);

// 本地曲线复算：首笔 1 BNB、2% 买税 → net = 0.97 BNB
const fresh = { gradAmt: 15n * 10n ** 18n, realQuote: 0n, virtualQuote: 5n * 10n ** 18n, sold: 0n, buyTaxBps: 200 };
const out = localTokensOut(fresh, 10n ** 18n, 10n ** 25n);
ok('本地复算：1 BNB 首笔被 1% 上限截断', out === 10n ** 25n, String(out));
const outSmall = localTokensOut(fresh, 10n ** 15n, 10n ** 25n);
ok('本地复算：0.001 BNB 首笔约 20.6 万枚', outSmall > 2.0e23 && outSmall < 2.1e23, String(outSmall));

// 链上发现：喂合成日志（与 WSS 推送同一处理），检查候选 / 路由解析 / 提醒 / 防刷
{
  const { ingestWatchLog, gangV3Status, WATCH_TOPICS } = await import('../quick/gangv3.mjs');
  const pad32 = (a) => `0x${'0'.repeat(24)}${a.slice(2).toLowerCase()}`;
  const fakePad = '0x1111111111111111111111111111111111111111';
  const log = (address, topic, extra = {}) => ({
    address, topics: [topic, ...(extra.topics || [])], data: extra.data || '0x', blockNumber: '0x100',
    transactionHash: `0x${'ab'.repeat(32)}`, logIndex: extra.logIndex || '0x0', removed: false,
  });
  // 预检：普通合约（主网 WBNB）发同签名事件 → 不算候选、不提醒（会查主网 RPC）
  const WBNB_MAIN = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
  await ingestWatchLog(log(WBNB_MAIN, WATCH_TOPICS.RouterSet, { topics: [pad32(ROUTER)], data: `0x${'0'.repeat(63)}1`, logIndex: '0x9' }));
  let st = await gangV3Status();
  ok('预检：非 V3 合约发同签名事件不算候选', !st.chainCandidates.some((c) => c.pad.toLowerCase() === WBNB_MAIN.toLowerCase()) && st.alerts.length === 0);

  const sk = { skipPrecheck: true };
  await ingestWatchLog(log(fakePad, WATCH_TOPICS.MigratorSet, { topics: [pad32(ROUTER)], logIndex: '0x1' }), sk);
  await ingestWatchLog(log(fakePad, WATCH_TOPICS.RouterSet, { topics: [pad32(ROUTER)], data: `0x${'0'.repeat(63)}1`, logIndex: '0x2' }), sk);
  await ingestWatchLog(log(fakePad, WATCH_TOPICS.RouterSet, { topics: [pad32(ROUTER)], data: `0x${'0'.repeat(63)}1`, logIndex: '0x2' }), sk); // 重复日志
  st = await gangV3Status();
  const cand = st.chainCandidates.find((c) => c.pad.toLowerCase() === fakePad);
  ok('链上事件 → 生成候选', Boolean(cand));
  ok('RouterSet(enabled=true) → 解析出路由地址', cand?.router === ROUTER, cand?.router);
  ok('同一条日志不重复记录', cand?.events.length === 2, String(cand?.events.length));
  ok('新部署 → 产生一条「未经官方确认」提醒', st.alerts.filter((a) => a.level === 'chain' && a.pad.toLowerCase() === fakePad).length === 1 && /未经官方确认/.test(st.alerts[0].text));
  ok('链上发现的候选不标记为官方', cand?.official === false);
  for (let i = 0; i < 25; i += 1) {
    const a = `0x${(0x2000 + i).toString(16).padStart(40, '0')}`;
    await ingestWatchLog(log(a, WATCH_TOPICS.AgentGateUpdated, { logIndex: `0x${(10 + i).toString(16)}` }), sk);
  }
  st = await gangV3Status();
  ok('防刷：候选封顶 20 个', st.chainCandidates.length === 20, String(st.chainCandidates.length));
  ok('防刷：超出只提醒一次', st.alerts.filter((a) => /疑似刷事件/.test(a.text)).length === 1);
}

// 多路由：官方后来又把聚合路由加进白名单（2026-10 主网实况）→ 要挑出指回 pad 的 GangRouter，而不是最后一条 RouterSet
{
  const { trackRouterSet, pickRouter } = await import('../quick/gangv3.mjs');
  const pad32 = (a) => `0x${'0'.repeat(24)}${a.slice(2).toLowerCase()}`;
  const GANG = '0xE040445690Aa56C8b68B7f7038C7b2562B5079C4';
  const AGG1 = '0x3508DcA95a64C9378Cb07eF6F40553A50905372a';
  const AGG2 = '0xDB97fC3329Ed1939012D56ECeaef00Be1C0CdFF5';
  const rs = (router, enabled) => ({ topics: ['0x', pad32(router)], data: `0x${'0'.repeat(63)}${enabled ? 1 : 0}`, transactionHash: `0x${'cd'.repeat(32)}` });
  const c = { pad: PAD, router: null, routers: new Map(), otherRouters: [] };
  await trackRouterSet(c, rs(GANG, true), 100);
  await trackRouterSet(c, rs(AGG1, true), 200);
  await trackRouterSet(c, rs(AGG2, true), 300);
  ok('多路由：入库时先暂取最新一条', c.router === AGG2, c.router);
  await pickRouter(c, async (r) => r === GANG);
  ok('多路由：核验时选指回 pad 的 GangRouter', c.router === GANG, c.router);
  ok('多路由：其它路由单列（新的在前）', c.otherRouters.join() === [AGG2, AGG1].join(), c.otherRouters.join());
  await pickRouter(c, async () => { throw new Error('revert'); });
  ok('多路由：都读不出时退回最新一条（让核验报原因）', c.router === AGG2, c.router);
  await trackRouterSet(c, rs(GANG, false), 400);
  await pickRouter(c, async (r) => r === GANG);
  ok('多路由：RouterSet(false) 移除后不再选它', c.router === AGG2 && !c.otherRouters.includes(GANG), `${c.router} ${c.otherRouters}`);
}

if (process.argv.includes('--testnet')) {
  const RPC = 'https://bsc-testnet-rpc.publicnode.com';
  const call = async (method, params) => {
    const res = await fetch(RPC, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) });
    const j = await res.json();
    if (j.error) { const e = new Error(j.error.message); e.data = j.error.data; e.code = j.error.code; throw e; }
    return j.result;
  };
  const ctx = {
    chainId: '97', wbnb: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd', agentId: '0x24D0A2106AC3Ebf7d770d19f4aF0a5149ebe5B2a', call,
    tokenMeta: async (a) => ({ address: a, symbol: a.toLowerCase() === '0xae13d989dac2f0debff460ac112a837c89baa7cd' ? 'WBNB' : 'V3T', decimals: 18 }),
  };
  console.log('\n--- 测试网只读核验');
  const v = await verifyDeployment(ctx, { pad: PAD, router: ROUTER });
  for (const c of v.checks) console.log(`  ${c.ok ? '✅' : c.fatal ? '❌' : '⚠️'} ${c.name}  ${c.detail}`);
  ok('测试网官方部署核验通过', v.ok);
  const fake = await verifyDeployment(ctx, { pad: PAD, router: OTHER });
  ok('假路由（普通地址）核验不通过', !fake.ok);
  const dep = { pad: PAD, router: ROUTER };
  const trader = '0xCa8e63434072B40d3dFE6f5e7Fd885F93A3200b6'; // 测试网部署者（持有测试网 Agent ID、持有 V3T）
  try {
    const p = await planV3Buy({ ctx, dep, wallet: trader, token: TOKEN, amount: '0.001', slippageBps: 300 });
    console.log(`  买入计划：付 ${p.pay.text} → 预计 ${p.receive.expected}，最少 ${p.receive.min}；冲击 ${p.impactBps}bps；${p.steps.map((s) => s.kind).join(' → ')}`);
    ok('测试网买入计划（模拟）成功且一笔完成', p.steps.length === 1 && p.steps[0].kind === 'buy');
  } catch (e) { ok('测试网买入计划', false, e.message); }
  try {
    await planV3Buy({ ctx, dep, wallet: OTHER, token: TOKEN, amount: '0.001', slippageBps: 300 });
    ok('无 Agent ID 钱包应被拒', false);
  } catch (e) { ok(`无 Agent ID 钱包被拒 → ${e.message}`, /Agent ID/.test(e.message)); }
  try {
    await planV3Buy({ ctx, dep, wallet: trader, token: OTHER, amount: '0.001', slippageBps: 300 });
    ok('未登记代币应被拒', false);
  } catch (e) { ok(`未登记代币被拒 → ${e.message}`, /未在已启用/.test(e.message)); }
  try {
    const s = await planV3Sell({ ctx, dep, wallet: trader, token: TOKEN, percent: '10', slippageBps: 300 });
    console.log(`  卖出计划：${s.pay.text} → 预计 ${s.receive.expected} ${s.receive.symbol}；${s.steps.map((x) => x.kind).join(' → ')}`);
    ok('测试网卖出计划生成（授权或卖出）', s.steps.length >= 1);
  } catch (e) { ok('测试网卖出计划', false, e.message); }
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
