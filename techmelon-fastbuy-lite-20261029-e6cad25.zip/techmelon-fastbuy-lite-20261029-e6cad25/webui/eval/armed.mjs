// 直接买入预授权评测（离线；临时替换 config.limits，结束后恢复）：node webui\eval\armed.mjs
import os from 'node:os';
import path from 'node:path';
import { readFileSync, rmSync } from 'node:fs';
import { getConfig, saveConfig } from '../config.mjs';
import { setLimits } from '../limits.mjs';

// 预授权落盘写到临时文件，绝不碰真实的 webui/arms.json（否则评测的预授权可能在真实重启时被恢复）
const ARMS_TMP = path.join(os.tmpdir(), `walletui-arms-eval-${process.pid}.json`);
process.env.ARMS_FILE = ARMS_TMP;
const { arm, armStatus, assertArmed, disarm, disarmAll, resumeDirect } = await import('../quick/armed.mjs');
const readArms = () => { try { return JSON.parse(readFileSync(ARMS_TMP, 'utf8')).entries || {}; } catch { return {}; } };

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };
const throwsWith = async (name, fn, inc) => {
  try { await fn(); ok(name, false, '应当拒绝但通过了'); } catch (e) { ok(`${name} → ${e.message}`, e.message.includes(inc), e.message); }
};
const W = 'eval-arm-wallet';
const wei = (bnb) => BigInt(Math.round(bnb * 1e6)) * 10n ** 12n;
const saved = (await getConfig()).limits;
try {
  await setLimits({ maxBuyBnb: '0', dailyBnb: '0' });
  await throwsWith('没设上限不能开启', () => arm({ walletId: W, maxSlippageBps: 300 }), '必须先');
  await setLimits({ maxBuyBnb: '0.05', dailyBnb: '0' });
  await throwsWith('只设单笔、没设每日也不能开启', () => arm({ walletId: W, maxSlippageBps: 300 }), '必须先');
  await setLimits({ maxBuyBnb: '0.05', dailyBnb: '0.5' });
  ok('未开启时直接买入被拒', await (async () => { try { assertArmed(W, { amountWei: wei(0.01), slippageBps: 100 }); return false; } catch (e) { return e.message.includes('没有开启'); } })());
  const s = await arm({ walletId: W, maxSlippageBps: 300, hours: 4 });
  ok('开启成功，策略带上当时的上限', s.armed && s.maxBuyBnb === '0.05' && s.dailyBnb === '0.5');
  assertArmed(W, { amountWei: wei(0.05), slippageBps: 300 });
  ok('金额 = 单笔上限、滑点 = 最大滑点：通过', true);
  await throwsWith('金额超过单笔上限被拒', () => assertArmed(W, { amountWei: wei(0.051), slippageBps: 100 }), '单笔上限');
  await throwsWith('滑点超过预授权被拒', () => assertArmed(W, { amountWei: wei(0.01), slippageBps: 500 }), '最大滑点');
  await throwsWith('别的钱包没开启被拒', () => assertArmed('other-wallet', { amountWei: wei(0.01), slippageBps: 100 }), '没有开启');
  disarmAll('limits-changed');
  ok('修改上限（disarmAll）后立即失效', !armStatus(W).armed);
  await arm({ walletId: W, maxSlippageBps: 300, hours: 0.000001 }); // 约 3.6ms 后到期
  await new Promise((r) => setTimeout(r, 20));
  const st = armStatus(W);
  ok('到期后自动失效', !st.armed && st.expired);
  await arm({ walletId: W, maxSlippageBps: 300 });
  disarm(W);
  ok('手动解除', !armStatus(W).armed);
  await throwsWith('有效期超过 24 小时被拒', () => arm({ walletId: W, maxSlippageBps: 300, hours: 48 }), '有效期');

  // ---- 重启恢复（arms.mjs）----
  await arm({ walletId: W, maxSlippageBps: 300, hours: 4 });
  await new Promise((r) => setTimeout(r, 50));
  const savedEntry = readArms()[`direct:${W}`];
  ok('开启后落盘（含原到期时间与上限签名）', Boolean(savedEntry?.expiresAt && savedEntry.limits === '0.05|0.5'));
  disarm(W);
  await new Promise((r) => setTimeout(r, 50));
  ok('解除后从落盘文件删除', !readArms()[`direct:${W}`]);
  const r1 = await resumeDirect(savedEntry);
  ok('上限没变、未过期 → 恢复', r1.ok && armStatus(W).armed);
  ok('恢复后有效期不顺延', armStatus(W).expiresAt === new Date(savedEntry.expiresAt).toISOString());
  disarm(W);
  ok('上限改过 → 不恢复', !(await resumeDirect({ ...savedEntry, limits: '0.1|0.5' })).ok && !armStatus(W).armed);
  ok('已过期 → 不恢复', !(await resumeDirect({ ...savedEntry, expiresAt: Date.now() - 1 })).ok && !armStatus(W).armed);
} finally {
  await saveConfig({ limits: saved ?? { maxBuyBnb: '0', dailyBnb: '0' } });
  await new Promise((r) => setTimeout(r, 50));
  rmSync(ARMS_TMP, { force: true });
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
