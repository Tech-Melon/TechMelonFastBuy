// GMGN OpenAPI 客户端评测（离线 + 一次无 Key 的联网握手）：node webui\eval\gmgn.mjs
// 签名串与官方 signer.ts 一致；Ed25519 签名可被公钥验证；未配置 Key 时明确报错而不是乱发请求。
import crypto from 'node:crypto';
import { buildMessage } from '../gmgn.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => {
  if (cond) { pass += 1; console.log(`PASS  ${name}${detail ? ` → ${detail}` : ''}`); } else { fail += 1; console.log(`FAIL  ${name}${detail ? ` → ${detail}` : ''}`); }
};

// 官方格式：{subPath}:{按 key 排序的 query}:{body}:{timestamp}；数组值排序后重复 k=v；值做 encodeURIComponent
const msg = buildMessage('/v1/user/wallet_holdings', { wallet_address: '0xAbC', chain: 'bsc', timestamp: 1700000000, client_id: 'u-1', tag: ['b', 'a'] }, '', 1700000000);
ok('签名串格式与官方一致', msg === '/v1/user/wallet_holdings:chain=bsc&client_id=u-1&tag=a&tag=b&timestamp=1700000000&wallet_address=0xAbC::1700000000', msg);
const msg2 = buildMessage('/v1/x', { q: 'a b&c' }, '{"k":1}', 1);
ok('特殊字符转义、body 原样拼接', msg2 === '/v1/x:q=a%20b%26c:{"k":1}:1', msg2);

const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const sig = crypto.sign(null, Buffer.from(msg, 'utf8'), privateKey.export({ type: 'pkcs8', format: 'pem' }));
ok('Ed25519 签名可被公钥验证（与官方 sign() 同算法：原始消息、无哈希）', crypto.verify(null, Buffer.from(msg, 'utf8'), publicKey, sig));

// 未配置 Key（临时清空进程内配置，不写盘）
const { getConfig } = await import('../config.mjs');
const cfg = await getConfig();
const saved = cfg.gmgn;
cfg.gmgn = {};
const { walletActivity } = await import('../gmgn.mjs');
try { await walletActivity('0x0000000000000000000000000000000000001001'); ok('未配置 API Key 时拒绝', false); } catch (e) { ok('未配置 API Key 时拒绝', /API Key/.test(e.message), e.message); }
cfg.gmgn = saved;

// 联网握手：用一个假 Key 请求一次，确认主机可达、返回的是 GMGN 的鉴权错误（不是网络错误）
try {
  const res = await fetch(`https://openapi.gmgn.ai/v1/user/wallet_activity?chain=bsc&wallet_address=0x0000000000000000000000000000000000001001&timestamp=${Math.floor(Date.now() / 1000)}&client_id=${crypto.randomUUID()}`, {
    headers: { 'X-APIKEY': 'invalid-key-for-test', 'User-Agent': 'walletui-gmgn/1.0' }, signal: AbortSignal.timeout(10000),
  });
  const text = await res.text();
  ok('openapi.gmgn.ai 可达，假 Key 被拒（401/403）', res.status === 401 || res.status === 403, `${res.status} ${text.slice(0, 120)}`);
} catch (e) { ok('openapi.gmgn.ai 可达', false, e.message); }

console.log(`\n${pass} passed, ${fail} failed`);
process.exitCode = fail ? 1 : 0; // 不用 process.exit：Windows 上 fetch 后立即退出会触发 libuv 断言
