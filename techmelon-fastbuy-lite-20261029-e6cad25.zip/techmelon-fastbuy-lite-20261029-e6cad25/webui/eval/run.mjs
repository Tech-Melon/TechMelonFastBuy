import { readFileSync } from 'node:fs';
import prompts from './prompts.mjs';

const BASE = process.env.BASE || 'http://127.0.0.1:8790';
// 服务启动时写入 webui/.api-token；也可用环境变量 API_TOKEN 覆盖
const API_TOKEN = process.env.API_TOKEN || (() => {
  try { return readFileSync(new URL('../.api-token', import.meta.url), 'utf8').trim(); } catch { return ''; }
})();
if (!API_TOKEN) {
  console.error('缺少 API 令牌：请先启动 server.mjs（会生成 webui/.api-token），或设置环境变量 API_TOKEN');
  process.exit(1);
}
// 钱包：环境变量 WALLET 优先，否则取 webui/wallets.json 里第一个已加载 EVM 地址的钱包
const WALLET = process.env.WALLET || (() => {
  try {
    const list = JSON.parse(readFileSync(new URL('../wallets.json', import.meta.url), 'utf8'));
    return list.find((w) => /^0x[0-9a-fA-F]{40}$/.test(w.evm || ''))?.evm || '';
  } catch { return ''; }
})();
if (!WALLET) {
  console.error('缺少钱包地址：请先在控制台登录一个钱包（会写入 wallets.json），或设置环境变量 WALLET=0x…');
  process.exit(1);
}
const only = process.argv[2];

function pick(data) {
  return {
    protocol: data.spec?.protocol ?? null,
    intent: data.spec?.intent ?? null,
    plan: Boolean(data.plan),
    steps: data.plan?.steps?.length ?? null,
    params: data.spec?.params || {},
    error: data.planError || '',
  };
}

/** 返回未通过的断言名列表（空数组 = 通过） */
function evaluate(got, exp, apiError) {
  const err = `${got.error} ${apiError}`;
  const fails = [];
  if (exp.protocol && got.protocol !== exp.protocol) fails.push('protocol');
  if (exp.intent && got.intent !== exp.intent) fails.push('intent');
  if (exp.plan != null && got.plan !== exp.plan) fails.push('plan');
  if (exp.steps != null && got.steps !== exp.steps) fails.push('steps');
  if (exp.errorIncludes && !err.includes(exp.errorIncludes)) fails.push('errorIncludes');
  if (exp.planOrErrorIncludes && !got.plan && !err.includes(exp.planOrErrorIncludes)) fails.push('planOrErrorIncludes');
  for (const [k, v] of Object.entries(exp.params || {})) {
    if (String(got.params[k] ?? '').toLowerCase() !== String(v).toLowerCase()) fails.push(`params.${k}`);
  }
  return fails;
}

const rows = [];
for (const item of prompts) {
  if (only && !item.name.includes(only)) continue;
  const started = Date.now();
  let data = null;
  let error = '';
  try {
    const res = await fetch(`${BASE}/api/agent/analyze`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-token': API_TOKEN },
      body: JSON.stringify({ text: item.text, wallet: WALLET }),
    });
    const payload = await res.json();
    if (payload.ok) data = payload.data;
    else error = payload.error || 'error';
  } catch (err) {
    error = err.message;
  }

  const got = data ? pick(data) : { protocol: null, intent: null, plan: false, steps: null, params: {}, error };
  const exp = item.expect || {};
  const fails = evaluate(got, exp, error);

  rows.push({
    name: item.name,
    pass: fails.length === 0,
    fails,
    got,
    exp,
    ms: Date.now() - started,
  });
}

let passed = 0;
for (const r of rows) {
  if (r.pass) passed += 1;
  const status = r.pass ? 'PASS' : 'FAIL';
  console.log(`${status}  ${r.name.padEnd(24)} ${String(r.got.protocol).padEnd(12)} ${String(r.got.intent).padEnd(8)} plan=${r.got.plan ? 'Y' : 'N'} ${r.ms}ms`);
  // 没生成计划时把原因打出来，避免「PASS」掩盖真实结果
  if (!r.got.plan && r.got.error) console.log(`      reason: ${r.got.error.split('|')[0]}`);
  if (!r.pass) {
    console.log(`      failed=${r.fails.join(',')}`);
    console.log(`      expect=${JSON.stringify(r.exp)}`);
    console.log(`      got=${JSON.stringify(r.got)}`);
  }
}
console.log(`\n${passed}/${rows.length} passed`);
process.exitCode = passed === rows.length ? 0 : 1;
