// 买入上限评测（离线；临时替换 config.limits，结束后恢复）：node webui\eval\limits.mjs
import { getConfig, saveConfig } from '../config.mjs';
import { setLimits, assertBuyLimit, reserveDaily, toWei } from '../limits.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };
const throwsWith = async (name, fn, inc) => {
  try { await fn(); ok(name, false, '应当拒绝但通过了'); } catch (e) { ok(`${name} → ${e.message}`, e.message.includes(inc), e.message); }
};

const saved = (await getConfig()).limits;
try {
  await setLimits({ maxBuyBnb: '0.05', dailyBnb: '0.1' });
  await assertBuyLimit(toWei('0.05'));
  ok('单笔 = 上限 0.05 通过', true);
  await throwsWith('单笔 0.051 超过 0.05 被拒', () => assertBuyLimit(toWei('0.051')), '单笔买入上限');

  const W = `eval-wallet-${Date.now()}`; // 日志里没有记录的钱包：今天已用 0
  const r1 = await reserveDaily(W, toWei('0.06'));
  ok('每日：第一笔 0.06 通过（在途登记）', typeof r1 === 'function');
  await throwsWith('每日：在途 0.06 + 0.05 超过 0.1 被拒（并发同时过检查也挡得住）', () => reserveDaily(W, toWei('0.05')), '每日上限');
  r1();
  const r2 = await reserveDaily(W, toWei('0.1'));
  ok('每日：释放在途后 0.1 通过', typeof r2 === 'function');
  r2();
  const r3 = await reserveDaily(W, 0n);
  ok('每日：不带 BNB 的交易（授权 / 卖出）不占额度', typeof r3 === 'function');

  // 真并发：两笔同时发起（不先 await 第一笔），只能过一笔
  const W2 = `eval-wallet-par-${Date.now()}`;
  const both = await Promise.allSettled([reserveDaily(W2, toWei('0.06')), reserveDaily(W2, toWei('0.06'))]);
  ok('每日：真并发两笔 0.06（上限 0.1）只放行一笔', both.filter((x) => x.status === 'fulfilled').length === 1, both.map((x) => x.status).join(','));
  both.filter((x) => x.status === 'fulfilled').forEach((x) => x.value(true)); // 这笔已广播：计入当天已花
  await throwsWith('每日：已花 0.06 后再来 0.05 被拒（广播完成计入内存计数）', () => reserveDaily(W2, toWei('0.05')), '每日上限');
  const r4 = await reserveDaily(W2, toWei('0.04'));
  ok('每日：已花 0.06 + 0.04 = 上限通过', typeof r4 === 'function');
  r4(false);

  await setLimits({ maxBuyBnb: '0', dailyBnb: '0' });
  await assertBuyLimit(toWei('100'));
  ok('上限为 0 = 不限', true);
  await throwsWith('非法上限被拒', () => setLimits({ maxBuyBnb: '1e3', dailyBnb: '0' }), '上限');
} finally {
  await saveConfig({ limits: saved ?? { maxBuyBnb: '0', dailyBnb: '0' } });
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
