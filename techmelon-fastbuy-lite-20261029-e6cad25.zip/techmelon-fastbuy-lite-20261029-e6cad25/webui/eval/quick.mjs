// 离线单测（不连链）：node webui\eval\quick.mjs
// 覆盖快捷交易路由的 calldata 构造与广播前复核（assertRouterTx）：任何被篡改的字段都必须被拒绝。
import { decodeFunctionData, encodeFunctionData } from 'viem';
import { buildRouterTx, assertRouterTx, routerAbi, PANCAKE, HUBS, WBNB } from '../quick/router.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };
const rejects = (name, fn, includes) => {
  try { fn(); ok(name, false, '应当报错但通过了'); } catch (e) { ok(`${name} → ${e.message}`, e.message.includes(includes), e.message); }
};

const WALLET = '0x0000000000000000000000000000000000001001';
const OTHER = '0x0000000000000000000000000000000000001002';
const TOKEN = '0x5e9305a3d099b44bb7c50e2eedb6ecf5bd322435';
const OANT = '0x24B518b332543a4E1C3649d063daB199d103760a';
const ADDRESS_THIS = '0x0000000000000000000000000000000000000002';
const { USDT } = HUBS;
const deadline = 2000000000n;
const allowed = new Set([WBNB, USDT, OANT, TOKEN, ...Object.values(HUBS)].map((a) => a.toLowerCase()));

// 买入：BNB → USDT（V3 0.01%）→ oANT（V3 0.25%）→ TOKEN（V2）
const buyHops = [
  { kind: 'v3', fee: 100, tokenIn: WBNB, tokenOut: USDT },
  { kind: 'v3', fee: 2500, tokenIn: USDT, tokenOut: OANT },
  { kind: 'v2', tokenIn: OANT, tokenOut: TOKEN },
];
const amountIn = 10n ** 16n;
const minOut = 123456789n;
const buy = buildRouterTx({ hops: buyHops, amountIn, minOut, wallet: WALLET, nativeIn: true, nativeOut: false, deadline });
const buyCtx = { wallet: WALLET, tokenIn: WBNB, tokenOut: TOKEN, amountIn, minOut, nativeIn: true, nativeOut: false, allowed };

ok('买入目标是 SmartRouter', buy.to === PANCAKE.smartRouter);
ok('买入 value = 金额', buy.value === amountIn.toString());
const outer = decodeFunctionData({ abi: routerAbi, data: buy.inputData });
const inner = outer.args[1].map((d) => decodeFunctionData({ abi: routerAbi, data: d }));
ok('相邻 V3 合并成一段 exactInput + 一段 V2', inner.length === 2 && inner[0].functionName === 'exactInput' && inner[1].functionName === 'swapExactTokensForTokens');
ok('V3 段输出到路由器自身', inner[0].args[0].recipient.toLowerCase() === ADDRESS_THIS);
ok('V3 段无单独下限（只在最后校验）', inner[0].args[0].amountOutMinimum === 0n);
ok('V2 段用路由器余额（amountIn=0）', inner[1].args[0] === 0n);
ok('V2 段收款人 = 钱包、下限 = minOut', inner[1].args[3].toLowerCase() === WALLET.toLowerCase() && inner[1].args[1] === minOut);
ok('deadline 透传', outer.args[0] === deadline);
let threw = null;
try { assertRouterTx(buy, buyCtx); } catch (e) { threw = e; }
ok('合法买入通过复核', !threw, threw?.message);

// 卖出：TOKEN → oANT（V2）→ USDT（V3）→ WBNB（V3）→ unwrap
const sellHops = [
  { kind: 'v2', tokenIn: TOKEN, tokenOut: OANT },
  { kind: 'v3', fee: 2500, tokenIn: OANT, tokenOut: USDT },
  { kind: 'v3', fee: 100, tokenIn: USDT, tokenOut: WBNB },
];
const sellIn = 10n ** 23n;
const sell = buildRouterTx({ hops: sellHops, amountIn: sellIn, minOut, wallet: WALLET, nativeIn: false, nativeOut: true, deadline });
const sellCtx = { wallet: WALLET, tokenIn: TOKEN, tokenOut: WBNB, amountIn: sellIn, minOut, nativeIn: false, nativeOut: true, allowed };
const sellInner = decodeFunctionData({ abi: routerAbi, data: sell.inputData }).args[1].map((d) => decodeFunctionData({ abi: routerAbi, data: d }));
ok('卖出 value = 0', sell.value === '0');
ok('卖出末步是 unwrapWETH9(minOut, 钱包)', sellInner.at(-1).functionName === 'unwrapWETH9' && sellInner.at(-1).args[0] === minOut && sellInner.at(-1).args[1].toLowerCase() === WALLET.toLowerCase());
ok('卖出首段从钱包扣 sellIn', sellInner[0].args[0] === sellIn);
threw = null;
try { assertRouterTx(sell, sellCtx); } catch (e) { threw = e; }
ok('合法卖出通过复核', !threw, threw?.message);

// ---- 篡改检测 ----
const rebuild = (calls, d = deadline) => ({ ...buy, inputData: encodeFunctionData({ abi: routerAbi, functionName: 'multicall', args: [d, calls] }) });
const raw = outer.args[1];
const v2 = (amt, min, path, to) => encodeFunctionData({ abi: routerAbi, functionName: 'swapExactTokensForTokens', args: [amt, min, path, to] });

rejects('目标合约被换', () => assertRouterTx({ ...buy, to: OTHER }, buyCtx), 'SmartRouter');
rejects('value 被改', () => assertRouterTx({ ...buy, value: '1' }, buyCtx), 'value');
rejects('最终收款人被换成别人', () => assertRouterTx(rebuild([raw[0], v2(0n, minOut, [OANT, TOKEN], OTHER)]), buyCtx), '收款人');
rejects('下限被改成 0', () => assertRouterTx(rebuild([raw[0], v2(0n, 0n, [OANT, TOKEN], WALLET)]), buyCtx), '下限');
rejects('路径混入白名单外代币', () => assertRouterTx(rebuild([raw[0], v2(0n, minOut, [OANT, OTHER, TOKEN], WALLET)]), buyCtx), '白名单外');
rejects('中间段收款人不是路由器', () => {
  const bad = encodeFunctionData({ abi: routerAbi, functionName: 'exactInput', args: [{ ...decodeFunctionData({ abi: routerAbi, data: raw[0] }).args[0], recipient: OTHER }] });
  assertRouterTx(rebuild([bad, raw[1]]), buyCtx);
}, '路由器自身');
rejects('中间段金额不是 0', () => assertRouterTx(rebuild([raw[0], v2(5n, minOut, [OANT, TOKEN], WALLET)]), buyCtx), 'amountIn=0');
rejects('路径不连续', () => assertRouterTx(rebuild([raw[0], v2(0n, minOut, [USDT, TOKEN], WALLET)]), buyCtx), '不连续');
rejects('输出代币不对', () => assertRouterTx(buy, { ...buyCtx, tokenOut: OANT }), '最终输出');
rejects('首段金额被改', () => assertRouterTx(buy, { ...buyCtx, amountIn: amountIn + 1n }), 'value');
rejects('unwrap 收款人被换', () => {
  const calls = decodeFunctionData({ abi: routerAbi, data: sell.inputData }).args[1].slice(0, -1);
  calls.push(encodeFunctionData({ abi: routerAbi, functionName: 'unwrapWETH9', args: [minOut, OTHER] }));
  assertRouterTx({ ...sell, inputData: encodeFunctionData({ abi: routerAbi, functionName: 'multicall', args: [deadline, calls] }) }, sellCtx);
}, 'unwrap 收款人');
rejects('卖出缺少 unwrap', () => {
  const calls = decodeFunctionData({ abi: routerAbi, data: sell.inputData }).args[1].slice(0, -1);
  assertRouterTx({ ...sell, inputData: encodeFunctionData({ abi: routerAbi, functionName: 'multicall', args: [deadline, calls] }) }, sellCtx);
}, '');
rejects('minOut=0 拒绝', () => assertRouterTx(buildRouterTx({ hops: buyHops, amountIn, minOut: 0n, wallet: WALLET, nativeIn: true, deadline }), { ...buyCtx, minOut: 0n }), '最少到账为 0');
rejects('首段金额 0（会变成「用合约余额」）', () => buildRouterTx({ hops: buyHops, amountIn: 0n, minOut, wallet: WALLET, nativeIn: true, deadline }), 'amountIn');
rejects('原生币买入首跳不是 WBNB', () => buildRouterTx({ hops: buyHops.slice(1), amountIn, minOut, wallet: WALLET, nativeIn: true, deadline }), 'WBNB');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
