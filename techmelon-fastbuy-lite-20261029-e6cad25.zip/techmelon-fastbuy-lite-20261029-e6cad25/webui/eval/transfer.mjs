// 一键转移评测：node webui\eval\transfer.mjs
// 离线：transfer calldata 复核、一键执行对转账的上限复核（换收款人 / 加数量 / 伪装成别的类型都要被拒）。
// 只读联网：地址检查（合约识别、首尾相同中间不同的疑似投毒地址、零地址）。
import { encodeFunctionData, parseAbi } from 'viem';
import { assertTransferTx, checkAddress } from '../quick/transfer.mjs';
import { boundsOf, checkStep } from '../quick/oneclick.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => {
  if (cond) { pass += 1; console.log(`PASS  ${name}${detail ? ` → ${detail}` : ''}`); } else { fail += 1; console.log(`FAIL  ${name}${detail ? ` → ${detail}` : ''}`); }
};
const rejects = (name, fn, want) => {
  try { fn(); ok(name, false, '没有被拒'); } catch (e) { ok(name, !want || e.message.includes(want), e.message); }
};

const abi = parseAbi(['function transfer(address,uint256) returns (bool)', 'function approve(address,uint256) returns (bool)']);
const TOKEN = '0x4444444444444444444444444444444444444444';
const TOKEN2 = '0x5555555555555555555555555555555555555555';
const TO = '0x0000000000000000000000000000000000001001';
const EVIL = '0x0000000000000000000000000000000000001002';
const AMT = 123456789n;
const tx = (o = {}) => ({
  to: o.to ?? TOKEN, value: String(o.value ?? 0),
  inputData: encodeFunctionData({ abi, functionName: o.fn ?? 'transfer', args: [o.recipient ?? TO, o.amount ?? AMT] }),
});

let threw = null;
try { assertTransferTx(tx(), { token: TOKEN, to: TO, amount: AMT }); } catch (e) { threw = e; }
ok('合法 transfer 通过', !threw, threw?.message);
rejects('收款人被换', () => assertTransferTx(tx({ recipient: EVIL }), { token: TOKEN, to: TO, amount: AMT }), '收款地址');
rejects('数量被改', () => assertTransferTx(tx({ amount: AMT + 1n }), { token: TOKEN, to: TO, amount: AMT }), '数量');
rejects('目标合约被换', () => assertTransferTx(tx({ to: TOKEN2 }), { token: TOKEN, to: TO, amount: AMT }), '代币合约');
rejects('附带 BNB', () => assertTransferTx(tx({ value: 1 }), { token: TOKEN, to: TO, amount: AMT }), 'BNB');
rejects('换成 approve', () => assertTransferTx(tx({ fn: 'approve' }), { token: TOKEN, to: TO, amount: AMT }), 'transfer');

// 一键执行的上限复核（转账步骤）
const flat = (t, kind = 'transfer') => ({ kind, to: t.to, value: t.value, inputData: t.inputData });
const steps = [flat(tx()), flat(tx({ to: TOKEN2, amount: 5n }))];
const bounds = boundsOf({ receive: { minRaw: null } }, steps);
ok('确认时的转账被记入上限', bounds.transfers.length === 2);
ok('原样的第 1 笔通过', checkStep(steps[0], bounds, 0n, null) === null);
ok('原样的第 2 笔通过', checkStep(steps[1], bounds, 0n, null) === null);
const why1 = checkStep(flat(tx({ recipient: EVIL })), bounds, 0n, null);
ok('收款人被换 → 停止', Boolean(why1), why1);
const why2 = checkStep(flat(tx({ amount: AMT + 1n })), bounds, 0n, null);
ok('数量变多 → 停止', Boolean(why2), why2);
const why3 = checkStep(flat(tx({ to: TOKEN2 })), bounds, 0n, null);
ok('代币和数量对不上（把 1 号数量用在 2 号代币）→ 停止', Boolean(why3), why3);
const why4 = checkStep(flat(tx({ recipient: EVIL }), 'buy'), bounds, 0n, null);
ok('伪装成别的步骤类型 → 停止', Boolean(why4), why4);

// 地址检查（只读联网）
const own = '0x1234aaaa00000000000000000000000000005678';
const lookalike = '0x1234bbbb11111111111111111111111111115678';
const c1 = await checkAddress(lookalike, { ownWallets: [own] });
ok('首尾相同中间不同 → 疑似投毒警告', c1.warnings.some((w) => /投毒/.test(w)), c1.warnings.join(' / '));
const c2 = await checkAddress('0x0000000000000000000000000000000000000000');
ok('零地址 → 拒绝', Boolean(c2.fatal), c2.fatal);
const c3 = await checkAddress('0x10ED43C718714eb63d5aA57B78B54704E256024E'); // Pancake V2 Router（合约）
ok('合约地址 → 警告', c3.isContract && c3.warnings.some((w) => /合约/.test(w)), c3.warnings[0]);
const c4 = await checkAddress(own, { ownWallets: [own] });
ok('本机钱包自己 → 提示', c4.warnings.some((w) => /本机/.test(w)), c4.warnings.join(' / '));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
