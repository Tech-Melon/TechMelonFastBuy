// 买入后自动授权评测：node webui\eval\autoapprove.mjs
// 离线：授权 calldata 复核（换对象 / 改额度 / 无上限 / 换代币 / 附带 BNB / 换函数都要被拒）、onDone 过滤（只处理完成的买入）。
// 只读联网（不预览、不广播）：用链上真实持有者，按当前阶段算出该发的授权（gang V3 内盘 → LaunchpadV3，外盘 → SmartRouter）。
import { encodeFunctionData, parseAbi, decodeFunctionData } from 'viem';
import { assertAutoApproveTx, planAutoApprove, afterBuy } from '../quick/autoapprove.mjs';
import { PANCAKE } from '../quick/router.mjs';
import { BUILTIN_V3 } from '../quick/gangv3.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => {
  if (cond) { pass += 1; console.log(`PASS  ${name}${detail ? ` → ${detail}` : ''}`); } else { fail += 1; console.log(`FAIL  ${name}${detail ? ` → ${detail}` : ''}`); }
};
const rejects = (name, fn, want) => {
  try { fn(); ok(name, false, '没有被拒'); } catch (e) { ok(name, !want || e.message.includes(want), e.message); }
};

const abi = parseAbi(['function approve(address,uint256) returns (bool)', 'function transfer(address,uint256) returns (bool)']);
const TOKEN = '0x4444444444444444444444444444444444444444';
const SP = PANCAKE.smartRouter;
const EVIL = '0x0000000000000000000000000000000000001002';
const AMT = 10n ** 21n;
const allowed = new Set([SP.toLowerCase()]);
const tx = (o = {}) => ({
  to: o.to ?? TOKEN, value: String(o.value ?? 0),
  inputData: encodeFunctionData({ abi, functionName: o.fn ?? 'approve', args: [o.spender ?? SP, o.amount ?? AMT] }),
});
const ctxOk = { token: TOKEN, spender: SP, amount: AMT, allowed };

let threw = null;
try { assertAutoApproveTx(tx(), ctxOk); } catch (e) { threw = e; }
ok('合法授权（白名单对象、额度 = 持有数量）通过', !threw, threw?.message);
rejects('授权对象被换成别的地址', () => assertAutoApproveTx(tx({ spender: EVIL }), ctxOk), '白名单');
rejects('授权对象不在白名单（即使与计划一致）', () => assertAutoApproveTx(tx({ spender: EVIL }), { ...ctxOk, spender: EVIL }), '白名单');
rejects('额度被改大', () => assertAutoApproveTx(tx({ amount: AMT + 1n }), ctxOk), '额度');
rejects('无上限授权', () => assertAutoApproveTx(tx({ amount: 2n ** 256n - 1n }), { ...ctxOk, amount: 2n ** 256n - 1n }), '无上限');
rejects('额度为 0', () => assertAutoApproveTx(tx({ amount: 0n }), { ...ctxOk, amount: 0n }), '额度');
rejects('目标代币被换', () => assertAutoApproveTx(tx({ to: EVIL }), ctxOk), '代币');
rejects('附带 BNB', () => assertAutoApproveTx(tx({ value: 1 }), ctxOk), 'BNB');
rejects('换成 transfer', () => assertAutoApproveTx(tx({ fn: 'transfer' }), ctxOk), 'approve');

// onDone 过滤：失败的任务、卖出、库存备货都不处理（不读配置、不联网）
const calls = [];
const deps = { previewStep: async () => { calls.push('preview'); return { ok: false }; }, doExecute: async () => { calls.push('execute'); return {}; } };
const base = { walletId: 'w', from: '0x0000000000000000000000000000000000000001', plan: { platform: 'dex', token: TOKEN } };
ok('失败的买入任务不授权', (await afterBuy({ state: 'failed' }, { ...base, req: { side: 'buy' } }, deps)) === null && !calls.length);
ok('卖出任务不授权', (await afterBuy({ state: 'done' }, { ...base, req: { side: 'sell' } }, deps)) === null && !calls.length);
ok('库存备货不授权', (await afterBuy({ state: 'done' }, { ...base, req: { side: 'buy' }, plan: { platform: 'inventory', token: TOKEN } }, deps)) === null && !calls.length);

// 只读联网：真实持有者
const live = [
  // gang V3 内盘币 AID（2026-10-29 创建），持有者是在曲线上买到的地址
  { name: 'gang V3 内盘（AID）', token: '0x60ad36E74C0853389888A3fdFb7C03cbcF1BdB7f', from: '0x9547bc4dbc340e7477a05af5a3a485ec684e0f98', want: BUILTIN_V3.pad, platform: 'gangv3' },
  // 外盘：CAKE，币安热钱包持有
  { name: '外盘（CAKE）', token: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82', from: '0xF977814e90dA44bFA03b6295A0616a897441aceC', want: PANCAKE.smartRouter, platform: 'dex' },
];
for (const c of live) {
  try {
    const p = await planAutoApprove(c.from, c.token, { waitMs: 0 });
    if (p.skip) { ok(`${c.name}：算出授权`, Boolean(p.enough) && p.platform === c.platform, p.skip); continue; }
    const d = decodeFunctionData({ abi, data: p.tx.inputData });
    ok(`${c.name}：平台 ${p.platform}，授权给 ${p.spenderLabel}`, p.platform === c.platform && d.args[0].toLowerCase() === c.want.toLowerCase(), p.label);
    ok(`${c.name}：额度 = 链上余额（不是无上限）`, d.args[1] === p.balance && p.balance < 2n ** 255n, p.balance.toString());
  } catch (e) { ok(`${c.name}：算出授权`, false, e.message); }
}

console.log(`\n${pass} 通过，${fail} 失败`);
process.exit(fail ? 1 : 0);
