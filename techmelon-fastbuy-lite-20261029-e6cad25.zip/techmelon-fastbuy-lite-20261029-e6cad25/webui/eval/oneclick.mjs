// 一键买入上限评测（离线，不连 baw / 不广播）：node webui\eval\oneclick.mjs
// 用假的 preview / execute / replan 跑完整流程；回执查询会走主网 RPC（假哈希查不到 → 用 mock 替代）。
import { encodeFunctionData, parseAbi } from 'viem';
import { boundsOf, checkStep } from '../quick/oneclick.mjs';

let pass = 0;
let fail = 0;
const ok = (name, cond, detail = '') => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : `  ${detail}`}`); cond ? pass++ : fail++; };

const erc20 = parseAbi(['function approve(address,uint256) returns (bool)']);
const PAD = '0x1B8F3f69DFa0a7F63d308C7EB0Fd38D8b099966E';
const SR = '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4';
const QUOTE = '0xbe9D156892E55e7154BcD3cB0FEA677F9D3103E1';
const EVIL = '0x0000000000000000000000000000000000001002';
const approve = (spender, amt) => ({ kind: 'approve', to: QUOTE, value: '0', inputData: encodeFunctionData({ abi: erc20, functionName: 'approve', args: [spender, amt] }) });
const swap = { kind: 'swap', to: SR, value: String(10n ** 15n), inputData: '0x' };
const buy = { kind: 'buy', to: PAD, value: '0', inputData: '0x' };

// 确认时的计划：换币 0.001 BNB → 授权 5 SPCXB 给 pad → 买入，最少收到 1,000,000
const plan = { receive: { minRaw: '1000000' } };
const b = boundsOf(plan, [swap, approve(PAD, 5n * 10n ** 15n), buy]);
ok('上限：BNB 合计 = 0.001', b.maxValueWei === 10n ** 15n);
ok('上限：授权对象 = pad、额度 = 5e15', b.approvals.length === 1 && b.approvals[0].spender === PAD.toLowerCase() && b.approvals[0].amount === 5n * 10n ** 15n);

ok('正常：第 2 步授权（额度更小）通过', checkStep(approve(PAD, 4n * 10n ** 15n), b, 10n ** 15n, 1000000n) === null);
ok('正常：第 3 步买入（最少收到不变）通过', checkStep(buy, b, 10n ** 15n, 1000000n) === null);
ok('正常：最少收到低 0.4%（取整差）通过', checkStep(buy, b, 10n ** 15n, 996000n) === null);
const r1 = checkStep(swap, b, 10n ** 15n, null);
ok(`重新报价后要再换一次币（BNB 超额）→ 拒绝：${r1}`, r1 && r1.includes('BNB'));
const r2 = checkStep(approve(EVIL, 10n ** 15n), b, 10n ** 15n, null);
ok(`授权给别的地址 → 拒绝：${r2}`, r2 && r2.includes('授权'));
const r3 = checkStep(approve(PAD, 6n * 10n ** 15n), b, 10n ** 15n, null);
ok(`授权额度变大 → 拒绝：${r3}`, r3 && r3.includes('授权'));
const r4 = checkStep(buy, b, 10n ** 15n, 900000n);
ok(`价格变差（最少收到 -10%）→ 拒绝：${r4}`, r4 && r4.includes('价格'));
const r5 = checkStep({ ...buy, to: EVIL }, b, 10n ** 15n, null);
ok(`交互合约被换 → 拒绝：${r5}`, r5 && r5.includes('不在确认范围'));
const r6 = checkStep({ kind: 'sell', to: PAD, value: '0', inputData: '0x' }, b, 0n, null);
ok(`出现确认时没有的步骤类型 → 拒绝：${r6}`, r6 && r6.includes('步骤类型'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
