/**
 * BSC WSS 共享连接（全项目只开一条，按需连接）：Four 狙击、gang V3 / 打新发现、自动打新、gang 内盘狙击、
 * 发射后自动转移都在这条连接上订阅；第一个订阅时连上，最后一个订阅取消时断开。
 * - 订阅登记在 hub 里：节点 URL 变更（设置页保存）时整体迁移到新连接；断线重连由 WsRpc 自动恢复订阅。
 * - onHubReconnect：每次（重新）连上时回调，各模块用 HTTP 补查断线期间漏掉的日志。
 * - 设置页「测试 WSS」仍是一次性的临时连接，不影响这里。
 *
 * 双节点订阅（config.wssDual，默认关；备用 = 节点池里第一条非主节点的 wss）：
 * - 再开一条连接到备用节点，**只镜像 logs 订阅**（newHeads 每 0.45 秒一条，按流量计费的节点很贵，也不抢时间）；
 * - 两路推来的同一条日志按「订阅 + txHash + logIndex + removed」去重，先到的那条交给业务处理，后到的只用来记「谁快、快多少」；
 * - eth_call 等请求（hubRequest）仍只走主节点；主节点断线时备用照样推送，等于顺带做了热备。
 * 计费（2026-10-29 核对）：QuickNode 按推送条数，NodeReal 按推送字节（0.04 CU / 字节）+ 心跳按方法 CU。
 */
import { WsRpc } from './four/wss.mjs';
import { getConfig, chainWssUrl, backupWssUrl, maskUrl } from './config.mjs';

const DEDUPE_MS = 30000; // 另一路超过这么久还没推同一条日志，就算它漏了
const MAX_LEADS = 300;

const hub = {
  ws: null, url: '', status: { state: 'idle', detail: '' }, lastBlock: 0,
  ws2: null, url2: '', status2: { state: 'off', detail: '' },
  subs: new Set(), // { id, params, handler, unsub, unsub2, label, since }
  reconnect: new Set(),
  seen: new Map(), // 去重键 → { src, at, label }
  race: null,
  nextId: 1,
};

const isLogs = (s) => s.params?.[0] === 'logs';
const other = (src) => (src === 'main' ? 'backup' : 'main');

function newRace() {
  return { since: new Date().toISOString(), total: 0, first: { main: 0, backup: 0 }, only: { main: 0, backup: 0 }, leads: { main: [], backup: [] }, samples: [] };
}

/** 一条推送进来：没开双节点直接交给业务；开了就去重 + 记先后 */
function deliver(s, r, src) {
  if (!hub.ws2 || !isLogs(s)) { s.handler(r); return; }
  const key = `${s.id}|${r?.transactionHash}|${r?.logIndex}|${r?.removed ? 1 : 0}`;
  const now = Date.now();
  const hit = hub.seen.get(key);
  if (!hit) {
    hub.seen.set(key, { src, at: now, label: s.label, block: r?.blockNumber ? Number(r.blockNumber) : null, tx: r?.transactionHash || null });
    s.handler(r);
    return;
  }
  if (hit.src === src || hit.done) return; // 同一路重复推送 / 已经配对过
  hit.done = true;
  const race = hub.race;
  if (!race) return;
  const lead = now - hit.at;
  race.total += 1;
  race.first[hit.src] += 1;
  const list = race.leads[hit.src];
  list.push(lead);
  if (list.length > MAX_LEADS) list.shift();
  race.samples.unshift({ at: new Date(hit.at).toISOString(), label: hit.label, block: hit.block, tx: hit.tx, first: hit.src, leadMs: lead });
  race.samples = race.samples.slice(0, 20);
}

/** 去重表清理：超时没配对的算「只有一路推了」 */
const pruneTimer = setInterval(() => {
  const cutoff = Date.now() - DEDUPE_MS;
  for (const [k, v] of hub.seen) {
    if (v.at > cutoff) continue;
    if (!v.done && hub.race && hub.ws2) hub.race.only[v.src] += 1;
    hub.seen.delete(k);
  }
}, 10000);
pruneTimer.unref?.();

function attachMain(s) {
  s.unsub = hub.ws ? hub.ws.subscribe(s.params, (r) => deliver(s, r, 'main')) : null;
}

function attachBackup(s) {
  s.unsub2 = hub.ws2 && isLogs(s) ? hub.ws2.subscribe(s.params, (r) => deliver(s, r, 'backup')) : null;
}

/** 双节点：按配置开 / 关 / 换备用连接（只在有订阅时连） */
async function ensureBackup(config) {
  const url2 = hub.subs.size ? backupWssUrl(56, config) : '';
  if (!url2) {
    if (hub.ws2) { hub.ws2.stop(); hub.ws2 = null; }
    for (const s of hub.subs) s.unsub2 = null;
    hub.url2 = '';
    hub.status2 = { state: 'off', detail: config.wssDual ? '节点池里没有备用 wss（或主节点没配置）' : '未开启双节点订阅' };
    hub.seen.clear();
    return null;
  }
  if (hub.ws2 && hub.url2 === url2 && !hub.ws2.closed) return hub.ws2;
  if (hub.ws2) hub.ws2.stop();
  hub.url2 = url2;
  const ws2 = new WsRpc(url2, { onStatus: (st) => { if (hub.ws2 === ws2) hub.status2 = { state: st.state, detail: st.detail }; } });
  hub.ws2 = ws2;
  hub.race = newRace();
  hub.seen.clear();
  for (const s of hub.subs) attachBackup(s);
  ws2.start();
  return ws2;
}

/** 按当前配置建立 / 迁移连接；没配置 WSS 时返回 null */
export async function ensureHub() {
  const config = await getConfig();
  const url = chainWssUrl(56, config);
  if (!url) {
    if (hub.ws) { hub.ws.stop(); hub.ws = null; }
    hub.url = '';
    hub.status = { state: 'off', detail: '未配置 BSC WSS 节点（设置页填写）' };
    await ensureBackup(config);
    return null;
  }
  if (!(hub.ws && hub.url === url && !hub.ws.closed)) {
    if (hub.ws) hub.ws.stop();
    hub.url = url;
    // 只让当前连接更新状态 / 触发补查：已 stop 的旧连接异步发来的 closed 不能覆盖新状态
    const ws = new WsRpc(url, {
      onStatus: (st) => { if (hub.ws === ws) hub.status = { state: st.state, detail: st.detail }; },
      onReconnect: () => { if (hub.ws === ws) for (const fn of hub.reconnect) Promise.resolve().then(fn).catch(() => {}); },
    });
    hub.ws = ws;
    for (const s of hub.subs) attachMain(s); // 迁移已有订阅（连上后 WsRpc 统一发 eth_subscribe）
    hub.ws.start();
  }
  await ensureBackup(config);
  return hub.ws;
}

/**
 * 没有任何订阅时关掉连接（按需连接）：两家都按推送 / 心跳计费，空连着只会白扣心跳。
 * 下一次 hubSubscribe 会自动重新连上；hubRequest 没连接时抛错，调用方退回 HTTP。
 */
function closeIfIdle() {
  if (hub.subs.size) return;
  if (hub.ws2) { hub.ws2.stop(); hub.ws2 = null; hub.url2 = ''; hub.status2 = { state: 'idle', detail: '没有订阅，连接已关闭' }; }
  if (!hub.ws) return;
  hub.ws.stop();
  hub.ws = null;
  hub.status = { state: 'idle', detail: '没有功能在订阅，连接已关闭（有订阅时自动连上）' };
}

/** 设置页修改了 WSS 节点 / 双节点开关后调用：有订阅才（迁移到新节点）连接，没有订阅不连 */
export async function reloadHub() {
  if (!hub.subs.size) { closeIfIdle(); return null; }
  return ensureHub();
}

/** 订阅（params 例如 ['logs', { address, topics }] / ['newHeads']）。返回取消函数 */
export async function hubSubscribe(params, handler, label = '') {
  const s = { id: hub.nextId++, params, handler, unsub: null, unsub2: null, label, since: new Date().toISOString() };
  hub.subs.add(s);
  // 先登记再连：新建连接时 ensureHub 会把 hub.subs 里的订阅（含这一条）统一挂上，这里只补挂还没挂的，不重复订阅
  await ensureHub();
  if (!s.unsub) attachMain(s);
  if (hub.ws2 && !s.unsub2) attachBackup(s);
  return () => {
    s.unsub?.();
    s.unsub2?.();
    hub.subs.delete(s);
    closeIfIdle();
  };
}

/** 每次（重新）连上时回调（用于 HTTP 补查）。返回取消函数 */
export function onHubReconnect(fn) {
  hub.reconnect.add(fn);
  return () => hub.reconnect.delete(fn);
}

export const hubConnected = () => Boolean(hub.ws?.connected);

/**
 * 在共享 WSS 连接上发一次 JSON-RPC 请求（比如 eth_call）。推送新币日志的就是这个节点，
 * 读到的状态和日志同步（HTTP 节点可能还落后 1~3 个块）。没连上时抛错，由调用方退回 HTTP。
 */
export async function hubRequest(method, params = []) {
  if (!hub.ws?.connected) throw new Error('WSS 未连接');
  return hub.ws.request(method, params);
}

const pct = (arr, p) => {
  if (!arr.length) return null;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * p))];
};

/** 双节点比较结果：谁先到几次、先到时领先多少毫秒（中位 / P90）、只有一路推了几次 */
export function hubRace() {
  const r = hub.race;
  if (!r) return null;
  const side = (src) => ({ first: r.first[src], only: r.only[src], leadP50: pct(r.leads[src], 0.5), leadP90: pct(r.leads[src], 0.9) });
  return { since: r.since, paired: r.total, main: side('main'), backup: side('backup'), samples: r.samples };
}

export function hubStatus() {
  return {
    ...hub.status,
    connected: hubConnected(),
    rttMs: hub.ws?.lastRttMs ?? null,
    subscriptions: hub.subs.size,
    url: hub.ws?.masked || '',
    backup: {
      ...hub.status2,
      connected: Boolean(hub.ws2?.connected),
      rttMs: hub.ws2?.lastRttMs ?? null,
      url: hub.url2 ? maskUrl(hub.url2) : '',
      mirrored: [...hub.subs].filter(isLogs).length,
    },
    race: hub.ws2 ? hubRace() : null,
  };
}

/** 当前所有订阅（后台任务清单用）：谁订的、订什么 */
export function hubSubscriptions() {
  return [...hub.subs].map((s) => {
    const [kind, f] = s.params;
    return {
      label: s.label || '（未标注）', kind, since: s.since,
      address: f?.address || null,
      topics: Array.isArray(f?.topics) ? f.topics.flat().filter(Boolean).length : 0,
      backup: Boolean(s.unsub2),
    };
  });
}
