import { encodeFunctionData, decodeFunctionResult, decodeEventLog, parseAbi, parseUnits } from 'viem';
import { rpc } from './config.mjs';

const ADDR = /^0x[0-9a-fA-F]{40}$/;

const foundryAbi = parseAbi([
  'function handleOf(address) view returns (string)',
  'function mintOpen() view returns (bool)',
  'function remaining() view returns (uint256)',
  'function quoteBnb(address,uint256) view returns (uint256)',
]);

const erc1155Abi = parseAbi([
  'event TransferSingle(address indexed operator, address indexed from, address indexed to, uint256 id, uint256 value)',
  'event TransferBatch(address indexed operator, address indexed from, address indexed to, uint256[] ids, uint256[] values)',
]);

const PART_NAMES = ['Gear', 'Piston', 'Boiler', 'Valve', 'Flywheel', 'Chain', 'Chimney', 'Gauge', 'Crankshaft'];

export function detectKind(text) {
  if (/ERC-1155/i.test(text) && /mint/i.test(text) && /(?:Contract|Foundry)[^\n]{0,80}0x[0-9a-fA-F]{40}/i.test(text)) return 'mint';
  if (/(^|\n)\s*CONFIG\s*\r?\n[\s\S]{0,800}MARKET=/i.test(text)) return 'flap';
  return 'unknown';
}

export function parseMint(text) {
  const contractMatch = text.match(/Contract[^\n:：]*[:：]\s*(0x[0-9a-fA-F]{40})/i)
    || text.match(/(?:Foundry|contract)[^\n]{0,40}(0x[0-9a-fA-F]{40})/i);
  if (!contractMatch) throw new Error('没有找到合约地址');
  const contract = contractMatch[1];

  const qtyMatch = text.match(/Mint\s+(\d+)\s+(?:FOUNDRY|Foundry|NFT|part)/i)
    || text.match(/Mint\s+(\d+)/i);
  if (!qtyMatch) throw new Error('没有找到要 Mint 的数量');
  const quantity = Number(qtyMatch[1]);

  const maxMatch = text.match(/Max\s+(\d+)\s+per\s+transaction/i);
  const maxPerTx = maxMatch ? Number(maxMatch[1]) : null;
  if (maxPerTx && quantity > maxPerTx) throw new Error(`数量 ${quantity} 超过单笔上限 ${maxPerTx}`);

  const priceMatch = text.match(/Price:\s*([\d.]+)\s*USDT\s*or\s*([\d.]+)\s*BNB\s*per\s*part/i);
  const perPartBnb = priceMatch ? priceMatch[2] : null;
  const expectedMatch = text.match(/expected\s+([\d.]+)\s*BNB/i);
  const expectedTotalBnb = expectedMatch ? expectedMatch[1] : null;

  let expectedRaw = null;
  if (expectedTotalBnb) {
    expectedRaw = parseUnits(expectedTotalBnb, 18).toString();
  } else if (perPartBnb) {
    expectedRaw = (parseUnits(perPartBnb, 18) * BigInt(quantity)).toString();
  }

  return {
    kind: 'mint',
    chainId: 56,
    contract,
    quantity,
    maxPerTx,
    perPartBnb,
    expectedTotalBnb,
    expectedRaw,
    expectsEmptyData: /EMPTY data|data \(0x\)|empty data/i.test(text),
    erc1155: /ERC-1155/i.test(text),
    partNames: PART_NAMES,
  };
}

export async function planMint({ wallet, text, quantity }) {
  if (!ADDR.test(wallet)) throw new Error('wallet 地址不正确');
  const spec = parseMint(text);
  if (quantity != null) {
    if (!Number.isInteger(quantity) || quantity <= 0) throw new Error('quantity 必须是正整数');
    if (spec.maxPerTx && quantity > spec.maxPerTx) throw new Error(`数量 ${quantity} 超过单笔上限 ${spec.maxPerTx}`);
    spec.quantity = quantity;
  }
  const checks = [];

  async function read(fn, args = []) {
    const data = encodeFunctionData({ abi: foundryAbi, functionName: fn, args });
    const raw = await rpc('eth_call', [{ to: spec.contract, data }, 'latest']);
    return decodeFunctionResult({ abi: foundryAbi, functionName: fn, data: raw });
  }

  let handle = '';
  try {
    handle = await read('handleOf', [wallet]);
    checks.push({ name: 'handleOf(wallet)', ok: Boolean(handle), detail: handle || '(空)' });
  } catch (err) {
    checks.push({ name: 'handleOf(wallet)', ok: false, detail: `调用失败：${err.message}` });
  }
  if (!handle) throw new Error('该钱包没有 .ai Agent ID（handleOf 为空），请先在 Binance Wallet 领取');

  const [open, remaining, quote, balanceHex] = await Promise.all([
    read('mintOpen'),
    read('remaining'),
    read('quoteBnb', [wallet, BigInt(spec.quantity)]),
    rpc('eth_getBalance', [wallet, 'latest']),
  ]);
  const balance = BigInt(balanceHex);

  checks.push({ name: 'mintOpen()', ok: Boolean(open), detail: String(open) });
  if (!open) throw new Error('mintOpen() = false，当前未开放 Mint');
  checks.push({ name: 'remaining()', ok: remaining >= BigInt(spec.quantity), detail: `${remaining} 剩余 / 需要 ${spec.quantity}` });
  if (remaining < BigInt(spec.quantity)) throw new Error(`剩余 ${remaining} 不足 ${spec.quantity}（不会自动减量）`);

  checks.push({ name: 'quoteBnb()', ok: quote > 0n, detail: `${quote} wei` });
  const gasBuffer = 300000000000000n; // 0.0003 BNB 预留
  checks.push({ name: 'BNB 余额', ok: balance >= quote + gasBuffer, detail: `${balance} wei` });
  if (balance < quote + gasBuffer) throw new Error('BNB 余额不足以支付报价 + gas');

  if (spec.expectedRaw) {
    const expected = BigInt(spec.expectedRaw);
    checks.push({
      name: '报价与提示词一致',
      ok: expected === quote,
      detail: `提示词 ${expected} / 链上 ${quote}`,
    });
  }
  if (!/0x[0-9a-fA-F]{40}/.test(spec.contract)) throw new Error('合约地址格式错误');

  return {
    kind: 'mint',
    spec,
    checks,
    quote: quote.toString(),
    quoteHuman: (Number(quote) / 1e18).toFixed(8),
    steps: [{
      label: `mint ${spec.quantity} part(s) → ${spec.contract}`,
      tx: { to: spec.contract, value: quote.toString(), inputData: '0x' },
    }],
    warnings: spec.expectsEmptyData ? [] : ['提示词未明确要求空 calldata，已按 Foundry 规则使用 0x'],
  };
}

export async function decodeMintReceipt({ hash, contract, wallet }) {
  const receipt = await rpc('eth_getTransactionReceipt', [hash]);
  if (!receipt) return { status: 'pending' };
  if (receipt.status !== '0x1') return { status: 'failed', receipt };
  const balances = {};
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() !== contract.toLowerCase()) continue;
    try {
      const decoded = decodeEventLog({ abi: erc1155Abi, data: log.data, topics: log.topics });
      const { to, ids, values } = decoded.args;
      if (to.toLowerCase() !== wallet.toLowerCase()) continue;
      const idList = ids ? [...ids] : [decoded.args.id];
      const valList = values ? [...values] : [decoded.args.value];
      idList.forEach((id, i) => {
        const key = Number(id);
        balances[key] = (balances[key] || 0n) + BigInt(valList[i]);
      });
    } catch { /* 非 ERC1155 事件 */ }
  }
  return {
    status: 'success',
    blockNumber: Number(BigInt(receipt.blockNumber)),
    parts: Object.entries(balances).map(([id, count]) => ({
      id: Number(id),
      name: PART_NAMES[Number(id)] || `#${id}`,
      count: count.toString(),
    })),
  };
}
