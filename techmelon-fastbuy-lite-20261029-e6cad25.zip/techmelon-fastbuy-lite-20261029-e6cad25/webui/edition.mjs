/**
 * 页面按版本裁剪：index.html 里用注释标出只属于某个版本的区块
 *   <!-- edition:full --> … <!-- /edition:full -->   只在全量版显示（狙击 / 打新 / 发射台）
 *   <!-- edition:lite --> … <!-- /edition:lite -->   只在轻量版显示（例如单独的「Four 手动交易」入口）
 * 服务端返回页面时按当前版本处理（开发环境的完整仓库也能切换），打包脚本对轻量版做同样的裁剪（scripts/make_release.py 同一规则）。
 * 标记不能嵌套。
 */
const BLOCK = /<!-- edition:(full|lite) -->([\s\S]*?)<!-- \/edition:\1 -->/g;

export function stripEditionBlocks(html, edition) {
  return String(html).replace(BLOCK, (_m, which, body) => (which === edition ? body : ''));
}
