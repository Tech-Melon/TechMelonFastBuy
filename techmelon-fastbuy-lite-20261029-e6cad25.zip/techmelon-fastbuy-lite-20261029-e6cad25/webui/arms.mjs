/**
 * 预授权持久化（webui/arms.json，权限 600，已 gitignore）：服务重启后按原策略恢复，任务不会因为重启悄悄停掉。
 *
 * 恢复条件（任何一条不满足就不恢复，并写一条 resume.skip 日志）：
 *   - 设置里「重启后自动恢复预授权」开着（config.resumeArms !== false，默认开）；
 *   - 没过期：按开启时的到期时间算，重启不顺延；
 *   - 买入上限（单笔 / 每日）和开启时一致（上限改过就说明当初确认的前提变了）；
 *   - 各引擎自己的复核（钱包仍能取到地址、发射台仍启用、策略参数仍合法）。
 * 已花的预算与次数一起恢复（并与执行日志对账取大值），总预算不会因为重启重新变满。
 * 手动解除 / 全部解除 / 到期 / 修改上限 → 各引擎在 disarm 时删除对应条目。
 */
import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const FILE = process.env.ARMS_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), 'arms.json');

let entries = {};
try {
  const d = JSON.parse(readFileSync(FILE, 'utf8'));
  if (d && typeof d.entries === 'object') entries = d.entries;
} catch { /* 没有文件 = 没有需要恢复的预授权 */ }

let chain = Promise.resolve();
function flush() {
  const body = JSON.stringify({ version: 1, savedAt: new Date().toISOString(), entries }, (_k, v) => (typeof v === 'bigint' ? v.toString() : v), 2);
  chain = chain.then(async () => {
    const tmp = `${FILE}.${process.pid}.tmp`;
    try {
      await writeFile(tmp, body, { encoding: 'utf8', mode: 0o600 });
      await rename(tmp, FILE); // 原子替换：写到一半崩溃也不会留下半个文件
    } catch (err) {
      console.warn(`[arms] 保存预授权失败：${err.message}（重启后这项不会自动恢复）`);
    }
  });
  return chain;
}

/** 保存 / 更新一项预授权（key 例：direct:wallet-1、snipe:v2、fairauto、four） */
export function saveArm(key, data) {
  entries[key] = { ...data, savedAt: new Date().toISOString() };
  return flush();
}

export function clearArm(key) {
  if (!(key in entries)) return chain;
  delete entries[key];
  return flush();
}

/** 启动时读到的全部条目（只读副本） */
export function savedArms() {
  return JSON.parse(JSON.stringify(entries));
}

/** 买入上限签名：恢复时与当前上限比较 */
export const limitsSig = (l) => `${l.maxBuyBnb}|${l.dailyBnb}`;
