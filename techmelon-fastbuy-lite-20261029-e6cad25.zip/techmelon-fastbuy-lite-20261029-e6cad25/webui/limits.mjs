/**
 * 买入上限（服务端强制，存 config.json 的 limits；0 = 不限）：
 * - maxBuyBnb：单笔买入最多花多少 BNB（快捷交易生成买入计划时检查：所有步骤附带的 BNB 合计）
 * - dailyBnb：每个钱包每天（本机时区自然日）经本控制台广播出去的 BNB 合计上限。
 *   在 doExecute（contract-call execute）广播前检查，覆盖快捷交易 / 一键买入 / 直接买入 / 狙击 / 打新 / 自动打新 / Flap /
 *   AI 执行 / 合约调用，是这些功能的最后一道兜底。兑换页（market-order swap）和转账页（wallet send）不走 doExecute，不受它约束。
 *   当天已用量：启动后从执行日志重建一次（重启不清零），之后在内存累加；被币安挂起等 App 确认的、CLI 超时可能已广播的也算，宁可多算。
 */
import { getConfig, saveConfig } from './config.mjs';
import { readJournal } from './journal.mjs';

const WEI = 10n ** 18n;
const inflight = new Map(); // walletId → 正在广播、还没计入已花的 BNB
const locks = new Map(); // walletId → 排队中的检查（串行）

export function toWei(s) {
  const v = String(s ?? '0').trim() || '0';
  if (!/^\d{1,9}(\.\d{1,18})?$/.test(v)) throw new Error('上限需要是不超过 18 位小数的 BNB 数量（0 表示不限）');
  const [w, f = ''] = v.split('.');
  return BigInt(w) * WEI + BigInt((f + '0'.repeat(18)).slice(0, 18) || '0');
}

export function fromWei(x) {
  const s = BigInt(x).toString().padStart(19, '0');
  const f = s.slice(-18).replace(/0+$/, '');
  return f ? `${s.slice(0, -18)}.${f}` : s.slice(0, -18);
}

export async function getLimits() {
  const l = (await getConfig()).limits || {};
  return { maxBuyBnb: String(l.maxBuyBnb ?? '0'), dailyBnb: String(l.dailyBnb ?? '0') };
}

export async function setLimits({ maxBuyBnb, dailyBnb }) {
  toWei(maxBuyBnb);
  toWei(dailyBnb);
  await saveConfig({ limits: { maxBuyBnb: String(maxBuyBnb || '0'), dailyBnb: String(dailyBnb || '0') } });
  return getLimits();
}

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};
const dayOf = (iso) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};

/*
 * 当天已花：内存计数（钱包 → wei），按本机日期分天。启动后第一次用到时从执行日志重建一次
 * （journal.1.jsonl + journal.jsonl 全部读，日志轮转不会丢当天记录），之后每笔广播完成直接累加，热路径不读文件。
 * 计入：execute.done，execute.error 里 maybeSent=true 的（CLI 超时 / 中途退出，交易可能已经广播：宁可多算），
 * 以及上次运行留下的「只有 begin、没有结果」的（广播途中服务被杀）。
 */
const PROCESS_STARTED = Date.now();
const spent = new Map(); // walletId → wei（只记 day 这一天）
let day = null;
let loading = null;

async function ensureLoaded() {
  const t = today();
  if (day === t) return;
  // 启动后第一次 / 跨天：从日志重建当天计数（之后同一天只在内存累加，不再读文件，也就不会重复计）
  if (!loading) {
    loading = (async () => {
      const rows = await readJournal(Infinity, { withRotated: true });
      const m = new Map();
      const add = (r) => {
        try {
          // 用报价币库存买入时 value=0，按记录的 BNB 等值（equivWei）计
          const v = BigInt(r.value || '0');
          const e = BigInt(r.equivWei || '0');
          m.set(r.walletId, (m.get(r.walletId) || 0n) + (e > v ? e : v));
        } catch { /* 坏行跳过 */ }
      };
      // 只有 execute.begin、没有 done / error 的：广播途中服务被杀 / 崩溃，交易可能已经发出 → 也算已花（宁可多算）。
      // 只认本进程启动之前写的（本进程正在广播的那几笔已经计在 inflight 里，不能重复算）
      const orphans = new Map();
      for (const r of rows) {
        if (!r.walletId || dayOf(r.at) !== t) continue;
        if (r.type === 'execute.begin' && r.requestId && Date.parse(r.at) < PROCESS_STARTED) orphans.set(r.requestId, r);
        else if (r.type === 'execute.done' || r.type === 'execute.error') orphans.delete(r.requestId);
        const counted = r.type === 'execute.done' || (r.type === 'execute.error' && r.maybeSent);
        if (counted) add(r);
      }
      for (const r of orphans.values()) add(r);
      spent.clear();
      for (const [k, v] of m) spent.set(k, v);
      day = t;
    })().finally(() => { loading = null; });
  }
  await loading;
}

/** 某钱包今天已经经本控制台广播出去的 BNB（wei），含正在广播的在途金额 */
export async function spentToday(walletId) {
  await ensureLoaded();
  return (spent.get(walletId) || 0n) + (inflight.get(walletId) || 0n);
}

/** 单笔买入检查：BNB 合计超过单笔上限就拒绝生成计划 */
export async function assertBuyLimit(valueWei) {
  const max = toWei((await getLimits()).maxBuyBnb);
  if (max > 0n && BigInt(valueWei) > max) {
    throw new Error(`超过单笔买入上限：这笔要花 ${fromWei(valueWei)} BNB，上限 ${fromWei(max)} BNB（在快捷交易页「买入上限」里修改）`);
  }
}

/**
 * 广播前的每日上限检查（doExecute 调用）。通过时登记在途金额，返回释放函数（日志写完后调用）。
 */
export async function reserveDaily(walletId, valueWei) {
  const v = BigInt(valueWei || '0');
  if (v === 0n) return () => {};
  // 同一钱包的检查串行执行（按钱包排队）：「读已花 → 比较 → 登记在途」之间不会插进另一笔
  const prev = locks.get(walletId) || Promise.resolve();
  let unlock;
  const mine = new Promise((r) => { unlock = r; });
  const tail = prev.then(() => mine);
  locks.set(walletId, tail);
  await prev;
  try {
    return await reserveLocked(walletId, v);
  } finally {
    unlock();
    if (locks.get(walletId) === tail) locks.delete(walletId);
  }
}

async function reserveLocked(walletId, v) {
  inflight.set(walletId, (inflight.get(walletId) || 0n) + v);
  let released = false;
  /** commit=true：这笔已广播（或可能已广播），计入当天已花；false：没发出去，只释放在途 */
  const release = (commit = false) => {
    if (released) return;
    released = true;
    inflight.set(walletId, (inflight.get(walletId) || 0n) - v);
    if (commit) spent.set(walletId, (spent.get(walletId) || 0n) + v);
  };
  try {
    const cap = toWei((await getLimits()).dailyBnb);
    if (cap > 0n) {
      const used = await spentToday(walletId); // 已含本笔在途
      if (used > cap) {
        throw new Error(`超过每日上限：该钱包今天已花 ${fromWei(used - v)} BNB，这笔 ${fromWei(v)} BNB，每日上限 ${fromWei(cap)} BNB（在快捷交易页「买入上限」里修改）`);
      }
    }
  } catch (err) {
    release(false);
    throw err;
  }
  return release;
}
