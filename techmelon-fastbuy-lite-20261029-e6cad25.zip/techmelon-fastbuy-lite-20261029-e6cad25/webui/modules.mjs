import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';

const FILE = new URL('./modules.json', import.meta.url);

async function load() {
  try {
    const list = JSON.parse(await readFile(FILE, 'utf8'));
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

async function persist(list) {
  await writeFile(FILE, JSON.stringify(list, null, 2), 'utf8');
}

export async function listModules() {
  const list = await load();
  return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function createModule({ name, text, protocol, intent }) {
  const list = await load();
  const params = [...new Set([...String(text).matchAll(/\{([^{}\n]{1,30})\}/g)].map((m) => m[1]))]
    .map((key) => ({ key }));
  const mod = {
    id: randomUUID(),
    name: String(name || '').slice(0, 60) || '未命名模块',
    text,
    protocol: protocol || 'unknown',
    intent: intent || 'unknown',
    params,
    createdAt: new Date().toISOString(),
  };
  list.push(mod);
  await persist(list);
  return mod;
}

export async function removeModule(id) {
  const list = await load();
  const next = list.filter((m) => m.id !== id);
  await persist(next);
  return { removed: list.length - next.length };
}

export async function getModule(id) {
  const list = await load();
  return list.find((m) => m.id === id) || null;
}
