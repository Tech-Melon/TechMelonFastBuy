/**
 * 静态资源缓存击穿（对齐 gmgn-toolkit 的 sniper/static_cache.py）：
 * 服务 HTML 时，把里面引用的本地 JS / CSS 改写成 `/app.js?v=<文件内容 MD5 前 8 位>`。
 * 哈希按文件 mtime 缓存：文件没变不重读；同步了新代码（内容变了）下一次打开页面就是新的版本号，不用重启、不用手动改。
 * 带 ?v= 的请求内容是确定的 → 浏览器可以长缓存（见 server.mjs）；不带的每次回源确认。
 */
import { createHash } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';

const hashes = new Map(); // 绝对路径 → { mtimeMs, hash }

export async function assetHash(file) {
  try {
    const s = await stat(file);
    const hit = hashes.get(file);
    if (hit && hit.mtimeMs === s.mtimeMs) return hit.hash;
    const hash = createHash('md5').update(await readFile(file)).digest('hex').slice(0, 8);
    hashes.set(file, { mtimeMs: s.mtimeMs, hash });
    return hash;
  } catch {
    return null;
  }
}

// src="/x.js" / href="/x.css"（可带旧的 ?v=），只认站内绝对路径
const ASSET_RE = /(\b(?:src|href)=")(\/[A-Za-z0-9_./-]+\.(?:js|css))(?:\?v=[A-Za-z0-9_.-]*)?(")/g;

/** 给 HTML 里引用的本地 JS / CSS 注入内容哈希版本号；publicDir 是静态文件根目录 */
export async function injectCacheBusters(html, publicDir) {
  const found = [...new Set([...html.matchAll(ASSET_RE)].map((m) => m[2]))];
  const map = new Map();
  await Promise.all(found.map(async (p) => {
    if (p.includes('..')) return;
    const h = await assetHash(path.join(publicDir, p));
    if (h) map.set(p, h);
  }));
  return html.replace(ASSET_RE, (all, pre, p, post) => (map.has(p) ? `${pre}${p}?v=${map.get(p)}${post}` : all));
}
