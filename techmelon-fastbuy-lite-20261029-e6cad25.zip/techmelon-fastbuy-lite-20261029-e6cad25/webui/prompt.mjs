import { encodeFunctionData, decodeFunctionResult, parseAbi } from 'viem';
import { getConfig, assertServiceUrl } from './config.mjs';
import { rpc } from './config.mjs';
import { instructionOf, numberAppears } from './agent/guard.mjs';

const factoryAbi = parseAbi([
  'function isMarket(address) view returns (bool)',
  'function probeOfMarket(address) view returns (address)',
]);
const probeAbi = parseAbi([
  'function market() view returns (address)',
  'function assetProbe()',
  'function actionStatusProbe()',
]);
const ADDR = /^0x[0-9a-fA-F]{40}$/;

export function extractConfig(text) {
  const blocks = [...text.matchAll(/(?:^|\n)\s*CONFIG\s*\r?\n([\s\S]*?)(?=\n\s*\n|\n[A-Z ]{4,}\s*\r?\n|$)/g)];
  if (!blocks.length) return null;
  const body = blocks[blocks.length - 1][1];
  const config = {};
  for (const line of body.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) config[m[1]] = m[2];
  }
  return Object.keys(config).length ? config : null;
}

export function validateConfig(config) {
  const checks = [];
  const require = ['CHAIN_ID', 'FACTORY', 'PORTAL', 'MARKET', 'PROBE'];
  for (const key of require) {
    checks.push({ name: key, ok: Boolean(config[key]), detail: config[key] || '缺失' });
  }
  if (config.CHAIN_ID && config.CHAIN_ID !== '56') {
    checks.push({ name: 'CHAIN_ID', ok: false, detail: `仅支持 56，收到 ${config.CHAIN_ID}` });
  }
  for (const key of ['FACTORY', 'PORTAL', 'READER', 'MARKET', 'PROBE', 'QUOTE_TOKEN']) {
    if (config[key] && config[key] !== 'null' && !ADDR.test(config[key])) {
      checks.push({ name: key, ok: false, detail: `地址非法（${config[key].length - 2} 位 hex）` });
    }
  }
  return checks;
}

function collectCandidates(text) {
  const found = new Set();
  const map = { buy: 'buy', sell: 'sell', claim: 'claim', query: 'query', dex_exit: 'dex_exit' };
  for (const m of text.matchAll(/OPERATION:\s*(buy|sell|claim|query|dex_exit)\b/gi)) {
    found.add(map[m[1].toLowerCase()]);
  }
  return [...found];
}

function parseParams(text) {
  const params = { amount: null, percent: null, slippageBps: null };

  const slip = text.match(/(?:滑点|slippage)[^\d]{0,8}(\d+(?:\.\d+)?)\s*%/i);
  if (slip) params.slippageBps = Math.round(Number(slip[1]) * 100);

  const pct = text.match(/(?:卖出|sell|清仓)[^\d%]{0,12}(\d+(?:\.\d+)?)\s*%/i);
  if (pct) params.percent = Number(pct[1]);

  const amt = text.match(/(?:买入|buy)[^\d\n]{0,10}(\d+(?:\.\d+)?)\s*(BNB|BNCB)\b/i)
    || text.match(/(?:买入|buy)\s*[:：]?\s*(\d+(?:\.\d+)?)\s*(?=[,，。\s]|$)/i);
  if (amt) params.amount = amt[1];

  return params;
}

export function inferByRules(text) {
  const candidates = collectCandidates(text);
  let operation = null;
  let source = 'rules';

  if (candidates.length === 1) {
    operation = candidates[0];
  } else {
    // 取最后一段「用户指令」：最后 400 字符里出现的动词
    const tail = text.slice(-400);
    const hits = [];
    if (/(买入|buy\b)/i.test(tail)) hits.push('buy');
    if (/(卖出|sell\b)/i.test(tail)) hits.push('sell');
    if (/(领取|claim\b)/i.test(tail)) hits.push('claim');
    if (/(查询|持仓|query\b)/i.test(tail)) hits.push('query');
    if (/(dex_exit|换成\s*BNB)/i.test(tail)) hits.push('dex_exit');
    if (hits.length === 1) operation = hits[0];
  }

  // 金额 / 比例 / 滑点只从用户指令里取：手册里的示例数值不能当成用户设置
  return { operation, candidates, source, ...parseParams(instructionOf(text)) };
}

async function llmExtract(text, ai) {
  assertServiceUrl(ai.baseUrl, 'AI Base URL');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const res = await fetch(`${ai.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${ai.apiKey}` },
      body: JSON.stringify({
        model: ai.model,
        temperature: 0,
        max_tokens: 300,
        response_format: { type: 'json_object' },
        messages: [
          {
            role: 'system',
            content: 'You extract the user\'s requested action from a Flap mini-app prompt. '
              + 'The prompt contains a long manual covering buy/sell/claim/query/dex_exit; only the final user instruction is a request. '
              + 'Return strict JSON {"operation":"buy|sell|claim|query|dex_exit|null","amount":string|null,"percent":number|null,"slippageBps":number|null,"reason":string}. '
              + 'If no explicit request exists, operation=null. Never invent amounts, percentages or slippage.',
          },
          { role: 'user', content: text.slice(-16000) },
        ],
      }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`LLM HTTP ${res.status}`);
    const payload = await res.json();
    const raw = payload.choices?.[0]?.message?.content;
    const parsed = JSON.parse(raw);
    return parsed;
  } finally {
    clearTimeout(timer);
  }
}

async function inspect(config, wallet) {
  const checks = [];
  const warnings = [];
  if (!ADDR.test(config.MARKET) || !ADDR.test(config.FACTORY)) {
    return { checks, warnings, probe: null, asset: null, status: null };
  }
  try {
    const isMarket = decodeFunctionResult({
      abi: factoryAbi,
      functionName: 'isMarket',
      data: await rpc('eth_call', [{ to: config.FACTORY, data: encodeFunctionData({ abi: factoryAbi, functionName: 'isMarket', args: [config.MARKET] }) }, 'latest']),
    });
    checks.push({ name: 'Factory.isMarket', ok: Boolean(isMarket), detail: String(isMarket) });
    if (!isMarket) return { checks, warnings, probe: null, asset: null, status: null };

    const probe = decodeFunctionResult({
      abi: factoryAbi,
      functionName: 'probeOfMarket',
      data: await rpc('eth_call', [{ to: config.FACTORY, data: encodeFunctionData({ abi: factoryAbi, functionName: 'probeOfMarket', args: [config.MARKET] }) }, 'latest']),
    });
    checks.push({ name: 'probeOfMarket', ok: !config.PROBE || probe.toLowerCase() === config.PROBE.toLowerCase(), detail: probe });

    const marketBack = decodeFunctionResult({
      abi: probeAbi,
      functionName: 'market',
      data: await rpc('eth_call', [{ to: probe, data: encodeFunctionData({ abi: probeAbi, functionName: 'market' }) }, 'latest']),
    });
    checks.push({ name: 'Probe.market()', ok: marketBack.toLowerCase() === config.MARKET.toLowerCase(), detail: marketBack });

    let asset = null;
    try {
      await rpc('eth_call', [{ from: wallet, to: probe, data: encodeFunctionData({ abi: probeAbi, functionName: 'assetProbe' }) }, 'latest']);
      checks.push({ name: 'assetProbe', ok: false, detail: '未 revert' });
    } catch (err) {
      const text = decodeErrorString(err.data || '');
      if (text) {
        asset = parseFields(text);
        checks.push({ name: 'assetProbe.MARKET', ok: asset.MARKET?.toLowerCase() === config.MARKET.toLowerCase(), detail: asset.MARKET });
        checks.push({ name: 'assetProbe.QUOTE', ok: !config.QUOTE_TOKEN || asset.QUOTE?.toLowerCase() === config.QUOTE_TOKEN.toLowerCase(), detail: asset.QUOTE });
        checks.push({ name: 'assetProbe.DECIMALS', ok: !config.QUOTE_DECIMALS || asset.DECIMALS === config.QUOTE_DECIMALS, detail: asset.DECIMALS });
        warnings.push(`链上报价资产：${asset.QUOTE === '0x0000000000000000000000000000000000000000' ? '原生 BNB' : asset.QUOTE}`);
      } else {
        checks.push({ name: 'assetProbe', ok: false, detail: '无法解码' });
      }
    }
    return { checks, warnings, probe, asset, status: null };
  } catch (err) {
    warnings.push(`链上校验失败：${err.message}`);
    return { checks, warnings, probe: null, asset: null, status: null };
  }
}

function decodeErrorString(hex) {
  if (!hex || !hex.startsWith('0x08c379a0')) return null;
  const d = hex.slice(10);
  const off = Number(BigInt(`0x${d.slice(0, 64)}`)) * 2;
  const len = Number(BigInt(`0x${d.slice(off, off + 64)}`)) * 2;
  return Buffer.from(d.slice(off + 64, off + 64 + len), 'hex').toString('utf8');
}

function parseFields(text) {
  if (!text.endsWith('END')) return null;
  const out = {};
  for (const part of text.replace(/;END;?$/, '').split(';').filter(Boolean)) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i)] = part.slice(i + 1);
  }
  return out;
}

export async function parsePrompt({ text, wallet }) {
  const started = Date.now();
  const clean = String(text || '');
  const config = extractConfig(clean);
  if (!config) throw new Error('没有找到 CONFIG 块（CONFIG 行 + KEY=VALUE）');

  const checks = validateConfig(config);
  let result = inferByRules(clean);
  let llmError = null;

  const ai = (await getConfig()).ai;
  if (ai.apiKey) {
    try {
      const out = await llmExtract(clean, ai);
      if (out && ['buy', 'sell', 'claim', 'query', 'dex_exit'].includes(out.operation)) {
        // 规则优先；模型只补缺失项，且数值必须在用户指令里字面出现
        const instruction = instructionOf(clean);
        const llmAmount = out.amount != null && numberAppears(out.amount, instruction) ? String(out.amount) : null;
        const llmPercent = out.percent != null && numberAppears(out.percent, instruction) ? Number(out.percent) : null;
        const llmSlip = out.slippageBps != null
          && (numberAppears(String(Number(out.slippageBps) / 100), instruction) || numberAppears(out.slippageBps, instruction))
          ? Number(out.slippageBps) : null;
        result = {
          operation: result.operation ?? out.operation,
          candidates: result.candidates,
          source: result.operation ? 'rules+llm' : 'llm',
          amount: result.amount ?? llmAmount,
          percent: result.percent ?? llmPercent,
          slippageBps: result.slippageBps ?? llmSlip,
          reason: out.reason,
        };
      }
    } catch (err) {
      llmError = err.message;
    }
  }

  const verified = await inspect(config, wallet);

  const missing = [];
  if (!result.operation) missing.push('operation');
  if (result.operation === 'buy' && !result.amount) missing.push('amount');
  if (result.operation === 'buy' && result.slippageBps == null) missing.push('slippageBps');
  if (result.operation === 'sell' && !result.percent) missing.push('percent');
  if (result.operation === 'sell' && result.slippageBps == null) missing.push('slippageBps');

  return {
    config,
    checks: [...checks, ...verified.checks],
    warnings: verified.warnings,
    operation: result.operation,
    candidates: result.candidates,
    amount: result.amount,
    percent: result.percent,
    slippageBps: result.slippageBps,
    missing,
    source: result.source,
    llmError,
    elapsedMs: Date.now() - started,
  };
}
