/*
 * CA 的「平台归属」缓存（服务端，落盘 webui/detect-cache.json，600，gitignore，不随代码同步）。
 *
 * 只记不会变的东西：这个地址属于哪几个内盘平台（ids）、报价币（extras）、是不是 Flap market、symbol / decimals。
 * 会变的东西（曲线中 / 已毕业、能不能交易、Agent 门槛、池子）每次照样读链：命中后只问归属平台 + 外盘，
 * 不再把 Four / gang V2 / gang V3 / Flap / Flap 税币挨个探一遍，也不再读 symbol / decimals。
 *
 * 有效期与容量：
 *   - 属于某个内盘平台：7 天（平台归属不会变；归属平台这次说「不是」就作废重识别）；
 *   - 不属于任何内盘：10 分钟（平台可能刚启用，例如 gang V3 刚上线）；
 *   - 最多 MAX 条，超出按最近使用淘汰最旧的；
 *   - 平台签名（sig）和记录时不一致就不用（当未命中、重新识别后覆盖）：例如 gang V3 启用 / 停用 / 换地址。
 * 识别有任何平台出错时不写入（见 registry.mjs）。
 */
import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const FILE = process.env.DETECT_CACHE_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'detect-cache.json');
export const ID_POS_MS = 7 * 24 * 3600 * 1000;
export const ID_NEG_MS = 10 * 60 * 1000;
export const ID_MAX = 3000;
const lc = (a) => String(a || '').toLowerCase();

/** lc(address) → { ids, extras, market, symbol, decimals, sig, at }；Map 的顺序 = 最近使用顺序 */
const book = new Map();
try {
  const d = JSON.parse(readFileSync(FILE, 'utf8'));
  const now = Date.now();
  for (const e of Array.isArray(d?.entries) ? d.entries : []) {
    if (e && /^0x[0-9a-f]{40}$/.test(e.address) && Array.isArray(e.ids) && now - e.at < (e.ids.length ? ID_POS_MS : ID_NEG_MS)) book.set(e.address, e);
  }
} catch { /* 还没有缓存 */ }
const stats = { hits: 0, misses: 0, invalid: 0 };

let chain = Promise.resolve();
let timer = null;
function flush() {
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    const body = JSON.stringify({ version: 1, savedAt: new Date().toISOString(), entries: [...book.values()] });
    chain = chain.then(async () => {
      const tmp = `${FILE}.${process.pid}.tmp`;
      try { await writeFile(tmp, body, { encoding: 'utf8', mode: 0o600 }); await rename(tmp, FILE); } catch (err) { console.warn(`[detect-cache] 保存失败：${err.message}`); }
    });
  }, 3000);
  timer.unref?.();
}

/** 命中返回归属记录（并挪到「最近使用」末尾）；过期 / 签名不一致返回 null */
export function idGet(address, sig) {
  const k = lc(address);
  const e = book.get(k);
  if (!e) { stats.misses += 1; return null; }
  if (Date.now() - e.at >= (e.ids.length ? ID_POS_MS : ID_NEG_MS)) {
    book.delete(k);
    flush();
    stats.misses += 1;
    return null;
  }
  // 签名不一致只当未命中、不删除（gang V3 复核时 RPC 抖一下会短暂变成 'off'），重新识别后会覆盖
  if (e.sig !== sig) { stats.misses += 1; return null; }
  book.delete(k);
  book.set(k, e);
  stats.hits += 1;
  return e;
}

export function idSet(address, { ids, extras, market, symbol, decimals }, sig) {
  const k = lc(address);
  book.delete(k);
  book.set(k, { address: k, ids: [...ids], extras: [...(extras || [])].map(lc), market: Boolean(market), symbol: symbol ?? null, decimals: decimals ?? null, sig, at: Date.now() });
  while (book.size > ID_MAX) book.delete(book.keys().next().value);
  flush();
}

/** 归属平台这次说「不是」：记录作废，按全量重新识别 */
export function idDrop(address) {
  if (book.delete(lc(address))) { stats.invalid += 1; flush(); }
}

export function idStats() {
  return { size: book.size, max: ID_MAX, ...stats };
}
