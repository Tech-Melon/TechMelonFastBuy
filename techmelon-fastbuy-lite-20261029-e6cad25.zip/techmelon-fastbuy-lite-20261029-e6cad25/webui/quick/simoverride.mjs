/**
 * 授权前模拟卖出：eth_call 的状态覆盖（state override）临时改写代币合约里「钱包 → spender」的授权额度，
 * 这样还没授权时也能以钱包身份模拟真实卖出（含税、门槛、手续费），算出准确的「最少收到」，
 * 卖出计划就能一次给出「授权 + 卖出」两步，不用等授权上链后重新报价。
 *
 * 只改模拟用的临时状态，不发交易、不碰链上真实授权。找不到存储位置（非常规代币）时返回 null，调用方退回原来的估算方式。
 *
 * 授权映射 mapping(owner => mapping(spender => uint256)) 在槽位 p 时，allowance[owner][spender] 的位置是
 * keccak256(spender . keccak256(owner . p))。常见布局：
 *   - OpenZeppelin ERC20（非升级）：_allowances 在 0~10 号槽之间（取决于继承顺序）
 *   - OpenZeppelin v5 upgradeable：ERC-7201 命名空间 ERC20Storage（0x52c6…ce00），_allowances 是第 2 个字段（+1）
 * 逐个候选写入一个特征值，读 allowance() 看是否生效，命中的槽位按代币缓存。
 */
import { encodeAbiParameters, keccak256, encodeFunctionData, decodeFunctionResult, parseAbi, toHex, pad } from 'viem';
import { rpc } from '../config.mjs';

const erc20Abi = parseAbi(['function allowance(address,address) view returns (uint256)', 'function balanceOf(address) view returns (uint256)']);
const ERC7201_ERC20 = BigInt('0x52c63247e1f47db19d5ce0460030c497f067ca4cebf71ba98eeadabe20bace00');
const CANDIDATES = [...Array.from({ length: 12 }, (_, i) => BigInt(i)), ERC7201_ERC20 + 1n, BigInt(51), BigInt(52), BigInt(101), BigInt(102), BigInt(151), BigInt(152), BigInt(201), BigInt(202)];
const MAGIC = 0x5ca1ab1e0000000000000000000000000000000000000000000000000000c0den;
const slotCache = new Map(); // token(lc) → 槽位（BigInt）或 null（都不命中）

const lc = (a) => String(a || '').toLowerCase();

/** allowance[owner][spender] 在槽位 p 时的存储 key */
export function allowanceKey(owner, spender, p) {
  const inner = keccak256(encodeAbiParameters([{ type: 'address' }, { type: 'uint256' }], [owner, p]));
  return keccak256(encodeAbiParameters([{ type: 'address' }, { type: 'bytes32' }], [spender, inner]));
}
/** balance[owner] 在槽位 p 时的存储 key（评测用：给没持仓的地址造余额） */
export function balanceKey(owner, p) {
  return keccak256(encodeAbiParameters([{ type: 'address' }, { type: 'uint256' }], [owner, p]));
}

async function readWithOverride(token, functionName, args, override, call = rpc) {
  const data = encodeFunctionData({ abi: erc20Abi, functionName, args });
  const raw = await call('eth_call', [{ to: token, data }, 'latest', override]);
  return decodeFunctionResult({ abi: erc20Abi, functionName, data: raw });
}

/** 找到这个代币授权映射的槽位（按代币缓存）；找不到返回 null。owner / spender 只用来验证，换钱包也通用 */
export async function findAllowanceSlot(token, owner, spender, { call = rpc } = {}) {
  const k = lc(token);
  if (slotCache.has(k)) return slotCache.get(k);
  let found = null;
  // 并行试所有候选：只读调用，很轻
  const hits = await Promise.all(CANDIDATES.map(async (p) => {
    try {
      const v = await readWithOverride(token, 'allowance', [owner, spender], { [token]: { stateDiff: { [allowanceKey(owner, spender, p)]: pad(toHex(MAGIC)) } } }, call);
      return v === MAGIC;
    } catch { return false; }
  }));
  const i = hits.indexOf(true);
  if (i >= 0) found = CANDIDATES[i];
  slotCache.set(k, found);
  return found;
}

/**
 * 生成「钱包 → spender 授权 amount」的状态覆盖（给 eth_call 第三个参数用）；找不到槽位返回 null。
 * extra：要合并进去的其它覆盖（比如评测里给钱包造余额）。
 */
export async function allowanceOverride(token, owner, spender, amount, { call = rpc } = {}) {
  const p = await findAllowanceSlot(token, owner, spender, { call });
  if (p == null) return null;
  return { [token]: { stateDiff: { [allowanceKey(owner, spender, p)]: pad(toHex(BigInt(amount))) } } };
}

/** 以 from 身份 eth_call（可带状态覆盖）。返回 { ok, raw } 或 { ok:false, reason } */
export async function simulateCall({ from, to, data, value = 0n, override = null, call = rpc }) {
  const params = [{ from, to, data, value: toHex(BigInt(value)) }, 'latest'];
  if (override) params.push(override);
  try {
    return { ok: true, raw: await call('eth_call', params) };
  } catch (err) {
    return { ok: false, reason: String(err.shortMessage || err.message || err).split('\n')[0].slice(0, 200), data: err.data || err.revertData || null };
  }
}
