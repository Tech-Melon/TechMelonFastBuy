// Four（OpenFour Core）内盘：只在 Trading 阶段可交易；Migrated（已毕业）交给外盘路由。
import { readCoreBrief, readErc20Balance, isNativeQuote, quoteKeyOf } from '../../four/openfour.mjs';
import { planBuy, planSell } from '../../four/trade.mjs';
import { pretty, parseUnitsStrict } from '../util.mjs';
import { estimateOut, WBNB } from '../router.mjs';

const unitOf = (quoteAsset) => (isNativeQuote(quoteAsset) ? 'BNB' : (quoteKeyOf(quoteAsset) || '计价币').toUpperCase());

export default {
  id: 'four',
  label: 'Four 内盘（OpenFour）',
  addressKind: 'token',
  async detect(address) {
    const b = await readCoreBrief(address);
    if (!b.exists) return null;
    const trading = b.phase === 1 && !b.paused;
    return {
      match: true,
      tradable: trading,
      phase: `${b.phaseName}${b.paused ? '（已暂停）' : ''}`,
      payUnit: unitOf(b.quoteAsset),
      graduated: b.phase === 3,
      extras: [b.quoteAsset],
      notes: trading ? ['内盘交易需要 Agent ID；单地址最多持有 1%'] : (b.phase === 3 ? ['已迁移到 PancakeSwap，改走外盘路由'] : []),
    };
  },
  async plan({ wallet, address, side, amount, percent, slippageBps }) {
    if (side === 'buy') {
      // 快捷交易按「预算」买：金额单位是计价币（BNB / BNCB / NVDAB）
      const p = await planBuy({ token: address, trader: wallet, mode: 'quote', amountWei: parseUnitsStrict(amount, 18), slippageBps });
      // 授权后的买入步骤也列出来（授权上链后会按最新状态重新生成），一键买入的上限才能覆盖它
      const steps = p.approveTx
        ? [
          { kind: 'approve', label: `授权 ${p.unit} 给 Four Core（只授权本次预算）`, replan: true, tx: p.approveTx },
          { kind: 'buy', label: p.summary.text, tx: p.tx },
        ]
        : [{ kind: 'buy', label: p.summary.text, tx: p.tx }];
      // 非 BNB 计价（BNCB / NVDAB）：按池子报价折合 BNB，单笔上限按它检查（步骤本身不带 BNB）。估不出来为 null
      let bnbEquivWei = '0';
      let equivText = '';
      if (!p.native) {
        const est = await estimateOut(p.quoteAsset, WBNB, BigInt(p.summary.maxPay)).catch(() => 0n);
        bnbEquivWei = est > 0n ? est.toString() : null;
        equivText = est > 0n ? `（≈ ${pretty(est)} BNB）` : '';
      }
      return {
        platform: 'four', side, token: p.token, symbol: p.symbol, decimals: 18,
        pay: { raw: p.summary.maxPay, text: `最多 ${pretty(p.summary.maxPay)} ${p.unit}${equivText}` },
        bnbEquivWei,
        receive: { expected: pretty(p.summary.amount), min: pretty(p.summary.minAmountOut), minRaw: String(p.summary.minAmountOut), symbol: p.symbol },
        route: `Four Core 内盘（${p.unit} 计价）`,
        checks: [], warnings: [], note: p.note, steps,
      };
    }
    let amountWei;
    if (percent) {
      const bal = await readErc20Balance(address, wallet);
      amountWei = (bal * BigInt(Math.round(Number(percent) * 100))) / 10000n;
      if (amountWei <= 0n) throw new Error('钱包没有该代币持仓');
    } else {
      amountWei = parseUnitsStrict(amount, 18);
    }
    const p = await planSell({ token: address, trader: wallet, amountWei, slippageBps });
    // 授权不足时一次给出「授权 → 卖出」两步：卖出的数量和最少收到在授权前就能算好（Four 的卖出估算不依赖授权），
    // 授权上链后直接预览原来的卖出交易，不重新报价。
    // 以前只给出「授权」一步（等上链后重新报价），一键执行的上限按 1 步确认，第 2 步卖出就被
    // 「步骤数超过确认时的 1 步」拦下（2026-10-28 4Broker 卖出实测）
    const sellStep = { kind: 'sell', label: p.summary.text, tx: p.tx };
    const steps = p.approveTx
      ? [{ kind: 'approve', label: `授权 ${p.symbol} 给 Four Core（只授权本次数量）`, replan: false, tx: p.approveTx }, sellStep]
      : [sellStep];
    return {
      platform: 'four', side, token: p.token, symbol: p.symbol, decimals: 18,
      pay: { raw: p.amount, text: `${pretty(p.amount)} ${p.symbol}` },
      receive: { expected: pretty(p.summary.userReceives), min: pretty(p.summary.minReceive), minRaw: String(p.summary.minReceive), symbol: p.unit },
      route: `Four Core 内盘（卖回 ${p.unit}）`,
      checks: [], warnings: [], note: p.approveTx ? '先授权本次卖出数量，上链后自动卖出（两步，一次确认）' : null, steps,
    };
  },
};
