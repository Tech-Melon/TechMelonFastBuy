// 外盘：PancakeSwap 智能路由（V2+V3 混合，单笔原子交易）。已毕业的内盘代币也走这里。
import { detectDex, planDexTrade } from '../router.mjs';

export default {
  id: 'dex',
  label: 'PancakeSwap 智能路由（外盘 / 已毕业）',
  addressKind: 'token',
  async detect(address, { extras = [] } = {}) {
    return detectDex(address, extras);
  },
  async plan({ wallet, address, side, amount, percent, slippageBps, extras = [] }) {
    return planDexTrade({ wallet, token: address, side, amount, percent, slippageBps, extras });
  },
};
