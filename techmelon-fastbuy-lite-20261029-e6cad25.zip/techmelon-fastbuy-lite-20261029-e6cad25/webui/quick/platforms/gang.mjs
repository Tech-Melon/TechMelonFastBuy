// gang.fun LaunchpadV2 曲线：未毕业走曲线；已毕业交给外盘路由（带上曲线报价币，如 oANT）。
import { gangInfo, planGang } from '../../agent/gang.mjs';
import { tokenMeta } from '../router.mjs';
import { pretty, stepKind } from '../util.mjs';

export default {
  id: 'gang',
  label: 'gang.fun 曲线（LaunchpadV2）',
  addressKind: 'token',
  async detect(address) {
    const g = await gangInfo(address);
    if (!g) return null;
    const q = await tokenMeta(g.quote).catch(() => ({ symbol: '?' }));
    return {
      match: true,
      tradable: !g.graduated,
      phase: g.graduated ? '已毕业（PancakeSwap V2）' : '曲线中',
      payUnit: 'BNB',
      graduated: g.graduated,
      extras: [g.quote],
      quoteSymbol: q.symbol,
      notes: [
        `报价币 ${q.symbol}${g.taxed ? ' · 税币（买卖各 1%）' : ''}`,
        ...(g.graduated ? ['已毕业，改走外盘路由'] : ['曲线买入需要 .ai Agent ID；BNB 会先经智能路由换成报价币']),
      ],
    };
  },
  async plan({ wallet, address, side, amount, percent, slippageBps, quoteIn, pendingApprove, maxImpactBps, maxLossBps }) {
    const params = side === 'buy'
      ? { side: 'buy', token: address, amountBnb: String(amount), quoteIn: quoteIn ?? null, pendingApprove: pendingApprove ?? null, slippageBps, maxImpactBps, maxLossBps }
      : { side: 'sell', token: address, percent: percent || null, amount: percent ? null : String(amount), slippageBps };
    const p = await planGang({ wallet, spec: { protocol: 'gang', params } });
    const meta = await tokenMeta(address);
    const quoteSym = p.spec.quoteSymbol;
    // 换币 / 包装上链后重新生成计划（到账数量要按链上结果算）。
    // 授权不改变任何数量：买入步骤的 quoteIn 和「最少收到」在计划里已经定好，授权上链后直接预览原来的买入交易，
    // 价格超出滑点时预览模拟会失败并停止（与确认时的保护完全一样）。以前授权后也重新报价，新币刚开盘价格涨得快，
    // 重新报价的「最少收到」低于确认值就被拦下（2026-10-27 狙击 5 次里 3 次因此没买成）
    // 买入时换币 / 包装之后也不再重新报价：买入交易 buy(minQuote, minTokens) 在计划里就定好了，
    // 换币的 SmartRouter 下限保证到账 ≥ minQuote（多出的部分留在钱包当库存）。以前换币上链后重新报价，
    // 新币价格几秒内就变，重新报价的「最少收到」低于确认值被拦下（2026-10-28 执行日志：换币+授权+买入 3 次全部因此停止）。
    // 价格超出滑点时买入的预览模拟会失败并停止，保护与确认时一致
    const steps = p.steps.map((s) => {
      const kind = stepKind(s.label);
      if (side === 'buy') return { kind, label: s.label, tx: s.tx, replan: false, next: null };
      return { kind, label: s.label, tx: s.tx, replan: Boolean(s.next) && kind !== 'approve', next: kind === 'approve' ? null : s.next || null };
    });
    if (side === 'buy') {
      const quoteMode = p.spec.quoteMode;
      const inv = p.spec.inventory;
      const payText = quoteMode
        ? `${pretty(p.spec.buyWithQuote)} ${quoteSym}（已换好的报价币，含 1% 手续费）`
        : inv
          ? `${amount} BNB 等值 = ${pretty(p.spec.buyWithQuote)} ${quoteSym}（用库存，含 1% 手续费）`
          : `${amount} BNB（先换成 ${quoteSym}，含 1% 手续费）`;
      return {
        platform: 'gang', side, token: meta.address, symbol: meta.symbol, decimals: 18,
        pay: { text: payText },
        bnbEquivWei: p.spec.bnbEquivWei,
        receive: { expected: pretty(p.spec.expectedTokens), min: pretty(p.spec.minTokens), minRaw: String(p.spec.minTokens), symbol: meta.symbol },
        route: quoteMode || inv ? `${quoteSym}${inv ? '（库存）' : ''} → gang 曲线（LaunchpadV2.buy）` : `BNB → ${quoteSym} → gang 曲线（LaunchpadV2.buy）`,
        checks: p.checks, warnings: p.warnings,
        note: steps.length > 1
          ? `曲线只收 ${quoteSym}：共 ${steps.length} 步，确认一次后按顺序执行（授权与换币并行发出）；买入数量和最少收到按这次报价锁定，换币多到账的 ${quoteSym} 留在钱包`
          : null,
        steps,
      };
    }
    return {
      platform: 'gang', side, token: meta.address, symbol: meta.symbol, decimals: 18,
      pay: { text: `${p.spec.tokenInHuman} ${meta.symbol}` },
      receive: { expected: p.spec.expectedOut, min: p.spec.minOut, minRaw: p.spec.minOutRaw ?? null, symbol: quoteSym },
      route: `gang 曲线 → ${quoteSym}`,
      checks: p.checks, warnings: p.warnings,
      note: steps.length > 1 ? `需要按顺序执行 ${steps.length} 笔` : null,
      steps,
    };
  },
};
