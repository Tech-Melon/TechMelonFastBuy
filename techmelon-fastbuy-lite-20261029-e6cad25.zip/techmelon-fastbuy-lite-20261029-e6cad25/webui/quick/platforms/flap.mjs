// Flap 曲线：输入的是 market 地址（不是代币 CA）；买入金额单位是该市场的计价币。
import { encodeFunctionData, decodeFunctionResult, parseAbi } from 'viem';
import { rpc } from '../../config.mjs';
import { FLAP, planFlap } from '../../flap.mjs';
import { tokenMeta, estimateOut, WBNB } from '../router.mjs';
import { stepKind, human } from '../util.mjs';

const factoryAbi = parseAbi(['function isMarket(address) view returns (bool)']);
const ZERO = /^0x0{40}$/i;

async function quoteSymbol(plan) {
  if (!plan.isErc20 || ZERO.test(plan.quoteToken) || String(plan.quoteToken).toLowerCase() === WBNB.toLowerCase()) return 'BNB';
  return (await tokenMeta(plan.quoteToken).catch(() => ({ symbol: '计价币' }))).symbol;
}

export default {
  id: 'flap',
  label: 'Flap 曲线（填 market 地址）',
  addressKind: 'market',
  async detect(address, { wallet } = {}) {
    const raw = await rpc('eth_call', [{ to: FLAP.factory, data: encodeFunctionData({ abi: factoryAbi, functionName: 'isMarket', args: [address] }) }, 'latest']);
    if (!decodeFunctionResult({ abi: factoryAbi, functionName: 'isMarket', data: raw })) return null;
    const q = await planFlap({ wallet, market: address, op: 'query' });
    const unit = await quoteSymbol(q);
    const phase = q.phase === '1' ? '曲线中' : q.phase === '3' ? '已发射（可 claim）' : `PHASE=${q.phase}`;
    return {
      match: true,
      tradable: q.phase === '1',
      phase,
      payUnit: unit,
      notes: [`持有份额 ${q.summary.heldSharesHuman}`, '买入需要 Agent ID；卖出只支持按比例（如 50%）'],
    };
  },
  async plan({ wallet, address, side, amount, percent, slippageBps }) {
    if (side === 'sell' && !percent) throw new Error('Flap 卖出只支持按比例：请填 25% / 50% / 100%');
    const op = side === 'buy' ? 'buy' : 'sell';
    const p = await planFlap({
      wallet, market: address, op, amount: String(amount ?? '0'),
      bps: side === 'sell' ? Math.round(Number(percent) * 100) : 0, slippageBps,
    });
    const unit = await quoteSymbol(p);
    const steps = p.steps.map((s) => ({ kind: stepKind(s.label), label: s.label, tx: s.tx }));
    const base = {
      platform: 'flap', side, token: address, symbol: '份额', decimals: 18,
      route: `Flap Portal（${unit} 计价）`, checks: p.checks, warnings: p.warnings,
      note: steps.length > 1 ? `需要按顺序执行 ${steps.length} 笔（先授权，再买入）` : null, steps,
    };
    if (side === 'buy') {
      // ERC20 计价（BNCB 等）步骤不带 BNB：按池子估值折合 BNB 计入单笔上限；估不出为 null（有上限时拒绝）
      let bnbEquivWei = '0';
      if (p.isErc20 && String(p.quoteToken).toLowerCase() !== WBNB.toLowerCase()) {
        const est = await estimateOut(p.quoteToken, WBNB, BigInt(p.quote.grossRaw)).catch(() => 0n);
        bnbEquivWei = est > 0n ? est.toString() : null;
      } else if (p.isErc20) {
        bnbEquivWei = String(p.quote.grossRaw); // WBNB 计价：1:1
      }
      return {
        ...base,
        bnbEquivWei,
        pay: { text: `${p.quote.grossHuman} ${unit}（手续费 ${p.quote.feeHuman}）` },
        receive: { expected: p.quote.sharesHuman, min: human(p.quote.minShares, 18), minRaw: String(p.quote.minShares), symbol: '份额' },
      };
    }
    return {
      ...base,
      pay: { text: `${p.quote.sharesHuman} 份额（${percent}%）` },
      receive: { expected: p.quote.outHuman, min: human(p.quote.minOut, p.decimals), symbol: unit },
    };
  },
};
