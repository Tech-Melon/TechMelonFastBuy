// Flap 新版 Portal（Tax Token V3 / Agent ID 内盘，地址以 7777 结尾）：填代币 CA。
// 2026-10-28 链上核对（代币 0xe3a7…7777）：
//   - 买卖都走 Portal.swapExactInput((inputToken, outputToken, inputAmount, minOutputAmount, permitData))，selector 0xef7ec2e7；
//     BNB 计价时 BNB 用 address(0) 表示：买入 input=0x0、value=金额；卖出 output=0x0（先把代币授权给 Portal）。
//   - quoteExactInput((inputToken, outputToken, inputAmount)) 报价（不检查 Agent ID 门槛，所以另以钱包身份模拟一次）。
//   - getTokenV2(token) 第一个字段是状态：0 不是 Flap 代币，1 内盘可交易，4 已上 DEX（交给外盘路由）。
//   - nftGate(token) ≠ 0 时只有持有该 NFT（Binance Agent ID）的 tx.origin 能在内盘买卖；maxBuyPerOrigin = 每个地址最多 2%。
// 只支持 BNB 计价的代币（ERC20 计价的报价会失败，识别为不可交易）。
import { encodeFunctionData, decodeFunctionResult, decodeFunctionData, decodeErrorResult, parseAbi, getAddress, toHex } from 'viem';
import { rpc } from '../../config.mjs';
import { tokenMeta } from '../router.mjs';
import { parseUnitsStrict, pretty } from '../util.mjs';
import { allowanceOverride, simulateCall } from '../simoverride.mjs';

export const FLAP_PORTAL = '0xe2cE6ab80874Fa9Fa2aAE65D277Dd6B8e65C9De0';
const ZERO = '0x0000000000000000000000000000000000000000';
const STATUS = { 1: '内盘交易中', 2: '决斗中', 3: '已终止', 4: '已上 DEX' };
const portalAbi = parseAbi([
  'function getTokenV2(address token) view returns (uint8 status, uint256 reserve, uint256 circulatingSupply, uint256 price, uint8 tokenVersion, uint256 r, uint256 dexSupplyThresh)',
  'function nftGate(address token) view returns (address)',
  'function maxBuyPerOrigin(address token) view returns (uint16 bps, uint256 amount)',
  'function quoteExactInput((address inputToken, address outputToken, uint256 inputAmount) p) returns (uint256)',
  'function swapExactInput((address inputToken, address outputToken, uint256 inputAmount, uint256 minOutputAmount, bytes permitData) p) payable returns (uint256)',
]);
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
]);
const lc = (a) => String(a || '').toLowerCase();

async function rd(to, abi, functionName, args = [], from) {
  const raw = await rpc('eth_call', [{ to, data: encodeFunctionData({ abi, functionName, args }), ...(from ? { from } : {}) }, 'latest']);
  return decodeFunctionResult({ abi, functionName, data: raw });
}

async function state(token) {
  const s = await rd(FLAP_PORTAL, portalAbi, 'getTokenV2', [token]).catch(() => null);
  if (!s || Number(s[0]) === 0) return null;
  const [gate, cap] = await Promise.all([
    rd(FLAP_PORTAL, portalAbi, 'nftGate', [token]).catch(() => ZERO),
    rd(FLAP_PORTAL, portalAbi, 'maxBuyPerOrigin', [token]).catch(() => [0, 0n]),
  ]);
  return { status: Number(s[0]), gate: lc(gate) === ZERO ? null : getAddress(gate), capBps: Number(cap[0]), capAmount: BigInt(cap[1]) };
}

const quote = (i, o, amt) => rd(FLAP_PORTAL, portalAbi, 'quoteExactInput', [{ inputToken: i, outputToken: o, inputAmount: amt }]);

// 币安 Agent ID 合集。Flap 的 Agent ID 门槛也可以是发币人指定的其它 ERC-721 合集（2026-10-28 实测 0x3c6e…7777 用的是 0xB29F…308F）
export const BINANCE_AGENT_ID = '0x60B9262456dE011F7d15a54CdD8c48bAaa8B022F';
export const gateLabel = (gate) => (lc(gate) === lc(BINANCE_AGENT_ID) ? '币安 Agent ID' : `NFT 合集 ${gate.slice(0, 6)}…${gate.slice(-4)}`);
const gateErrAbi = parseAbi(['error NFTGatedOnly(address origin)', 'error BuyCapExceeded(address origin, uint256 balance, uint256 cap)']);
/** 模拟失败是不是门槛 / 上限造成的：返回中文原因，否则 null */
function gateError(sim, gate) {
  try {
    const d = decodeErrorResult({ abi: gateErrAbi, data: sim.data });
    if (d.errorName === 'NFTGatedOnly') return `只有持有 ${gate ? gateLabel(gate) : 'Agent ID'} 的钱包能在内盘交易（NFTGatedOnly）`;
    if (d.errorName === 'BuyCapExceeded') return '已达到每个地址 2% 的持仓上限（BuyCapExceeded）';
  } catch { /* 不是这两种 */ }
  return null;
}

/** 广播前复核：只能是 Portal.swapExactInput，方向 / 代币 / 数量 / 最少收到与计划一致 */
export function assertFlapSwapTx(tx, { token, side, amount, minOut }) {
  if (lc(tx.to) !== lc(FLAP_PORTAL)) throw new Error('目标合约不是 Flap Portal');
  const d = decodeFunctionData({ abi: portalAbi, data: tx.inputData });
  if (d.functionName !== 'swapExactInput') throw new Error('calldata 不是 swapExactInput');
  const p = d.args[0];
  const [i, o] = side === 'buy' ? [ZERO, token] : [token, ZERO];
  if (lc(p.inputToken) !== lc(i) || lc(p.outputToken) !== lc(o)) throw new Error('swapExactInput 的买卖方向 / 代币与计划不一致');
  if (BigInt(p.inputAmount) !== amount || amount <= 0n) throw new Error('数量与计划不一致');
  if (BigInt(p.minOutputAmount) !== minOut || minOut <= 0n) throw new Error('最少收到与计划不一致或为 0');
  if (BigInt(tx.value) !== (side === 'buy' ? amount : 0n)) throw new Error('交易 value 与买入金额不一致');
}

export default {
  id: 'flaptax',
  label: 'Flap 税币（新版 Portal，填代币 CA）',
  addressKind: 'token',
  async detect(address, { wallet } = {}) {
    const s = await state(address);
    if (!s) return null;
    const notes = [];
    let holder = null;
    if (s.gate) {
      holder = wallet ? (await rd(s.gate, erc20Abi, 'balanceOf', [wallet]).catch(() => 0n)) > 0n : null;
      notes.push(`只有持有 ${gateLabel(s.gate)} 的钱包能在内盘买卖${holder === false ? '：当前钱包没有，买卖会被拒绝' : ''}`);
    }
    if (s.capBps) notes.push(`每个地址最多买 ${s.capBps / 100}%（超出部分自动退回）`);
    // 能用 BNB 报价才算支持（ERC20 计价的报价会失败）
    const bnbQuote = s.status === 1 ? await quote(ZERO, address, 10n ** 15n).then((x) => x > 0n).catch(() => false) : false;
    if (s.status === 1 && !bnbQuote) notes.push('不是 BNB 计价（或报价失败）：暂不支持');
    return {
      match: true,
      tradable: s.status === 1 && bnbQuote && holder !== false,
      phase: STATUS[s.status] || `状态 ${s.status}`,
      payUnit: 'BNB',
      graduated: s.status === 4,
      notes,
    };
  },
  async plan({ wallet, address, side, amount, percent, slippageBps }) {
    const token = getAddress(address);
    const s = await state(token);
    if (!s || s.status !== 1) throw new Error('不在 Flap 内盘（可能已上 DEX，请用自动识别走外盘）');
    const meta = await tokenMeta(token);
    const slip = BigInt(slippageBps);
    const checks = [{ name: 'Flap 状态', ok: true, detail: STATUS[s.status] }];
    const warnings = ['Flap 税币：买卖都按代币设置的税率扣税（报价已含）'];
    if (s.gate) {
      // 两种 Agent ID 模式：门槛是币安 Agent ID（0x60B9…022F），或发币人指定的其它 ERC-721 合集（如 0xB29F…308F）
      const has = (await rd(s.gate, erc20Abi, 'balanceOf', [wallet])) > 0n;
      const label = gateLabel(s.gate);
      checks.push({ name: `门槛：${label}（按 tx.origin）`, ok: has, detail: has ? '持有' : '没有' });
      if (!has) throw new Error(`这个代币只允许持有 ${label} 的钱包在内盘买卖，当前钱包没有，会被拒绝（NFTGatedOnly）${lc(s.gate) === lc(BINANCE_AGENT_ID) ? '' : '：注意它要的不是币安 Agent ID，而是另一个 NFT 合集'}`);
    }
    if (side === 'buy') {
      const amountIn = parseUnitsStrict(amount, 18);
      const q = await quote(ZERO, token, amountIn);
      // 以钱包身份模拟真实成交（含门槛与 2% 上限截断）；拿不到就退回报价
      const simData = encodeFunctionData({ abi: portalAbi, functionName: 'swapExactInput', args: [{ inputToken: ZERO, outputToken: token, inputAmount: amountIn, minOutputAmount: 0n, permitData: '0x' }] });
      let out = q;
      const sim = await simulateCall({ from: wallet, to: FLAP_PORTAL, data: simData, value: amountIn });
      if (sim.ok) out = decodeFunctionResult({ abi: portalAbi, functionName: 'swapExactInput', data: sim.raw });
      else {
        const why = gateError(sim, s.gate);
        if (why) throw new Error(`买入模拟失败：${why}`);
        warnings.push(`钱包身份模拟失败（${sim.reason.slice(0, 80)}），按报价算；以币安预览为准`);
      }
      if (out <= 0n) throw new Error('算出的可买数量为 0（可能已达 2% 上限）');
      if (out < q) warnings.push('触及每地址 2% 上限：只能买到一部分，多付的 BNB 合约退回');
      const minOut = (out * (10000n - slip)) / 10000n;
      const tx = { chainId: '56', to: FLAP_PORTAL, value: amountIn.toString(), inputData: encodeFunctionData({ abi: portalAbi, functionName: 'swapExactInput', args: [{ inputToken: ZERO, outputToken: token, inputAmount: amountIn, minOutputAmount: minOut, permitData: '0x' }] }) };
      assertFlapSwapTx(tx, { token, side: 'buy', amount: amountIn, minOut });
      return {
        platform: 'flaptax', side, token, symbol: meta.symbol, decimals: 18,
        pay: { raw: amountIn.toString(), text: `${amount} BNB` },
        bnbEquivWei: '0',
        receive: { expected: pretty(out), min: pretty(minOut), minRaw: minOut.toString(), symbol: meta.symbol },
        route: 'Flap Portal.swapExactInput（BNB → 代币，一笔完成）', checks, warnings, note: null,
        steps: [{ kind: 'buy', label: `买入 ${meta.symbol}（Flap 内盘）`, tx }],
      };
    }
    // 卖出：数量按比例或指定数量；授权不够时先只授权本次数量
    const bal = await rd(token, erc20Abi, 'balanceOf', [wallet]);
    let amountIn = percent ? (bal * BigInt(Math.round(Number(percent) * 100))) / 10000n : parseUnitsStrict(amount, meta.decimals ?? 18);
    if (amountIn > bal) amountIn = bal;
    if (amountIn <= 0n) throw new Error('该钱包没有这个代币');
    const q = await quote(token, ZERO, amountIn);
    if (q <= 0n) throw new Error('报价为 0');
    const allowance = await rd(token, erc20Abi, 'allowance', [wallet, FLAP_PORTAL]);
    // quoteExactInput 不检查 Agent ID 门槛：以钱包身份模拟真实卖出（门槛、税都算在内）。
    // 授权不够时用状态覆盖临时授权本次数量；找不到授权存储位置的非常规代币退回报价
    const override = allowance < amountIn ? await allowanceOverride(token, wallet, FLAP_PORTAL, amountIn).catch(() => null) : null;
    let out = q;
    if (allowance >= amountIn || override) {
      const simData = encodeFunctionData({ abi: portalAbi, functionName: 'swapExactInput', args: [{ inputToken: token, outputToken: ZERO, inputAmount: amountIn, minOutputAmount: 0n, permitData: '0x' }] });
      const sim = await simulateCall({ from: wallet, to: FLAP_PORTAL, data: simData, override });
      if (!sim.ok) throw new Error(`卖出模拟失败：${gateError(sim, s.gate) || sim.reason}`);
      out = decodeFunctionResult({ abi: portalAbi, functionName: 'swapExactInput', data: sim.raw });
      checks.push({ name: '钱包身份模拟', ok: true, detail: `到手 ${pretty(out)} BNB${out < q ? `（比报价少 ${((Number(q - out) / Number(q)) * 100).toFixed(2)}%）` : ''}` });
    } else {
      warnings.push('没法在授权前模拟这个代币的卖出：最少收到按 Portal 报价算');
    }
    if (out <= 0n) throw new Error('模拟到手为 0');
    const minOut = (out * (10000n - slip)) / 10000n;
    const steps = [];
    if (allowance < amountIn) {
      steps.push({ kind: 'approve', label: `授权 ${pretty(amountIn)} ${meta.symbol} → Flap Portal（只授权本次数量）`, tx: { chainId: '56', to: token, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [FLAP_PORTAL, amountIn] }) } });
    }
    const tx = { chainId: '56', to: FLAP_PORTAL, value: '0', inputData: encodeFunctionData({ abi: portalAbi, functionName: 'swapExactInput', args: [{ inputToken: token, outputToken: ZERO, inputAmount: amountIn, minOutputAmount: minOut, permitData: '0x' }] }) };
    assertFlapSwapTx(tx, { token, side: 'sell', amount: amountIn, minOut });
    steps.push({ kind: 'sell', label: `卖出 ${pretty(amountIn)} ${meta.symbol}（Flap 内盘 → BNB）`, tx });
    return {
      platform: 'flaptax', side, token, symbol: meta.symbol, decimals: 18,
      pay: { raw: amountIn.toString(), text: `${pretty(amountIn)} ${meta.symbol}${percent ? `（${percent}%）` : ''}` },
      receive: { expected: pretty(out), min: pretty(minOut), minRaw: minOut.toString(), symbol: 'BNB' },
      route: 'Flap Portal.swapExactInput（代币 → BNB）', checks, warnings,
      note: steps.length > 1 ? '需要按顺序执行 2 笔（先授权本次数量，再卖出）' : null,
      steps,
    };
  },
};
