// gang.fun LaunchpadV3（税收接收地址代币）：只在「已启用且链上核验通过」时参与识别；毕业后交给外盘路由。
import { activeDeployment, curveOf, mainnetCtx, planV3Buy, planV3Sell, taxNotes } from '../gangv3.mjs';
import { tokenMeta, WBNB } from '../router.mjs';

export default {
  id: 'gangv3',
  label: 'gang.fun V3 曲线（税收币 · 未审计）',
  addressKind: 'token',
  /** 归属缓存的平台签名：启用 / 停用 / 换部署地址时，之前的识别结果全部作废（registry.mjs platformSig） */
  async epoch() {
    const dep = await activeDeployment();
    return dep ? String(dep.pad).toLowerCase() : 'off';
  },
  async detect(address) {
    const dep = await activeDeployment();
    if (!dep) return null; // 未启用 / 核验未通过：完全不参与
    const c = await curveOf(mainnetCtx, dep.pad, address);
    if (!c) return null;
    const isWbnb = c.quote.toLowerCase() === WBNB.toLowerCase();
    const q = isWbnb ? { symbol: 'BNB' } : await tokenMeta(c.quote).catch(() => ({ symbol: '?' }));
    return {
      match: true,
      tradable: !c.graduated,
      phase: c.graduated ? '已毕业（PancakeSwap V2）' : '曲线中',
      payUnit: 'BNB',
      graduated: c.graduated,
      extras: [c.quote],
      quoteSymbol: q.symbol,
      notes: [
        ...taxNotes(c, { recipient: null }).slice(0, 1),
        isWbnb ? '买入经 GangRouter 用 BNB 一笔完成' : `报价币 ${q.symbol}：买入需换币 → 授权 → 买入多笔`,
        ...(c.graduated ? ['已毕业，改走外盘路由'] : []),
      ],
    };
  },
  async plan({ wallet, address, side, amount, percent, slippageBps, maxImpactBps, maxLossBps }) {
    const dep = await activeDeployment();
    if (!dep) throw new Error('gang V3 未启用或链上核验未通过');
    return side === 'buy'
      ? planV3Buy({ dep, wallet, token: address, amount, slippageBps, maxImpactBps, maxLossBps })
      : planV3Sell({ dep, wallet, token: address, amount, percent, slippageBps });
  },
};
