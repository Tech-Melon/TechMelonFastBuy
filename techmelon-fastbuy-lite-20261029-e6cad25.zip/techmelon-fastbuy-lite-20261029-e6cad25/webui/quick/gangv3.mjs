/**
 * gang.fun LaunchpadV3（税收接收地址代币）+ GangRouter 接入。
 *
 * 安全原则（V3 未经外部审计，见 docs/quick-trade.md「gang V3」）：
 * 1. 默认关闭。只交互「已启用」的合约地址；地址来自官方渠道或手填，必须先通过链上核验，再由用户确认启用。
 * 2. 核验不过 / 启用后链上状态变了（路由被移出白名单、准入被关等）→ 立即视为未启用，拒绝生成交易。
 * 3. 代币归属只看 pad.curves(token) 是否登记（代币自报的 launchpad() 不可信）。
 * 4. 每笔交易以钱包身份 eth_call 模拟拿真实到手量，再按滑点算下限；广播前解码 calldata 复核。
 * 5. 未审计合约单笔买入上限（QUICK_GANG_V3_MAX_BNB，默认 0.1 BNB）；授权只给本次数量。
 * 6. 发现新地址：核验通过后交给 discovery.mjs 判断「可信」（官方 GitHub 一致，或 owner = 官方 V2 多签 + 两步转移
 *    + 接线交易由官方地址发起），可信才自动启用；否则只提示，由用户核对后手动启用。
 */
import {
  encodeFunctionData, decodeFunctionResult, decodeFunctionData, decodeErrorResult, parseAbi, getAddress, toHex, toEventSelector,
} from 'viem';
import { rpcFor, getConfig, saveConfig, chainWssUrl, runBackground } from '../config.mjs';
import { hubSubscribe, onHubReconnect, hubConnected, hubStatus } from '../wsshub.mjs';
import { routeSwap, tokenMeta, pretty, human, WBNB } from './router.mjs';
import { journal } from '../journal.mjs';
import { allowanceOverride } from './simoverride.mjs';

export const MAINNET_EXPECT = {
  chainId: '56',
  wbnb: WBNB,
  agentId: '0x60B9262456dE011F7d15a54CdD8c48bAaa8B022F', // SPACE ID Agent ID（V2 / Four / Flap 同一个）
};

/** 未审计合约的单笔买入上限（BNB） */
export const MAX_BUY_WEI = (() => {
  const s = String(process.env.QUICK_GANG_V3_MAX_BNB || '0.1');
  if (!/^\d+(\.\d+)?$/.test(s)) return 10n ** 17n;
  const [w, f = ''] = s.split('.');
  return BigInt(w) * 10n ** 18n + BigInt((f + '0'.repeat(18)).slice(0, 18));
})();

const MAX_IMPACT_BPS = 1000;
const VERIFY_TTL_MS = 10 * 60 * 1000;
const DEADLINE_SEC = 600;
const ZERO = /^0x0{40}$/i;
const lc = (a) => String(a).toLowerCase();

export const padAbi = parseAbi([
  'function curves(address token) view returns (address creator, address quote, uint128 realQuote, uint128 sold, uint128 gradAmt, uint128 virtualQuote, bool graduated, uint16 buyTaxBps, uint16 sellTaxBps, uint16 dividendBps, address pair, address refPair)',
  'function taxConfigOf(address token) view returns (uint16 buyTaxBps, uint16 sellTaxBps, uint16 dividendBps, address recipient)',
  'function isAgent(address account) view returns (bool)',
  'function walletRoom(address token, address buyer) view returns (uint256)',
  'function graduationRemaining(address token) view returns (uint256)',
  'function routers(address router) view returns (bool)',
  'function agentGateEnabled() view returns (bool)',
  'function walletCapEnabled() view returns (bool)',
  'function agentIdRegistry() view returns (address)',
  'function migrator() view returns (address)',
  'function wbnb() view returns (address)',
  'function owner() view returns (address)',
  'function recipientRegistry() view returns (address)',
  'function PROTOCOL_FEE_BPS() view returns (uint256)',
  'function PLATFORM_TAX_BPS() view returns (uint256)',
  'function MAX_PER_WALLET() view returns (uint256)',
  'function TARGET_GRAD_BNB() view returns (uint256)',
  'function MIN_TAX_BPS() view returns (uint16)',
  'function MAX_TAX_BPS() view returns (uint16)',
  'function TOTAL_SUPPLY() view returns (uint256)',
  'function buy(address token, uint256 quoteIn, uint256 minTokensOut) returns (uint256)',
  'function sell(address token, uint256 tokensIn, uint256 minQuoteOut) returns (uint256)',
  'error UnknownToken()', 'error AlreadyGraduated()', 'error ZeroAmount()', 'error Slippage()', 'error NotAgent()',
  'error WalletCapReached()', 'error OnlyRouter()', 'error RouterNeedsGate()', 'error QuoteNotAllowed()', 'error MigratorNotSet()',
]);
export const gangRouterAbi = parseAbi([
  'function v3() view returns (address)',
  'function wbnb() view returns (address)',
  'function v3BuyBNB(address token, uint256 minTokensOut, uint256 deadline) payable returns (uint256)',
  'error Expired()', 'error NotDeployed()', 'error UnknownToken()', 'error NotWbnbQuote()', 'error NotEnoughValue()',
]);
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
]);
const wbnbAbi = parseAbi(['function withdraw(uint256 wad)']);
const registryAbi = parseAbi(['function entries(address) view returns (bool listed, uint64 listedAt, string label)']);
const ALL_ERRORS = [...padAbi, ...gangRouterAbi].filter((x) => x.type === 'error');

// ---------------------------------------------------------------- 链访问

/** 主网 ctx；eval 可传入自定义 call（测试网） */
export const mainnetCtx = { ...MAINNET_EXPECT, call: (method, params) => rpcFor('56', method, params) };

async function rd(ctx, to, abi, functionName, args = []) {
  const raw = await ctx.call('eth_call', [{ to, data: encodeFunctionData({ abi, functionName, args }) }, 'latest']);
  return decodeFunctionResult({ abi, functionName, data: raw });
}

/** revert 原因：优先按 pad / router 的自定义错误解码 */
function revertReason(err) {
  const data = typeof err?.data === 'string' ? err.data : err?.data?.data;
  if (typeof data === 'string' && /^0x[0-9a-fA-F]{8}/.test(data)) {
    try { return decodeErrorResult({ abi: ALL_ERRORS, data }).errorName; } catch { /* 非自定义错误 */ }
  }
  return String(err?.message || 'execution reverted').replace(/:\s*0x[0-9a-fA-F]*$/, '').slice(0, 160);
}

async function simulate(ctx, { from, to, data, value = 0n, overrideBalance = false, override = null }) {
  const params = [{ from, to, data, value: toHex(value) }, 'latest'];
  // override：状态覆盖（如授权前模拟卖出用的临时授权）；可与余额覆盖合并
  const ov = { ...(override || {}), ...(overrideBalance ? { [from]: { balance: toHex(value + 10n ** 18n) } } : {}) };
  if (Object.keys(ov).length) params.push(ov);
  try {
    return { ok: true, raw: await ctx.call('eth_call', params) };
  } catch (err) {
    return { ok: false, reason: revertReason(err) };
  }
}

// ---------------------------------------------------------------- 部署核验

/**
 * 链上核验一套 V3 部署。fatal 项任一不通过 → ok=false（不能启用 / 交易）。
 * 只用链上事实判断，不信任任何来源给的「说明」。
 */
export async function verifyDeployment(ctx, { pad, router }) {
  const checks = [];
  const add = (name, ok, detail, fatal = true) => checks.push({ name, ok: Boolean(ok), detail: String(detail ?? ''), fatal });
  const safe = (p) => p.then((v) => ({ v }), (e) => ({ e: e.shortMessage || e.message }));
  pad = getAddress(pad);
  router = getAddress(router);
  const [padCode, routerCode] = await Promise.all([ctx.call('eth_getCode', [pad, 'latest']), ctx.call('eth_getCode', [router, 'latest'])]);
  add('LaunchpadV3 有合约代码', padCode && padCode !== '0x', pad);
  add('GangRouter 有合约代码', routerCode && routerCode !== '0x', router);
  if (!padCode || padCode === '0x' || !routerCode || routerCode === '0x') return { ok: false, checks, pad, router };

  const names = ['PROTOCOL_FEE_BPS', 'PLATFORM_TAX_BPS', 'MAX_PER_WALLET', 'TARGET_GRAD_BNB', 'MIN_TAX_BPS', 'MAX_TAX_BPS', 'TOTAL_SUPPLY',
    'wbnb', 'agentGateEnabled', 'walletCapEnabled', 'agentIdRegistry', 'migrator', 'owner'];
  const vals = await Promise.all(names.map((n) => safe(rd(ctx, pad, padAbi, n))));
  const v = Object.fromEntries(names.map((n, i) => [n, vals[i]]));
  const eq = (n, want, label) => add(label, v[n].v != null && BigInt(v[n].v) === BigInt(want), v[n].e || String(v[n].v));
  eq('PROTOCOL_FEE_BPS', 100n, '内盘手续费 = 1%');
  eq('PLATFORM_TAX_BPS', 50n, '平台抽成 = 成交额 0.5%');
  eq('MAX_PER_WALLET', 10n ** 25n, '单地址上限 = 1000 万枚（1%）');
  eq('TOTAL_SUPPLY', 10n ** 27n, '总量 = 10 亿枚');
  eq('TARGET_GRAD_BNB', 15n * 10n ** 18n, '毕业线 = 15 BNB');
  eq('MIN_TAX_BPS', 100n, '税率下限 = 1%');
  eq('MAX_TAX_BPS', 500n, '税率上限 = 5%');
  add('wbnb() = 官方 WBNB', v.wbnb.v && lc(v.wbnb.v) === lc(ctx.wbnb), v.wbnb.e || v.wbnb.v);
  add('Agent 准入开启', v.agentGateEnabled.v === true, v.agentGateEnabled.e || v.agentGateEnabled.v);
  add('准入用官方 Agent ID 合约', v.agentIdRegistry.v && lc(v.agentIdRegistry.v) === lc(ctx.agentId), v.agentIdRegistry.e || v.agentIdRegistry.v);
  add('1% 持仓上限开启', v.walletCapEnabled.v === true, v.walletCapEnabled.e || v.walletCapEnabled.v);
  add('migrator 已接好（能毕业）', v.migrator.v && !ZERO.test(v.migrator.v), v.migrator.e || v.migrator.v);

  const [listed, rV3, rWbnb] = await Promise.all([
    safe(rd(ctx, pad, padAbi, 'routers', [router])),
    safe(rd(ctx, router, gangRouterAbi, 'v3')),
    safe(rd(ctx, router, gangRouterAbi, 'wbnb')),
  ]);
  add('路由在 V3 白名单内（routers）', listed.v === true, listed.e || listed.v);
  add('路由指向这个 V3（router.v3()）', rV3.v && lc(rV3.v) === lc(pad), rV3.e || rV3.v);
  add('路由的 WBNB 正确', rWbnb.v && lc(rWbnb.v) === lc(ctx.wbnb), rWbnb.e || rWbnb.v);

  // owner 能冻结内盘（审计说明 §4.2）：多签（合约）才算可接受，普通钱包只警告
  let ownerIsContract = null;
  if (v.owner.v) {
    const code = await ctx.call('eth_getCode', [v.owner.v, 'latest']).catch(() => null);
    ownerIsContract = Boolean(code && code !== '0x');
  }
  add('owner 是合约（多签）', ownerIsContract === true, `${v.owner.v || v.owner.e}${ownerIsContract === false ? '（普通钱包：可单方面冻结内盘）' : ''}`, false);

  return { ok: checks.every((c) => c.ok || !c.fatal), checks, pad, router, owner: v.owner.v || null, ownerIsContract };
}

// ---------------------------------------------------------------- 启用状态（config.json: gangV3）

let verified = null; // { pad, router, at, result }

/*
 * 内置的官方主网部署（2026-10-29 用户确认固定）：LaunchpadV3 + GangRouter。
 * 2026-10-28 由 owner = 官方多签、接线交易由官方地址发起判定可信，服务器与本机启用的都是这一组。
 * config.json 没有 gangV3 时默认用它（轻量版没有发射台页面，也能直接交易 V3 币）；
 * 用户在发射台手动停用（enabled=false）则尊重停用；手动启用了别的地址则用配置里的。
 * 内置地址同样每 10 分钟链上复核一次，复核不过（停用 / 换路由 / 常量变了）就不参与交易。
 */
export const BUILTIN_V3 = Object.freeze({
  pad: '0x15CFD2dc8278Fb87a1783ef42111618E20874365',
  router: '0xE040445690Aa56C8b68B7f7038C7b2562B5079C4',
  source: 'builtin:官方主网部署（2026-10-28 核验可信，2026-10-29 固定）',
});

/** 当前生效的部署配置（不含核验）：配置里启用的 > 内置；手动停用返回 null */
export async function v3Config() {
  const cfg = (await getConfig()).gangV3;
  if (cfg?.enabled && cfg.pad && cfg.router) return cfg;
  if (cfg && cfg.enabled === false) return null;
  return { enabled: true, ...BUILTIN_V3 };
}

/** 已启用且当前核验通过的部署；否则 null（附原因） */
export async function activeDeployment() {
  const cfg = await v3Config();
  if (!cfg) return null;
  const fresh = verified && verified.pad === cfg.pad && verified.router === cfg.router && Date.now() - verified.at < VERIFY_TTL_MS;
  if (!fresh) {
    try {
      // 复核是只读、非即时的：走公共节点（runBackground），不消耗付费节点积分
      verified = { pad: cfg.pad, router: cfg.router, at: Date.now(), result: await runBackground(() => verifyDeployment(mainnetCtx, cfg), 'gang V3 部署复核') };
    } catch (err) {
      // RPC 出错：不在没核验的状态下放行
      verified = { pad: cfg.pad, router: cfg.router, at: Date.now() - VERIFY_TTL_MS + 30000, result: { ok: false, checks: [{ name: '核验 RPC', ok: false, detail: err.message, fatal: true }] } };
    }
  }
  return verified.result.ok ? { pad: cfg.pad, router: cfg.router } : null;
}

/** 最近一次核验没通过，是不是只因为 RPC 出错（而不是部署本身有问题） */
export function lastVerifyRpcError() {
  const c = verified?.result?.checks;
  return Boolean(verified && !verified.result.ok && c?.length === 1 && c[0].name === '核验 RPC');
}

export async function gangV3Status() {
  const cfg = await v3Config();
  await activeDeployment().catch(() => null);
  const d = await discoveryCfg();
  return {
    // 部署发现关闭时（V3 已上线、已启用后的常态）不再下发候选：旧候选会把人引向别的路由
    discovery: { v3: d.v3, chainWatch: chainWatchActive() },
    enabled: Boolean(cfg?.enabled),
    config: cfg ? { pad: cfg.pad, router: cfg.router, source: cfg.source, enabledAt: cfg.enabledAt } : null,
    live: cfg?.enabled && verified?.pad === cfg.pad ? verified.result : null,
    candidate: watcher.candidate,
    chainCandidates: d.v3 ? [...chain.candidates.values()].map(publicChainCandidate) : [],
    watch: { lastCheck: watcher.lastCheck, lastError: watcher.lastError, apiConfigured: watcher.apiConfigured },
    wss: { ...hubStatus(), ...(chain.error ? { detail: chain.error } : {}), lastBlock: chain.lastBlock },
    alerts: alerts.list,
    alertSeq: alerts.seq,
    maxBuyBnb: human(MAX_BUY_WEI),
  };
}

/** 地址是否与官方来源（GitHub 上官方 CLI 的主网配置）一致 */
function isOfficial(pad, router) {
  const c = watcher.candidate;
  return Boolean(c && lc(c.pad) === lc(pad) && lc(c.router) === lc(router));
}

/**
 * 启用：服务端重新核验（不信前端传来的核验结果），通过才写配置。
 * 地址与官方来源一致 → source=official；否则必须 attest=true（用户声明已从官方渠道核对，
 * 因为开源合约可以被原样仿冒部署，链上核验无法区分官方与仿冒）。
 */
export async function enableGangV3({ pad, router, attest, source: autoSource }) {
  const result = await verifyDeployment(mainnetCtx, { pad, router });
  if (!result.ok) {
    const bad = result.checks.filter((c) => !c.ok && c.fatal).map((c) => c.name).join('、');
    throw new Error(`核验未通过，不能启用：${bad}`);
  }
  const official = isOfficial(result.pad, result.router);
  if (!official && attest !== true) {
    throw new Error('地址与官方来源（gangfun/gang-launchpad 主网配置）不一致或官方尚未公布：链上核验无法区分仿冒部署。请从 gang.fun 官方渠道核对后，在确认框里勾选声明再启用');
  }
  const source = official ? 'official:github gangfun/gang-launchpad' : (autoSource || 'manual（用户声明已从官方渠道核对）');
  await saveConfig({ gangV3: { enabled: true, pad: result.pad, router: result.router, source, enabledAt: new Date().toISOString() } });
  verified = { pad: result.pad, router: result.router, at: Date.now(), result };
  return gangV3Status();
}

export async function disableGangV3() {
  // 停用时把当前生效的那组地址一起记下（内置部署时配置里原本没有 pad）：
  // 「新部署发现」靠 pad 判断「这套地址被停用过，不再自动启用」，不记地址会把内置部署又自动启用回来
  const cur = (await getConfig()).gangV3 || (await v3Config()) || {};
  await saveConfig({ gangV3: { ...cur, pad: cur.pad || BUILTIN_V3.pad, router: cur.router || BUILTIN_V3.router, enabled: false, disabledAt: new Date().toISOString() } });
  verified = null;
  return gangV3Status();
}

// ---------------------------------------------------------------- 主网地址监控（只读、只提示）

const watcher = { candidate: null, lastCheck: null, lastError: null, apiConfigured: null, timer: null };
const WATCH_MS = 10 * 60 * 1000;
const SOURCE_V3JS = 'https://raw.githubusercontent.com/gangfun/gang-launchpad/main/skill/gang-cli/src/v3.js';

/** 从官方 CLI 源码的 mainnet 配置里取地址（外部内容只当数据：只提取地址，之后一律链上核验） */
export function parseMainnetAddresses(src) {
  const block = String(src).match(/mainnet:\s*\{([\s\S]*?)\n\s*\},/);
  if (!block) return null;
  const pick = (key) => (block[1].match(new RegExp(`${key}:\\s*process\\.env\\.[A-Z0-9_]+\\s*\\|\\|\\s*'(0x[0-9a-fA-F]{40})'`)) || [])[1] || null;
  const pad = pick('pad');
  const router = pick('router');
  return pad && router ? { pad: getAddress(pad), router: getAddress(router) } : null;
}

async function fetchText(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(10000), headers: { 'user-agent': 'walletui-gangv3-watch' } });
  if (!res.ok) throw new Error(`${url} HTTP ${res.status}`);
  return res.text();
}

export async function checkForMainnet({ force = false } = {}) {
  if (!force && !(await discoveryCfg()).v3) return; // V3 发现已暂停（设置页 / config.discovery.v3）
  watcher.lastCheck = new Date().toISOString();
  try {
    const api = await fetchText('https://gang.fun/api/v3/tokens?status=all&limit=1').catch(() => '');
    watcher.apiConfigured = api ? !/not configured/i.test(api) : null;
    const found = parseMainnetAddresses(await fetchText(SOURCE_V3JS));
    watcher.lastError = null;
    if (!found) { watcher.candidate = null; return; }
    const cfg = (await getConfig()).gangV3;
    if (cfg?.enabled && lc(cfg.pad) === lc(found.pad) && lc(cfg.router) === lc(found.router)) { watcher.candidate = null; return; }
    const result = await verifyDeployment(mainnetCtx, found);
    const isNew = !watcher.candidate || lc(watcher.candidate.pad) !== lc(found.pad) || lc(watcher.candidate.router) !== lc(found.router);
    watcher.candidate = { ...found, source: 'github:gangfun/gang-launchpad skill/gang-cli/src/v3.js', foundAt: watcher.lastCheck, result };
    if (isNew) {
      pushAlert('official', `官方仓库公布了 gang V3 主网地址：pad ${found.pad}，核验${result.ok ? '通过' : '未通过'}`, found);
      journal('discovery.v3.found', { via: 'github', pad: found.pad, router: found.router, ok: result.ok });
    }
    if (result.ok) emitCandidate('v3', { pad: found.pad, router: found.router, official: true, via: 'github' });
  } catch (err) {
    watcher.lastError = err.message;
  }
}

export function startGangV3Watcher() {
  if (watcher.timer) return;
  // 监控 / 补查 / 核验都是后台任务：低优先级，不和交易抢 RPC 额度
  setTimeout(() => { runBackground(() => checkForMainnet(), 'gang V3 官方地址检查'); }, 8000).unref?.();
  watcher.timer = setInterval(() => { runBackground(() => checkForMainnet(), 'gang V3 官方地址检查'); }, WATCH_MS);
  watcher.timer.unref?.();
  setTimeout(() => { runBackground(() => syncChainWatch(), '新部署发现').catch((err) => { chain.error = err.message; }); }, 5000).unref?.();
}

// ---------------------------------------------------------------- 发现开关（config.discovery）
/*
 * v3 / fair：要不要找新部署（GitHub 轮询 + 链上 WSS 订阅）。两项都关时退订那条不限地址的 WSS 订阅、不再补查。
 * autoEnable：发现的部署「可信」时自动启用（规则见 discovery.mjs）；trustedSenders：官方部署 / 接线地址名单。
 */
export const DISCOVERY_DEFAULTS = { v3: true, fair: true, autoEnable: true, trustedSenders: ['0x4EEdcDF5fab775e10C0D09951b6F59Ab81ba19d3'] };
export async function discoveryCfg() {
  const d = (await getConfig()).discovery || {};
  return {
    v3: d.v3 !== false, fair: d.fair !== false, autoEnable: d.autoEnable !== false,
    trustedSenders: Array.isArray(d.trustedSenders) ? d.trustedSenders : DISCOVERY_DEFAULTS.trustedSenders,
  };
}

/** 发现到「核验通过」的部署时回调（discovery.mjs 注册：判断可信 → 自动启用）。kind = 'v3' | 'fair' */
let candidateHook = null;
export function setCandidateHook(fn) { candidateHook = fn; }
export function emitCandidate(kind, cand) {
  if (!candidateHook) return;
  Promise.resolve().then(() => candidateHook(kind, cand)).catch((err) => console.error(`[discovery] ${kind} ${cand.pad}：${err.message}`));
}

export const chainWatchActive = () => chain.unsubs.length > 0;

/** 按开关挂上 / 退订链上发现订阅（启动时、设置页改开关后调用） */
export async function syncChainWatch() {
  const d = await discoveryCfg();
  const want = d.v3 || d.fair;
  if (want && !chain.unsubs.length) await startChainWatch();
  else if (!want && chain.unsubs.length) {
    for (const u of chain.unsubs) u();
    chain.unsubs = [];
    chain.ws = null;
  }
  return { subscribed: chain.unsubs.length > 0, ...d };
}

// ---------------------------------------------------------------- 告警（网页端铃声提醒）

const alerts = { seq: 0, list: [] };

/** 打新模块（fairmint.mjs）共用同一条提醒通道：网页顶部横幅 + 铃声 */
export const pushGangAlert = (level, text, extra = {}) => pushAlert(level, text, extra);

/*
 * 链上发现的兜底识别：打新核心（FairMintPad）也发 RouterSet / MigratorSet / AgentGateUpdated（签名相同），
 * 但读不出 V3 特征常量。不是 V3 时交给打新模块判断，命中就不再记为「已排除」。
 */
let watchFallback = null;
export function setWatchFallback(fn) { watchFallback = fn; }

function pushAlert(level, text, extra = {}) {
  alerts.seq += 1;
  alerts.list.unshift({ seq: alerts.seq, at: new Date().toISOString(), level, text, ...extra });
  alerts.list = alerts.list.slice(0, 20);
  console.log(`[gang-v3] 提醒 #${alerts.seq}：${text}`);
}

// ---------------------------------------------------------------- 链上发现（QuickNode WSS 订阅）
/*
 * 主网地址未知，按事件签名订阅（不限地址）：V3 部署接线 / 首个代币创建时必然发出这些事件，
 * 实测主网此前 9000 块内 0 条，几乎无误报。链上发现只代表「有人部署了一套 V3 代码」，
 * 开源合约可被原样仿冒部署，所以这里只提示，不提供「直接启用」：启用规则见 enableGangV3。
 */
export const WATCH_TOPICS = {
  RouterSet: toEventSelector('RouterSet(address,bool)'),
  MigratorSet: toEventSelector('MigratorSet(address)'),
  AgentGateUpdated: toEventSelector('AgentGateUpdated(bool,address)'),
  TaxConfigured: toEventSelector('TaxConfigured(address,uint16,uint16,uint16,address)'),
};
const TOPIC_NAME = Object.fromEntries(Object.entries(WATCH_TOPICS).map(([k, v]) => [v, k]));
const BACKFILL_BLOCKS = 28800; // 约 6 小时（0.75s 出块）：服务重启期间的部署也能补到
const LOG_CHUNK = 2000;
const MAX_CHAIN_CANDIDATES = 20;

const chain = { ws: null, unsubs: [], status: { state: 'idle', detail: '' }, lastBlock: 0, candidates: new Map(), seenLogs: new Set(), timers: new Map(), rejected: new Set() };

function publicChainCandidate(c) {
  return {
    pad: c.pad, router: c.router, otherRouters: c.otherRouters || [], firstSeen: c.firstSeen, firstBlock: c.firstBlock, sender: c.sender, owner: c.owner,
    events: c.events.slice(-8), result: c.result, official: c.router ? isOfficial(c.pad, c.router) : false,
  };
}

/**
 * 在同一条 WSS 连接上追加一个 logs 订阅（打新自动打新用；断线重连后 WsRpc 自动恢复订阅）。
 * 没配 WSS / 连接还没建立时返回 null，调用方改用 HTTP 轮询。返回取消订阅函数。
 */
export async function subscribeChainLogs(filter, handler, label = '') {
  if (!chainWssUrl(56, await getConfig())) return null;
  return hubSubscribe(['logs', filter], handler, label);
}
export const chainWsConnected = () => hubConnected();

async function startChainWatch() {
  // 全项目共享一条 WSS 连接（wsshub）：没配置时也先登记订阅，之后在设置页填了节点会自动连上
  chain.ws = true;
  chain.unsubs.push(await hubSubscribe(['logs', { topics: [Object.values(WATCH_TOPICS)] }], (log) => {
    runBackground(() => onWatchLog(log), '新部署发现').catch((err) => { chain.error = `处理日志失败：${err.message}`; });
  }, '发现 gang 新部署（V3 / 打新接线事件，不限地址）'));
  // 每次（重新）连上后用 HTTP 补查断线期间的日志
  chain.unsubs.push(onHubReconnect(() => { runBackground(() => backfill(chain.lastBlock ? chain.lastBlock - 5 : null), '新部署发现：补查').catch(() => {}); }));
}

async function backfill(fromBlock) {
  const latest = Number(await rpcFor('56', 'eth_blockNumber', []));
  const start = Math.max(fromBlock ?? latest - BACKFILL_BLOCKS, latest - BACKFILL_BLOCKS);
  for (let from = start; from <= latest; from += LOG_CHUNK) {
    const to = Math.min(from + LOG_CHUNK - 1, latest);
    const logs = await rpcFor('56', 'eth_getLogs', [{ fromBlock: toHex(from), toBlock: toHex(to), topics: [Object.values(WATCH_TOPICS)] }]);
    for (const log of logs) await onWatchLog(log);
  }
  chain.lastBlock = Math.max(chain.lastBlock, latest);
}

/** 评测用：直接喂一条日志（与 WSS 推送 / 补查走同一处理）；skipPrecheck 只给离线评测用 */
export const ingestWatchLog = (log, opts) => onWatchLog(log, opts);

/** 预检：V3 pad 的几个特征常量（平台抽成 0.5%、毕业 15 BNB、税率上限 5%） */
async function looksLikeV3(pad) {
  try {
    const [platform, grad, maxTax] = await Promise.all([
      rd(mainnetCtx, pad, padAbi, 'PLATFORM_TAX_BPS'),
      rd(mainnetCtx, pad, padAbi, 'TARGET_GRAD_BNB'),
      rd(mainnetCtx, pad, padAbi, 'MAX_TAX_BPS'),
    ]);
    return BigInt(platform) === 50n && BigInt(grad) === 15n * 10n ** 18n && BigInt(maxTax) === 500n;
  } catch {
    return false;
  }
}

async function onWatchLog(log, opts = {}) {
  if (log.removed) return;
  const key = `${log.transactionHash}:${log.logIndex}`;
  if (chain.seenLogs.has(key)) return;
  chain.seenLogs.add(key);
  const block = Number(BigInt(log.blockNumber));
  chain.lastBlock = Math.max(chain.lastBlock, block);
  const name = TOPIC_NAME[log.topics?.[0]];
  if (!name) return;
  const pad = getAddress(log.address);
  let c = chain.candidates.get(lc(pad));
  if (!c) {
    // 防刷第一层：发事件的合约必须读得出 V3 特征常量，否则不算候选、不提醒（结果缓存，不重复查）
    if (chain.rejected.has(lc(pad))) return;
    const v3On = opts.skipPrecheck || (await discoveryCfg()).v3; // V3 发现暂停时只交给打新判断
    if (!opts.skipPrecheck && (!v3On || !(await looksLikeV3(pad)))) {
      if (watchFallback && await watchFallback(pad, name, log).catch(() => false)) return;
      // 只有真按 V3 特征查过才记「已排除」：V3 发现暂停期间没查过，之后重新打开还要能发现
      if (v3On && chain.rejected.size < 5000) chain.rejected.add(lc(pad));
      return;
    }
    // 防刷第二层：候选数量封顶，超出只记一次提醒（官方地址仍可经 GitHub 轮询发现）
    if (chain.candidates.size >= MAX_CHAIN_CANDIDATES) {
      if (!chain.overflowAlerted) { chain.overflowAlerted = true; pushAlert('chain', `链上同签名事件来源超过 ${MAX_CHAIN_CANDIDATES} 个，疑似刷事件，之后的新来源不再提醒`); }
      return;
    }
    c = { pad, router: null, routers: new Map(), otherRouters: [], firstSeen: new Date().toISOString(), firstBlock: block, sender: null, owner: null, events: [], result: null, alertedOk: false };
    chain.candidates.set(lc(pad), c);
    const tx = await rpcFor('56', 'eth_getTransactionByHash', [log.transactionHash]).catch(() => null);
    c.sender = tx?.from ? getAddress(tx.from) : null;
    pushAlert('chain', `链上发现疑似 gang V3 部署：${pad}（事件 ${name}，区块 ${block}）。未经官方确认，可能是仿冒部署`, { pad });
    journal('discovery.v3.found', { via: 'chain', pad, block, event: name, sender: c.sender });
  }
  c.events.push({ name, block, tx: log.transactionHash });
  // RouterSet(address indexed router, bool enabled)：pad 可以有多个白名单路由（官方后来又加过聚合路由），
  // 全部记下（含每个路由那笔接线交易的发起人：交易签名伪造不了，自动启用要看它），核验时再挑出真正的 GangRouter
  if (name === 'RouterSet' && log.topics[1]) await trackRouterSet(c, log, block);
  scheduleChainVerify(c);
}

/** 维护候选的白名单路由表：enabled=true 加入、false 移除；c.router 先暂取最新一个，核验时由 pickRouter 改正 */
export async function trackRouterSet(c, log, block) {
  const router = getAddress(`0x${log.topics[1].slice(-40)}`);
  // 同一路由以区块更新的那条为准：补查的老日志可能晚于实时日志到达，不能覆盖更新的状态
  const seen = c.routerBlocks || (c.routerBlocks = new Map());
  if ((seen.get(lc(router)) ?? -1) > block) return;
  seen.set(lc(router), block);
  if (BigInt(log.data && log.data !== '0x' ? log.data : '0x0') === 1n) {
    c.routers.set(lc(router), { router, block, sender: await txSender(log.transactionHash) });
  } else {
    c.routers.delete(lc(router));
  }
  const newest = [...c.routers.values()].sort((a, b) => b.block - a.block)[0] || null;
  c.router = newest?.router || null;
  c.routerSender = newest?.sender || null;
}

/**
 * 补查这个 pad 自己的 RouterSet 历史（按地址过滤，约 10 天）：服务重启后全局补查只回看 6 小时，
 * 早期接好的 GangRouter（例如 2026-10 主网的 0xE040…，后面又加了聚合路由）会漏掉。每个候选只成功查一次。
 */
const ROUTER_HISTORY_BLOCKS = 2_000_000;
export async function scanRouterHistory(c) {
  if (c.historyScanned || !c.firstBlock) return;
  const end = c.firstBlock - 1;
  const start = Math.max(0, end - ROUTER_HISTORY_BLOCKS);
  // 按地址的 getLogs：在后台上下文里走公共节点（publicnode 服务器实测 5 万块可行，本机 1 万块），超限自动减半
  let size = 10_000;
  try {
    for (let to = end; to >= start;) {
      const from = Math.max(start, to - size + 1);
      let logs;
      try {
        logs = await rpcFor('56', 'eth_getLogs', [{ address: c.pad, topics: [WATCH_TOPICS.RouterSet], fromBlock: toHex(from), toBlock: toHex(to) }]);
      } catch (err) {
        if (size > LOG_CHUNK) { size = Math.max(LOG_CHUNK, Math.floor(size / 2)); continue; } // 节点限制区块跨度：缩小重试
        throw err;
      }
      for (const l of logs || []) {
        // 个别公共节点会忽略过滤条件：本地再核一次地址与事件
        if (l.removed || lc(l.address) !== lc(c.pad) || l.topics?.[0] !== WATCH_TOPICS.RouterSet || !l.topics[1]) continue;
        await trackRouterSet(c, l, Number(BigInt(l.blockNumber)));
      }
      to = from - 1;
    }
    c.historyScanned = true;
  } catch (err) {
    c.historyError = err.message; // 下次核验再试
  }
}

/**
 * 从候选的白名单路由里挑出指回这个 pad 的那个（isMine 读链上判断，如 router.v3() == pad）；
 * 多个都是时取最新的，都不是时取最新的一个让核验给出原因。其它路由只记录、不参与交易。
 */
export async function pickRouter(c, isMine) {
  const list = [...c.routers.values()].sort((a, b) => b.block - a.block);
  let chosen = null;
  for (const r of list) {
    if (await isMine(r.router).catch(() => false)) { chosen = r; break; }
  }
  chosen ||= list[0] || null;
  c.router = chosen?.router || null;
  c.routerSender = chosen?.sender || null;
  c.otherRouters = list.filter((r) => r !== chosen).map((r) => r.router);
}

/** 交易发起地址（读不到返回 null） */
export async function txSender(hash) {
  const tx = await rpcFor('56', 'eth_getTransactionByHash', [hash]).catch(() => null);
  return tx?.from ? getAddress(tx.from) : null;
}

/** 同一批接线事件常在同一区块：合并 3 秒再核验 */
function scheduleChainVerify(c) {
  clearTimeout(chain.timers.get(c.pad));
  chain.timers.set(c.pad, setTimeout(async () => {
    try {
      c.owner = await rd(mainnetCtx, c.pad, padAbi, 'owner').catch(() => null);
      await scanRouterHistory(c);
      await pickRouter(c, async (r) => lc(await rd(mainnetCtx, r, gangRouterAbi, 'v3')) === lc(c.pad));
      if (!c.router) { c.result = { ok: false, checks: [{ name: '等待 RouterSet（路由接线）', ok: false, detail: '', fatal: true }] }; return; }
      c.result = await verifyDeployment(mainnetCtx, { pad: c.pad, router: c.router });
      if (c.result.ok && !c.alertedOk) {
        c.alertedOk = true;
        const official = isOfficial(c.pad, c.router);
        pushAlert(official ? 'official' : 'chain', `链上 V3 部署 ${c.pad} 接线完成，核验通过${official ? '，且与官方来源一致' : '（未经官方确认：正在按自动启用规则判断是否可信）'}`, { pad: c.pad, router: c.router });
        journal('discovery.v3.verified', { pad: c.pad, router: c.router, routerSender: c.routerSender || null, official });
        emitCandidate('v3', { pad: c.pad, router: c.router, routerSender: c.routerSender || null, official, via: 'chain' });
      }
    } catch (err) {
      c.result = { ok: false, checks: [{ name: '核验 RPC', ok: false, detail: err.message, fatal: true }] };
    }
  }, 3000));
  chain.timers.get(c.pad).unref?.();
}


// ---------------------------------------------------------------- 交易

/** 代币在 V3 上的曲线；未登记返回 null（只看 pad 的登记，不看代币自报） */
export async function curveOf(ctx, pad, token) {
  const c = await rd(ctx, pad, padAbi, 'curves', [token]);
  const [creator, quote, realQuote, sold, gradAmt, virtualQuote, graduated, buyTaxBps, sellTaxBps, dividendBps, pair] = c;
  if (ZERO.test(creator)) return null;
  return { creator, quote, realQuote, sold, gradAmt, virtualQuote, graduated, buyTaxBps: Number(buyTaxBps), sellTaxBps: Number(sellTaxBps), dividendBps: Number(dividendBps), pair };
}

async function recipientOf(ctx, pad, token) {
  const [, , , recipient] = await rd(ctx, pad, padAbi, 'taxConfigOf', [token]);
  if (ZERO.test(recipient)) return { recipient: null, label: null };
  let label = null;
  try {
    const reg = await rd(ctx, pad, padAbi, 'recipientRegistry');
    label = (await rd(ctx, reg, registryAbi, 'entries', [recipient]))[2] || null;
  } catch { /* 读不到名字不影响交易 */ }
  return { recipient, label };
}

const pctText = (bps) => `${(bps / 100).toFixed(2).replace(/\.?0+$/, '')}%`;

export function taxNotes(c, rec) {
  const notes = [
    `买税 ${pctText(c.buyTaxBps)} · 卖税 ${pctText(c.sellTaxBps)}（另收内盘手续费 1%；毕业后外盘仍按此税率收）`,
    `税的分配：平台拿成交额 0.5%，剩余的 ${pctText(c.dividendBps)} 分给持币人${rec.recipient ? `，其余给接收地址 ${rec.label ? `「${rec.label}」` : ''}${rec.recipient}` : ''}`,
    'gang V3 合约尚未经过外部审计；owner 能冻结内盘（冻结期间毕业前无法卖出）',
  ];
  return notes;
}

/** 广播前复核：v3BuyBNB */
export function assertV3BuyTx(tx, { router, token, amountIn, minOut }) {
  if (lc(tx.to) !== lc(router)) throw new Error('目标合约不是已启用的 GangRouter');
  if (BigInt(tx.value) !== amountIn || amountIn <= 0n) throw new Error('交易 value 与买入金额不一致');
  if (amountIn > MAX_BUY_WEI) throw new Error(`超过 gang V3 单笔上限 ${human(MAX_BUY_WEI)} BNB`);
  const d = decodeFunctionData({ abi: gangRouterAbi, data: tx.inputData });
  if (d.functionName !== 'v3BuyBNB') throw new Error('calldata 不是 v3BuyBNB');
  if (lc(d.args[0]) !== lc(token)) throw new Error('calldata 中的代币与计划不一致');
  if (BigInt(d.args[1]) !== minOut || minOut <= 0n) throw new Error('最少到手与计划不一致或为 0');
}

/** 广播前复核：pad.buy / pad.sell */
export function assertV3PadTx(tx, { pad, fn, token, amount, minOut }) {
  if (lc(tx.to) !== lc(pad)) throw new Error('目标合约不是已启用的 LaunchpadV3');
  if (BigInt(tx.value) !== 0n) throw new Error(`${fn} 不应附带 BNB`);
  const d = decodeFunctionData({ abi: padAbi, data: tx.inputData });
  if (d.functionName !== fn) throw new Error(`calldata 不是 ${fn}`);
  if (lc(d.args[0]) !== lc(token)) throw new Error('calldata 中的代币与计划不一致');
  if (BigInt(d.args[1]) !== amount || amount <= 0n) throw new Error('数量与计划不一致');
  if (BigInt(d.args[2]) !== minOut || minOut <= 0n) throw new Error('下限与计划不一致或为 0');
}

/** 广播前复核：只授权给 pad、只授权本次数量 */
export function assertApprove(tx, { token, spender, amount }) {
  if (lc(tx.to) !== lc(token)) throw new Error('approve 目标代币不一致');
  const d = decodeFunctionData({ abi: erc20Abi, data: tx.inputData });
  if (d.functionName !== 'approve' || lc(d.args[0]) !== lc(spender)) throw new Error('approve 对象不是 LaunchpadV3');
  if (BigInt(d.args[1]) !== amount) throw new Error('approve 额度不是本次数量');
  if (BigInt(tx.value) !== 0n) throw new Error('approve 不应附带 BNB');
}

function parseWei(value, decimals = 18) {
  const s = String(value ?? '').trim();
  if (!/^\d+(\.\d+)?$/.test(s) || !/[1-9]/.test(s)) throw new Error('数量需要大于 0 的十进制数');
  const [w, f = ''] = s.split('.');
  if (f.length > decimals) throw new Error(`小数位超过 ${decimals} 位`);
  return BigInt(w) * 10n ** BigInt(decimals) + BigInt((f + '0'.repeat(decimals)).slice(0, decimals) || '0');
}

const impactOf = (small, big, scale) => {
  if (small <= 0n) return null;
  const ideal = small * scale;
  return ideal > big ? Number(((ideal - big) * 10000n) / ideal) : 0;
};

/**
 * 买入（金额单位 BNB）。
 * - WBNB 报价：GangRouter.v3BuyBNB 一笔完成（无需 wrap / 授权），多付部分退回 BNB。
 * - 其它报价币（主网首批只开 USDT）：智能路由换报价币 → 授权本次数量给 pad → pad.buy，按顺序 2~3 笔。
 */
export async function planV3Buy({ ctx = mainnetCtx, dep, wallet, token, amount, slippageBps, maxImpactBps, maxLossBps }) {
  const amountIn = parseWei(amount);
  if (amountIn > MAX_BUY_WEI) throw new Error(`gang V3 未经外部审计，单笔买入上限 ${human(MAX_BUY_WEI)} BNB（可用环境变量 QUICK_GANG_V3_MAX_BNB 调整）`);
  const c = await curveOf(ctx, dep.pad, token);
  if (!c) throw new Error('该代币未在已启用的 LaunchpadV3 登记');
  if (c.graduated) throw new Error('已毕业，改走外盘路由');
  const [agent, room, remaining, rec, meta, balance] = await Promise.all([
    rd(ctx, dep.pad, padAbi, 'isAgent', [wallet]),
    rd(ctx, dep.pad, padAbi, 'walletRoom', [token, wallet]),
    rd(ctx, dep.pad, padAbi, 'graduationRemaining', [token]),
    recipientOf(ctx, dep.pad, token),
    (ctx.tokenMeta || tokenMeta)(token),
    ctx.call('eth_getBalance', [wallet, 'latest']).then(BigInt),
  ]);
  if (!agent) throw new Error('该钱包没有 Agent ID，V3 内盘只允许 Agent 钱包');
  if (room === 0n) throw new Error('该钱包已达 1% 持仓上限');
  const slip = BigInt(slippageBps);
  const checks = [
    { name: 'Agent ID', ok: true, detail: '持有' },
    { name: '1% 额度剩余', ok: true, detail: `${pretty(room)} 枚` },
    { name: '距毕业', ok: true, detail: `${pretty(remaining)}（报价币）` },
  ];
  const warnings = [...taxNotes(c, rec)];
  const enough = balance >= amountIn;
  if (!enough) warnings.push(`钱包 BNB 余额不足（${pretty(balance)}），已用模拟余额报价；执行前请先充值`);
  const deadline = BigInt(Math.floor(Date.now() / 1000) + DEADLINE_SEC);
  const feeText = `含 1% 手续费 + 买税 ${pctText(c.buyTaxBps)}`;

  if (lc(c.quote) === lc(ctx.wbnb)) {
    const simData = (min) => encodeFunctionData({ abi: gangRouterAbi, functionName: 'v3BuyBNB', args: [token, min, deadline] });
    const [sim, probe] = await Promise.all([
      simulate(ctx, { from: wallet, to: dep.router, data: simData(0n), value: amountIn, overrideBalance: !enough }),
      simulate(ctx, { from: wallet, to: dep.router, data: simData(0n), value: amountIn / 1000n, overrideBalance: true }),
    ]);
    if (!sim.ok) throw new Error(`买入模拟失败：${sim.reason}`);
    const out = decodeFunctionResult({ abi: gangRouterAbi, functionName: 'v3BuyBNB', data: sim.raw });
    const small = probe.ok ? decodeFunctionResult({ abi: gangRouterAbi, functionName: 'v3BuyBNB', data: probe.raw }) : 0n;
    const impactBps = out >= room ? null : impactOf(small, out, 1000n); // 触及上限时会退款，冲击无意义
    if (impactBps != null && impactBps > MAX_IMPACT_BPS) throw new Error(`价格冲击 ${impactBps / 100}% 超过 10%，请减少金额`);
    if (out >= room) warnings.push('这笔会触及 1% 持仓上限：超出部分以 BNB 退回');
    const netApprox = (amountIn * BigInt(10000 - 100 - c.buyTaxBps)) / 10000n;
    if (netApprox >= remaining) warnings.push('这笔会触发毕业建池（gas 约 250 万，由你支付），超出毕业线的部分退回');
    const minOut = (out * (10000n - slip)) / 10000n;
    const tx = { chainId: '56', to: dep.router, value: amountIn.toString(), inputData: encodeFunctionData({ abi: gangRouterAbi, functionName: 'v3BuyBNB', args: [token, minOut, deadline] }) };
    assertV3BuyTx(tx, { router: dep.router, token, amountIn, minOut });
    return {
      platform: 'gangv3', side: 'buy', token: meta.address, symbol: meta.symbol, decimals: 18,
      pay: { raw: amountIn.toString(), text: `${human(amountIn)} BNB（${feeText}）` },
      receive: { expected: pretty(out), min: pretty(minOut), minRaw: minOut.toString(), symbol: meta.symbol },
      route: 'GangRouter.v3BuyBNB → LaunchpadV3 曲线（一笔完成）', impactBps, lossBps: null, bnbEquivWei: '0',
      checks, warnings, note: null,
      steps: [{ kind: 'buy', label: `买入 ${meta.symbol}（BNB 直付，一笔完成）`, tx }],
    };
  }

  // 非 WBNB 报价：先换报价币（智能路由，避开小池子），再授权本次数量，再 pad.buy
  const quoteMeta = await tokenMeta(c.quote);
  const [quoteBal, allowance] = await Promise.all([
    rd(ctx, c.quote, erc20Abi, 'balanceOf', [wallet]),
    rd(ctx, c.quote, erc20Abi, 'allowance', [wallet, dep.pad]),
  ]);
  const swap = await routeSwap({ wallet, tokenIn: ctx.wbnb, tokenOut: c.quote, amountIn, slippageBps, nativeIn: true, extras: [c.quote], overrideBalance: true, maxImpactBps, maxLossBps });
  const quoteIn = swap.minOut;
  const tokensOut = localTokensOut(c, quoteIn, room);
  if (tokensOut <= 0n) throw new Error('计算出的可买数量为 0');
  const minOut = (tokensOut * (10000n - slip)) / 10000n;
  const steps = [];
  if (quoteBal < quoteIn) steps.push({ kind: 'swap', label: `换 ${quoteMeta.symbol}：${swap.route}`, tx: swap.tx });
  if (allowance < quoteIn) {
    const tx = { chainId: '56', to: c.quote, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [dep.pad, quoteIn] }) };
    assertApprove(tx, { token: c.quote, spender: dep.pad, amount: quoteIn });
    steps.push({ kind: 'approve', label: `授权 ${pretty(quoteIn)} ${quoteMeta.symbol} → LaunchpadV3（只授权本次数量）`, tx });
  }
  const buyTx = { chainId: '56', to: dep.pad, value: '0', inputData: encodeFunctionData({ abi: padAbi, functionName: 'buy', args: [token, quoteIn, minOut] }) };
  assertV3PadTx(buyTx, { pad: dep.pad, fn: 'buy', token, amount: quoteIn, minOut });
  steps.push({ kind: 'buy', label: `用 ${pretty(quoteIn)} ${quoteMeta.symbol} 买入 ${meta.symbol}`, tx: buyTx });
  return {
    platform: 'gangv3', side: 'buy', token: meta.address, symbol: meta.symbol, decimals: 18,
    pay: { raw: amountIn.toString(), text: `${human(amountIn)} BNB → ${pretty(quoteIn)} ${quoteMeta.symbol}（${feeText}）` },
    // 用钱包里已有的报价币（不换币）时，步骤不带 BNB：按这笔的 BNB 金额计入单笔上限
    bnbEquivWei: steps.some((s) => s.kind === 'swap') ? '0' : amountIn.toString(),
    receive: { expected: pretty(tokensOut), min: pretty(minOut), minRaw: minOut.toString(), symbol: meta.symbol },
    route: `BNB → ${quoteMeta.symbol}（${swap.route}）→ LaunchpadV3 曲线`, impactBps: swap.impactBps, lossBps: null,
    checks: [...checks, ...swap.checks], warnings: [...warnings, ...swap.warnings],
    note: steps.length > 1 ? `${quoteMeta.symbol} 报价的币要按顺序执行 ${steps.length} 笔（每笔上链后再预览下一笔）` : null,
    steps,
  };
}

/** 本地复算 LaunchpadV3._prepBuy（只用于非 WBNB 报价的多步计划；最终以上链前的 baw 预览为准） */
export function localTokensOut(c, quoteIn, room) {
  const VT = 1066666666666666666666666667n;
  const gross = BigInt(quoteIn);
  const protocolFee = (gross * 100n) / 10000n;
  const tax = (gross * BigInt(100 + c.buyTaxBps)) / 10000n - protocolFee;
  let net = gross - protocolFee - tax;
  const remaining = BigInt(c.gradAmt) - BigInt(c.realQuote);
  if (net > remaining) net = remaining;
  const vq = BigInt(c.virtualQuote);
  const k = vq * VT;
  const qReserve = vq + BigInt(c.realQuote);
  const tReserve = VT - BigInt(c.sold);
  const newT = (k + (qReserve + net) - 1n) / (qReserve + net);
  let out = tReserve - newT;
  if (out > room) out = room;
  return out;
}

/**
 * 卖出：只能本人直接调 pad.sell（毕业前代币锁定）。授权不足时先只授权本次数量（上链后重新报价）；
 * WBNB 报价卖出得到 WBNB，附一步可选的 unwrap。
 */
export async function planV3Sell({ ctx = mainnetCtx, dep, wallet, token, amount, percent, slippageBps }) {
  const c = await curveOf(ctx, dep.pad, token);
  if (!c) throw new Error('该代币未在已启用的 LaunchpadV3 登记');
  if (c.graduated) throw new Error('已毕业，改走外盘路由');
  const [agent, balance, allowance, rec, meta, quoteMeta] = await Promise.all([
    rd(ctx, dep.pad, padAbi, 'isAgent', [wallet]),
    rd(ctx, token, erc20Abi, 'balanceOf', [wallet]),
    rd(ctx, token, erc20Abi, 'allowance', [wallet, dep.pad]),
    recipientOf(ctx, dep.pad, token),
    (ctx.tokenMeta || tokenMeta)(token),
    (ctx.tokenMeta || tokenMeta)(c.quote),
  ]);
  if (!agent) throw new Error('毕业前卖出也要求钱包持有 Agent ID');
  const tokensIn = percent ? (balance * BigInt(Math.round(Number(percent) * 100))) / 10000n : parseWei(amount);
  if (tokensIn <= 0n) throw new Error(`钱包没有 ${meta.symbol} 持仓`);
  if (tokensIn > balance) throw new Error(`余额不足：持有 ${pretty(balance)}，要卖 ${pretty(tokensIn)}`);
  const isWbnb = lc(c.quote) === lc(ctx.wbnb);
  const unit = isWbnb ? 'WBNB' : quoteMeta.symbol;
  const checks = [{ name: `${meta.symbol} 持仓`, ok: true, detail: `${pretty(balance)}，卖出 ${pretty(tokensIn)}${percent ? `（${percent}%）` : ''}` }];
  const warnings = [...taxNotes(c, rec)];
  const base = {
    platform: 'gangv3', side: 'sell', token: meta.address, symbol: meta.symbol, decimals: 18,
    pay: { raw: tokensIn.toString(), text: `${pretty(tokensIn)} ${meta.symbol}（扣 1% 手续费 + 卖税 ${pctText(c.sellTaxBps)}）` },
    route: `LaunchpadV3 曲线 → ${unit}`, checks, warnings,
  };

  // 授权不够时：用状态覆盖临时把「钱包 → pad」的授权设成本次数量，照样以钱包身份模拟真实卖出，
  // 一次给出「授权 + 卖出」两步（授权上链后直接执行卖出，不再重新报价）。找不到授权存储位置的非常规代币才退回旧流程
  const needApprove = allowance < tokensIn;
  const override = needApprove ? await allowanceOverride(token, wallet, dep.pad, tokensIn, { call: ctx.call }).catch(() => null) : null;
  const approveTx = { chainId: '56', to: meta.address, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [dep.pad, tokensIn] }) };
  if (needApprove) assertApprove(approveTx, { token: meta.address, spender: dep.pad, amount: tokensIn });
  if (needApprove && !override) {
    return {
      ...base,
      receive: { expected: '授权后报价', min: '授权后报价', symbol: unit },
      note: `先授权 ${pretty(tokensIn)} ${meta.symbol} 给 LaunchpadV3（只授权本次数量）。这个代币没法在授权前模拟卖出：授权上链后再点一次卖出`,
      steps: [{ kind: 'approve', label: `授权 ${pretty(tokensIn)} ${meta.symbol} → LaunchpadV3`, replan: true, tx: approveTx }],
    };
  }

  const sellData = (amt) => encodeFunctionData({ abi: padAbi, functionName: 'sell', args: [token, amt, 0n] });
  const [sim, probe] = await Promise.all([
    simulate(ctx, { from: wallet, to: dep.pad, data: sellData(tokensIn), override }),
    simulate(ctx, { from: wallet, to: dep.pad, data: sellData(tokensIn / 1000n), override }),
  ]);
  if (!sim.ok) throw new Error(`卖出模拟失败：${sim.reason}`);
  const out = decodeFunctionResult({ abi: padAbi, functionName: 'sell', data: sim.raw });
  const small = probe.ok ? decodeFunctionResult({ abi: padAbi, functionName: 'sell', data: probe.raw }) : 0n;
  const impactBps = impactOf(small, out, 1000n);
  if (impactBps != null && impactBps > MAX_IMPACT_BPS) throw new Error(`价格冲击 ${impactBps / 100}% 超过 10%，请分批卖出`);
  const minOut = (out * (10000n - BigInt(slippageBps))) / 10000n;
  const tx = { chainId: '56', to: dep.pad, value: '0', inputData: encodeFunctionData({ abi: padAbi, functionName: 'sell', args: [token, tokensIn, minOut] }) };
  assertV3PadTx(tx, { pad: dep.pad, fn: 'sell', token, amount: tokensIn, minOut });
  const steps = [];
  if (needApprove) steps.push({ kind: 'approve', label: `授权 ${pretty(tokensIn)} ${meta.symbol} → LaunchpadV3（只授权本次数量）`, tx: approveTx });
  steps.push({ kind: 'sell', label: `卖出 ${pretty(tokensIn)} ${meta.symbol} → ${unit}`, tx });
  if (isWbnb) {
    steps.push({
      kind: 'unwrap', label: `（可选）把 ${pretty(minOut)} WBNB 换回 BNB`,
      tx: { chainId: '56', to: ctx.wbnb, value: '0', inputData: encodeFunctionData({ abi: wbnbAbi, functionName: 'withdraw', args: [minOut] }) },
    });
  }
  if (needApprove) checks.push({ name: '授权前模拟', ok: true, detail: '用临时授权（状态覆盖）以钱包身份模拟了真实卖出' });
  return {
    ...base,
    receive: { expected: pretty(out, quoteMeta.decimals), min: pretty(minOut, quoteMeta.decimals), minRaw: minOut.toString(), symbol: unit },
    impactBps, lossBps: null,
    note: [needApprove ? '先授权本次数量，上链后直接卖出（卖出已按授权后的状态模拟过）' : null,
      isWbnb ? '卖出得到 WBNB；最后一步是可选的解包（把最少到手部分换回 BNB）' : null].filter(Boolean).join('；') || null,
    steps,
  };
}
