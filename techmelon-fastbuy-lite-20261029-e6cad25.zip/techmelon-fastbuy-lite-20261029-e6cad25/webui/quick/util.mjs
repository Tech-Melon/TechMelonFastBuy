export { pretty, human } from './router.mjs';

/** 十进制字符串 → 最小单位 BigInt；不接受科学计数法 / 负数 / 超精度 */
export function parseUnitsStrict(value, decimals = 18) {
  const s = String(value ?? '').trim();
  if (!/^\d+(\.\d+)?$/.test(s) || !/[1-9]/.test(s)) throw new Error('数量需要大于 0 的十进制数');
  const [whole, frac = ''] = s.split('.');
  if (frac.length > decimals) throw new Error(`小数位超过 ${decimals} 位`);
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt((frac + '0'.repeat(decimals)).slice(0, decimals) || '0');
}

/** 从步骤 label 推断步骤类型（给已有平台的计划用） */
export function stepKind(label) {
  const s = String(label || '').toLowerCase();
  if (s.startsWith('approve') || s.includes('授权')) return 'approve';
  if (s.startsWith('wrap')) return 'wrap';
  if (s.startsWith('unwrap')) return 'unwrap';
  if (s.startsWith('swap')) return 'swap';
  if (s.includes('sell')) return 'sell';
  return 'buy';
}
