/**
 * 一键转移：把钱包里的非 BNB 代币（gang 已迁移代币、报价币等 ERC20）转到已保存的白名单地址。
 * docs/AUTOMATION_RULES.md 硬性规则 3 第五个例外：确认框列出每一笔（链、代币合约、数量、完整收款地址）后确认一次，服务端逐笔执行。
 *
 * 安全原则：
 * 1. 收款地址只能是白名单（config.json: transferTargets）里的地址；白名单的增删要单独确认，前端不能临时手填。
 * 2. 加白名单前做地址检查：是不是本机钱包自己、是不是合约、是否与本机钱包 / 已有白名单「首尾相同中间不同」（地址投毒）。
 * 3. gang LaunchpadV2 代币毕业（迁移）前锁转账：列表标灰，计划里直接排除；其它代币以钱包身份 eth_call 模拟 transfer，revert 的排除并写明原因。
 * 4. 广播前解码 calldata 复核：函数只能是 transfer、收款人必须是选定的白名单地址、数量与计划一致、目标是该代币合约。
 * 5. 不带 BNB（value=0）；一次最多 20 笔。
 */
import { randomUUID } from 'node:crypto';
import { encodeFunctionData, decodeFunctionData, decodeFunctionResult, parseAbi, getAddress, formatUnits } from 'viem';
import { rpc, getConfig, saveConfig } from '../config.mjs';
import { gangInfo } from '../agent/gang.mjs';

const MAX_ITEMS = 20;
const MAX_TARGETS = 20;
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function transfer(address to, uint256 amount) returns (bool)',
]);
const lc = (a) => String(a || '').toLowerCase();

async function read(to, functionName, args = []) {
  const raw = await rpc('eth_call', [{ to, data: encodeFunctionData({ abi: erc20Abi, functionName, args }) }, 'latest']);
  return decodeFunctionResult({ abi: erc20Abi, functionName, data: raw });
}

function fmt(raw, decimals) {
  const s = formatUnits(BigInt(raw), decimals);
  const [i, f = ''] = s.split('.');
  const cut = f.slice(0, 6).replace(/0+$/, '');
  return cut ? `${i}.${cut}` : i;
}

// ---------------------------------------------------------------- 白名单地址

export async function listTargets() {
  const list = (await getConfig()).transferTargets;
  return Array.isArray(list) ? list : [];
}

/**
 * 地址检查（加白名单前、转移前都会做）：返回 { address, isContract, warnings[], fatal? }。
 * ownWallets：本机钱包的 EVM 地址；existing：已有白名单地址。
 */
export async function checkAddress(address, { ownWallets = [], existing = [] } = {}) {
  const a = getAddress(address);
  const warnings = [];
  let fatal = null;
  if (/^0x0{40}$/i.test(a) || /^0x0{36}dead$/i.test(a)) fatal = '不能转到零地址 / 销毁地址';
  const code = await rpc('eth_getCode', [a, 'latest']).catch(() => null);
  const isContract = Boolean(code && code !== '0x');
  if (isContract) warnings.push('这是一个合约地址：如果它不是你自己的多签 / 智能钱包，转进去的代币可能取不出来');
  const head = (x) => lc(x).slice(2, 6);
  const tail = (x) => lc(x).slice(-4);
  for (const [label, list] of [['本机钱包', ownWallets], ['已保存的白名单地址', existing]]) {
    for (const o of list) {
      if (!o) continue;
      if (lc(o) === lc(a)) { if (label === '本机钱包') warnings.push('这是本机的一个钱包地址'); continue; }
      if (head(o) === head(a) && tail(o) === tail(a)) {
        warnings.push(`⚠ 与${label} ${o} 首尾相同、中间不同：疑似地址投毒，请逐字核对`);
      }
    }
  }
  return { address: a, isContract, warnings, fatal };
}

export async function addTarget({ name, address }, ctx) {
  const list = await listTargets();
  if (list.length >= MAX_TARGETS) throw new Error(`白名单最多 ${MAX_TARGETS} 个地址`);
  const chk = await checkAddress(address, { ...ctx, existing: list.map((t) => t.address) });
  if (chk.fatal) throw new Error(chk.fatal);
  if (list.some((t) => lc(t.address) === lc(chk.address))) throw new Error('该地址已在白名单里');
  const entry = { id: randomUUID(), name: String(name || '').trim().slice(0, 40) || '未命名', address: chk.address, addedAt: new Date().toISOString() };
  await saveConfig({ transferTargets: [...list, entry] });
  return { entry, check: chk };
}

export async function removeTarget(id) {
  const list = await listTargets();
  const next = list.filter((t) => t.id !== id);
  if (next.length === list.length) throw new Error('白名单里没有这个地址');
  await saveConfig({ transferTargets: next });
  return next;
}

// ---------------------------------------------------------------- 可转代币

/**
 * 钱包持有的非 BNB 代币（只读）。candidates 来自 baw 余额 + 前端补充 CA，逐个链上核实余额。
 * gang LaunchpadV2 代币标出是否已毕业（未毕业锁转账，不能转）。
 */
export async function listTransferable({ wallet, candidates }) {
  const seen = new Set();
  const list = candidates.filter((c) => {
    const k = lc(c.token);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  }).slice(0, 80);
  const rows = await Promise.all(list.map(async (c) => {
    try {
      const token = getAddress(c.token);
      const [balance, decimals, symbol, g] = await Promise.all([
        read(token, 'balanceOf', [wallet]),
        read(token, 'decimals').then(Number).catch(() => 18),
        read(token, 'symbol').then((s) => String(s).slice(0, 32)).catch(() => '?'),
        gangInfo(token).catch(() => null),
      ]);
      if (balance <= 0n) return null;
      const gang = g ? { graduated: Boolean(g.graduated), taxed: Boolean(g.taxed) } : null;
      return {
        token, symbol, decimals, balance: balance.toString(), balanceText: fmt(balance, decimals),
        usdValue: c.usdValue ?? null, gang,
        locked: Boolean(gang && !gang.graduated),
        status: gang ? (gang.graduated ? 'gang · 已迁移' : 'gang · 未毕业（锁转账）') : '普通代币',
      };
    } catch {
      return null;
    }
  }));
  return rows.filter(Boolean).sort((a, b) => {
    const rank = (x) => (x.gang && !x.locked ? 0 : x.gang ? 2 : 1);
    return rank(a) - rank(b) || (Number(b.usdValue) || 0) - (Number(a.usdValue) || 0);
  });
}

// ---------------------------------------------------------------- 计划

/** 广播前复核：只能是该代币的 transfer(白名单地址, 计划数量)，不带 BNB */
export function assertTransferTx(tx, { token, to, amount }) {
  if (lc(tx.to) !== lc(token)) throw new Error('交易目标不是该代币合约');
  if (BigInt(tx.value || '0') !== 0n) throw new Error('转移代币不应附带 BNB');
  let d;
  try { d = decodeFunctionData({ abi: erc20Abi, data: tx.inputData }); } catch { throw new Error('calldata 不是 ERC20 transfer'); }
  if (d.functionName !== 'transfer') throw new Error('calldata 不是 transfer');
  if (lc(d.args[0]) !== lc(to)) throw new Error('收款地址与选定的白名单地址不一致');
  if (BigInt(d.args[1]) !== BigInt(amount) || BigInt(amount) <= 0n) throw new Error('转移数量与计划不一致或为 0');
}

/**
 * 生成转移计划：items = [{ token, percent }]（percent 1~100，默认 100）。
 * 逐个读余额、按比例算数量、以钱包身份模拟 transfer；模拟失败 / 锁转账的排除并写进 skipped。
 */
export async function planTransfer({ wallet, targetId, items, ownWallets = [] }) {
  const targets = await listTargets();
  const target = targets.find((t) => t.id === targetId);
  if (!target) throw new Error('请选择一个白名单地址（只能转给已保存的白名单地址）');
  if (lc(target.address) === lc(wallet)) throw new Error('收款地址就是当前钱包自己');
  if (!Array.isArray(items) || !items.length) throw new Error('请勾选要转移的代币');
  if (items.length > MAX_ITEMS) throw new Error(`一次最多转 ${MAX_ITEMS} 个代币`);
  const chk = await checkAddress(target.address, { ownWallets, existing: targets.filter((t) => t.id !== targetId).map((t) => t.address) });
  if (chk.fatal) throw new Error(chk.fatal);

  const steps = [];
  const skipped = [];
  const seen = new Set();
  for (const it of items) {
    let token;
    try { token = getAddress(String(it.token)); } catch { skipped.push({ token: it.token, reason: '地址格式不对' }); continue; }
    if (seen.has(lc(token))) continue;
    seen.add(lc(token));
    const pct = it.percent == null ? 100 : Number(it.percent);
    if (!(Number.isInteger(pct) && pct >= 1 && pct <= 100)) { skipped.push({ token, reason: '比例需要是 1~100 的整数' }); continue; }
    try {
      const [balance, decimals, symbol, g] = await Promise.all([
        read(token, 'balanceOf', [wallet]),
        read(token, 'decimals').then(Number).catch(() => 18),
        read(token, 'symbol').then((s) => String(s).slice(0, 32)).catch(() => '?'),
        gangInfo(token).catch(() => null),
      ]);
      if (g && !g.graduated) { skipped.push({ token, symbol, reason: 'gang 代币未毕业（迁移前锁转账）' }); continue; }
      const amount = pct === 100 ? balance : (balance * BigInt(pct)) / 100n;
      if (amount <= 0n) { skipped.push({ token, symbol, reason: '余额为 0' }); continue; }
      const data = encodeFunctionData({ abi: erc20Abi, functionName: 'transfer', args: [target.address, amount] });
      try {
        const raw = await rpc('eth_call', [{ from: wallet, to: token, data }, 'latest']);
        // 返回 false（不 revert）的代币也算失败；不返回值的老式代币（raw = 0x）视为成功
        if (raw && raw !== '0x' && BigInt(raw.slice(0, 66)) === 0n) throw new Error('transfer 返回 false');
      } catch (err) {
        skipped.push({ token, symbol, reason: `模拟转账失败：${String(err.message || err).replace(/:\s*0x[0-9a-fA-F]*$/, '').slice(0, 120)}` });
        continue;
      }
      const tx = { chainId: '56', to: token, value: '0', inputData: data };
      assertTransferTx(tx, { token, to: target.address, amount });
      steps.push({
        kind: 'transfer',
        label: `转 ${fmt(amount, decimals)} ${symbol}（${pct}%）→ ${target.name} ${target.address}`,
        tx,
        meta: { token, symbol, decimals, amount: amount.toString(), amountText: fmt(amount, decimals), percent: pct, taxed: Boolean(g?.taxed) },
      });
    } catch (err) {
      skipped.push({ token, reason: `读取失败：${err.message}` });
    }
  }
  if (!steps.length) throw new Error(`没有可转的代币：${skipped.map((s) => `${s.symbol || s.token}：${s.reason}`).join('；') || '—'}`);
  const warnings = [...chk.warnings];
  if (steps.some((s) => s.meta.taxed)) warnings.push('含 gang 有税代币：钱包之间转账一般不扣税（税只对池子买卖收），以链上结果为准');
  return {
    platform: 'transfer', side: 'transfer', target, checks: [], warnings, skipped,
    pay: { text: `${steps.length} 个代币` }, receive: { expected: target.address, min: target.address, minRaw: null, symbol: '' },
    route: 'ERC20 transfer（逐笔）', note: null,
    items: steps.map((s) => s.meta),
    steps: steps.map(({ meta: _m, ...s }) => s),
  };
}
