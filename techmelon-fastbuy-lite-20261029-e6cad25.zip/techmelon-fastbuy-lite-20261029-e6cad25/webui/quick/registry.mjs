/**
 * 快捷交易平台注册表。
 *
 * 新增平台：在 platforms/ 下加一个文件，导出
 *   { id, label, addressKind: 'token' | 'market',
 *     detect(address, { wallet, extras }) → null | { match, tradable, phase, payUnit, graduated?, extras?, notes? },
 *     plan({ wallet, address, side, amount, percent, slippageBps, extras }) → 统一计划 }
 * 然后加进下面的 PLATFORMS 数组即可（顺序 = 自动识别时的优先级）。dex 永远是兜底，不放进数组。
 *
 * 统一计划：
 *   { platform, side, token, symbol, decimals,
 *     pay: { text }, receive: { expected, min, symbol },     ← 确认框里的「扣取 / 收到」
 *     route, alternatives?, v2Only?, impactBps?, lossBps?,
 *     checks: [{ name, ok, detail }], warnings: [], note,
 *     steps: [{ kind, label, replan?, tx: { to, value, inputData } }] }
 * steps 按顺序执行；replan=true 表示这一步（授权）上链后需要重新生成计划（模拟才准确）。
 */
import { tokenMeta } from './router.mjs';
import { cacheGet, cacheSet } from '../cache.mjs';
import { idGet, idSet, idDrop } from './detectcache.mjs';
import four from './platforms/four.mjs';
import gangv3 from './platforms/gangv3.mjs';
import gang from './platforms/gang.mjs';
import flap from './platforms/flap.mjs';
import flaptax from './platforms/flaptax.mjs';
import dex from './platforms/dex.mjs';

const PLATFORMS = [four, gangv3, gang, flaptax, flap];
const ALL = [...PLATFORMS, dex];

export function listPlatforms() {
  return ALL.map((p) => ({ id: p.id, label: p.label, addressKind: p.addressKind }));
}

function platformById(id) {
  const p = ALL.find((x) => x.id === id);
  if (!p) throw new Error(`未知平台：${id}`);
  return p;
}

/**
 * 并行探测所有平台；已毕业的内盘代币把报价币交给外盘路由（extras），
 * 推荐顺序：可交易的内盘平台 > 外盘。
 */
const DETECT_CACHE_MS = 20000; // 「识别」后紧接着点「买入」不必再识别一遍（计划本身会重新读链）

const settle = async (p, fn) => {
  try {
    const r = await fn();
    return r ? { id: p.id, label: p.label, ...r } : null;
  } catch (err) {
    return { id: p.id, label: p.label, match: false, error: err.message };
  }
};

/** 平台签名：平台可选实现 epoch()（例如 gang V3 返回已启用部署的地址 / 'off'），任何一个变了归属缓存全部作废 */
async function platformSig() {
  const parts = await Promise.all(PLATFORMS.map(async (p) => (p.epoch ? `${p.id}=${await p.epoch().catch(() => 'err')}` : p.id)));
  return parts.join('|');
}

export async function detectAll(address, { wallet } = {}) {
  const key = `quick:detect:${String(address).toLowerCase()}:${String(wallet || '').toLowerCase()}`;
  const hit = cacheGet(key);
  if (hit) return hit;
  const sig = await platformSig();
  const known = idGet(address, sig);
  const out = known ? await detectKnown(address, wallet, known) : null;
  if (out) {
    if (!out.errors.length) cacheSet(key, out, DETECT_CACHE_MS);
    return out;
  }
  if (known) idDrop(address); // 归属平台这次说「不是」：作废，全量重识别
  const full = await detectFull(address, wallet);
  if (!full.errors.length) {
    cacheSet(key, full, DETECT_CACHE_MS);
    const ids = full.candidates.filter((c) => c.id !== 'dex').map((c) => c.id);
    const market = ids.includes('flap');
    // 属于内盘却读不到 symbol（节点抖动）：不写归属缓存，否则 7 天都显示「未知代币」
    if (!(ids.length && !market && full.symbol == null)) {
      idSet(address, { ids, extras: full.extras, market, symbol: full.symbol, decimals: full.decimals }, sig);
    }
  }
  return full;
}

/** 已知归属：只问归属平台（读最新阶段 / 能否交易）+ 外盘（报价币已知，两者并行），不读代币信息 */
async function detectKnown(address, wallet, known) {
  const mine = PLATFORMS.filter((p) => known.ids.includes(p.id));
  const [results, dexResult] = await Promise.all([
    Promise.all(mine.map((p) => settle(p, () => p.detect(address, { wallet })))),
    known.market ? null : settle(dex, () => dex.detect(address, { extras: known.extras })),
  ]);
  // 归属平台不再认这个地址（不应该发生）：交给全量识别；单纯出错照常返回（不缓存，下次重试）
  if (results.some((r) => !r || (!r.match && !r.error))) return null;
  const matched = results.filter((r) => r.match);
  const extras = [...new Set([...known.extras, ...matched.flatMap((m) => m.extras || []).map((a) => String(a).toLowerCase())])];
  const candidates = [...matched, ...(dexResult?.match ? [dexResult] : [])];
  return {
    address,
    symbol: known.symbol || (known.market ? 'Flap market' : null),
    decimals: known.decimals,
    candidates,
    recommended: candidates.find((c) => c.tradable)?.id || null,
    extras,
    errors: [...results, dexResult].filter((r) => r && r.error).map((r) => `${r.label}：${r.error}`),
    cachedIdentity: true,
  };
}

async function detectFull(address, wallet) {
  // 内盘平台、外盘（只看主流中转币）、代币信息三路并行；外盘再按平台报价币补查少量币对（其余命中缓存）
  const [results, dexBase, meta] = await Promise.all([
    Promise.all(PLATFORMS.map((p) => settle(p, () => p.detect(address, { wallet })))),
    settle(dex, () => dex.detect(address, { extras: [] })),
    tokenMeta(address).catch(() => null),
  ]);
  const matched = results.filter((r) => r && r.match);
  const extras = [...new Set(matched.flatMap((m) => m.extras || []).map((a) => String(a).toLowerCase()))];
  const isMarket = matched.some((m) => m.id === 'flap');
  let dexResult = null;
  if (!isMarket) {
    dexResult = extras.length ? await settle(dex, () => dex.detect(address, { extras })) : dexBase;
  }
  const candidates = [...matched, ...(dexResult?.match ? [dexResult] : [])];
  const recommended = candidates.find((c) => c.tradable)?.id || null;
  return {
    address,
    symbol: meta?.symbol || (isMarket ? 'Flap market' : null),
    decimals: meta?.decimals ?? null,
    candidates,
    recommended,
    extras,
    errors: [...results, dexResult].filter((r) => r && r.error).map((r) => `${r.label}：${r.error}`),
  };
}

/**
 * 指定平台时只探测这一个平台（用户在对应平台的输入框里填了 CA，不必把所有平台都识别一遍）。
 * 仍然要链上确认地址确实属于该平台：填错框不会被当成该平台下单。
 */
export async function detectOne(id, address, wallet) {
  const key = `quick:detect1:${id}:${String(address).toLowerCase()}:${String(wallet || '').toLowerCase()}`;
  const hit = cacheGet(key);
  if (hit) return hit;
  const out = await detectOneRaw(id, address, wallet);
  cacheSet(key, out, DETECT_CACHE_MS);
  return out;
}

async function detectOneRaw(id, address, wallet) {
  const p = platformById(id);
  const r = await p.detect(address, { wallet });
  if (!r?.match) throw new Error(`该地址不是 ${p.label} 的代币${id === 'flap' ? '（Flap 需要填 market 地址）' : ''}，请换到正确的输入框或用「自动识别」`);
  const cand = { id: p.id, label: p.label, ...r };
  if (r.graduated && id !== 'dex') throw new Error(`${p.label}：该代币已毕业，请用「自动识别」输入框（会走外盘路由）`);
  return { address, candidates: [cand], recommended: r.tradable ? id : null, extras: r.extras || [], errors: [] };
}

/** 生成计划：platform='auto' 时先识别再用推荐平台；指定平台时只探测该平台 */
export async function planQuick({ wallet, address, platform, side, amount, percent, slippageBps, quoteIn, pendingApprove, maxImpactBps, maxLossBps }) {
  const t0 = Date.now();
  const det = platform === 'auto' ? await detectAll(address, { wallet }) : await detectOne(platform, address, wallet);
  const detectMs = Date.now() - t0;
  const id = platform === 'auto' ? det.recommended : platform;
  if (!id) {
    // 识别到了内盘平台、只是当前钱包不能交易（如 Agent ID 门槛）：把那个平台的说明带出来，而不是笼统的「没有平台」
    const hit = det.candidates.find((c) => c.id !== 'dex' && c.match && !c.graduated);
    if (hit) throw new Error(`${hit.label} 当前不可交易（${hit.phase}）${hit.notes?.length ? `：${hit.notes.join('；')}` : ''}`);
    throw new Error('没有识别到可交易的平台（内盘未开放 / 外盘无流动性）');
  }
  const cand = det.candidates.find((c) => c.id === id);
  if (!cand) throw new Error(`该地址不属于 ${platformById(id).label}`);
  if (!cand.tradable) throw new Error(`${cand.label} 当前不可交易（${cand.phase}）`);
  const t1 = Date.now();
  const plan = await platformById(id).plan({ wallet, address, side, amount, percent, slippageBps, quoteIn, pendingApprove, maxImpactBps, maxLossBps, extras: det.extras });
  return { ...plan, platform: id, platformLabel: cand.label, payUnit: cand.payUnit, detect: det, timing: { detectMs, planMs: Date.now() - t1 } };
}
