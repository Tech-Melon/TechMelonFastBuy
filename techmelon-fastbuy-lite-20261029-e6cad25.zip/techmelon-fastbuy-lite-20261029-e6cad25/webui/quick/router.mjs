/**
 * PancakeSwap 智能路由（BSC）：V2 + V3 混合多跳，单笔原子交易。
 *
 * 设计要点（防止「池子小的路由」把钱吃掉）：
 * 1. 中转币只用白名单（主流稳定币 + WBNB）+ 发币平台声明的报价币（如 gang 的 oANT、Four 的 BNCB），
 *    不从链上任意扩展，避免被假池子引导。
 * 2. 在这些币之间发现所有 V2 pair / V3 pool（0.01% / 0.05% / 0.25% / 1%），
 *    按「实际金额」逐跳报价，取输出最多的路径（金额单调 → 按节点保留最优即是全局最优）。
 * 3. 价格冲击检查：同一路径用 1/1000 金额报价得到边际价，冲击超过阈值直接拒绝生成交易。
 * 4. 用 SmartRouter.multicall 把多段串成一笔交易：中间段输出到 ADDRESS_THIS，下一段 amountIn=0（用合约余额），
 *    只在最后一段校验 amountOutMin；以钱包身份 eth_call 模拟拿到「真实到账」（含转账税），再按滑点算下限。
 * 5. 广播前 assertRouterTx 解码 calldata 复核：目标合约、收款人、代币白名单、金额、下限。
 */
import {
  encodeFunctionData, decodeFunctionResult, decodeFunctionData, parseAbi, encodePacked, toHex, getAddress,
} from 'viem';
import { rpc, rpcBatch, runBackground } from '../config.mjs';
import { cacheGet, cacheSet } from '../cache.mjs';
import { allowanceOverride } from './simoverride.mjs';
import {
  getPin, pinFailed, pinOk, pinNeedsRecheck, pinChecked, rememberTx, serialHops, pathKeyOf, PIN_MAX_FAILS,
} from './routebook.mjs';

export const PANCAKE = {
  smartRouter: '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4',
  v2Factory: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
  v3Factory: '0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865',
  quoterV2: '0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997',
};

export const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';

/** 中转币白名单（不从链上发现） */
export const HUBS = {
  WBNB,
  USDT: '0x55d398326f99059fF775485246999027B3197955',
  USDC: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
  USD1: '0x8d0D000Ee44948FC98c9B98A4FA4921476f08B0d',
  U: '0xcE24439F2D9C6a2289F741120FE202248B666666',
};

const V3_FEES = [100, 500, 2500, 10000];
const V2_FEE_BPS = 25n; // Pancake V2 固定 0.25%
const MAX_HOPS = 3;
const ADDRESS_THIS = '0x0000000000000000000000000000000000000002';
const POOL_CACHE_MS = 5 * 60 * 1000; // 池子地址很少变：缓存 5 分钟；储备 / 流动性每次重读
const HUB_POOL_CACHE_MS = 30 * 60 * 1000; // 中转币之间的池子（WBNB/USDT 等）
const LIVE_CACHE_MS = 15000;
const DEADLINE_SEC = 600;
/** 价格冲击上限（bps）：超过即拒绝生成交易，可用环境变量 QUICK_MAX_IMPACT_BPS 调整 */
export const MAX_IMPACT_BPS = (() => {
  const v = Number(process.env.QUICK_MAX_IMPACT_BPS || 1000);
  return Number.isInteger(v) && v > 0 && v <= 5000 ? v : 1000;
})();
/** 实测损耗（转账税等）上限：超过视为疑似恶意高税 / 貔貅，拒绝 */
export const MAX_LOSS_BPS = 2000;

const factoryV2Abi = parseAbi(['function getPair(address,address) view returns (address)']);
const factoryV3Abi = parseAbi(['function getPool(address,address,uint24) view returns (address)']);
const pairAbi = parseAbi(['function getReserves() view returns (uint112,uint112,uint32)']);
const poolAbi = parseAbi(['function liquidity() view returns (uint128)']);
const pairIdAbi = parseAbi(['function token0() view returns (address)', 'function token1() view returns (address)']);
const quoterAbi = parseAbi([
  'function quoteExactInputSingle((address tokenIn,address tokenOut,uint256 amountIn,uint24 fee,uint160 sqrtPriceLimitX96)) returns (uint256 amountOut,uint160 sqrtPriceX96After,uint32 initializedTicksCrossed,uint256 gasEstimate)',
]);
export const routerAbi = parseAbi([
  'function multicall(uint256 deadline, bytes[] data) payable returns (bytes[])',
  'function swapExactTokensForTokens(uint256 amountIn, uint256 amountOutMin, address[] path, address to) payable returns (uint256)',
  'struct ExactInputParams { bytes path; address recipient; uint256 amountIn; uint256 amountOutMinimum; }',
  'function exactInput(ExactInputParams params) payable returns (uint256)',
  'function unwrapWETH9(uint256 amountMinimum, address recipient) payable',
]);
const erc20Abi = parseAbi([
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
]);

const lc = (a) => String(a).toLowerCase();
const isZero = (a) => /^0x0{40}$/i.test(String(a));

export function human(raw, decimals = 18) {
  const s = BigInt(raw).toString().padStart(decimals + 1, '0');
  const whole = s.slice(0, -decimals) || '0';
  const frac = s.slice(-decimals).replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole;
}

/** 便于阅读的数量：保留 6 位有效小数 */
export function pretty(raw, decimals = 18) {
  const n = Number(human(raw, decimals));
  if (!Number.isFinite(n)) return human(raw, decimals);
  return n.toLocaleString('en-US', { maximumFractionDigits: n >= 1 ? 4 : 8 });
}


/*
 * 路由模块自用的请求限速（只管本模块，不拖慢狙击引擎）：
 * 节点普遍按「每秒请求数」限流，batch 里每一项都算一次。按 Date.now() 的整秒窗口计数，
 * 用满就等到窗口结束（绝对时间对齐，不累计 sleep）。QUICK_RPC_RATE 可调，默认 40/s。
 */
const RPC_RATE = (() => {
  const v = Number(process.env.QUICK_RPC_RATE || 40);
  return Number.isInteger(v) && v >= 5 ? v : 40;
})();
let windowStart = 0;
let used = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));

// 限速已统一在 config.mjs（全局每秒窗口，所有模块共用），这里不再重复计数，否则吞吐会减半
async function take() {}

/** 重试前等到下一个整秒（与全局窗口对齐，不累计 sleep） */
async function nextWindow() {
  const now = Date.now();
  if (now - windowStart >= 1000) windowStart = now;
  used = 0;
  await sleep(windowStart + 1000 - now);
}

function isRevertError(err) {
  if (!err) return false;
  if (err.code === -32007 || err.code === 429) return false; // 限流
  return err.code === 3 || /revert/i.test(String(err.message || ''));
}

const isRateLimit = (err) => err && (err.code === -32007 || err.code === 429 || /limit|too many/i.test(String(err.message || '')));

/** 单个只读调用：限速 + 限流时等下一个窗口重试（最多 3 次） */
async function call(method, params) {
  for (let attempt = 0; ; attempt += 1) {
    await take(1);
    try {
      return await rpc(method, params);
    } catch (err) {
      if (!isRateLimit(err) || attempt >= 3) throw err;
      await nextWindow();
    }
  }
}

async function read(to, abi, functionName, args = []) {
  const raw = await call('eth_call', [{ to, data: encodeFunctionData({ abi, functionName, args }) }, 'latest']);
  return decodeFunctionResult({ abi, functionName, data: raw });
}

/**
 * 一批 eth_call：JSON-RPC batch 分块顺序发送并限速；出错（非 revert）的项最多重试 3 轮。
 * revert 视为结果为空（null）。返回 { results, failed }：failed > 0 表示有项始终没查到，
 * 调用方不能把它当成「没有池子」缓存或用来选路。
 */
async function ethCalls(calls) {
  const CHUNK = Math.min(20, RPC_RATE);
  const results = new Array(calls.length).fill(null);
  let pending = calls.map((_, i) => i);
  for (let round = 0; round < 4 && pending.length; round += 1) {
    if (round > 0) await nextWindow();
    const again = [];
    for (let i = 0; i < pending.length; i += CHUNK) {
      const idxs = pending.slice(i, i + CHUNK);
      await take(idxs.length);
      try {
        const r = await rpcBatch(idxs.map((k) => ({ method: 'eth_call', params: [{ to: calls[k].to, data: calls[k].data }, 'latest'] })));
        idxs.forEach((k, j) => {
          if (r.results[j] != null) results[k] = r.results[j];
          else if (!isRevertError(r.errors[j])) again.push(k);
        });
      } catch {
        again.push(...idxs); // 整批被拒（如返回的不是数组）：下一轮重试
      }
    }
    pending = again;
  }
  return { results, failed: pending.length };
}

const metaCache = new Map();
const KNOWN = new Map([
  ...Object.entries(HUBS).map(([k, a]) => [lc(a), { address: getAddress(a), symbol: k, decimals: 18 }]),
]);

/** 代币 symbol / decimals（缓存） */
export async function tokenMeta(address) {
  const key = lc(address);
  if (KNOWN.has(key)) return KNOWN.get(key);
  if (metaCache.has(key)) return metaCache.get(key);
  const [symbol, decimals] = await Promise.all([
    read(address, erc20Abi, 'symbol').catch(() => '?'),
    read(address, erc20Abi, 'decimals'),
  ]);
  const meta = { address: getAddress(address), symbol: String(symbol).slice(0, 32), decimals: Number(decimals) };
  metaCache.set(key, meta);
  return meta;
}

/**
 * 平台报价币（来自 gang LaunchpadV2.curves / Four Core.tokens 登记，或报价币库存）：
 * 它们和中转币之间的池子很少新建，池子地址按中转币同等对待，缓存 30 分钟。
 */
const LONG_CACHE_TOKENS = new Set();
export function markLongCache(addrs) {
  for (const a of addrs) if (/^0x[0-9a-fA-F]{40}$/.test(String(a))) LONG_CACHE_TOKENS.add(lc(a));
}

/**
 * 在给定代币集合之间发现 V2 / V3 池子，并读取当前储备 / 流动性。
 * 返回可用（有流动性）的池子列表。
 */
export function discoverPools(tokens, opts = {}) {
  // 同一组币正在发现时直接复用那次的结果（识别后台预热还没跑完、用户就点了买入：不重复打一遍 RPC）。
  // refresh / refreshLive 是要强制重读的，不合并
  if (opts.refresh || opts.refreshLive) return discoverPoolsRaw(tokens, opts);
  const k = JSON.stringify([[...new Set(tokens.map(lc))].sort(), opts.only ? lc(opts.only) : null, opts.ends ? opts.ends.map(lc).sort() : null]);
  const running = POOLS_INFLIGHT.get(k);
  if (running) return running;
  const p = discoverPoolsRaw(tokens, opts).finally(() => POOLS_INFLIGHT.delete(k));
  POOLS_INFLIGHT.set(k, p);
  return p;
}
const POOLS_INFLIGHT = new Map();

async function discoverPoolsRaw(tokens, { only = null, refresh = false, refreshLive = false, ends = null } = {}) {
  const list = [...new Map(tokens.map((t) => [lc(t), getAddress(t)])).values()];
  // ends = [起点, 终点]：findRoutes 的剪枝规则下，「两个中转币之间、且都不是起点 / 终点」的池子永远用不上
  // （第一跳只从起点出发；之后中转币 → 中转币的边只允许直达终点）。这类池子不读储备，省掉大半请求。
  const endSet = ends ? new Set(ends.map(lc)) : null;
  const trueHubs = new Set(Object.values(HUBS).map(lc));
  const usable = (a, b) => !endSet || endSet.has(lc(a)) || endSet.has(lc(b)) || !(trueHubs.has(lc(a)) && trueHubs.has(lc(b)));
  const key = `quick:pools:${only ? `only=${lc(only)}:` : ''}${endSet ? `ends=${[...endSet].sort().join('>')}:` : ''}${list.map(lc).sort().join(',')}`;
  // 按币对缓存池子地址：中转币 / 平台报价币之间的池子几乎不变（30 分钟），含目标代币的币对 5 分钟。
  // refresh：后台定时预热用，忽略缓存重新发现（保证缓存在用户点买入前一直是热的）
  const hubSet = new Set([...Object.values(HUBS).map(lc), ...LONG_CACHE_TOKENS]);
  const pairKey = (a, b) => `quick:pair:${[lc(a), lc(b)].sort().join(':')}`;
  const pairs = [];
  for (let i = 0; i < list.length; i += 1) {
    for (let j = i + 1; j < list.length; j += 1) {
      // only：只看包含该代币的币对（识别用，不需要中转币之间的池子）
      if (only && lc(list[i]) !== lc(only) && lc(list[j]) !== lc(only)) continue;
      if (!usable(list[i], list[j])) continue;
      pairs.push([list[i], list[j]]);
    }
  }
  let pools = [];
  const todo = [];
  for (const [a, b] of pairs) {
    const hit = refresh ? null : cacheGet(pairKey(a, b));
    if (hit) pools.push(...hit);
    else todo.push([a, b]);
  }
  if (todo.length) {
    const calls = [];
    const meta = [];
    for (const [a, b] of todo) {
      calls.push({ to: PANCAKE.v2Factory, data: encodeFunctionData({ abi: factoryV2Abi, functionName: 'getPair', args: [a, b] }) });
      meta.push({ kind: 'v2', a, b });
      for (const fee of V3_FEES) {
        calls.push({ to: PANCAKE.v3Factory, data: encodeFunctionData({ abi: factoryV3Abi, functionName: 'getPool', args: [a, b, fee] }) });
        meta.push({ kind: 'v3', a, b, fee });
      }
    }
    const { results: raws, failed } = await ethCalls(calls);
    if (failed) throw new Error(`池子发现失败：${failed} 个 RPC 请求出错（节点限流或网络问题），请稍后重试`);
    const found = [];
    raws.forEach((raw, i) => {
      if (!raw || raw.length < 66) return;
      const addr = `0x${raw.slice(-40)}`;
      if (isZero(addr)) return;
      found.push({ ...meta[i], pool: getAddress(addr) });
    });
    // 复核池子身份（防止节点返回错位数据造出「幽灵池」）：地址来自官方工厂，
    // V2 / V3 的 token0 都是两币中地址较小的那个，读 token0 一项即可确认这对币，省一半请求
    const ids = await ethCalls(found.map((p) => ({ to: p.pool, data: encodeFunctionData({ abi: pairIdAbi, functionName: 'token0' }) })));
    if (ids.failed) throw new Error(`池子复核失败：${ids.failed} 个 RPC 请求出错，请稍后重试`);
    const verified = found.filter((p, i) => {
      const t0 = ids.results[i];
      if (!t0) return false;
      const lower = lc(p.a) < lc(p.b) ? lc(p.a) : lc(p.b);
      return lc(`0x${t0.slice(-40)}`) === lower;
    });
    for (const [a, b] of todo) {
      const mine = verified.filter((p) => pairKey(p.a, p.b) === pairKey(a, b));
      const bothHubs = hubSet.has(lc(a)) && hubSet.has(lc(b));
      cacheSet(pairKey(a, b), mine, bothHubs ? HUB_POOL_CACHE_MS : POOL_CACHE_MS);
    }
    pools.push(...verified);
  }
  // 储备只缓存几秒：同一次「识别 + 报价」请求内复用，选路足够新；最终下限以链上模拟为准
  const liveKey = `${key}:live`;
  const cachedLive = refreshLive ? null : cacheGet(liveKey);
  if (cachedLive) return cachedLive;
  const { results: states, failed: stateFailed } = await ethCalls(pools.map((p) => ({
    to: p.pool,
    data: p.kind === 'v2'
      ? encodeFunctionData({ abi: pairAbi, functionName: 'getReserves' })
      : encodeFunctionData({ abi: poolAbi, functionName: 'liquidity' }),
  })));
  // 储备读不到就无法判断哪个池子更深：宁可报错，也不在残缺数据上选路
  if (stateFailed) throw new Error(`读取池子储备失败：${stateFailed} 个 RPC 请求出错，请稍后重试`);
  const live = [];
  pools.forEach((p, i) => {
    const raw = states[i];
    if (!raw || raw === '0x') return;
    try {
      if (p.kind === 'v2') {
        const [r0, r1] = decodeFunctionResult({ abi: pairAbi, functionName: 'getReserves', data: raw });
        if (r0 === 0n || r1 === 0n) return;
        // V2 pair 的 token0 是地址较小的那个
        const aIs0 = lc(p.a) < lc(p.b);
        live.push({ ...p, reserveA: aIs0 ? r0 : r1, reserveB: aIs0 ? r1 : r0 });
      } else {
        const liq = decodeFunctionResult({ abi: poolAbi, functionName: 'liquidity', data: raw });
        if (liq === 0n) return;
        live.push({ ...p, liquidity: liq });
      }
    } catch { /* 解码失败的池子忽略 */ }
  });
  // 储备 / 流动性缓存 15 秒：只用于选路排序，最终「最少收到」以链上模拟为准，旧几秒的储备不影响安全
  cacheSet(liveKey, live, LIVE_CACHE_MS);
  return live;
}

/** 单跳报价：V2 用储备本地计算（不打 RPC），V3 走 QuoterV2；不通返回 0n */
async function quoteHop(hop, amountIn) {
  if (amountIn <= 0n) return 0n;
  if (hop.kind === 'v2') {
    const forward = lc(hop.tokenIn) === lc(hop.p.a);
    const rIn = forward ? hop.p.reserveA : hop.p.reserveB;
    const rOut = forward ? hop.p.reserveB : hop.p.reserveA;
    const inFee = amountIn * (10000n - V2_FEE_BPS);
    return (inFee * rOut) / (rIn * 10000n + inFee);
  }
  const data = encodeFunctionData({
    abi: quoterAbi,
    functionName: 'quoteExactInputSingle',
    args: [{ tokenIn: hop.tokenIn, tokenOut: hop.tokenOut, amountIn, fee: hop.fee, sqrtPriceLimitX96: 0n }],
  });
  let raw;
  try {
    raw = await call('eth_call', [{ to: PANCAKE.quoterV2, data }, 'latest']);
  } catch (err) {
    if (isRevertError(err)) return 0n; // 池子流动性不够 / 价格越界：此路不通
    // 限流重试后仍失败 / 网络错误：抛出，不在残缺报价上选路
    throw new Error(`V3 报价 RPC 失败：${err.message}`);
  }
  return decodeFunctionResult({ abi: quoterAbi, functionName: 'quoteExactInputSingle', data: raw })[0];
}

/** 沿固定路径逐跳报价 */
export async function quoteHops(hops, amountIn) {
  let amt = amountIn;
  for (const h of hops) {
    amt = await quoteHop(h, amt);
    if (amt === 0n) return 0n;
  }
  return amt;
}

/**
 * 按金额搜索最优路径（最多 MAX_HOPS 跳）。
 * 每一轮对「上一轮刚改进过的节点」的所有出边报价，节点只保留输出最多的路径。
 * 返回所有到达终点的候选（按输出从高到低）。
 * kinds：限制池子类型（例如只用 ['v2'] 做对比）。
 */
export async function findRoutes({ from, to, amountIn, extras = [], kinds = ['v2', 'v3'], pools }) {
  const fromL = lc(from);
  const toL = lc(to);
  const live = pools || await discoverPools([from, to, ...Object.values(HUBS), ...extras], { ends: [from, to] });
  const adj = new Map();
  for (const p of live) {
    if (!kinds.includes(p.kind)) continue;
    for (const [x, y] of [[p.a, p.b], [p.b, p.a]]) {
      if (!adj.has(lc(x))) adj.set(lc(x), []);
      adj.get(lc(x)).push({ kind: p.kind, fee: p.fee, pool: p.pool, tokenIn: x, tokenOut: y, p });
    }
  }
  const best = new Map([[fromL, { amount: amountIn, hops: [] }]]);
  const finals = [];
  let frontier = [fromL];
  // 剪枝：中转币之间来回换（如 USDC→USDT、USDT→USD1）只允许出现在第一跳（从起点出发）。
  // 稳定币互换池子有十几个、每个都要一次 V3 报价，但「再换一次稳定币」几乎不可能比直接走更划算，
  // 实测这类边占了报价请求的大头（报价 2~4 秒的主要来源）。BNB→USDT→报价币→代币 这类路径不受影响。
  const hubL = new Set(Object.values(HUBS).map(lc));
  for (let round = 0; round < MAX_HOPS && frontier.length; round += 1) {
    const tasks = [];
    for (const u of frontier) {
      const cur = best.get(u);
      const seen = new Set([fromL, ...cur.hops.map((h) => lc(h.tokenOut))]);
      for (const e of adj.get(u) || []) {
        const v = lc(e.tokenOut);
        if (seen.has(v)) continue;
        if (round === MAX_HOPS - 1 && v !== toL) continue; // 最后一轮只看能到终点的边
        if (round > 0 && hubL.has(u) && hubL.has(v) && v !== toL) continue;
        tasks.push({ v, e, cur });
      }
    }
    const outs = await Promise.all(tasks.map((t) => quoteHop(t.e, t.cur.amount)));
    const next = new Set();
    tasks.forEach((t, i) => {
      const out = outs[i];
      if (out <= 0n) return;
      const hops = [...t.cur.hops, t.e];
      if (t.v === toL) finals.push({ hops, out });
      const b = best.get(t.v);
      if (!b || out > b.amount) {
        best.set(t.v, { amount: out, hops });
        if (t.v !== toL) next.add(t.v);
      }
    });
    frontier = [...next];
  }
  const uniq = new Map();
  for (const r of finals) {
    const k = r.hops.map((h) => h.pool).join('>');
    if (!uniq.has(k) || uniq.get(k).out < r.out) uniq.set(k, r);
  }
  return { routes: [...uniq.values()].sort((a, b) => (b.out > a.out ? 1 : b.out < a.out ? -1 : 0)), pools: live };
}

/** 路由文字：BNB → USDT（V3 0.05%）→ oANT（V3 0.25%）→ 蚂蚁（V2） */
export async function routeText(hops, { nativeIn = false, nativeOut = false } = {}) {
  const metas = await Promise.all(hops.map((h) => tokenMeta(h.tokenOut).catch(() => ({ symbol: '?' }))));
  const first = await tokenMeta(hops[0].tokenIn).catch(() => ({ symbol: '?' }));
  const name = (m, isEnd) => (isEnd && m.address && lc(m.address) === lc(WBNB) ? 'BNB' : m.symbol);
  const parts = [nativeIn ? 'BNB' : first.symbol];
  hops.forEach((h, i) => {
    const pool = h.kind === 'v2' ? 'V2' : `V3 ${h.fee / 10000}%`;
    parts.push(`${name(metas[i], nativeOut && i === hops.length - 1)}（${pool}）`);
  });
  return parts.join(' → ');
}

/** 把连续同类的跳合并成一段（V2 一段用 address[]，V3 一段用 packed path） */
function segments(hops) {
  const segs = [];
  for (const h of hops) {
    const last = segs[segs.length - 1];
    if (last && last.kind === h.kind) last.hops.push(h);
    else segs.push({ kind: h.kind, hops: [h] });
  }
  return segs;
}

function v3Path(hops) {
  const types = ['address'];
  const values = [getAddress(hops[0].tokenIn)];
  for (const h of hops) {
    types.push('uint24', 'address');
    values.push(h.fee, getAddress(h.tokenOut));
  }
  return encodePacked(types, values);
}

/**
 * 构造 SmartRouter.multicall 交易。
 * nativeIn：msg.value 付 BNB（首跳 tokenIn 必须是 WBNB，路由器自动包装）
 * nativeOut：最后得到 WBNB 时 unwrapWETH9 成 BNB 发给钱包，下限放在 unwrap 上
 */
export function buildRouterTx({ hops, amountIn, minOut, wallet, nativeIn, nativeOut, deadline }) {
  if (amountIn <= 0n) throw new Error('amountIn 必须大于 0'); // 0 在路由器里表示「用合约余额」，不允许出现在首段
  if (nativeIn && lc(hops[0].tokenIn) !== lc(WBNB)) throw new Error('原生币买入的首跳必须是 WBNB');
  if (nativeOut && lc(hops[hops.length - 1].tokenOut) !== lc(WBNB)) throw new Error('卖出成 BNB 的末跳必须是 WBNB');
  const segs = segments(hops);
  const calls = segs.map((seg, i) => {
    const first = i === 0;
    const last = i === segs.length - 1;
    const amt = first ? amountIn : 0n;
    const toWallet = last && !nativeOut;
    const recipient = toWallet ? getAddress(wallet) : ADDRESS_THIS;
    const min = toWallet ? minOut : 0n;
    if (seg.kind === 'v2') {
      const path = [getAddress(seg.hops[0].tokenIn), ...seg.hops.map((h) => getAddress(h.tokenOut))];
      return encodeFunctionData({ abi: routerAbi, functionName: 'swapExactTokensForTokens', args: [amt, min, path, recipient] });
    }
    return encodeFunctionData({
      abi: routerAbi,
      functionName: 'exactInput',
      args: [{ path: v3Path(seg.hops), recipient, amountIn: amt, amountOutMinimum: min }],
    });
  });
  if (nativeOut) calls.push(encodeFunctionData({ abi: routerAbi, functionName: 'unwrapWETH9', args: [minOut, getAddress(wallet)] }));
  return {
    chainId: '56',
    to: PANCAKE.smartRouter,
    value: nativeIn ? amountIn.toString() : '0',
    inputData: encodeFunctionData({ abi: routerAbi, functionName: 'multicall', args: [deadline, calls] }),
  };
}

function parseV3Path(path) {
  const hex = path.slice(2);
  const tokens = [`0x${hex.slice(0, 40)}`];
  for (let i = 40; i < hex.length; i += 46) tokens.push(`0x${hex.slice(i + 6, i + 46)}`);
  return tokens;
}

/**
 * 广播前复核 calldata：目标 SmartRouter；只含三种调用；中间收款人只能是路由器自身；
 * 首段金额 / 代币与预期一致；最终输出代币、收款人（本钱包）与下限一致；所有代币在白名单内。
 */
export function assertRouterTx(tx, { wallet, tokenIn, tokenOut, amountIn, minOut, nativeIn, nativeOut, allowed }) {
  if (lc(tx.to) !== lc(PANCAKE.smartRouter)) throw new Error('目标合约不是 Pancake SmartRouter');
  if (BigInt(tx.value) !== (nativeIn ? amountIn : 0n)) throw new Error('交易 value 与买入金额不一致');
  if (minOut <= 0n) throw new Error('最少到账为 0，拒绝生成无保护的交易');
  let outer;
  try { outer = decodeFunctionData({ abi: routerAbi, data: tx.inputData }); } catch { throw new Error('calldata 不是 multicall'); }
  if (outer.functionName !== 'multicall') throw new Error('calldata 不是 multicall');
  const inner = outer.args[1].map((d) => decodeFunctionData({ abi: routerAbi, data: d }));
  const allow = new Set([...allowed].map(lc));
  const me = lc(wallet);
  let prevOut = null;
  inner.forEach((c, i) => {
    const last = i === inner.length - 1;
    if (c.functionName === 'unwrapWETH9') {
      if (!last || !nativeOut) throw new Error('unwrapWETH9 只能是卖出成 BNB 的最后一步');
      if (lc(c.args[1]) !== me) throw new Error('unwrap 收款人不是本钱包');
      if (BigInt(c.args[0]) !== minOut) throw new Error('unwrap 下限与计划不一致');
      if (lc(prevOut) !== lc(WBNB)) throw new Error('unwrap 前的输出不是 WBNB');
      return;
    }
    let tokens;
    let recipient;
    let amt;
    let min;
    if (c.functionName === 'swapExactTokensForTokens') {
      [amt, min, tokens, recipient] = c.args;
    } else if (c.functionName === 'exactInput') {
      ({ recipient, amountIn: amt, amountOutMinimum: min } = c.args[0]);
      tokens = parseV3Path(c.args[0].path);
    } else {
      throw new Error(`calldata 含不允许的调用 ${c.functionName}`);
    }
    for (const t of tokens) if (!allow.has(lc(t))) throw new Error(`路径含白名单外代币 ${t}`);
    if (i === 0) {
      if (lc(tokens[0]) !== lc(tokenIn)) throw new Error('首段输入代币与计划不一致');
      if (BigInt(amt) !== amountIn) throw new Error('首段金额与计划不一致');
    } else {
      if (BigInt(amt) !== 0n) throw new Error('中间段必须使用路由器余额（amountIn=0）');
      if (lc(tokens[0]) !== lc(prevOut)) throw new Error('路径不连续');
    }
    const finalSwap = nativeOut ? i === inner.length - 2 : last;
    if (finalSwap && !nativeOut) {
      if (lc(recipient) !== me) throw new Error('最终收款人不是本钱包');
      if (BigInt(min) !== minOut) throw new Error('最终下限与计划不一致');
    } else if (lc(recipient) !== lc(ADDRESS_THIS)) {
      throw new Error('中间段收款人必须是路由器自身');
    }
    prevOut = tokens[tokens.length - 1];
  });
  if (lc(prevOut) !== lc(nativeOut ? WBNB : tokenOut)) throw new Error('最终输出代币与计划不一致');
  if (nativeOut && inner[inner.length - 1].functionName !== 'unwrapWETH9') throw new Error('卖出成 BNB 缺少 unwrap');
}

/** 以钱包身份模拟 multicall，返回最终到账（最后一段 swap 的返回值；V2 段按收款人余额差计算，含转账税） */
async function simulateRouter(tx, wallet, { overrideBalance = false, stateOverride = null } = {}) {
  const params = [{ from: wallet, to: tx.to, value: toHex(BigInt(tx.value)), data: tx.inputData }, 'latest'];
  // stateOverride：授权前模拟卖出用的临时授权（simoverride.mjs）；可与余额覆盖合并
  const ov = { ...(stateOverride || {}), ...(overrideBalance ? { [wallet]: { balance: toHex(BigInt(tx.value) + 10n ** 18n) } } : {}) };
  if (Object.keys(ov).length) params.push(ov);
  try {
    const raw = await call('eth_call', params);
    const results = decodeFunctionResult({ abi: routerAbi, functionName: 'multicall', data: raw });
    const swaps = results.filter((r) => r && r !== '0x');
    const out = BigInt(swaps[swaps.length - 1].slice(0, 66));
    return { ok: true, out };
  } catch (err) {
    return { ok: false, reason: String(err.message || 'execution reverted').replace(/:\s*0x[0-9a-fA-F]*$/, '').slice(0, 200) };
  }
}

/**
 * 生成一次路由兑换（不广播）：选路 → 冲击检查 → 模拟真实到账 → 按滑点算下限 → 构造并复核 calldata。
 * tokenIn / tokenOut 为 ERC20 地址；nativeIn / nativeOut 表示用 BNB 付 / 收 BNB（此时对应端是 WBNB）。
 * skipSim：卖出且授权不足时无法模拟，只给报价（调用方先授权、再重新生成）。
 */
export async function routeSwap({
  wallet, tokenIn, tokenOut, amountIn, slippageBps, extras = [], nativeIn = false, nativeOut = false,
  skipSim = false, overrideBalance = false, maxImpactBps = MAX_IMPACT_BPS, maxLossBps = MAX_LOSS_BPS, stateOverride = null,
}) {
  // 调用方只能收紧护栏（狙击用更严的冲击 / 损耗上限，避开小池子和高手续费池），不能放宽
  maxImpactBps = Math.min(Number(maxImpactBps) || MAX_IMPACT_BPS, MAX_IMPACT_BPS);
  maxLossBps = Math.min(Number(maxLossBps) || MAX_LOSS_BPS, MAX_LOSS_BPS);
  const slip = BigInt(slippageBps);
  const allowedExtras = extras.filter((x) => /^0x[0-9a-fA-F]{40}$/.test(String(x)));
  const deadline = BigInt(Math.floor(Date.now() / 1000) + DEADLINE_SEC);
  const allowed = new Set([tokenIn, tokenOut, ...Object.values(HUBS), ...allowedExtras].map(lc));
  const opts = { nativeIn, nativeOut };

  // 固定路由（见 routebook.mjs）：先只走固定路径；不通就这一次改用完整搜索，并累计失败（连续多次会暂停固定）
  const pin = getPin(tokenIn, tokenOut);
  let pinned = null;
  let pinNote = null;
  if (pin) {
    try {
      pinned = await pinnedRoute(pin, { amountIn, allowed, skipSim, wallet, opts, deadline, overrideBalance, stateOverride });
      pinOk(tokenIn, tokenOut);
      if (pinNeedsRecheck(pin)) recheckPin(pin, { tokenIn, tokenOut, amountIn, allowedExtras, pinnedOut: pinned.out, opts });
    } catch (err) {
      pinNote = err.message;
      pinFailed(tokenIn, tokenOut, err.message);
    }
  }

  let routes;
  let v2only = { routes: [] };
  if (pinned) {
    routes = [pinned];
  } else {
    const pools = await discoverPools([tokenIn, tokenOut, ...Object.values(HUBS), ...allowedExtras], { ends: [tokenIn, tokenOut] });
    [{ routes }, v2only] = await Promise.all([
      findRoutes({ from: tokenIn, to: tokenOut, amountIn, pools }),
      findRoutes({ from: tokenIn, to: tokenOut, amountIn, pools, kinds: ['v2'] }),
    ]);
  }
  if (!routes.length) {
    throw new Error('没有找到可用路由：该代币与 WBNB / 主流稳定币 / 平台报价币之间都没有 PancakeSwap V2/V3 流动性');
  }
  const outMeta = await tokenMeta(tokenOut);
  const outDec = nativeOut ? 18 : outMeta.decimals;
  const outSym = nativeOut ? 'BNB' : outMeta.symbol;

  const v2Best = v2only.routes[0] || null;

  // 按「真实到账」选路：池子报价不含转账税，税币走不同池子（V2 按余额差结算 / V3 按池子数量）
  // 实际到账可能排序相反。前 SIM_TOP 条并行模拟，取模拟到账最多的；都失败再往后试。
  const SIM_TOP = 3;
  const failures = [];
  let chosen = null;
  let simOut = null;
  // 价格冲击的小额探测和模拟互不依赖：先对报价最优的那条并行发起（绝大多数情况它就是最终选中的路由）
  const probeAmt = amountIn / 1000n;
  const probeFor = new Map();
  if (probeAmt > 0n && routes[0]) probeFor.set(routes[0], quoteHops(routes[0].hops, probeAmt));
  if (pinned) {
    chosen = pinned; // 固定路径已在 pinnedRoute 里模拟过（skipSim 时除外）
    simOut = pinned.sim ?? null;
  } else if (skipSim) {
    chosen = routes[0];
  } else {
    for (let start = 0; start < Math.min(routes.length, 6) && !chosen; start += SIM_TOP) {
      const batch = routes.slice(start, start + SIM_TOP);
      const sims = await Promise.all(batch.map((r) => simulateRouter(
        buildRouterTx({ hops: r.hops, amountIn, minOut: 1n, wallet, ...opts, deadline }), wallet, { overrideBalance, stateOverride },
      )));
      for (let i = 0; i < batch.length; i += 1) {
        const r = batch[i];
        const s = sims[i];
        if (s.ok) {
          r.sim = s.out;
          if (!chosen || s.out > simOut) { chosen = r; simOut = s.out; }
        } else {
          r.simError = s.reason;
          failures.push(`${await routeText(r.hops, opts)}：${s.reason}`);
        }
      }
    }
  }
  if (!chosen) throw new Error(`所有候选路由模拟都失败（可能是代币限制交易 / 黑名单 / 貔貅）：${failures.join('；')}`);

  const alternatives = await Promise.all(routes.slice(0, 6).map(async (r) => ({
    route: await routeText(r.hops, opts),
    chosen: r === chosen,
    outText: `${pretty(r.sim ?? r.out, outDec)} ${outSym}${r.sim != null ? '（模拟到账）' : r.simError ? '（模拟失败）' : '（池子报价）'}`,
  })));

  const checks = [];
  const warnings = [];
  const plainRoute = await routeText(chosen.hops, opts);
  const route = pinned ? `📌 ${plainRoute}` : plainRoute;
  if (pinned) checks.push({ name: '固定路由', ok: true, detail: '按已固定的路径报价 + 模拟（不做完整搜索）' });
  if (pinNote) warnings.push(`固定路由这次走不通（${pinNote}），已改用自动搜索的路由；连续 ${PIN_MAX_FAILS} 次不通会自动暂停固定`);

  // 价格冲击：同一路径用 1/1000 金额得到边际价（选中的是最优报价那条时直接用已并行算好的结果）
  const probe = probeAmt;
  let impactBps = null;
  if (probe > 0n) {
    const spot = await (probeFor.get(chosen) ?? quoteHops(chosen.hops, probe));
    if (spot > 0n) {
      const ideal = spot * 1000n;
      impactBps = ideal > chosen.out ? Number(((ideal - chosen.out) * 10000n) / ideal) : 0;
    }
  }
  checks.push({ name: '价格冲击', ok: impactBps == null || impactBps <= maxImpactBps, detail: impactBps == null ? '无法估算' : `${impactBps / 100}%（上限 ${maxImpactBps / 100}%）` });
  if (impactBps != null && impactBps > maxImpactBps) {
    throw new Error(`价格冲击 ${impactBps / 100}% 超过上限 ${maxImpactBps / 100}%：池子太小，按这个金额会明显亏损。请减少金额或分批买卖（最优路由：${route}）`);
  }

  // 实测损耗：模拟到账 vs 池子报价（转账税 / 通缩）
  let lossBps = null;
  if (simOut != null) {
    lossBps = simOut >= chosen.out ? 0 : Number(((chosen.out - simOut) * 10000n) / chosen.out);
    checks.push({ name: '模拟到账', ok: true, detail: `${pretty(simOut, outDec)} ${outSym}（较池子报价少 ${lossBps / 100}%）` });
    if (lossBps > maxLossBps) {
      throw new Error(`模拟到账比池子报价少 ${lossBps / 100}%（> ${maxLossBps / 100}%），疑似高税 / 高手续费路径，已拒绝`);
    }
    if (lossBps >= 50) warnings.push(`实测转账损耗约 ${lossBps / 100}%（税币），预计到账已按模拟结果计算`);
  } else {
    warnings.push('未能模拟真实到账（需要先授权）：授权完成后会自动重新报价并模拟');
  }
  const lastHop = chosen.hops[chosen.hops.length - 1];
  if (!nativeOut && lastHop.kind === 'v3') warnings.push('最后一跳是 V3 池：若代币有转账税，实际到账会比显示略少');

  const expected = simOut ?? chosen.out;
  const minOut = (expected * (10000n - slip)) / 10000n;
  const tx = buildRouterTx({ hops: chosen.hops, amountIn, minOut, wallet, ...opts, deadline });
  assertRouterTx(tx, { wallet, tokenIn, tokenOut, amountIn, minOut, nativeIn, nativeOut, allowed });
  // 登记这笔的路径：广播后等回执记成功 / 失败（routebook.noteSent）
  rememberTx(tx.inputData, {
    tokenIn, tokenOut, hops: serialHops(chosen.hops), text: plainRoute,
    inSym: nativeIn ? 'BNB' : (await tokenMeta(tokenIn).catch(() => null))?.symbol || null, outSym,
  });

  if (v2Best && v2Best.out * 10000n < chosen.out * 9500n) {
    warnings.push(`普通 V2 路由只能拿到 ${pretty(v2Best.out, outDec)} ${outSym}（${await routeText(v2Best.hops, opts)}），本路由多拿 ${chosen.out > 0n && v2Best.out > 0n ? `${(Number(chosen.out) / Number(v2Best.out)).toFixed(1)} 倍` : '很多'}，已自动避开小池子`);
  }
  checks.push({ name: '路由', ok: true, detail: route });

  return {
    tx, route, hops: chosen.hops.length, pinned: Boolean(pinned), pathKey: pathKeyOf(chosen.hops),
    quoteOut: chosen.out, expected, minOut, outDecimals: outDec, outSymbol: outSym,
    impactBps, lossBps, alternatives,
    v2Only: v2Best ? { route: await routeText(v2Best.hops, opts), outText: `${pretty(v2Best.out, outDec)} ${outSym}` } : null,
    checks, warnings, deadline: Number(deadline),
  };
}

/**
 * 只读估值：amountIn 个 tokenIn 现在按最优路由值多少 tokenOut（池子报价，不模拟、不含转账税）。
 * 用于报价币库存：BNB 金额 ⇄ 报价币数量的换算、库存折合 BNB。同币直接返回原数；没有路由返回 0n。
 * 池子集合与 routeSwap(WBNB ⇄ 报价币, extras=[报价币]) 相同，命中同一份缓存。
 */
export async function estimateOut(tokenIn, tokenOut, amountIn) {
  const a = BigInt(amountIn);
  if (a <= 0n) return 0n;
  if (lc(tokenIn) === lc(tokenOut)) return a;
  // 路由记忆：GANG / NVDAB / BNCB 这类固定底池的最优路径几乎不变，ROUTE_MEMO_MS 内只沿记住的路径重新报价
  // （V2 跳重读一次储备、V3 跳一次 QuoterV2，共 1~3 个请求，而完整搜索要几十个）。
  // 只用于估值；真正下单的 routeSwap 每次都完整搜索 + 链上模拟，不受影响。
  // 按金额数量级分开记（小额走浅池最好，大额可能就不是）
  const pin = getPin(tokenIn, tokenOut);
  if (pin) {
    const out = await liveHops(pin.hops).then((h) => quoteHops(h, a)).catch(() => 0n);
    if (out > 0n) return out; // 不通时不在这里记失败（估值不算交易），照常走下面的搜索
  }
  const memoKey = `${lc(tokenIn)}>${lc(tokenOut)}:${a.toString().length}`;
  const memo = routeMemo.get(memoKey);
  if (memo && Date.now() - memo.at < ROUTE_MEMO_MS) {
    const out = await quoteHops(await freshHops(memo.hops), a).catch(() => 0n);
    if (out > 0n) return out;
    routeMemo.delete(memoKey); // 路径不通了（池子被抽干等）：退回完整搜索
  }
  const other = lc(tokenIn) === lc(WBNB) ? tokenOut : tokenIn;
  const pools = await discoverPools([tokenIn, tokenOut, ...Object.values(HUBS), other], { ends: [tokenIn, tokenOut] });
  const { routes } = await findRoutes({ from: tokenIn, to: tokenOut, amountIn: a, pools });
  if (routes[0]) routeMemo.set(memoKey, { hops: routes[0].hops, at: Date.now() });
  return routes[0]?.out ?? 0n;
}

const ROUTE_MEMO_MS = 10 * 60 * 1000; // 到期后完整搜索一次，换到更好的路径
const routeMemo = new Map(); // 'in>out:金额位数' → { hops, at }

/** 记住的路径里 V2 跳的储备是旧的：重读这几个 pair 的储备（V3 跳报价时本来就现查） */
async function freshHops(hops) {
  const v2 = hops.filter((h) => h.kind === 'v2');
  if (!v2.length) return hops;
  const { results, failed } = await ethCalls(v2.map((h) => ({ to: h.pool, data: encodeFunctionData({ abi: pairAbi, functionName: 'getReserves' }) })));
  if (failed) throw new Error('读取储备失败');
  const fresh = new Map();
  v2.forEach((h, i) => {
    const [r0, r1] = decodeFunctionResult({ abi: pairAbi, functionName: 'getReserves', data: results[i] });
    const aIs0 = lc(h.p.a) < lc(h.p.b);
    fresh.set(h.pool, { ...h.p, reserveA: aIs0 ? r0 : r1, reserveB: aIs0 ? r1 : r0 });
  });
  return hops.map((h) => (h.kind === 'v2' ? { ...h, p: fresh.get(h.pool) } : h));
}

/** 记录里的路径 → 可报价的 hop（V2 储备现读） */
async function liveHops(saved) {
  const hops = await freshHops(saved.map((h) => ({
    kind: h.kind, fee: h.kind === 'v3' ? Number(h.fee) : undefined, pool: h.pool, tokenIn: h.tokenIn, tokenOut: h.tokenOut,
    p: { kind: h.kind, a: h.a, b: h.b, fee: h.fee, pool: h.pool },
  })));
  for (const h of hops) {
    if (h.kind === 'v2' && (!h.p.reserveA || !h.p.reserveB)) throw new Error(`V2 池子 ${h.pool.slice(0, 10)}… 已没有流动性`);
  }
  return hops;
}

/**
 * 沿固定路径报价（+ 不跳过时模拟真实到账）。任何一步不通都抛错，由调用方改用完整搜索。
 * 路径上的代币必须都在本次交易的白名单里（白名单变了就不用这条固定路径）。
 */
async function pinnedRoute(pin, { amountIn, allowed, skipSim, wallet, opts, deadline, overrideBalance, stateOverride }) {
  for (const h of pin.hops) {
    if (!allowed.has(lc(h.tokenIn)) || !allowed.has(lc(h.tokenOut))) throw new Error(`路径经过本次不在白名单的代币 ${h.tokenOut}`);
  }
  if (opts.nativeIn && lc(pin.hops[0].tokenIn) !== lc(WBNB)) throw new Error('固定路径的首跳不是 WBNB');
  const hops = await liveHops(pin.hops);
  const out = await quoteHops(hops, amountIn);
  if (out <= 0n) throw new Error('固定路径报价为 0（池子流动性不足或已下线）');
  const r = { hops, out };
  if (!skipSim) {
    const s = await simulateRouter(buildRouterTx({ hops, amountIn, minOut: 1n, wallet, ...opts, deadline }), wallet, { overrideBalance, stateOverride });
    if (!s.ok) throw new Error(`固定路径模拟失败：${s.reason}`);
    r.sim = s.out;
  }
  return r;
}

/** 固定期间定期在后台完整搜索一次：有明显更好的路径（池子报价多 0.5% 以上）就记下来提示用户，不自动换 */
function recheckPin(pin, { tokenIn, tokenOut, amountIn, allowedExtras, pinnedOut, opts }) {
  pinChecked(tokenIn, tokenOut, pin.better || null); // 先占位，避免并发多次复查
  runBackground(async () => {
    const pools = await discoverPools([tokenIn, tokenOut, ...Object.values(HUBS), ...allowedExtras], { ends: [tokenIn, tokenOut] });
    const { routes } = await findRoutes({ from: tokenIn, to: tokenOut, amountIn, pools });
    const best = routes[0];
    if (!best || pathKeyOf(best.hops) === pin.pathKey || pinnedOut <= 0n) { pinChecked(tokenIn, tokenOut, null); return; }
    const bps = Number(((best.out - pinnedOut) * 10000n) / pinnedOut);
    pinChecked(tokenIn, tokenOut, bps >= 50 ? { text: await routeText(best.hops, opts), bps, pathKey: pathKeyOf(best.hops) } : null);
  }).catch(() => null);
}

/** 外盘（已毕业 / 普通代币）买卖计划：BNB ⇄ 代币，经 SmartRouter 一笔完成 */
export async function planDexTrade({ wallet, token, side, amount, percent, slippageBps, extras = [] }) {
  const meta = await tokenMeta(token);
  if (lc(token) === lc(WBNB)) throw new Error('目标代币不能是 WBNB');
  const checks = [];
  const warnings = [];

  if (side === 'buy') {
    const amountIn = BigInt(parseAmount(amount, 18));
    const balance = BigInt(await call('eth_getBalance', [wallet, 'latest']));
    const enough = balance >= amountIn;
    checks.push({ name: 'BNB 余额', ok: enough, detail: `${pretty(balance)} BNB，需付 ${human(amountIn)} BNB（另需 gas）` });
    if (!enough) warnings.push(`钱包 BNB 余额不足（${pretty(balance)}），已用模拟余额报价；执行前请先充值，否则会失败`);
    const r = await routeSwap({
      wallet, tokenIn: WBNB, tokenOut: token, amountIn, slippageBps, extras, nativeIn: true, overrideBalance: !enough,
    });
    return {
      platform: 'dex', side, token: meta.address, symbol: meta.symbol, decimals: meta.decimals,
      pay: { raw: amountIn.toString(), text: `${human(amountIn)} BNB` }, bnbEquivWei: '0', // 全部 BNB 在交易 value 里
      receive: { expected: pretty(r.expected, meta.decimals), min: pretty(r.minOut, meta.decimals), minRaw: r.minOut.toString(), symbol: meta.symbol },
      route: r.route, alternatives: r.alternatives, v2Only: r.v2Only, impactBps: r.impactBps, lossBps: r.lossBps,
      checks: [...checks, ...r.checks], warnings: [...warnings, ...r.warnings], note: null,
      steps: [{ kind: 'swap', label: `买入：${r.route}`, tx: r.tx }],
    };
  }

  const [balance, allowance] = await Promise.all([
    read(token, erc20Abi, 'balanceOf', [wallet]),
    read(token, erc20Abi, 'allowance', [wallet, PANCAKE.smartRouter]),
  ]);
  const amountIn = percent
    ? (BigInt(balance) * BigInt(Math.round(Number(percent) * 100))) / 10000n
    : BigInt(parseAmount(amount, meta.decimals));
  if (amountIn <= 0n) throw new Error(`钱包没有 ${meta.symbol} 持仓`);
  if (amountIn > BigInt(balance)) throw new Error(`${meta.symbol} 余额不足：持有 ${pretty(balance, meta.decimals)}，要卖 ${pretty(amountIn, meta.decimals)}`);
  checks.push({ name: `${meta.symbol} 持仓`, ok: true, detail: `${pretty(balance, meta.decimals)}，卖出 ${pretty(amountIn, meta.decimals)}${percent ? `（${percent}%）` : ''}` });
  const needApprove = BigInt(allowance) < amountIn;
  checks.push({ name: '授权 SmartRouter', ok: !needApprove, detail: needApprove ? '需要先授权本次卖出数量' : '足够' });
  // 授权不够时用状态覆盖临时授权本次数量，照样模拟真实到账（含转账税）：一次给出「授权 + 卖出」两步，
  // 授权上链后直接执行卖出。以前只给一步授权、上链后重新报价，一键执行会被「步骤数超过确认时的 1 步」拦下
  const stateOverride = needApprove ? await allowanceOverride(token, wallet, PANCAKE.smartRouter, amountIn).catch(() => null) : null;

  const r = await routeSwap({
    wallet, tokenIn: token, tokenOut: WBNB, amountIn, slippageBps, extras, nativeOut: true, skipSim: needApprove && !stateOverride, stateOverride,
  });
  const base = {
    platform: 'dex', side, token: meta.address, symbol: meta.symbol, decimals: meta.decimals,
    pay: { raw: amountIn.toString(), text: `${pretty(amountIn, meta.decimals)} ${meta.symbol}` },
    receive: { expected: pretty(r.expected), min: pretty(r.minOut), minRaw: needApprove && !stateOverride ? null : r.minOut.toString(), symbol: 'BNB' },
    route: r.route, alternatives: r.alternatives, v2Only: r.v2Only, impactBps: r.impactBps, lossBps: r.lossBps,
    checks: [...checks, ...r.checks], warnings: [...warnings, ...r.warnings],
  };
  const approveTx = { chainId: '56', to: meta.address, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [PANCAKE.smartRouter, amountIn] }) };
  if (needApprove && stateOverride) {
    return {
      ...base,
      note: `先授权 ${pretty(amountIn, meta.decimals)} ${meta.symbol} 给 Pancake SmartRouter（只授权本次数量），上链后直接卖出（卖出已按授权后的状态模拟过）`,
      steps: [
        { kind: 'approve', label: `授权 ${pretty(amountIn, meta.decimals)} ${meta.symbol} → SmartRouter（只授权本次数量）`, tx: approveTx },
        { kind: 'swap', label: `卖出：${r.route}`, tx: r.tx },
      ],
    };
  }
  if (needApprove) {
    return {
      ...base,
      note: `先授权 ${pretty(amountIn, meta.decimals)} ${meta.symbol} 给 Pancake SmartRouter（只授权本次数量）。这个代币没法在授权前模拟卖出：授权上链后再点一次卖出`,
      steps: [{ kind: 'approve', label: `授权 ${pretty(amountIn, meta.decimals)} ${meta.symbol} → SmartRouter`, replan: true, tx: approveTx }],
    };
  }
  return { ...base, note: null, steps: [{ kind: 'swap', label: `卖出：${r.route}`, tx: r.tx }] };
}

/** 外盘识别：代币有合约、可读 decimals，且与白名单/平台报价币之间存在流动性 */
export async function detectDex(token, extras = []) {
  const code = await call('eth_getCode', [token, 'latest']);
  if (!code || code === '0x') return null;
  const meta = await tokenMeta(token).catch(() => null);
  if (!meta) return null;
  // 识别只需要「这个代币有没有活池子」：只查包含它的币对，不读中转币之间的池子
  const own = await discoverPools([token, ...Object.values(HUBS), ...extras], { only: token });
  return {
    match: true,
    tradable: own.length > 0,
    phase: own.length ? `外盘 ${own.length} 个池子` : '无外盘流动性',
    payUnit: 'BNB',
    extras,
    notes: own.length ? [] : ['PancakeSwap 上没有找到该代币与 WBNB / 稳定币 / 平台报价币的池子'],
  };
}

function parseAmount(value, decimals) {
  const s = String(value ?? '').trim();
  if (!/^\d+(\.\d+)?$/.test(s) || !/[1-9]/.test(s)) throw new Error('数量需要大于 0 的十进制数');
  const [whole, frac = ''] = s.split('.');
  if (frac.length > decimals) throw new Error(`小数位超过 ${decimals} 位`);
  return (BigInt(whole) * 10n ** BigInt(decimals) + BigInt((frac + '0'.repeat(decimals)).slice(0, decimals) || '0')).toString();
}
