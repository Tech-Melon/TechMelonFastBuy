/**
 * 本系统买入的持仓（插件持仓条只显示这些，不显示钱包里别处来的代币）：
 *   - gang V2 / V3 狙击（`gangsnipe.buy` / `gangsnipe3.buy`）、自动打新（`fairauto.mint`）；
 *   - Four 狙击（sniper.targets 里 stage = bought 的钱包）；
 *   - 快捷交易 / 插件的一键买入与直接买入（`oneclick.start` 是买入 + `oneclick.end` = done），不含报价币库存备货。
 * 只记「哪个钱包、哪个币、什么时候、从哪买的」；余额照常读链上（卖光了就显示 0）。
 * 落盘 webui/positions.json（600，gitignore，不随代码同步）：执行日志轮转掉的老记录也不丢。
 * 启动时扫一遍执行日志 + Four 记录（按事件去重，可重复执行），之后 onJournal 实时追加。
 */
import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJournal, onJournal } from '../journal.mjs';

const FILE = process.env.POSITIONS_FILE || path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'positions.json');
const SEEN_MAX = 5000;
const SRC = { gangsnipe: '狙击 V2', gangsnipe3: '狙击 V3', fairauto: '自动打新', four: 'Four 狙击', oneclick: '手动买入' };
const lc = (a) => String(a || '').toLowerCase();
const ADDR = /^0x[0-9a-f]{40}$/;

let book = { version: 1, wallets: {}, seen: [] };
try {
  const d = JSON.parse(readFileSync(FILE, 'utf8'));
  if (d && typeof d.wallets === 'object') book = { ...book, ...d, seen: Array.isArray(d.seen) ? d.seen : [] };
} catch { /* 还没有记录 */ }
const seen = new Set(book.seen);

let chain = Promise.resolve();
let timer = null;
function flush() {
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    book.seen = [...seen].slice(-SEEN_MAX);
    const body = JSON.stringify({ ...book, savedAt: new Date().toISOString() }, null, 2);
    chain = chain.then(async () => {
      const tmp = `${FILE}.${process.pid}.tmp`;
      try { await writeFile(tmp, body, { encoding: 'utf8', mode: 0o600 }); await rename(tmp, FILE); } catch (err) { console.warn(`[positions] 保存失败：${err.message}`); }
    });
  }, 1500);
  timer.unref?.();
}

/** 记一笔买入（key 去重：同一事件重复扫描不重复计数） */
function add(walletId, token, src, at, key) {
  const t = lc(token);
  if (!walletId || !ADDR.test(t)) return;
  if (key) { if (seen.has(key)) return; seen.add(key); }
  const w = book.wallets[walletId] || (book.wallets[walletId] = {});
  const p = w[t] || (w[t] = { token: t, firstAt: at, lastAt: at, buys: 0, sources: {} });
  p.buys += 1;
  p.sources[src] = (p.sources[src] || 0) + 1;
  if (!p.firstAt || at < p.firstAt) p.firstAt = at;
  if (!p.lastAt || at > p.lastAt) p.lastAt = at;
  flush();
}

const isBuyStart = (r) => r.platform !== 'inventory' && (r.side ? r.side === 'buy' : r.amount != null && r.amount !== '');
const pendingJobs = new Map(); // jobId → oneclick.start（等结束）

function onRow(r) {
  const [mod, kind] = String(r.type || '').split('.');
  if ((mod === 'gangsnipe' || mod === 'gangsnipe3') && kind === 'buy') add(r.walletId, r.token, mod, r.at, `${r.type}:${r.at}:${r.walletId}:${lc(r.token)}`);
  else if (r.type === 'fairauto.mint') add(r.walletId, r.token, 'fairauto', r.at, `${r.type}:${r.at}:${r.walletId}:${lc(r.token)}`);
  else if (r.type === 'oneclick.start' && isBuyStart(r)) pendingJobs.set(r.jobId, r);
  else if (r.type === 'oneclick.end') {
    const s = pendingJobs.get(r.jobId);
    pendingJobs.delete(r.jobId);
    if (s && r.state === 'done') add(s.walletId, s.planToken || s.token, 'oneclick', r.at, `oneclick:${r.jobId}`);
  }
}

/** Four 狙击记录（与狙击看板同一口径）：每个钱包 stage = bought */
export function addFourTargets(targets) {
  for (const t of targets || []) {
    const at = new Date(Number(t.detectedAt) || Date.now()).toISOString();
    const list = t.wallets && Object.keys(t.wallets).length
      ? Object.entries(t.wallets)
      : (t.stage === 'bought' ? [[t.plans?.[0]?.walletId, { stage: 'bought' }]] : []);
    for (const [walletId, w] of list) if (w?.stage === 'bought') add(walletId, t.token, 'four', at, `four:${lc(t.token)}:${walletId}`);
  }
}

let started = false;
/** 启动：扫一遍执行日志（去重），然后实时跟进 */
export async function startPositions({ fourTargets } = {}) {
  if (started) return;
  started = true;
  onJournal(onRow);
  for (const r of await readJournal(Infinity, { withRotated: true })) onRow(r);
  if (fourTargets) addFourTargets(fourTargets());
}

/** 这个钱包的这个币是不是本系统买的；是则返回记录 */
export function managed(walletId, token) {
  return book.wallets[walletId]?.[lc(token)] || null;
}

/** 所选钱包里本系统买过的币（插件本地判断用：不在列表里就不用问持仓） */
export function managedTokens(walletIds) {
  const out = new Set();
  for (const id of walletIds) for (const t of Object.keys(book.wallets[id] || {})) out.add(t);
  return [...out];
}

export const sourceText = (sources) => Object.entries(sources || {}).map(([k, n]) => `${SRC[k] || k}${n > 1 ? ` ×${n}` : ''}`).join('、');
