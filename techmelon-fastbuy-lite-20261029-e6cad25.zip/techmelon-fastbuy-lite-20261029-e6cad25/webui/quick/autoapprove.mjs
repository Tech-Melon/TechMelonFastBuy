/**
 * 买入后自动授权（docs/AUTOMATION_RULES.md 硬性规则 3 第九个例外，2026-10-29 用户确认）：
 * 一键执行（交易台 / 插件的一键买入、直接买入，以及狙击走普通流程的买入）上链完成后，
 * 自动把刚买到的代币授权给「卖出时要用的合约」，额度 = 钱包当前持有数量（不是无上限），之后卖出只剩一笔。
 *
 * 只在「资金与授权」页打开开关（config.autoApprove === true）时生效，默认关。每笔：
 *   1. 按当前阶段识别平台，取该平台卖出用的合约（只能是下面 SPENDERS 里的固定地址 / 已启用且核验通过的 LaunchpadV3）；
 *      Flap 曲线（卖份额，不需要授权）和识别不出的直接跳过；
 *   2. 读链上余额与现有授权：授权已经 ≥ 余额就跳过；
 *   3. 生成 approve(spender, 余额)，广播前复核：目标是这个代币、函数只能是 approve、spender 在白名单且与第 1 步一致、
 *      额度 = 余额（> 0，绝不是无上限）、value = 0；
 *   4. 币安预览：模拟不过、或币安预判要 App 确认（requireConfirmation，挂起会锁住钱包的所有交易）都不执行，只记日志；
 *   5. 广播（value = 0，不占每日买入上限），写执行日志 autoapprove.*。不重试。
 * 代币之后毕业换了平台（内盘 → Pancake）授权对象会变，那时卖出计划会照常带一步「授权本次数量」。
 */
import { decodeFunctionData, encodeFunctionData, parseAbi, getAddress } from 'viem';
import { getConfig, rpcFor } from '../config.mjs';
import { journal } from '../journal.mjs';
import { detectAll } from './registry.mjs';
import { PANCAKE, tokenMeta, pretty } from './router.mjs';
import { LAUNCHPAD_V2 } from '../agent/gang.mjs';
import { OPENFOUR } from '../four/openfour.mjs';
import { FLAP_PORTAL } from './platforms/flaptax.mjs';
import { activeDeployment } from './gangv3.mjs';

const lc = (a) => String(a || '').toLowerCase();
const UNLIMITED = 2n ** 255n;
const BALANCE_WAIT_MS = 6000; // 买入刚上链，个别节点余额还没更新：按绝对时间最多等这么久
const MAX_EVENTS = 40;
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
]);

/** 平台 → 卖出时的授权对象（与各平台卖出计划里的 approve spender 一致） */
const SPENDERS = {
  four: { address: OPENFOUR.core, label: 'Four Core' },
  gang: { address: LAUNCHPAD_V2, label: 'gang LaunchpadV2' },
  flaptax: { address: FLAP_PORTAL, label: 'Flap Portal' },
  dex: { address: PANCAKE.smartRouter, label: 'Pancake SmartRouter' },
};

async function spenderFor(platform) {
  if (platform === 'gangv3') {
    const dep = await activeDeployment().catch(() => null);
    return dep?.pad ? { address: getAddress(dep.pad), label: 'gang LaunchpadV3' } : null;
  }
  return SPENDERS[platform] || null;
}

/** 所有可能的授权对象（复核用）：固定地址 + 当前启用的 LaunchpadV3 */
async function allowedSpenders() {
  const set = new Set(Object.values(SPENDERS).map((s) => lc(s.address)));
  const v3 = await spenderFor('gangv3');
  if (v3) set.add(lc(v3.address));
  return set;
}

/** 广播前复核（导出给评测用） */
export function assertAutoApproveTx(tx, { token, spender, amount, allowed }) {
  if (lc(tx.to) !== lc(token)) throw new Error('授权交易的目标不是这个代币');
  if (BigInt(tx.value || '0') !== 0n) throw new Error('授权不应附带 BNB');
  let d;
  try { d = decodeFunctionData({ abi: erc20Abi, data: tx.inputData }); } catch { throw new Error('calldata 不是 approve'); }
  if (d.functionName !== 'approve') throw new Error('calldata 不是 approve');
  if (lc(d.args[0]) !== lc(spender) || !allowed.has(lc(d.args[0]))) throw new Error(`授权对象 ${d.args[0]} 不在卖出合约白名单里`);
  const amt = BigInt(d.args[1]);
  if (amt !== amount || amt <= 0n) throw new Error('授权额度与持有数量不一致');
  if (amt >= UNLIMITED) throw new Error('不允许无上限授权');
}

const st = { events: [], inflight: new Set() };
function note(type, walletId, token, text, extra = {}) {
  st.events.unshift({ at: new Date().toISOString(), type, walletId, token, text, ...extra });
  st.events = st.events.slice(0, MAX_EVENTS);
  journal(`autoapprove.${type}`, { walletId, token, text, ...extra });
}

export async function autoApproveEnabled() {
  return (await getConfig()).autoApprove === true;
}

export function autoApproveStatus() {
  return { events: st.events };
}

async function read(token, fn, args) {
  const data = await rpcFor('56', 'eth_call', [{ to: token, data: encodeFunctionData({ abi: erc20Abi, functionName: fn, args }) }, 'latest']);
  return BigInt(data);
}

/**
 * 一键任务结束时调用（server.mjs startQuickJob 的 onDone）。只处理完成的买入；deps = { previewStep, doExecute }。
 * 返回 Promise（评测可以 await），失败只记日志不抛出。
 */
export async function afterBuy(job, ctx, deps) {
  if (job.state !== 'done' || ctx.req?.side !== 'buy' || ctx.plan?.platform === 'inventory') return null;
  if (!(await autoApproveEnabled())) return null;
  const token = ctx.plan?.token || ctx.req?.address;
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(token))) return null;
  const key = `${ctx.walletId}|${lc(token)}`;
  if (st.inflight.has(key)) return null; // 同一钱包同一个币连点几次：只授权一次（额度按当时余额）
  st.inflight.add(key);
  try {
    return await approveOnce(ctx.walletId, ctx.from, getAddress(token), deps);
  } catch (err) {
    note('fail', ctx.walletId, token, `买入后自动授权失败：${err.message}`);
    return { ok: false, error: err.message };
  } finally {
    st.inflight.delete(key);
  }
}

/**
 * 只读：算出这次该发的授权（不预览、不广播）。返回 { skip: 原因 } 或 { tx, platform, spender, balance, label, symbol }。
 * 评测 / 自检可以直接调用（webui/eval/autoapprove.mjs）。
 */
export async function planAutoApprove(from, token, { waitMs = BALANCE_WAIT_MS } = {}) {
  // 1. 当前阶段的平台 → 卖出用的合约
  const det = await detectAll(token, { wallet: from });
  const platform = det.recommended;
  if (!platform) return { skip: '识别不出可交易的平台，没有授权' };
  if (platform === 'flap') return { skip: 'Flap 曲线卖出不需要授权', platform };
  const sp = await spenderFor(platform);
  if (!sp) return { skip: `平台 ${platform} 没有登记卖出合约，没有授权`, platform };

  // 2. 余额（刚上链可能还没同步：按绝对时间等一会）与现有授权
  const until = Date.now() + waitMs;
  let balance = await read(token, 'balanceOf', [from]);
  while (balance === 0n && Date.now() < until) {
    await new Promise((r) => { setTimeout(r, 500); });
    balance = await read(token, 'balanceOf', [from]);
  }
  if (balance === 0n) return { skip: '钱包里读不到这个币（余额 0），没有授权', platform };
  const allowance = await read(token, 'allowance', [from, sp.address]);
  const meta = await tokenMeta(token).catch(() => ({ symbol: '?', decimals: 18 }));
  if (allowance >= balance) {
    return { skip: `${meta.symbol} 对 ${sp.label} 的授权已足够（${allowance >= UNLIMITED ? '无上限' : pretty(allowance, meta.decimals)}），不用再授权`, platform, enough: true };
  }

  // 3. 生成 + 复核
  const tx = { to: token, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [getAddress(sp.address), balance] }) };
  assertAutoApproveTx(tx, { token, spender: sp.address, amount: balance, allowed: await allowedSpenders() });
  return {
    tx, platform, spender: sp.address, spenderLabel: sp.label, balance, allowance, symbol: meta.symbol,
    label: `买入后自动授权：${pretty(balance, meta.decimals)} ${meta.symbol} → ${sp.label}`,
  };
}

async function approveOnce(walletId, from, token, deps) {
  const p = await planAutoApprove(from, token);
  if (p.skip) { note('skip', walletId, token, p.skip, { platform: p.platform || null }); return { ok: Boolean(p.enough), skip: true }; }
  const { tx, platform, balance, label } = p;
  const sp = { address: p.spender };
  const meta = { symbol: p.symbol };

  // 4. 币安预览：要 App 确认的不执行（挂起会锁住这个钱包的所有交易，包括卖出和狙击）
  const pv = await deps.previewStep(walletId, from, { kind: 'approve', label, tx });
  if (!pv.ok || !pv.preview?.requestId) { note('fail', walletId, token, `授权预览未通过：${pv.error || '未返回 requestId'}`, { platform }); return { ok: false, error: pv.error }; }
  if (pv.preview.requireConfirmation === true) {
    note('skip', walletId, token, '币安预判这笔授权要在 App 里确认（挂起会锁住钱包），没有执行；卖出时会照常先授权本次数量', { platform });
    return { ok: false, skip: true };
  }

  // 5. 广播（value = 0）
  const ex = await deps.doExecute(walletId, pv.preview.requestId);
  const txHash = ex.result?.txHash || null;
  note(txHash ? 'done' : 'hold', walletId, token, txHash ? label : `${label}：被币安风控挂起，去 App 确认`, {
    platform, spender: sp.address, amount: balance.toString(), symbol: meta.symbol, txHash,
  });
  return { ok: Boolean(txHash), txHash, spender: sp.address, amount: balance.toString(), platform };
}
