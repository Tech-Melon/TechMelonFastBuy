/**
 * 发射后自动转移（docs/AUTOMATION_RULES.md 硬性规则 3 第七个例外）：gang 代币发射（毕业迁到 PancakeSwap / 打新 sale 发射）后，
 * 自动把代币转到一个白名单地址。发射前 gang 代币锁转账，所以只能等发射后再转。
 *
 * 预授权（arm）一份策略：钱包（1~5 个）、收款地址（只能是白名单里的）、按平台分别勾选（V2 / V3 / 打新）及各自的转出比例
 * （打新可选「只转超出出局线的部分」保留持有奖励，或全部转走）、是否自动加入预授权之后买到的代币、有效期 ≤ 7 天。
 * 监控列表 = 手动加入的 CA（每加一个要确认一次）+「买入即加入」（可关）：
 *   预授权时所选钱包已持有、未发射的 gang 代币全部加入；之后一买入（执行日志一写入）立即加入，不等发射；
 *   V2 毕业事件到达时，不在列表里但所选钱包持有的（比如在币安 App 里买的）也加入并马上转。
 *
 * 发现发射：
 *   - gang V2：在全项目共享的 WSS 上订阅 LaunchpadV2 的 Graduated 事件（topic1 = 代币；2026-10-27 用真实毕业交易
 *     0xb45d64f2…cfdc5 核对过签名 Graduated(address,address,address,uint256,uint256)），收到后再读 curves(token).graduated 确认；
 *   - gang V3 / 打新：主网还没有可核对的发射事件，轮询 curves(token).graduated / sales(token).launched；
 *   - 兜底：每 15 秒用 HTTP 把监控列表里没发射的都查一遍（WSS 断线、服务重启期间发射的也能补上）。
 * 执行：读余额 → 按比例算数量 → 以钱包身份模拟 transfer → 币安预览 → 复核（只能是该代币的 transfer、收款人 = 白名单地址、
 *   数量 = 计划值、不带 BNB）→ 广播。每个钱包每个币只转一次。被币安风控挂起（没有 txHash）时铃声提醒去 App 确认，不重试。
 * 改任意参数、到期、手动解除、白名单地址被删除都会立即失效；服务重启后按 arms.mjs 的条件恢复（白名单地址仍在且一致）。
 */
import { encodeFunctionData, decodeFunctionResult, parseAbi, getAddress } from 'viem';
import { rpcFor, getConfig, runBackground } from '../config.mjs';
import { journal, readJournal, onJournal } from '../journal.mjs';
import { gangInfo, LAUNCHPAD_V2 } from '../agent/gang.mjs';
import { padAbi as v3PadAbi, activeDeployment, subscribeChainLogs, chainWsConnected, pushGangAlert } from './gangv3.mjs';
// 打新模块可选：轻量版没有 fairmint.mjs（不支持打新），这里就不认打新代币
let fairmint = null;
try { fairmint = await import('./fairmint.mjs'); } catch (err) { if (err?.code !== 'ERR_MODULE_NOT_FOUND') throw err; }
import { assertTransferTx } from './transfer.mjs';
import { onHubReconnect } from '../wsshub.mjs';
import { saveArm, clearArm } from '../arms.mjs';

export const GRADUATED_TOPIC_V2 = '0x6da2ac486174425e3bbc9aab3a6fd9ee8fb4d1c1e769a02af4a159b37c52eea9';
const POLL_MS = 15000;
const V2_SAFETY_MS = 120000; // WSS 正常时 V2 的保险检查间隔
const MAX_HOURS = 168;
const MAX_WALLETS = 5;
const MAX_TOKENS = 100;
const MAX_EVENTS = 120;
const SIM_RETRIES = 4; // 刚发射的那几秒，个别节点状态还没同步：模拟失败按绝对时间间隔重试几次
const SIM_RETRY_MS = 5000;
const ARM_KEY = 'autoxfer';
/** 余额过少自动移出：所选钱包合计持有少于这么多枚（默认 50 万）就移出监控。只在买入 / 卖出后检查一次，不定时轮询 */
export const MIN_KEEP_TOKENS = (() => {
  const v = Number(process.env.AUTOXFER_MIN_TOKENS ?? 500000);
  return Number.isFinite(v) && v >= 0 ? v : 500000;
})();
const AFTER_CONFIRMED_MS = 1500; // 一键任务结束时已上链：稍等节点同步
const AFTER_BROADCAST_MS = 8000; // 狙击极速通道 / 自动卖出只是广播了：等它大概率上链再读
const PLATFORMS = ['v2', 'v3', 'fair'];
const PLATFORM_LABEL = { v2: 'gang V2', v3: 'gang V3', fair: 'gang 打新' };
const lc = (a) => String(a || '').toLowerCase();
const erc20Abi = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function transfer(address to, uint256 amount) returns (bool)',
]);

const st = {
  arm: null, // { cfg, target, wallets: Map(id→addr), armedAt, expiresAt, deps, done: Set('wallet|token'), tokens: Map(token→{platform, source, addedAt, status}) }
  events: [], unsubs: [], timer: null, busy: false, lastV2Sweep: 0,
};

function log(type, text, extra = {}) {
  st.events.unshift({ at: new Date().toISOString(), type, text, ...extra });
  st.events = st.events.slice(0, MAX_EVENTS);
}

/** 代币名称（只为界面显示）：第一次查询时后台读 symbol 并缓存，读到之前返回 null（界面显示地址） */
const symbols = new Map();
function symbolOf(token) {
  if (!symbols.has(token)) {
    symbols.set(token, null);
    erc(token, 'symbol').then((x) => symbols.set(token, String(x).slice(0, 32))).catch(() => symbols.delete(token));
  }
  return symbols.get(token);
}

async function erc(token, fn, args = []) {
  const raw = await rpcFor('56', 'eth_call', [{ to: token, data: encodeFunctionData({ abi: erc20Abi, functionName: fn, args }) }, 'latest']);
  return decodeFunctionResult({ abi: erc20Abi, functionName: fn, data: raw });
}

/** 策略校验（全部有上下限） */
export function parseXferConfig(c = {}) {
  const raw = Array.isArray(c.walletIds) ? c.walletIds : [];
  const walletIds = [...new Set(raw.map((x) => String(x || '').trim()))];
  if (!walletIds.length) throw new Error('请至少选择一个钱包');
  if (walletIds.length > MAX_WALLETS) throw new Error(`钱包最多选 ${MAX_WALLETS} 个`);
  if (!walletIds.every((id) => /^[\w-]{1,64}$/.test(id))) throw new Error('钱包 ID 无效');
  const targetId = String(c.targetId || '');
  if (!/^[0-9a-f-]{36}$/.test(targetId)) throw new Error('请选择一个白名单收款地址');
  const platforms = {};
  for (const p of PLATFORMS) {
    const x = c.platforms?.[p] || {};
    const pct = x.percent == null ? 100 : Number(x.percent);
    if (!(Number.isInteger(pct) && pct >= 1 && pct <= 100)) throw new Error(`${PLATFORM_LABEL[p]} 的转出比例需要是 1~100 的整数`);
    platforms[p] = { enabled: x.enabled === true, percent: pct };
    if (p === 'fair') platforms[p].keepHold = x.keepHold !== false; // 默认只转超出出局线的部分（保留打新持有奖励）
  }
  if (!PLATFORMS.some((p) => platforms[p].enabled)) throw new Error('至少勾选一个平台');
  const hours = Number(c.hours ?? 72);
  if (!(hours > 0 && hours <= MAX_HOURS)) throw new Error(`有效期需要在 0~${MAX_HOURS} 小时（7 天）之间`);
  return { walletIds, targetId, platforms, autoAdd: c.autoAdd !== false, hours };
}

const publicCfg = (c) => ({ walletIds: c.walletIds, targetId: c.targetId, platforms: c.platforms, autoAdd: c.autoAdd, hours: c.hours });

/** 识别代币属于哪个平台、发射了没有。不是 gang 代币返回 null */
async function launchState(token) {
  const g = await gangInfo(token).catch(() => null);
  if (g) return { platform: 'v2', launched: Boolean(g.graduated) };
  const v3 = await activeDeployment().catch(() => null);
  if (v3) {
    try {
      const raw = await rpcFor('56', 'eth_call', [{ to: v3.pad, data: encodeFunctionData({ abi: v3PadAbi, functionName: 'curves', args: [token] }) }, 'latest']);
      const c = decodeFunctionResult({ abi: v3PadAbi, functionName: 'curves', data: raw });
      if (!/^0x0{40}$/i.test(c[0])) return { platform: 'v3', launched: Boolean(c[6]) };
    } catch { /* 不是 V3 代币 */ }
  }
  const fair = fairmint ? await fairmint.activeFair().catch(() => null) : null;
  if (fair) {
    const s = await fairmint.saleOf(fairmint.mainnetFairCtx, fair.pad, token).catch(() => null);
    if (s) return { platform: 'fair', launched: Boolean(s.launched), fair: { dep: fair, sale: s } };
  }
  return null;
}

export function xferStatus() {
  if (st.arm && Date.now() > st.arm.expiresAt) disarmXfer('expired');
  const a = st.arm;
  return {
    armed: Boolean(a),
    arm: a ? {
      ...publicCfg(a.cfg), target: a.target, wallets: [...a.wallets].map(([id, address]) => ({ id, address })),
      armedAt: new Date(a.armedAt).toISOString(), expiresAt: new Date(a.expiresAt).toISOString(), doneCount: a.done.size,
    } : null,
    tokens: a ? [...a.tokens].map(([token, t]) => ({ token, ...t, symbol: symbolOf(token) })) : [],
    source: a ? (st.unsubs.length
      ? (chainWsConnected()
        ? 'V2：WSS 实时推送毕业事件（每 2 分钟 HTTP 保险检查一次）· V3 / 打新：每 15 秒查询'
        : 'WSS 断线中：全部改为每 15 秒 HTTP 查询，重连后立即补查')
      : '每 15 秒 HTTP 查询（没有配置 WSS）') : null,
    wsConnected: chainWsConnected(),
    graduatedTopic: GRADUATED_TOPIC_V2,
    minKeepTokens: MIN_KEEP_TOKENS,
    events: st.events,
  };
}

function persist() {
  const a = st.arm;
  if (!a) return;
  saveArm(ARM_KEY, {
    cfg: publicCfg(a.cfg), targetAddress: a.target.address, armedAt: a.armedAt, expiresAt: a.expiresAt,
    done: [...a.done], tokens: [...a.tokens].map(([token, t]) => ({ token, platform: t.platform, source: t.source, addedAt: t.addedAt })),
  });
}

/** 预授权。deps：{ walletEvm, listTargets, preview(walletId, from, step), execute(walletId, requestId) } */
export async function armXfer(config, deps, { tokens = [], resumed = null } = {}) {
  const cfg = parseXferConfig(config);
  const target = (await deps.listTargets()).find((t) => t.id === cfg.targetId);
  if (!target) throw new Error('收款地址不在白名单里（先在「一键转移」里加入白名单）');
  if (resumed && lc(resumed.targetAddress) !== lc(target.address)) throw new Error('白名单地址已改过');
  const addrs = await Promise.all(cfg.walletIds.map((id) => deps.walletEvm(id)));
  if (addrs.some((a) => lc(a) === lc(target.address))) throw new Error('收款地址是所选钱包自己');
  stopWatch();
  const now = Date.now();
  st.arm = {
    cfg, target, wallets: new Map(cfg.walletIds.map((id, i) => [id, addrs[i]])), deps,
    armedAt: resumed ? Number(resumed.armedAt) : now,
    expiresAt: resumed ? Number(resumed.expiresAt) : now + cfg.hours * 3600 * 1000,
    done: new Set(resumed?.done || []), tokens: new Map(),
  };
  for (const t of (resumed?.tokens || tokens)) {
    try { st.arm.tokens.set(lc(getAddress(t.token)), { platform: t.platform || null, source: t.source || 'manual', addedAt: t.addedAt || new Date().toISOString(), status: '待检查' }); } catch { /* 地址不对跳过 */ }
  }
  if (cfg.autoAdd) await seedFromHistory(st.arm); // 已经买了、还没发射的 gang 代币立即进监控（含预授权之前买的）
  journal(resumed ? 'autoxfer.resume' : 'autoxfer.arm', { ...publicCfg(cfg), target: target.address, tokens: st.arm.tokens.size });
  log('arm', `${resumed ? '服务重启后已恢复' : '已预授权'}：发射后转到 ${target.name} ${target.address}；钱包 ${cfg.walletIds.join('、')}；${PLATFORMS.filter((p) => cfg.platforms[p].enabled).map((p) => `${PLATFORM_LABEL[p]} ${cfg.platforms[p].percent}%${p === 'fair' ? (cfg.platforms.fair.keepHold ? '（只转超出出局线的部分）' : '（全部，会失去持有奖励）') : ''}`).join('、')}；${cfg.autoAdd ? '买入即加入监控（已持有未发射的立即加入）' : '只转手动加入的代币'}；到 ${new Date(st.arm.expiresAt).toLocaleString('zh-CN', { hour12: false })}`);
  persist();
  await startWatch();
  return xferStatus();
}

export async function resumeXfer(saved, deps) {
  if (Date.now() > Number(saved.expiresAt)) throw new Error('已过期');
  return armXfer(saved.cfg, deps, { resumed: saved });
}

export function disarmXfer(reason = 'manual') {
  clearArm(ARM_KEY);
  if (!st.arm) return xferStatus();
  journal('autoxfer.disarm', { reason, done: st.arm.done.size });
  log('disarm', `已解除（${{ manual: '手动', expired: '到期', 'target-removed': '白名单地址被删除', 'kill-switch': '全部解除', 'identity-changed': '钱包登录的币安账号变了' }[reason] || reason}）`);
  st.arm = null;
  stopWatch();
  return xferStatus();
}

/** 加入 / 移出监控列表（加入要前端单独确认；移出随时可以） */
export async function setXferToken(token, add) {
  const a = st.arm;
  if (!a) throw new Error('还没有预授权「发射后自动转移」');
  const key = lc(getAddress(token));
  if (!add) { a.tokens.delete(key); persist(); log('token', `移出监控：${key}`); return xferStatus(); }
  if (a.tokens.size >= MAX_TOKENS) throw new Error(`监控列表最多 ${MAX_TOKENS} 个代币`);
  const s = await launchState(key);
  if (!s) throw new Error('不是 gang V2 / 已启用的 V3 / 已启用的打新代币');
  if (!a.cfg.platforms[s.platform].enabled) throw new Error(`${PLATFORM_LABEL[s.platform]} 没有勾选（改平台勾选需要重新预授权）`);
  a.tokens.set(key, { platform: s.platform, source: 'manual', addedAt: new Date().toISOString(), status: s.launched ? '已发射，待转' : '等发射' });
  persist();
  journal('autoxfer.token', { token: key, platform: s.platform });
  log('token', `加入监控：${key}（${PLATFORM_LABEL[s.platform]}${s.launched ? '，已发射，马上处理' : '，等发射'}）`, { token: key });
  scan().catch(() => {});
  return xferStatus();
}

function stopWatch() {
  for (const u of st.unsubs) u?.();
  st.unsubs = [];
  clearInterval(st.timer);
  st.timer = null;
}

async function startWatch() {
  const a = st.arm;
  // gang V2：WSS 实时推送毕业事件（topic1 = 代币），只处理监控列表里的
  const unsub = await subscribeChainLogs({ address: LAUNCHPAD_V2, topics: [GRADUATED_TOPIC_V2] }, (l) => {
    if (l.removed || !l.topics?.[1] || st.arm !== a) return;
    const token = lc(`0x${l.topics[1].slice(-40)}`);
    const known = a.tokens.has(token);
    // 不在监控列表里的（比如在币安 App 里买的）：开了「自动加入」且所选钱包持有，也照样转
    (async () => {
      if (!known) {
        if (!a.cfg.autoAdd || !a.cfg.platforms.v2.enabled) return;
        const held = await Promise.all([...a.wallets.values()].map((w) => erc(token, 'balanceOf', [w]).catch(() => 0n)));
        if (!held.some((b) => b > 0n) || !addToken(a, token, 'v2', 'auto', '发射时发现钱包持有')) return;
        persist();
      }
      log('detect', `WSS 收到毕业事件：${token}（区块 ${Number(BigInt(l.blockNumber))}）`, { token, txHash: l.transactionHash });
      await scan([token]);
    })().catch(() => {});
  }, '发射后转移：gang V2 毕业事件');
  if (unsub) st.unsubs.push(unsub, onHubReconnect(() => { scan().catch(() => {}); }));
  // 轮询：V3 / 打新没有可核对的发射事件，一直 15 秒查一次；
  // V2 在 WSS 连着时只做 2 分钟一次的保险检查（防推送漏掉 / 节点没推），WSS 断了退回 15 秒
  st.timer = setInterval(() => {
    const now = Date.now();
    const sweepV2 = !chainWsConnected() || !st.unsubs.length || now - st.lastV2Sweep >= V2_SAFETY_MS;
    if (sweepV2) st.lastV2Sweep = now;
    const list = sweepV2 ? null : [...(st.arm?.tokens || new Map())].filter(([, t]) => t.platform !== 'v2').map(([k]) => k);
    if (list && !list.length) return;
    scan(list).catch((err) => log('error', `轮询失败：${err.message}`));
  }, POLL_MS);
  st.timer.unref?.();
  st.lastV2Sweep = Date.now();
  scan().catch(() => {});
}

/** 执行日志里的一行是不是 gang 买入：返回平台（v2 / v3 / fair），不是返回 null */
function buyKind(r) {
  if (!r?.token || !r.walletId) return null;
  if (r.type === 'gangsnipe.buy') return 'v2';
  if (r.type === 'gangsnipe3.buy') return 'v3';
  if (r.type === 'fairauto.mint') return 'fair';
  if (r.type === 'oneclick.start' && r.platform === 'gang') return 'v2';
  if (r.type === 'oneclick.start' && r.platform === 'gangv3') return 'v3';
  if (r.type === 'oneclick.start' && r.platform === 'fair') return 'fair';
  return null;
}

function addToken(a, token, platform, source, why) {
  const key = lc(token);
  if (a.tokens.has(key) || a.tokens.size >= MAX_TOKENS) return false;
  a.tokens.set(key, { platform, source, addedAt: new Date().toISOString(), status: '等发射' });
  log('token', `加入监控：${key}（${PLATFORM_LABEL[platform] || '?'}，${why}）`, { token: key });
  return true;
}

/**
 * 预授权时：所选钱包历史上买过（狙击 / 快捷买入 / 自动打新）、现在还持有、还没发射的 gang 代币，立即全部进监控。
 * 预授权之前就已经发射的不加（那是你选择继续持有的，不替你转）。
 */
async function seedFromHistory(a) {
  const rows = await readJournal(Infinity, { withRotated: true }).catch(() => []);
  const mine = new Set(a.cfg.walletIds);
  const cand = new Map(); // token → platform（null = 待识别）
  for (const r of rows) {
    const kind = buyKind(r);
    if (kind && mine.has(r.walletId) && a.cfg.platforms[kind].enabled) cand.set(lc(r.token), kind);
  }
  // 执行日志只记本机下的单：钱包实际持有的代币（币安余额接口）也查一遍，在别处 / App 里买的同样能加入
  if (a.deps.heldTokens) {
    for (const id of a.cfg.walletIds) {
      for (const t of await a.deps.heldTokens(id).catch(() => [])) if (!cand.has(lc(t))) cand.set(lc(t), null);
    }
  }
  let added = 0;
  for (const [token, kind] of cand) {
    if (a.tokens.has(token) || a.tokens.size >= MAX_TOKENS) continue;
    const s = await launchState(token).catch(() => null);
    if (!s || s.launched || !a.cfg.platforms[s.platform].enabled) continue;
    const held = await Promise.all([...a.wallets.values()].map((w) => erc(token, 'balanceOf', [w]).catch(() => 0n)));
    if (!held.some((b) => b > 0n)) continue;
    if (addToken(a, token, s.platform || kind, 'auto', '已持有、未发射')) added += 1;
  }
  if (added) log('token', `已把 ${added} 个持有中、未发射的 gang 代币加入监控`);
}

/** 买入一写进执行日志就加入监控（同进程回调，没有轮询延迟） */
onJournal((r) => {
  const a = st.arm;
  if (!a?.cfg.autoAdd) return;
  const kind = buyKind(r);
  if (!kind || !a.wallets.has(r.walletId) || !a.cfg.platforms[kind].enabled) return;
  if (addToken(a, r.token, kind, 'auto', `${r.walletId} 刚买入`)) persist();
});

/*
 * 余额过少自动移出（2026-10-29 用户要求）：所选钱包买入 / 卖出监控列表里的代币之后，读一次这些钱包的合计余额，
 * 少于 MIN_KEEP_TOKENS 枚就移出监控（剩这么点不值得发射后再转一笔）。不加定时检查。
 *   - 买入后：合计为 0 不移出（交易可能还没上链，读到的是旧余额），只有 0 < 余额 < 下限才移出；
 *   - 卖出后：余额 < 下限（含卖光了）就移出。
 * 触发：一键任务（交易台 / 插件 / 狙击普通流程）结束且完成；狙击极速买入 / 自动卖出、自动打新（只是广播了，晚几秒再读）。
 */
const jobSides = new Map(); // jobId → { walletId, token, side }
function tradeOf(r) {
  if (r.type === 'oneclick.start' && r.jobId && r.walletId && r.token && r.platform !== 'inventory') {
    jobSides.set(r.jobId, { walletId: r.walletId, token: r.planToken || r.token, side: r.side === 'sell' ? 'sell' : 'buy' });
    if (jobSides.size > 500) jobSides.delete(jobSides.keys().next().value);
    return null;
  }
  if (r.type === 'oneclick.end' && r.jobId) {
    const s = jobSides.get(r.jobId);
    jobSides.delete(r.jobId);
    return s && r.state === 'done' ? { ...s, delayMs: AFTER_CONFIRMED_MS } : null;
  }
  // 狙击极速买入（有 jobId 的那条是普通流程，已由 oneclick.end 触发）/ 自动打新 / 狙击自动卖出
  if (r.walletId && r.token && !r.jobId && (r.type === 'gangsnipe.buy' || r.type === 'gangsnipe3.buy' || r.type === 'fairauto.mint')) {
    return { walletId: r.walletId, token: r.token, side: 'buy', delayMs: AFTER_BROADCAST_MS };
  }
  if (r.walletId && r.token && (r.type === 'gangsnipe.autosell' || r.type === 'gangsnipe3.autosell')) {
    return { walletId: r.walletId, token: r.token, side: 'sell', delayMs: AFTER_BROADCAST_MS };
  }
  return null;
}
onJournal((r) => {
  const t = tradeOf(r);
  const a = st.arm;
  if (!t || !a || !a.wallets.has(t.walletId) || !a.tokens.has(lc(t.token))) return;
  setTimeout(() => { checkDust(a, lc(t.token), t.side).catch((err) => log('error', `余额检查失败（${t.token}）：${err.message}`, { token: lc(t.token) })); }, t.delayMs).unref?.();
});

/** 读所选钱包合计余额，过少就移出。返回是否移出（评测用） */
export async function checkDust(a, token, side) {
  if (st.arm !== a || !a.tokens.has(token)) return false;
  const [bals, decimals] = await runBackground(() => Promise.all([
    Promise.all([...a.wallets.values()].map((w) => erc(token, 'balanceOf', [w]))),
    erc(token, 'decimals').then(Number).catch(() => 18),
  ]), '发射后转移：余额检查');
  const total = bals.reduce((x, b) => x + b, 0n);
  if (side === 'buy' && total === 0n) return false;
  const min = BigInt(Math.round(MIN_KEEP_TOKENS)) * 10n ** BigInt(decimals);
  if (total >= min || st.arm !== a || !a.tokens.has(token)) return false;
  a.tokens.delete(token);
  persist();
  const human = (Number(total) / 10 ** decimals).toLocaleString('zh-CN', { maximumFractionDigits: 2 });
  const sym = symbolOf(token) || token;
  log('token', `自动移出 ${sym}：${side === 'sell' ? '卖出' : '买入'}后所选钱包合计只剩 ${human} 枚（少于 ${MIN_KEEP_TOKENS.toLocaleString('zh-CN')}）`, { token });
  journal('autoxfer.dust', { token, side, total: total.toString(), min: String(MIN_KEEP_TOKENS) });
  return true;
}

/** 全部移出监控（预授权保留，之后买入仍会按「买入即加入」加入） */
export function clearXferTokens() {
  const a = st.arm;
  if (!a) throw new Error('还没有预授权「发射后自动转移」');
  const n = a.tokens.size;
  a.tokens.clear();
  persist();
  log('token', `已全部移出监控（${n} 个）`);
  journal('autoxfer.clear', { count: n });
  return xferStatus();
}

/** 查一遍（tokens 不传 = 全部）：已发射的逐个钱包转走 */
async function scan(only = null) {
  if (st.busy) { if (only) setTimeout(() => scan(only).catch(() => {}), 1000).unref?.(); return; }
  const a = st.arm;
  if (!a) return;
  if (Date.now() > a.expiresAt) { disarmXfer('expired'); return; }
  st.busy = true;
  try {
    const targets = await a.deps.listTargets();
    const now = targets.find((t) => t.id === a.cfg.targetId);
    if (!now || lc(now.address) !== lc(a.target.address)) { disarmXfer('target-removed'); return; }
    const list = only || [...a.tokens.keys()];
    for (const token of list) {
      if (st.arm !== a) return;
      const t = a.tokens.get(token);
      if (!t) continue;
      const pending = [...a.wallets.keys()].filter((id) => !a.done.has(`${id}|${token}`));
      if (!pending.length) { t.status = '已全部转走'; continue; }
      let s;
      // 「发射了没」的轮询是后台查询（15 秒一次，晚几秒无所谓）：走后台节点 / 公共节点；真正转账那一步仍走交易节点
      try { s = await runBackground(() => launchState(token), '发射后转移：发射检查'); } catch (err) { t.status = `读取失败：${err.message}`; continue; }
      if (!s) { t.status = '不是 gang 代币'; continue; }
      t.platform = s.platform;
      if (!a.cfg.platforms[s.platform].enabled) { t.status = `${PLATFORM_LABEL[s.platform]} 未勾选`; continue; }
      if (!s.launched) { t.status = '等发射'; continue; }
      t.status = '已发射，转移中';
      for (const id of pending) {
        if (st.arm !== a) return;
        await transferOne(a, id, token, s).catch((err) => { log('fail', `${id} 转 ${token} 失败：${err.message}`, { token }); journal('autoxfer.fail', { walletId: id, token, error: err.message }); });
      }
      t.status = [...a.wallets.keys()].every((id) => a.done.has(`${id}|${token}`)) ? '已全部转走' : '部分未转（见事件）';
    }
  } finally {
    st.busy = false;
  }
}

async function transferOne(a, walletId, token, s) {
  const wallet = a.wallets.get(walletId);
  const key = `${walletId}|${token}`;
  const [balance, decimals, symbol] = await Promise.all([
    erc(token, 'balanceOf', [wallet]),
    erc(token, 'decimals').then(Number).catch(() => 18),
    erc(token, 'symbol').then((x) => String(x).slice(0, 32)).catch(() => '?'),
  ]);
  const p = a.cfg.platforms[s.platform];
  let amount = p.percent === 100 ? balance : (balance * BigInt(p.percent)) / 100n;
  if (s.platform === 'fair' && p.keepHold) {
    const pos = await fairmint.positionOf(fairmint.mainnetFairCtx, s.fair.dep, s.fair.sale, wallet).catch(() => null);
    const room = pos?.reward === 'earning' ? BigInt(pos.sellableBeforeOut || '0') : balance; // 已出局 / 没打过：没有资格可保留
    if (amount > room) amount = room;
  }
  if (amount <= 0n) { a.done.add(key); persist(); log('skip', `${walletId}：${symbol} 没有可转的数量（余额为 0 或都在出局线以内）`, { token }); return; }
  const data = encodeFunctionData({ abi: erc20Abi, functionName: 'transfer', args: [a.target.address, amount] });
  // 以钱包身份模拟：刚发射时个别节点还没同步到毕业块，失败就按绝对时间间隔重试
  let simErr = null;
  for (let i = 0; i < SIM_RETRIES; i += 1) {
    const t0 = Date.now();
    try {
      const raw = await rpcFor('56', 'eth_call', [{ from: wallet, to: token, data }, 'latest']);
      if (raw && raw !== '0x' && BigInt(raw.slice(0, 66)) === 0n) throw new Error('transfer 返回 false');
      simErr = null;
      break;
    } catch (err) {
      simErr = err;
      const wait = SIM_RETRY_MS - (Date.now() - t0);
      if (wait > 0 && i < SIM_RETRIES - 1) await new Promise((r) => setTimeout(r, wait));
    }
  }
  if (simErr) throw new Error(`模拟转账失败：${String(simErr.message || simErr).slice(0, 120)}`);
  const tx = { to: getAddress(token), value: '0', inputData: data };
  assertTransferTx(tx, { token, to: a.target.address, amount });
  const pv = await a.deps.preview(walletId, wallet, { kind: 'transfer', label: `发射后自动转移 ${symbol}`, tx });
  if (!pv.ok || !pv.preview?.requestId) throw new Error(`币安预览未通过：${pv.error || '未返回 requestId'}`);
  if (st.arm !== a || Date.now() > a.expiresAt || a.done.has(key)) throw new Error('预授权已失效（预览期间被解除或到期），未广播');
  assertTransferTx(tx, { token, to: a.target.address, amount }); // 广播前再复核一次
  a.done.add(key); // 先记「已处理」再广播：广播报错（可能已发出）也不会重复转
  persist();
  const ex = await a.deps.execute(walletId, pv.preview.requestId);
  const txHash = ex.result?.txHash || null;
  const amountText = (Number(amount) / 10 ** decimals).toLocaleString('zh-CN', { maximumFractionDigits: 4 });
  journal('autoxfer.sent', { walletId, token, platform: s.platform, to: a.target.address, amount: amount.toString(), txHash });
  if (txHash) {
    log('sent', `${walletId}：已转 ${amountText} ${symbol} → ${a.target.name}`, { token, txHash });
  } else {
    log('confirm', `${walletId}：转 ${amountText} ${symbol} 被币安风控挂起，请在币安 App 里确认（几分钟内有效）`, { token });
    pushGangAlert('confirm', `发射后自动转移：${walletId} 转 ${symbol} 需要在币安 App 里确认`, { kind: 'autoxfer', token });
  }
}
