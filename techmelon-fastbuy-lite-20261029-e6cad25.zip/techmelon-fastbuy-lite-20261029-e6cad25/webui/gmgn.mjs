/**
 * GMGN OpenAPI 客户端（只读：钱包持仓 / 历史仓位 / 交易记录 / 收益统计）。不用 gmgn-cli，按官方实现直接签名：
 *   - 主机 https://openapi.gmgn.ai；所有请求带 X-APIKEY 头，query 里带 timestamp（秒，服务端允许 ±5s）+ client_id（UUID，7 秒内防重放）。
 *   - 「critical auth」接口（wallet_holdings）另带 X-Signature：对 `{subPath}:{按 key 排序的 query}:{body}:{timestamp}` 用 Ed25519 私钥签名，base64。
 *   - 签名私钥是 GMGN 的 API 签名密钥（不是区块链钱包私钥）：本机生成，公钥上传到 https://gmgn.ai/ai 创建 API Key。
 * 限速：免费档漏桶 5/5（holdings 权重 2，activity / stats / profits 权重 3）。这里本地再限一层（≤ 每秒 4 个权重单位），
 * 收到 429 时按 reset_at 暂停全部请求，避免 GMGN 把封禁延长到 5 分钟。结果缓存 20 秒；用户点击触发的查询带 fresh 跳过缓存。
 * 凭据存 config.json 的 gmgn（已 gitignore），不会返回给前端、不写日志。
 */
import crypto from 'node:crypto';
import { getConfig, saveConfig } from './config.mjs';
import { cacheGet, cacheSet } from './cache.mjs';

const HOST = 'https://openapi.gmgn.ai';
const UA = 'walletui-gmgn/1.0';
const CACHE_MS = 20000;
const RATE_PER_SEC = 4; // 权重单位 / 秒（免费档 5，留余量）
const ROUTE_WEIGHT = { '/v1/user/wallet_holdings': 2, '/v1/user/wallet_activity': 3, '/v1/user/wallet_stats': 3, '/v1/user/wallet_profits': 3 };

const bucket = { tokens: RATE_PER_SEC, at: Date.now(), bannedUntil: 0, lastError: null };

async function creds() {
  const g = (await getConfig()).gmgn || {};
  return { apiKey: g.apiKey || '', privateKeyPem: g.privateKeyPem || '', publicKeyPem: g.publicKeyPem || '' };
}

export async function gmgnStatus() {
  const c = await creds();
  return {
    apiKeySet: Boolean(c.apiKey),
    apiKeyMasked: c.apiKey ? `••••${c.apiKey.slice(-4)}` : '', // 只露后 4 位
    signerSet: Boolean(c.privateKeyPem),
    publicKeyPem: c.publicKeyPem || null,
    bannedUntil: bucket.bannedUntil > Date.now() ? new Date(bucket.bannedUntil).toISOString() : null,
    lastError: bucket.lastError,
  };
}

/** 生成 Ed25519 签名密钥对（GMGN API 用，不是钱包私钥）。已有密钥时必须 replace=true */
export async function generateSigner({ replace = false } = {}) {
  const c = await creds();
  if (c.privateKeyPem && !replace) throw new Error('已经有签名密钥了；重新生成会让 GMGN 上已上传的公钥失效，需要确认替换');
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const publicKeyPem = publicKey.export({ type: 'spki', format: 'pem' });
  const privateKeyPem = privateKey.export({ type: 'pkcs8', format: 'pem' });
  const g = (await getConfig()).gmgn || {};
  await saveConfig({ gmgn: { ...g, privateKeyPem, publicKeyPem } });
  return { publicKeyPem };
}

export async function setApiKey(apiKey) {
  const k = String(apiKey || '').trim();
  if (k && !/^[\w.\-:]{16,200}$/.test(k)) throw new Error('API Key 格式不对（至少 16 位）');
  const g = (await getConfig()).gmgn || {};
  await saveConfig({ gmgn: { ...g, apiKey: k } });
  return gmgnStatus();
}

/** 签名串：{subPath}:{按 key 排序、数组值排序后重复 k=v 的 query}:{body}:{timestamp}（与官方 signer.ts 一致） */
export function buildMessage(subPath, query, body, timestamp) {
  const qs = Object.keys(query).sort().flatMap((k) => {
    const ek = encodeURIComponent(k);
    const v = query[k];
    return Array.isArray(v) ? [...v].sort().map((x) => `${ek}=${encodeURIComponent(x)}`) : [`${ek}=${encodeURIComponent(String(v))}`];
  }).join('&');
  return `${subPath}:${qs}:${body}:${timestamp}`;
}

function buildUrl(subPath, query) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (Array.isArray(v)) for (const x of v) p.append(k, x);
    else p.set(k, String(v));
  }
  return `${HOST}${subPath}?${p.toString()}`;
}

/** 本地漏桶：不足就等到够（以 Date.now() 计时，不累计 sleep） */
async function take(weight) {
  for (;;) {
    if (bucket.bannedUntil > Date.now()) throw new Error(`GMGN 限频封禁中，${new Date(bucket.bannedUntil).toLocaleTimeString()} 后再试`);
    const now = Date.now();
    bucket.tokens = Math.min(RATE_PER_SEC, bucket.tokens + ((now - bucket.at) / 1000) * RATE_PER_SEC);
    bucket.at = now;
    if (bucket.tokens >= weight) { bucket.tokens -= weight; return; }
    await new Promise((r) => setTimeout(r, Math.ceil(((weight - bucket.tokens) / RATE_PER_SEC) * 1000)));
  }
}

async function request(method, subPath, queryExtra = {}, body = null, { signed = false, fresh = false } = {}) {
  const c = await creds();
  if (!c.apiKey) throw new Error('还没有配置 GMGN API Key（在「钱包持仓」面板里填写）');
  if (signed && !c.privateKeyPem) throw new Error('这个接口需要签名：先在「钱包持仓」面板生成签名密钥，并把公钥上传到 gmgn.ai/ai');
  const cacheKey = `gmgn:${method}:${subPath}:${JSON.stringify(queryExtra)}:${body ? JSON.stringify(body) : ''}`;
  const hit = fresh ? null : cacheGet(cacheKey); // fresh：用户点击触发，跳过本地缓存直接问 GMGN
  if (hit) return hit;
  // 同一个查询正在进行就等它（插件 / 控制台同时刷新持仓时不重复占 GMGN 额度）
  if (!fresh && INFLIGHT.has(cacheKey)) return INFLIGHT.get(cacheKey);
  const p = doRequest(method, subPath, queryExtra, body, { signed, c, cacheKey }).finally(() => INFLIGHT.delete(cacheKey));
  if (!fresh) INFLIGHT.set(cacheKey, p);
  return p;
}
const INFLIGHT = new Map();

async function doRequest(method, subPath, queryExtra, body, { signed, c, cacheKey }) {
  await take(ROUTE_WEIGHT[subPath] || 3);
  const timestamp = Math.floor(Date.now() / 1000);
  const query = { ...queryExtra, timestamp, client_id: crypto.randomUUID() };
  const bodyStr = body != null ? JSON.stringify(body) : '';
  const headers = { 'X-APIKEY': c.apiKey, 'Content-Type': 'application/json', 'User-Agent': UA };
  if (signed) headers['X-Signature'] = crypto.sign(null, Buffer.from(buildMessage(subPath, query, bodyStr, timestamp), 'utf8'), c.privateKeyPem).toString('base64');
  let res;
  try {
    res = await fetch(buildUrl(subPath, query), { method, headers, body: bodyStr || undefined, signal: AbortSignal.timeout(12000) });
  } catch (err) {
    bucket.lastError = `网络错误：${err.message}`;
    throw new Error(`GMGN 请求失败：${err.message}（GMGN 只支持 IPv4）`);
  }
  const text = await res.text();
  let j = null;
  try { j = JSON.parse(text); } catch { /* 非 JSON */ }
  if (res.status === 429) {
    const reset = Number(j?.reset_at || res.headers.get('x-ratelimit-reset') || 0);
    bucket.bannedUntil = reset ? reset * 1000 : Date.now() + 60000;
    bucket.lastError = `${j?.error || 'RATE_LIMIT'}：${new Date(bucket.bannedUntil).toLocaleTimeString()} 前暂停请求`;
    throw new Error(`GMGN 限频（${j?.error || 429}），${new Date(bucket.bannedUntil).toLocaleTimeString()} 后再试；免费档每秒约 2 次查询，可在 gmgn.ai/ai 升级`);
  }
  if (!res.ok || (j && j.code != null && Number(j.code) !== 0)) {
    const msg = j?.message || j?.msg || j?.error || text.slice(0, 160) || `HTTP ${res.status}`;
    bucket.lastError = `${res.status} ${msg}`;
    if (res.status === 401 || res.status === 403) throw new Error(`GMGN 拒绝（${res.status}）：${msg}。检查 API Key、签名公钥是否已上传，以及是否走了 IPv6（GMGN 只支持 IPv4）`);
    throw new Error(`GMGN 返回错误：${msg}`);
  }
  bucket.lastError = null;
  const data = j && Object.prototype.hasOwnProperty.call(j, 'data') ? j.data : j;
  cacheSet(cacheKey, data, CACHE_MS);
  return data;
}

const num = (v) => (v == null || v === '' ? null : Number(v));

/**
 * 持仓 / 历史仓位（closed=true 时只看已清仓的）。字段名按 2026-10-27 实测返回。
 * 不传 hide_airdrop：GMGN 把「转入 / 经聚合器换来、没有直接买入记录」的币算成空投，hide_airdrop=true 会把
 * BNCB / NVDAB / WBNB 这类库存币全部藏掉（实测 4 条 vs 网站 9 条）。持仓默认按价值排序（与 gmgn.ai 一致）。
 * onToken(row)：每条持仓回调一次（server 用它登记头像来源）。
 */
export async function walletHoldings(wallet, { closed = false, cursor = '', limit = 50, fresh = false, onToken } = {}) {
  const q = { chain: 'bsc', wallet_address: wallet, limit, direction: 'desc', order_by: closed ? 'last_active_timestamp' : 'usd_value' };
  if (closed) { q.hide_closed = 'false'; q.hide_open = 'true'; } else { q.hide_closed = 'true'; }
  if (cursor) q.cursor = cursor;
  const d = await request('GET', '/v1/user/wallet_holdings', q, null, { signed: true, fresh });
  const list = d?.list || d?.holdings || [];
  const rows = list.map((x) => {
    const t = x.token || {};
    const start = num(x.start_holding_at);
    const end = num(x.end_holding_at) || null;
    const boughtAmt = num(x.history_bought_amount);
    const soldAmt = num(x.history_sold_amount);
    return {
      token: t.token_address || t.address, symbol: t.symbol, name: t.name,
      price: num(t.price), liquidity: num(t.liquidity), createdAt: num(t.creation_timestamp),
      launchpad: t.launchpad_platform || t.launchpad || null, honeypot: Boolean(t.is_honeypot),
      tags: Array.isArray(x.wallet_token_tags) ? x.wallet_token_tags.slice(0, 5).map(String) : [],
      balance: num(x.balance), usdValue: num(x.usd_value), accuCost: num(x.accu_cost), accuAmount: num(x.accu_amount),
      boughtCost: num(x.history_bought_cost), soldIncome: num(x.history_sold_income),
      avgBuy: boughtAmt ? num(x.history_bought_cost) / boughtAmt : null, // 买入均价（美元 / 枚）
      avgSell: soldAmt ? num(x.history_sold_income) / soldAmt : null,
      transferIns: num(x.history_total_transfer_ins), transferOuts: num(x.history_total_transfer_outs),
      buys: num(x.history_total_buys), sells: num(x.history_total_sells),
      realized: num(x.realized_profit), realizedPnl: num(x.realized_profit_pnl),
      unrealized: num(x.unrealized_profit), unrealizedPnl: num(x.unrealized_profit_pnl),
      totalProfit: num(x.total_profit), totalPnl: num(x.total_profit_pnl),
      startAt: start, endAt: end, lastActive: num(x.last_active_timestamp),
    };
  });
  if (onToken) for (const r of rows) { try { onToken(r); } catch { /* 头像登记失败不影响持仓 */ } }
  return { next: d?.next || null, rows };
}

/** 交易记录（买 / 卖 / 转入 / 转出） */
export async function walletActivity(wallet, { cursor = '', limit = 50, token = '', fresh = false } = {}) {
  const q = { chain: 'bsc', wallet_address: wallet, limit };
  if (cursor) q.cursor = cursor;
  if (token) q.token = token;
  const d = await request('GET', '/v1/user/wallet_activity', q, null, { fresh });
  const list = d?.activities || d?.list || [];
  return {
    next: d?.next || null,
    rows: list.map((x) => ({
      type: x.event_type ?? x.type, token: x.token?.address || x.token?.token_address, symbol: x.token?.symbol,
      amount: num(x.token_amount), costUsd: num(x.cost_usd), priceUsd: num(x.price_usd), buyCostUsd: num(x.buy_cost_usd),
      gasUsd: num(x.gas_usd), time: num(x.timestamp), tx: x.tx_hash,
    })),
  };
}

/** 收益统计（7d / 30d）：已实现 / 未实现、胜率、买卖笔数 */
export async function walletStats(wallets, period = '7d', { fresh = false } = {}) {
  const d = await request('GET', '/v1/user/wallet_stats', { chain: 'bsc', wallet_address: wallets, period }, null, { fresh });
  const arr = Array.isArray(d) ? d : [d];
  return arr.filter(Boolean).map((s) => ({
    wallet: s.wallet_address || null, realized: num(s.realized_profit), unrealized: num(s.unrealized_profit),
    winrate: num(s.winrate), totalCost: num(s.total_cost), buys: num(s.buy_count), sells: num(s.sell_count), pnl: num(s.pnl),
  }));
}
