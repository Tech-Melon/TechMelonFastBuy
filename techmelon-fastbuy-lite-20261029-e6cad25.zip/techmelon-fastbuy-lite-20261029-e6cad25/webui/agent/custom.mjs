import { encodeFunctionData, parseAbi, decodeFunctionResult } from 'viem';
import { rpc } from '../config.mjs';

const ADDR = /^0x[0-9a-fA-F]{40}$/;

/** 内联写法：「FairSlotLaunch 0x873e… 调 fillSlot(token=0x3508…)」——地址后紧跟「调/调用/call 函数(名=值)」 */
const INLINE_RE = /(0x[0-9a-fA-F]{40})(?![0-9a-fA-F])[^\n()]{0,24}?(?:调用|调|call|invoke)\s*([A-Za-z_]\w*)\s*\(([^()]*)\)/i;
/** 参数是否是「名=值」形式（没有 Solidity 类型） */
const isNamedValues = (params) => /=/.test(params)
  && !/\b(u?int\d*|address|bool|string|bytes\d*)(\[\d*\])*\s+[A-Za-z_]/.test(params);

/** 识别「单次合约调用」型提示词：合约 + 函数签名 + BNB 金额 + 可选 gasLimit */
export function detectCustom(text) {
  const inline = text.match(INLINE_RE);
  if (inline && isNamedValues(inline[3])) {
    const value = (text.match(VALUE_RE) || [])[1];
    if (!value || /CONFIG\s*\n/i.test(text)) return null;
    return {
      contract: inline[1],
      functionName: inline[2],
      // 类型由取值推断，签名在 parseCustom 里生成，planCustom 会用合约字节码核对选择器
      signature: null,
      inlineParams: inline[3],
      valueBnb: value,
      otherSignatures: [],
    };
  }
  const contract = (text.match(/(?:合约|contract)[^\n:：]*[:：]\s*(0x[0-9a-fA-F]{40})/i) || [])[1]
    || inline?.[1];
  const sigs = [...text.matchAll(/\b([A-Za-z_]\w*)\s*\(([^)]*)\)/g)]
    .map((m) => ({ name: m[1], params: m[2].trim() }));
  const typed = sigs.filter((s) => s.params && /uint\d*|int\d*|address|bool|bytes\d*|string/.test(s.params));
  const picked = typed[0]
    || sigs.find((s) => s.params)
    || sigs[0];
  // 识别与实际取值共用同一条规则，避免「显示 0.5 BNB、实际发 0」
  const value = (text.match(VALUE_RE) || [])[1];
  if (!contract || !picked || !value) return null;
  if (/CONFIG\s*\n/i.test(text)) return null;
  const sigOf = (s) => `${s.name}(${normalizeParams(s.params)})`;
  const distinct = new Set(typed.map(sigOf));
  return {
    contract,
    functionName: picked.name,
    signature: sigOf(picked),
    valueBnb: value,
    otherSignatures: [...distinct].filter((s) => s !== sigOf(picked)),
  };
}

/** 规范化参数列表：去掉 memory/calldata/storage 修饰，统一空格，便于 parseAbi 与参数名提取 */
function normalizeParams(params) {
  return params
    .split(',')
    .map((p) => p.replace(/\b(memory|calldata|storage)\b/g, ' ').replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join(', ');
}

const VALUE_RE = /(?:附带|value|支付|付|转入|with|pay(?:ing)?|send(?:ing)?)[^\d\n]{0,8}(\d+(?:\.\d+)?)\s*BNB/i;

/**
 * 「名=值」参数推断类型：地址 → address、true/false → bool、引号 → string、
 * 整数 → uint256（负数 int256）、0x 偶数位 hex → bytes。推断不了就拒绝。
 * 推断结果只是假设：planCustom 会到合约字节码里核对函数选择器，对不上就不生成交易。
 */
function inferNamedArgs(raw, fn) {
  const parts = splitTopLevel(raw);
  return parts.map((p, i) => {
    const m = p.match(/^\s*([A-Za-z_]\w*)\s*[=＝:：]\s*([\s\S]+?)\s*$/);
    if (!m) throw new Error(`${fn}() 的第 ${i + 1} 个参数「${p.trim()}」需要写成 名=值`);
    const [, name, v] = m;
    let type;
    if (/^0x[0-9a-fA-F]{40}$/.test(v)) type = 'address';
    else if (/^(true|false)$/i.test(v)) type = 'bool';
    else if (QUOTES[v[0]]) type = 'string';
    else if (/^\d+$/.test(v)) type = 'uint256';
    else if (/^-\d+$/.test(v)) type = 'int256';
    else if (/^0x([0-9a-fA-F]{2})*$/.test(v)) type = 'bytes';
    else throw new Error(`${fn}() 的参数 ${name}=${v} 无法推断类型，请写出完整签名，例如 ${fn}(uint256 ${name})`);
    return { name, type, literal: v };
  });
}

/** 按顶层逗号切分（忽略引号与方括号内的逗号） */
function splitTopLevel(raw) {
  const out = [];
  let depth = 0;
  let quote = null;
  let cur = '';
  for (const ch of raw) {
    if (quote) {
      cur += ch;
      if (ch === quote) quote = null;
      continue;
    }
    if (QUOTES[ch]) { quote = QUOTES[ch]; cur += ch; continue; }
    if (ch === '[') depth += 1;
    if (ch === ']') depth -= 1;
    if ((ch === ',' || ch === '，') && depth === 0) { out.push(cur); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out.filter((s) => s.trim());
}

function parseGasLimit(text) {
  const m = text.match(/gas\s*limit[^\d]{0,12}(\d+)/i);
  return m ? Number(m[1]) : null;
}

/** 支持的参数类型：基础类型 + 任意维数组（T[] / T[N] / T[][N]…）；tuple 暂不支持 */
const TYPE_RE = /^(u?int\d*|address|bool|string|bytes\d*)(\[\d*\])*$/;
const MAX_ARRAY_LEN = 256;
const MAX_STRING_LEN = 2000;
/** 字符串引号：英文双/单引号、中文引号、直角引号 */
const QUOTES = { '"': '"', "'": "'", '“': '”', '‘': '’', '「': '」' };

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function skipWs(s, i) {
  let j = i;
  while (j < s.length && /\s/.test(s[j])) j += 1;
  return j;
}

/**
 * 从 s[i] 开始按 Solidity 类型读一个字面量，返回 { value, end }。
 * 写法：整数 123 / -5；地址 0x…；布尔 true/false；字符串 "…"；bytes 0x…；数组 [a, b, c]（可嵌套）。
 */
function readValue(type, s, start, label) {
  const i = skipWs(s, start);

  // 数组：最外层维度是类型末尾那一对 []，例如 uint256[2][] 是「若干个 uint256[2]」
  const arr = type.match(/^(.*)\[(\d*)\]$/);
  if (arr) {
    const [, inner, size] = arr;
    if (s[i] !== '[') throw new Error(`参数 ${label}（${type}）需要写成 [值1, 值2] 的形式`);
    const out = [];
    let j = skipWs(s, i + 1);
    if (s[j] === ']') {
      j += 1;
    } else {
      for (;;) {
        const r = readValue(inner, s, j, `${label}[${out.length}]`);
        out.push(r.value);
        if (out.length > MAX_ARRAY_LEN) throw new Error(`参数 ${label} 元素超过 ${MAX_ARRAY_LEN} 个`);
        j = skipWs(s, r.end);
        if (s[j] === ',' || s[j] === '，') { j += 1; continue; }
        if (s[j] === ']') { j += 1; break; }
        throw new Error(`参数 ${label}（${type}）数组格式错误：元素之间要用逗号分隔，并以 ] 结尾`);
      }
    }
    if (size !== '' && out.length !== Number(size)) {
      throw new Error(`参数 ${label}（${type}）需要正好 ${size} 个元素，实际 ${out.length} 个`);
    }
    return { value: out, end: j };
  }

  const rest = s.slice(i);
  let m;

  if ((m = type.match(/^(u?)int(\d*)$/))) {
    const unsigned = m[1] === 'u';
    const bits = Number(m[2] || 256);
    if (!(bits >= 8 && bits <= 256 && bits % 8 === 0)) throw new Error(`不合法的整数类型：${type}`);
    // (?![\dxX.]) 防止把 0x… 地址开头的 0、或小数当成整数
    const mm = rest.match(unsigned ? /^\d+(?![\dxX.])/ : /^-?\d+(?![\dxX.])/);
    if (!mm) throw new Error(`参数 ${label}（${type}）需要${unsigned ? '非负' : ''}整数`);
    const v = BigInt(mm[0]);
    const min = unsigned ? 0n : -(2n ** BigInt(bits - 1));
    const max = unsigned ? 2n ** BigInt(bits) - 1n : 2n ** BigInt(bits - 1) - 1n;
    if (v < min || v > max) throw new Error(`参数 ${label}=${mm[0]} 超出 ${type} 的取值范围`);
    return { value: v, end: i + mm[0].length };
  }

  if (type === 'address') {
    const mm = rest.match(/^0x[0-9a-fA-F]{40}(?![0-9a-fA-F])/);
    if (!mm) throw new Error(`参数 ${label}（address）需要 0x 开头的 40 位地址`);
    // 统一小写：viem 对大小写混合地址做 checksum 校验，用户粘贴的地址未必是 checksum 格式
    return { value: mm[0].toLowerCase(), end: i + mm[0].length };
  }

  if (type === 'bool') {
    const mm = rest.match(/^(true|false)(?![\w])/i);
    if (!mm) throw new Error(`参数 ${label}（bool）需要 true 或 false`);
    return { value: mm[1].toLowerCase() === 'true', end: i + mm[0].length };
  }

  if (type === 'string') {
    // 字符串必须加引号：不加引号无法确定在哪里结束
    const close = QUOTES[rest[0]];
    if (!close) throw new Error(`参数 ${label}（string）需要用引号包起来，例如 ${label} = "hello"`);
    const endIdx = rest.indexOf(close, 1);
    if (endIdx < 0) throw new Error(`参数 ${label}（string）缺少结束引号 ${close}`);
    const value = rest.slice(1, endIdx);
    if (value.length > MAX_STRING_LEN) throw new Error(`参数 ${label} 超过 ${MAX_STRING_LEN} 字符`);
    return { value, end: i + endIdx + 1 };
  }

  if ((m = type.match(/^bytes(\d*)$/))) {
    const mm = rest.match(/^0x([0-9a-fA-F]*)(?![0-9a-zA-Z])/);
    if (!mm) throw new Error(`参数 ${label}（${type}）需要 0x 开头的十六进制`);
    const hex = mm[1];
    if (hex.length % 2) throw new Error(`参数 ${label}（${type}）的十六进制长度必须是偶数`);
    if (m[1]) {
      const n = Number(m[1]);
      if (!(n >= 1 && n <= 32)) throw new Error(`不合法的类型：${type}`);
      if (hex.length !== n * 2) throw new Error(`参数 ${label}（${type}）需要正好 ${n} 字节（${n * 2} 位十六进制），实际 ${hex.length / 2} 字节`);
    }
    return { value: `0x${hex.toLowerCase()}`, end: i + mm[0].length };
  }

  throw new Error(`暂不支持的参数类型：${type}`);
}

/** 按参数类型取值：`name = 值`；参数名前后必须是边界，避免 a 匹配到 minTokens 里的 a */
function parseArgs(text, types, names) {
  const args = [];
  for (let i = 0; i < types.length; i += 1) {
    const type = types[i];
    const name = names[i] || `arg${i}`;
    const m = text.match(new RegExp(`(?<![\\w])${escapeRe(name)}\\s*[=＝:：]\\s*`, 'i'));
    if (!m) throw new Error(`缺少参数 ${name}（${type}）的取值，请写成 ${name} = 值`);
    args.push(readValue(type, text, m.index + m[0].length, name).value);
  }
  return args;
}

/** 参数展示：BigInt 转字符串、字符串加引号、数组递归 */
export function formatArg(v) {
  if (Array.isArray(v)) return `[${v.map(formatArg).join(', ')}]`;
  if (typeof v === 'bigint') return v.toString();
  if (typeof v === 'string' && !/^0x[0-9a-f]*$/.test(v)) return JSON.stringify(v);
  return String(v);
}

/**
 * 预检期望值从提示词原文判断：「true 就停止 / 如果是 true 停止」→ 期望 false；
 * 「必须为 true / true 才继续 / false 就停止」→ 期望 true。判断不了就拒绝，不默认。
 */
function preflightExpect(after) {
  const s = after.slice(0, 40);
  if (/不需要|无需|不用|skip/i.test(s)) return 'skip';
  if (/(true|真)[^\n]{0,8}(停止|stop|abort|退出|放弃)|必须(为|是)?\s*false|must\s*be\s*false|(false|假)[^\n]{0,6}(才|再)\s*(继续|执行|continue)/i.test(s)) return false;
  if (/(false|假)[^\n]{0,8}(停止|stop|abort|退出|放弃)|必须(为|是)?\s*true|must\s*be\s*true|(true|真)[^\n]{0,6}(才|再)\s*(继续|执行|continue)/i.test(s)) return true;
  return null;
}

export function parseCustom(text) {
  const base = detectCustom(text);
  if (!base) return null;

  if (base.inlineParams != null) {
    const named = inferNamedArgs(base.inlineParams, base.functionName);
    const types = named.map((a) => a.type);
    const names = named.map((a) => a.name);
    const args = named.map((a, i) => readValue(types[i], a.literal, 0, a.name).value);
    return {
      kind: 'custom',
      chainId: 56,
      contract: base.contract,
      functionName: base.functionName,
      signature: `${base.functionName}(${named.map((a) => `${a.type} ${a.name}`).join(', ')})`,
      types,
      names,
      args,
      valueBnb: base.valueBnb,
      gasLimit: parseGasLimit(text),
      preflight: [],
      otherSignatures: [],
      inferred: true,
    };
  }

  const inner = base.signature.slice(base.signature.indexOf('(') + 1, -1);
  const parts = inner ? inner.split(',').map((s) => s.trim()).filter(Boolean) : [];
  const types = parts.map((p) => p.split(/\s+/)[0]);
  const names = parts.map((p) => p.split(/\s+/)[1] || '');

  for (const t of types) {
    if (/^tuple|^\(/.test(t)) throw new Error('暂不支持 tuple / struct 参数');
    if (!TYPE_RE.test(t)) {
      throw new Error(`暂不支持的参数类型：${t}（支持 uint/int/address/bool/string/bytes/bytesN 及其数组）`);
    }
  }

  const args = parseArgs(text, types, names);
  const valueBnb = base.valueBnb;
  const gasLimit = parseGasLimit(text);
  const preflight = [];
  const read = text.match(/(?:先读|先调用|read)\s*([A-Za-z_]\w*)\(\)/i);
  if (read) {
    const expect = preflightExpect(text.slice(read.index + read[0].length));
    if (expect === null) {
      throw new Error(`无法判断预检 ${read[1]}() 的期望值：请写明「true 就停止」或「必须为 true 才继续」`);
    }
    if (expect !== 'skip') preflight.push({ fn: read[1], signature: `${read[1]}()`, expect });
  }

  return {
    kind: 'custom',
    chainId: 56,
    contract: base.contract,
    functionName: base.functionName,
    signature: base.signature,
    types,
    names,
    args,
    valueBnb,
    gasLimit,
    preflight,
    otherSignatures: base.otherSignatures,
  };
}

export async function planCustom({ wallet, text }) {
  const spec = parseCustom(text);
  if (!spec) throw new Error('不是可识别的单次合约调用提示词');
  if (!ADDR.test(spec.contract)) throw new Error('合约地址格式不正确');

  const checks = [];
  const code = await rpc('eth_getCode', [spec.contract, 'latest']);
  const size = code && code !== '0x' ? (code.length - 2) / 2 : 0;
  checks.push({ name: '合约已部署', ok: size > 0, detail: `${size} bytes` });
  if (!size) throw new Error('目标地址没有合约代码');

  for (const pf of spec.preflight) {
    try {
      const abi = parseAbi([`function ${pf.fn}() returns (bool)`]);
      const data = encodeFunctionData({ abi, functionName: pf.fn });
      const val = decodeFunctionResult({ abi, functionName: pf.fn, data: await rpc('eth_call', [{ to: spec.contract, data }, 'latest']) });
      const ok = val === pf.expect;
      checks.push({ name: `${pf.fn}() == ${pf.expect}`, ok, detail: String(val) });
      if (!ok) throw new Error(`${pf.fn}() 为 ${val}，提示词要求为 ${pf.expect}，提示词要求停止`);
    } catch (err) {
      if (/提示词要求停止/.test(err.message)) throw err;
      checks.push({ name: `${pf.fn}()`, ok: false, detail: err.message });
      throw new Error(`预检 ${pf.fn}() 失败：${err.message}`);
    }
  }

  const valueWei = parseUnitsLocal(spec.valueBnb);
  // value 为 0 是合法的（如 approve），这里只做展示
  checks.push({ name: 'value', ok: true, detail: `${spec.valueBnb} BNB` });
  if (BigInt(valueWei) > 1_000_000_000_000_000_000n) {
    throw new Error('单笔 value 超过 1 BNB 安全上限');
  }

  const abi = parseAbi([`function ${spec.signature}`]);
  const inputData = encodeFunctionData({
    abi,
    functionName: spec.functionName,
    args: spec.args,
  });

  // 选择器核对：函数签名写错（或类型推断错）时 calldata 会打到不存在的函数上
  const selector = inputData.slice(2, 10).toLowerCase();
  const codes = [code.toLowerCase(), ...(await proxyTargetsCode(spec.contract, code))];
  // 函数分发表里选择器以 PUSH4（0x63）立即数出现；只搜裸 4 字节会被常量 / 元数据里的偶然片段误命中
  const found = codes.some((c) => c.includes(`63${selector}`));
  checks.push({
    name: `函数选择器 0x${selector}`,
    ok: found,
    detail: found ? '存在' : '不存在',
  });
  const simplified = spec.signature.replace(/\s+\w+(?=[,)])/g, '');
  if (!found && spec.inferred) {
    throw new Error(`按取值推断的签名 ${simplified} 在合约里不存在：请在提示词里写出完整签名（例如 ${spec.functionName}(uint256 x)）`);
  }

  // 生成计划前 eth_call 模拟：revert 原因直接显示（不阻断，最终以 CLI 预览为准）
  const simWarnings = [];
  try {
    await rpc('eth_call', [{ from: wallet, to: spec.contract, value: `0x${BigInt(valueWei).toString(16)}`, data: inputData }, 'latest']);
    checks.push({ name: '链上模拟', ok: true, detail: '不会 revert' });
  } catch (err) {
    const reason = String(err.message || '').replace(/^execution reverted:?\s*/i, '').replace(/:?\s*0x[0-9a-fA-F]{8,}\s*$/, '').trim() || 'revert';
    checks.push({ name: '链上模拟', ok: false, detail: reason });
    simWarnings.push(`链上模拟会 revert：${reason}。现在执行很可能失败，请先确认条件`);
  }

  return {
    kind: 'custom',
    protocol: 'custom',
    spec: {
      contract: spec.contract,
      functionName: spec.functionName,
      signature: spec.signature,
      valueBnb: spec.valueBnb,
      gasLimit: spec.gasLimit,
      // 每个参数一行「类型 名称 = 值」，确认前可逐项核对
      args: spec.args.map((a, i) => `${spec.types[i]} ${spec.names[i] || `arg${i}`} = ${formatArg(a)}`),
    },
    checks,
    steps: [{
      label: `${spec.functionName}(…)`,
      tx: {
        to: spec.contract,
        value: valueWei,
        inputData,
        ...(spec.gasLimit ? { gasLimit: spec.gasLimit } : {}),
      },
    }],
    // notes：正常情况下的说明（灰色）；warnings：需要用户注意的风险（红色）
    notes: [
      ...(spec.inferred ? [`参数类型按取值推断为 ${simplified}，已在合约字节码中确认该函数存在`] : []),
      ...(spec.gasLimit ? [] : ['未指定 gasLimit，由节点估算']),
    ],
    warnings: [
      ...simWarnings,
      ...(found ? [] : ['合约字节码中找不到该函数选择器（可能是代理合约或签名写错），请以预览模拟结果为准']),
      ...(spec.otherSignatures?.length
        ? [`提示词里还出现了其它函数签名（${spec.otherSignatures.join('、')}），已选择 ${spec.signature}，请核对`]
        : []),
    ],
  };
}

/** 代理合约的实现代码：EIP-1967 实现槽 + EIP-1167 最小代理 */
async function proxyTargetsCode(contract, code) {
  const targets = new Set();
  try {
    const slot = await rpc('eth_getStorageAt', [contract, '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc', 'latest']);
    const impl = `0x${String(slot).slice(-40)}`;
    if (!/^0x0{40}$/.test(impl)) targets.add(impl);
  } catch { /* 节点不支持就跳过 */ }
  const minimal = String(code).toLowerCase().match(/^0x363d3d373d3d3d363d73([0-9a-f]{40})5af43d82803e903d91602b57fd5bf3/);
  if (minimal) targets.add(`0x${minimal[1]}`);
  const out = [];
  for (const t of targets) {
    try { out.push(String(await rpc('eth_getCode', [t, 'latest'])).toLowerCase()); } catch { /* ignore */ }
  }
  return out;
}

function parseUnitsLocal(value) {
  const s = String(value).trim();
  if (!/^\d+(\.\d*)?$/.test(s)) throw new Error(`金额格式不正确：${value}`);
  const [whole, frac = ''] = s.split('.');
  if (frac.length > 18) throw new Error('小数位超过 18，拒绝四舍五入');
  const padded = (frac + '0'.repeat(18)).slice(0, 18);
  return (BigInt(whole) * 10n ** 18n + BigInt(padded || '0')).toString();
}
