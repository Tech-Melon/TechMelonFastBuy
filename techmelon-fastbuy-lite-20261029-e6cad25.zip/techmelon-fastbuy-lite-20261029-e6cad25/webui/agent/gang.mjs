import { encodeFunctionData, decodeFunctionResult, parseAbi, toEventSelector } from 'viem';
import { rpc } from '../config.mjs';
import { parseUnits } from './adapters.mjs';
import { assertSlippageBps, instructionOf } from './guard.mjs';
import { routeSwap, estimateOut } from '../quick/router.mjs';
import { allowanceOverride, simulateCall } from '../quick/simoverride.mjs';

const VIRTUAL_TOKEN = 1066666666666666666666666667n;
const FEE_BPS = 100n;

const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const PANCAKE = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
// Gang 官方 LaunchpadV2（来源：gang.fun 仓库 README / gang-cli README，BSC 主网）
const LAUNCHPAD_V2 = '0x1B8F3f69DFa0a7F63d308C7EB0Fd38D8b099966E';
const ZERO_ADDR = /^0x0{40}$/i;

const padAbi = parseAbi([
  'function launchpad() view returns (address)',
  'function curves(address token) view returns (address creator,address quote,uint128 realQuote,uint128 sold,uint128 gradAmt,uint128 virtualQuote,bool graduated,bool taxed,address pair,address refPair)',
  'function isAgent(address) view returns (bool)',
  'function walletRoom(address token,address buyer) view returns (uint256)',
  'function buy(address token,uint256 quoteIn,uint256 minTokensOut) returns (uint256)',
  'function sell(address token,uint256 tokenIn,uint256 minQuoteOut) returns (uint256)',
]);

const erc20Abi = parseAbi([
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function allowance(address,address) view returns (uint256)',
  'function approve(address,uint256) returns (bool)',
  'function balanceOf(address) view returns (uint256)',
]);

const wbnbAbi = parseAbi(['function deposit() payable', 'function withdraw(uint256 wad)']);

export { LAUNCHPAD_V2 };

/** LaunchpadV2 Created 事件 topic0（狙击发现新币、图标按创建日志找 logoURI 共用；与主网日志核对过） */
export const CREATED_TOPIC = toEventSelector(parseAbi(['event Created(address indexed token, address indexed creator, string name, string symbol, string logoURI, bool taxed, address indexed quote, address refPair, uint256 gradAmt)'])[0]);

/**
 * 只读识别：是否为 Gang LaunchpadV2 代币及曲线状态（快捷交易用）。
 * token.launchpad() 不存在 / 不是官方 LaunchpadV2 → 返回 null。
 */
export async function gangInfo(token) {
  let reported;
  try {
    const raw = await call(token, encodeFunctionData({ abi: padAbi, functionName: 'launchpad' }));
    reported = decodeFunctionResult({ abi: padAbi, functionName: 'launchpad', data: raw });
  } catch {
    return null;
  }
  if (String(reported).toLowerCase() !== LAUNCHPAD_V2.toLowerCase()) return null;
  const raw = await call(LAUNCHPAD_V2, encodeFunctionData({ abi: padAbi, functionName: 'curves', args: [token] }));
  const [creator, quote, , , , , graduated, taxed, pair] = decodeFunctionResult({ abi: padAbi, functionName: 'curves', data: raw });
  if (ZERO_ADDR.test(creator) || ZERO_ADDR.test(quote)) return null;
  return { quote, graduated, taxed, pair, quoteIsWbnb: quote.toLowerCase() === WBNB.toLowerCase() };
}

export function detectGang(text) {
  // gang.fun 文档推荐的说法：「在 Gang 买 0.05 BNB 的 0x…」
  if (!/gang\.fun|LaunchpadV2|gang\s+(?:buy|sell)|(?:buy|sell)\s+on\s+gang|在\s*gang\s*(?:上|内盘)?\s*(?:买入?|购买|卖出?|卖掉)|gang\s*内盘\s*(?:买|卖)/i.test(text)) return null;
  // 金额 / 滑点只看用户指令；代币地址优先取指令里的，其次才是全文
  const ins = instructionOf(text);
  const pick = (src) => [...src.matchAll(/0x[0-9a-fA-F]{40}/g)].map((m) => m[0])
    .find((a) => a.toLowerCase() !== PANCAKE.toLowerCase() && a.toLowerCase() !== WBNB.toLowerCase()
      && a.toLowerCase() !== LAUNCHPAD_V2.toLowerCase());
  const token = pick(ins) || pick(text);
  const SLIP = /(?:滑点|slippage)[^\d\n]{0,8}(\d+(?:\.\d+)?)\s*%/i;
  const slip = (ins.match(SLIP) || [])[1];
  if (!token) return null;
  const slippageBps = slip ? Math.round(Number(slip) * 100) : null;

  // 卖出：「在 Gang 卖出 50% 的 0x…」「卖出全部」「卖出 100000 个」
  if (/(卖出|卖掉|卖|sell)/i.test(ins)) {
    const clean = ins.replace(new RegExp(SLIP.source, 'gi'), ' ').replace(/0x[0-9a-fA-F]{40}/g, ' ');
    const all = /全部|所有|全仓|\ball\b|--all/i.test(clean);
    const percent = all ? '100' : (clean.match(/(\d+(?:\.\d+)?)\s*%/) || [])[1] || null;
    const amount = all || percent ? null : (clean.match(/(\d+(?:\.\d+)?)(?![\d.])/) || [])[1] || null;
    return {
      protocol: 'gang',
      intent: 'sell',
      params: { side: 'sell', token, percent, amount, slippageBps },
      assumptions: [],
      unknowns: [],
    };
  }

  const amount = (ins.match(/([\d.]+)\s*BNB/i) || [])[1];
  return {
    protocol: 'gang',
    intent: 'buy',
    params: {
      side: 'buy',
      token,
      amountBnb: amount || null,
      slippageBps,
    },
    assumptions: [],
    unknowns: [],
  };
}

const human18 = (v) => {
  const s = BigInt(v).toString().padStart(19, '0');
  const f = s.slice(-18).replace(/0+$/, '');
  return f ? `${s.slice(0, -18)}.${f}` : s.slice(0, -18);
};

/**
 * 内盘卖出。输出公式已用合约实际返回值核对（误差 0）：
 *   gross = (vQ + realQuote) − ceil(vQ·VT / (VT − sold + tokenIn))，net = gross − gross/100（1% 手续费）
 * 步骤：approve 代币 → LaunchpadV2（只授权本次数量）→ sell；报价币是 WBNB 时再把下限部分解包成 BNB。
 */
async function planGangSell({ wallet, spec, pad, token, curve, checks, warnings }) {
  const { percent, amount } = spec.params;
  const slip = spec.params.slippageBps;
  if (slip == null) throw new Error('缺少滑点：不提供默认值');
  assertSlippageBps(slip);
  if (!percent && !amount) throw new Error('缺少卖出数量：写「卖出 50%」「卖出全部」或「卖出 100000 个」');

  const [, quoteToken, realQuote, sold, , virtualQuote, graduated, taxed] = curve;
  if (graduated) throw new Error('该代币已毕业，内盘已关闭，请改去 PancakeSwap 卖出');

  const [balRaw, decRaw, symRaw, quoteSymRaw, allowRaw] = await Promise.all([
    call(token, encodeFunctionData({ abi: erc20Abi, functionName: 'balanceOf', args: [wallet] })),
    call(token, encodeFunctionData({ abi: erc20Abi, functionName: 'decimals' })),
    call(token, encodeFunctionData({ abi: erc20Abi, functionName: 'symbol' })),
    call(quoteToken, encodeFunctionData({ abi: erc20Abi, functionName: 'symbol' })),
    call(token, encodeFunctionData({ abi: erc20Abi, functionName: 'allowance', args: [wallet, pad] })),
  ]);
  const balance = decodeFunctionResult({ abi: erc20Abi, functionName: 'balanceOf', data: balRaw });
  const decimals = Number(decodeFunctionResult({ abi: erc20Abi, functionName: 'decimals', data: decRaw }));
  const symbol = decodeFunctionResult({ abi: erc20Abi, functionName: 'symbol', data: symRaw });
  const quoteSymbol = decodeFunctionResult({ abi: erc20Abi, functionName: 'symbol', data: quoteSymRaw });
  const allowance = decodeFunctionResult({ abi: erc20Abi, functionName: 'allowance', data: allowRaw });
  if (decimals !== 18) throw new Error(`代币精度为 ${decimals}，内盘曲线按 18 位计算，拒绝生成交易`);

  let tokenIn;
  if (percent) {
    const bps = Math.round(Number(percent) * 100);
    if (!(bps > 0 && bps <= 10000)) throw new Error(`卖出比例不合法：${percent}%`);
    tokenIn = (balance * BigInt(bps)) / 10000n;
  } else {
    tokenIn = BigInt(parseUnits(amount, 18));
  }
  checks.push({ name: `${symbol} 持仓`, ok: balance >= tokenIn && tokenIn > 0n, detail: `${human18(balance)}，卖出 ${human18(tokenIn)}${percent ? `（${percent}%）` : ''}` });
  if (tokenIn === 0n) throw new Error(`钱包里没有 ${symbol}，无法卖出`);
  if (tokenIn > balance) throw new Error(`${symbol} 余额不足：持有 ${human18(balance)}，要卖 ${human18(tokenIn)}`);

  // 2026-10-28 链上实测：LaunchpadV2 曲线卖出同样要求 Agent ID（没有的钱包 revert NotAgent），提前拦下说清楚
  const agentRaw = await call(pad, encodeFunctionData({ abi: padAbi, functionName: 'isAgent', args: [wallet] }));
  const isAgent = decodeFunctionResult({ abi: padAbi, functionName: 'isAgent', data: agentRaw });
  checks.push({ name: 'isAgent(wallet)', ok: isAgent, detail: String(isAgent) });
  if (!isAgent) throw new Error('该钱包没有 .ai Agent ID：gang V2 曲线卖出同样要求 Agent ID，会被合约拒绝（NotAgent）');

  const k = BigInt(virtualQuote) * VIRTUAL_TOKEN;
  const q = BigInt(virtualQuote) + BigInt(realQuote);
  const t = VIRTUAL_TOKEN - BigInt(sold);
  const gross = q - (k + (t + tokenIn) - 1n) / (t + tokenIn);
  let net = gross - (gross * FEE_BPS) / 10000n;
  if (net <= 0n) throw new Error('计算出的卖出所得为 0');
  if (gross > BigInt(realQuote)) throw new Error('卖出所得超过内盘储备，数据异常，拒绝生成交易');
  // 以钱包身份模拟真实卖出（税币另扣的税、门槛都算在内）。授权不够时用状态覆盖临时授权本次数量；
  // 找不到授权存储位置的非常规代币退回本地公式
  const needApprove = allowance < tokenIn;
  const override = needApprove ? await allowanceOverride(token, wallet, pad, tokenIn).catch(() => null) : null;
  if (!needApprove || override) {
    const sim = await simulateCall({ from: wallet, to: pad, data: encodeFunctionData({ abi: padAbi, functionName: 'sell', args: [token, tokenIn, 0n] }), override });
    if (!sim.ok) throw new Error(`卖出模拟失败：${sim.reason}`);
    const simOut = decodeFunctionResult({ abi: padAbi, functionName: 'sell', data: sim.raw });
    if (simOut < net) checks.push({ name: '模拟到账', ok: true, detail: `${human18(simOut)} ${quoteSymbol}（比公式少 ${((Number(net - simOut) / Number(net)) * 100).toFixed(2)}%，${taxed ? '税币另扣税' : '链上实际'}）` });
    net = simOut;
  } else {
    warnings.push(`没法在授权前模拟这个代币的卖出：最少收到按曲线公式算${taxed ? '（税币另扣的税没算进去，滑点建议 ≥ 3%）' : ''}`);
  }
  const minOut = (net * BigInt(10000 - slip)) / 10000n;
  checks.push({ name: '预计所得（扣 1% 手续费）', ok: true, detail: `${human18(net)} ${quoteSymbol}` });
  checks.push({ name: `最少所得（滑点 ${slip / 100}%）`, ok: true, detail: `${human18(minOut)} ${quoteSymbol}` });

  const steps = [];
  if (allowance < tokenIn) {
    steps.push({
      label: `approve ${symbol} → pad`,
      tx: { to: token, value: '0', inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [pad, tokenIn] }) },
    });
  }
  steps.push({
    label: `sell ${symbol} → ${quoteSymbol}`,
    recipient: wallet,
    tx: { to: pad, value: '0', inputData: encodeFunctionData({ abi: padAbi, functionName: 'sell', args: [token, tokenIn, minOut] }) },
  });
  const quoteIsWbnb = quoteToken.toLowerCase() === WBNB.toLowerCase();
  if (quoteIsWbnb) {
    // 只解包最少所得：实际所得 ≥ minOut，不会因为余额不足失败；多出的少量 WBNB 留在钱包
    steps.push({
      label: 'unwrap WBNB → BNB',
      recipient: wallet,
      tx: { to: WBNB, value: '0', inputData: encodeFunctionData({ abi: wbnbAbi, functionName: 'withdraw', args: [minOut] }) },
    });
    warnings.push('卖出得到 WBNB，最后一步把最少所得部分解包成 BNB；超出下限的少量 WBNB 会留在钱包');
  } else {
    warnings.push(`卖出得到的是报价币 ${quoteSymbol}，需要 BNB 可再到「兑换」页卖出 ${quoteSymbol}`);
  }

  return {
    kind: 'gang',
    protocol: 'gang',
    spec: {
      side: 'sell', token, pad, quote: quoteToken, quoteSymbol, symbol,
      tokenIn: tokenIn.toString(), tokenInHuman: human18(tokenIn), percent: percent || null,
      expectedOut: human18(net), minOut: human18(minOut), minOutRaw: minOut.toString(), slippageBps: slip,
    },
    checks,
    steps,
    warnings,
  };
}

async function call(to, data) {
  return rpc('eth_call', [{ to, data }, 'latest']);
}

export async function planGang({ wallet, spec }) {
  const token = spec.params.token;
  const isSell = spec.params.side === 'sell';
  const amountBnb = spec.params.amountBnb;
  // quoteIn（报价币最小单位）：与官方 gang CLI 一致，直接用钱包里已有的报价币买，不再换币。
  // 快捷交易在「换报价币」上链后带着上一步的保底数量重新生成计划，避免按新价格重复换币
  const quoteInRaw = spec.params.quoteIn != null ? BigInt(spec.params.quoteIn) : null;
  // pendingApprove：一键买入流水线里「授权已广播、正在等上链」的额度。重新报价可以和等授权上链并行，
  // 这时把它当作已授权（不再生成第二笔授权）；买入步骤仍要等授权上链后才预览，预览不过就停止
  const pendingApprove = spec.params.pendingApprove != null ? BigInt(spec.params.pendingApprove) : 0n;
  const slip = spec.params.slippageBps;
  if (!isSell && !amountBnb && !quoteInRaw) throw new Error('缺少买入金额（BNB）');
  if (slip == null) throw new Error('缺少滑点：不提供默认值');
  assertSlippageBps(slip);

  const checks = [];
  const warnings = [];

  // token.launchpad() 是代币自报的，不可信：只作为交叉校验，实际交互对象固定为官方 LaunchpadV2。
  // 交互对象固定，所以 curves(token) 不依赖 launchpad() 的结果：两次读取并行（少一次往返）
  const [padRaw, curveRaw] = await Promise.all([
    call(token, encodeFunctionData({ abi: padAbi, functionName: 'launchpad' })),
    call(LAUNCHPAD_V2, encodeFunctionData({ abi: padAbi, functionName: 'curves', args: [token] })),
  ]);
  const reportedPad = decodeFunctionResult({ abi: padAbi, functionName: 'launchpad', data: padRaw });
  const padOk = reportedPad.toLowerCase() === LAUNCHPAD_V2.toLowerCase();
  checks.push({ name: 'launchpad() == 官方 LaunchpadV2', ok: padOk, detail: reportedPad });
  if (!padOk) {
    throw new Error(`代币自报的 launchpad ${reportedPad} 不是 Gang 官方 LaunchpadV2（${LAUNCHPAD_V2}），拒绝生成交易`);
  }
  const pad = LAUNCHPAD_V2;

  const curve = decodeFunctionResult({ abi: padAbi, functionName: 'curves', data: curveRaw });
  const [creator, quoteToken, realQuote, sold, , virtualQuote, graduated, taxed] = curve;
  const registered = !ZERO_ADDR.test(creator) && !ZERO_ADDR.test(quoteToken);
  checks.push({ name: 'LaunchpadV2.curves(token) 已注册', ok: registered, detail: quoteToken });
  if (!registered) throw new Error('该代币未在 Gang LaunchpadV2 注册曲线，拒绝生成交易');
  checks.push({ name: 'graduated', ok: !graduated, detail: String(graduated) });
  // 内盘卖出同样要求 Agent ID（planGangSell 里检查）
  if (isSell) return planGangSell({ wallet, spec, pad, token, curve, checks, warnings });
  if (graduated) throw new Error('该代币已毕业，请改去 PancakeSwap');

  const [agentRaw, roomRaw, quoteDecimalsRaw, quoteSymbolRaw, quoteBalRaw, allowanceRaw] = await Promise.all([
    call(pad, encodeFunctionData({ abi: padAbi, functionName: 'isAgent', args: [wallet] })),
    call(pad, encodeFunctionData({ abi: padAbi, functionName: 'walletRoom', args: [token, wallet] })),
    call(quoteToken, encodeFunctionData({ abi: erc20Abi, functionName: 'decimals' })),
    call(quoteToken, encodeFunctionData({ abi: erc20Abi, functionName: 'symbol' })),
    call(quoteToken, encodeFunctionData({ abi: erc20Abi, functionName: 'balanceOf', args: [wallet] })),
    call(quoteToken, encodeFunctionData({ abi: erc20Abi, functionName: 'allowance', args: [wallet, pad] })),
  ]);
  const isAgent = decodeFunctionResult({ abi: padAbi, functionName: 'isAgent', data: agentRaw });
  const room = decodeFunctionResult({ abi: padAbi, functionName: 'walletRoom', data: roomRaw });
  const quoteDecimals = Number(decodeFunctionResult({ abi: erc20Abi, functionName: 'decimals', data: quoteDecimalsRaw }));
  const quoteSymbol = decodeFunctionResult({ abi: erc20Abi, functionName: 'symbol', data: quoteSymbolRaw });
  const quoteBalance = decodeFunctionResult({ abi: erc20Abi, functionName: 'balanceOf', data: quoteBalRaw });
  checks.push({ name: 'isAgent(wallet)', ok: isAgent, detail: String(isAgent) });
  if (!isAgent) throw new Error('该钱包没有 .ai Agent ID，无法买入');

  // 报价币是 WBNB：BNB 按 1:1 包装（WBNB.deposit），不走 Pancake（WBNB→WBNB 会 IDENTICAL_ADDRESSES）
  const quoteIsWbnb = quoteToken.toLowerCase() === WBNB.toLowerCase();
  const bnbWei = quoteInRaw ?? BigInt(parseUnits(amountBnb, 18));
  let gangOut;
  let swapRoute = null;
  let inventory = false; // 用钱包里已有的报价币库存买（不换币 / 不包装）
  if (quoteInRaw != null) {
    if (quoteInRaw <= 0n) throw new Error('报价币数量必须大于 0');
    gangOut = quoteInRaw;
    // 非 WBNB 报价：只用已有的报价币（官方 CLI 同样要求余额足够）；WBNB 报价不足部分仍可从 BNB 包装
    if (!quoteIsWbnb && quoteBalance < quoteInRaw) {
      throw new Error(`${quoteSymbol} 余额不足：需要 ${human18(quoteInRaw)}，钱包只有 ${human18(quoteBalance)}（上一步换币可能还没上链，稍后重试）`);
    }
    checks.push({ name: `使用已有 ${quoteSymbol}`, ok: true, detail: `${human18(quoteInRaw)}（余额 ${human18(quoteBalance)}）` });
  } else if (quoteIsWbnb) {
    gangOut = bnbWei;
    checks.push({ name: 'BNB → WBNB 包装', ok: true, detail: `1:1，${gangOut} wei` });
  } else {
    // 报价币库存：钱包里已备好足够的报价币时，按「这笔 BNB 现在值多少报价币」直接用库存买，
    // 省掉换币那一笔（配合常驻授权就是一笔完成）。估值用池子报价；成交保护仍由曲线的 minTokens 负责
    let inv = 0n;
    if (quoteBalance > 0n) inv = await estimateOut(WBNB, quoteToken, bnbWei).catch(() => 0n);
    if (inv > 0n && quoteBalance >= inv) {
      gangOut = inv;
      inventory = true;
      checks.push({ name: `使用 ${quoteSymbol} 库存`, ok: true, detail: `${amountBnb} BNB ≈ ${human18(inv)} ${quoteSymbol}（库存 ${human18(quoteBalance)}）` });
    } else {
      // 智能路由（V2+V3 混合）：只走 V2 时报价币若只有极小的 WBNB 池（如 oANT 约 $1），
      // 旧逻辑会把 BNB 全部换进小池子；这里按真实金额选路、做价格冲击检查并模拟真实到账
      swapRoute = await routeSwap({
        wallet, tokenIn: WBNB, tokenOut: quoteToken, amountIn: bnbWei, slippageBps: slip,
        nativeIn: true, extras: [quoteToken], overrideBalance: true,
        // 狙击传入更严的上限（只会收紧）：换报价币必须走深池子、低损耗路径
        maxImpactBps: spec.params.maxImpactBps ?? undefined, maxLossBps: spec.params.maxLossBps ?? undefined,
      });
      gangOut = swapRoute.expected;
      checks.push({ name: 'Pancake 智能路由报价', ok: true, detail: `${human18(gangOut)} ${quoteSymbol}，路由 ${swapRoute.route}` });
      warnings.push(...swapRoute.warnings);
    }
  }
  // WBNB 报价且钱包已有足够 WBNB：同样算库存（不用包装）
  if (quoteInRaw == null && quoteIsWbnb && quoteBalance >= gangOut) inventory = true;

  // 包装没有价格变动，内盘买入金额就是全额；走 Pancake 时用模拟到账按滑点留出下限
  const minQuote = swapRoute ? swapRoute.minOut : gangOut;
  // 与官方 CLI / LaunchpadV2._prepBuy 一致：1% 手续费、毕业线截断（多付退回）、1% 持仓上限截断
  let net = minQuote - (minQuote * FEE_BPS) / 10000n;
  const gradAmt = BigInt(curve[4]);
  const remaining = gradAmt > BigInt(realQuote) ? gradAmt - BigInt(realQuote) : 0n;
  if (remaining === 0n) throw new Error('曲线已达毕业线，等待迁移后到外盘交易');
  if (net > remaining) {
    net = remaining;
    warnings.push('这笔超过了毕业线：只按剩余额度成交，多付的报价币会退回，并会触发毕业建池（gas 较高）');
  }
  const k = BigInt(virtualQuote) * VIRTUAL_TOKEN;
  const qReserve = BigInt(virtualQuote) + BigInt(realQuote);
  const tReserve = VIRTUAL_TOKEN - BigInt(sold);
  const newT = (k + (qReserve + net) - 1n) / (qReserve + net);
  let tokensOut = tReserve - newT;
  if (tokensOut > room) {
    tokensOut = room;
    warnings.push('这笔触及 1% 持仓上限：超出部分的报价币会退回');
  }
  if (tokensOut <= 0n) throw new Error('计算出的可买数量为 0');
  const minTokens = (tokensOut * BigInt(10000 - slip)) / 10000n;
  checks.push({ name: '预计获得', ok: true, detail: `${tokensOut} tokens` });
  checks.push({ name: '钱包上限剩余', ok: room >= tokensOut, detail: String(room) });

  const allowance = decodeFunctionResult({ abi: erc20Abi, functionName: 'allowance', data: allowanceRaw });

  const steps = [];

  const needSwapIn = quoteBalance < minQuote;
  let wrapped = 0n; // 本计划包装的 BNB（其余用钱包已有 WBNB）
  if (needSwapIn && quoteIsWbnb) {
    // 与官方 CLI 一致：只包装差额（已有的 WBNB 先用）
    const short = minQuote - quoteBalance;
    wrapped = short;
    steps.push({
      label: `wrap ${human18(short)} BNB → WBNB`,
      recipient: wallet,
      next: { quoteIn: minQuote.toString() },
      tx: {
        to: WBNB,
        value: short.toString(),
        inputData: encodeFunctionData({ abi: wbnbAbi, functionName: 'deposit' }),
      },
    });
    warnings.push('先把差额 BNB 1:1 包装成 WBNB，再用 WBNB 内盘买入');
  } else if (needSwapIn) {
    steps.push({
      label: `swap ${amountBnb} BNB → ${quoteSymbol}（${swapRoute.route}）`,
      recipient: wallet,
      // 换币上链后按「保底到账」用已有报价币重新生成计划（官方 CLI：执行后 re-run 同一命令）
      next: { quoteIn: minQuote.toString() },
      tx: swapRoute.tx,
    });
    warnings.push(`先用 Pancake 智能路由换 ${quoteSymbol}，再用 ${quoteSymbol} 买；若已有足够 ${quoteSymbol} 会跳过兑换`);
  }

  if (allowance < minQuote && pendingApprove < minQuote) {
    steps.push({
      label: `approve ${human18(minQuote)} ${quoteSymbol} → pad（只授权本次数量）`,
      next: { quoteIn: minQuote.toString() },
      tx: {
        to: quoteToken,
        value: '0',
        inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [pad, minQuote] }),
      },
    });
  }

  steps.push({
    label: `buy ${quoteSymbol} → token`,
    tx: {
      to: pad,
      value: '0',
      inputData: encodeFunctionData({
        abi: padAbi,
        functionName: 'buy',
        args: [token, minQuote, minTokens],
      }),
    },
  });

  void quoteDecimals;

  // 用钱包里已有的报价币付的部分折合多少 BNB（步骤 value 之外的花费；单笔上限 = value 合计 + 这一项）。
  // 估不出时为 null：调用方在设了单笔上限时拒绝，而不是按 0 放行
  let bnbEquiv = 0n;
  if (quoteInRaw != null) {
    bnbEquiv = quoteIsWbnb ? quoteInRaw : await estimateOut(quoteToken, WBNB, quoteInRaw).catch(() => 0n);
    if (bnbEquiv === 0n) bnbEquiv = null;
  } else if (quoteIsWbnb) {
    bnbEquiv = minQuote - wrapped; // 已有 WBNB 用掉的部分（包装的那部分在 wrap 步骤的 value 里）
  } else if (inventory) {
    bnbEquiv = bnbWei;
  }

  return {
    kind: 'gang',
    protocol: 'gang',
    spec: {
      token,
      pad,
      quote: quoteToken,
      quoteSymbol,
      amountBnb,
      slippageBps: slip,
      buyWithQuote: minQuote.toString(),
      quoteMode: quoteInRaw != null,
      inventory,
      // 用钱包已有报价币付的部分折合的 BNB（单笔上限按 value 合计 + 它检查）；null = 估不出
      bnbEquivWei: bnbEquiv == null ? null : bnbEquiv.toString(),
      expectedTokens: tokensOut.toString(),
      minTokens: minTokens.toString(),
    },
    checks,
    steps,
    warnings,
  };
}
