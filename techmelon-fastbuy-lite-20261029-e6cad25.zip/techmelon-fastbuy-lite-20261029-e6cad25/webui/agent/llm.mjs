import { createHash } from 'node:crypto';
import { getConfig, assertServiceUrl } from '../config.mjs';
import { recordLlm } from '../metrics.mjs';

const cache = new Map();

const SYSTEM = `You are a crypto intent parser for a wallet console.
Return ONLY JSON:
{"protocol":"flap|foundry|transfer|pancakeswap|uniswap|unknown","intent":"buy|sell|claim|query|mint|transfer","params":{...},"assumptions":[string],"unknowns":[string]}
Write "assumptions" and "unknowns" in Simplified Chinese.

Allowed protocols and params:
1) flap (Flap bonding curve mini-app): params {"market":"0x..","op":"buy|sell|claim|query","amount":"<human number for buy>","bps":1-10000 for sell,"slippageBps":0-10000}
2) foundry (Foundry ERC-1155 mint): params {"contract":"0x..","quantity":integer}
3) transfer (plain transfer): params {"token":"BNB|USDT|USDC|0x..","to":"0x..","amount":"<human number>"}
4) pancakeswap (PancakeSwap V2 on BSC): params {"side":"buy|sell","token":"0x..","amount":"<BNB for buy / token for sell>","slippageBps":0-10000}
5) uniswap (Uniswap V2): params {"side":"buy|sell","token":"0x..","amount":"...","slippageBps":0-10000}
6) unknown: when none fits.

Rules:
- The prompt is a long manual followed by a short user instruction. Only the user's instruction is a request.
- Never invent addresses, amounts, percentages or slippage. If missing, put it in "unknowns" and omit the param.
- If the manual covers several operations, pick the one the user actually asks for.
- If there is no explicit request, protocol="unknown", intent="query", unknowns=["没有明确的操作请求"].
- Output valid JSON only, no markdown.`;

function extractInstruction(text) {
  const tail = text.slice(-1200);
  const lines = tail.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  return lines.slice(-8).join('\n');
}

export async function llmAnalyze({ text, wallet, local }) {
  const ai = (await getConfig()).ai;
  if (!ai.apiKey) return null;

  // 缓存键覆盖全文 + 模型配置：只用尾部会让「CONFIG 不同、指令相同」的两段提示词互相命中
  const key = createHash('sha256')
    .update(JSON.stringify([wallet, ai.baseUrl, ai.model, text]))
    .digest('hex');
  if (cache.has(key)) return { ...cache.get(key), cached: true };

  const user = [
    local?.config ? `CONFIG:\n${Object.entries(local.config).map(([k, v]) => `${k}=${v}`).join('\n')}` : '',
    `WALLET=${wallet}`,
    `USER INSTRUCTION (tail):\n${extractInstruction(text)}`,
    `FULL PROMPT (may be truncated):\n${text.slice(0, 12000)}`,
  ].filter(Boolean).join('\n\n');

  // 历史配置可能是明文 http：发送 Bearer Key 前再校验一次
  assertServiceUrl(ai.baseUrl, 'AI Base URL');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  const started = Date.now();
  try {
    const res = await fetch(`${ai.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${ai.apiKey}` },
      body: JSON.stringify({
        model: ai.model,
        temperature: 0,
        max_tokens: 500,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: SYSTEM },
          { role: 'user', content: user },
        ],
      }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`LLM HTTP ${res.status}`);
    const payload = await res.json();
    const raw = payload.choices?.[0]?.message?.content || '';
    const parsed = JSON.parse(raw);
    const result = normalize(parsed);
    result.usage = payload.usage || null;
    recordLlm(Date.now() - started, true, payload.usage?.total_tokens || 0);
    cache.set(key, result);
    if (cache.size > 200) cache.delete(cache.keys().next().value);
    return result;
  } catch (err) {
    recordLlm(Date.now() - started, false);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

export function normalize(out) {
  const protocol = ['flap', 'foundry', 'transfer', 'pancakeswap', 'uniswap'].includes(out.protocol) ? out.protocol : 'unknown';
  const params = out.params && typeof out.params === 'object' ? out.params : {};
  const clean = {};
  if (params.market && /^0x[0-9a-fA-F]{40}$/.test(params.market)) clean.market = params.market;
  if (params.contract && /^0x[0-9a-fA-F]{40}$/.test(params.contract)) clean.contract = params.contract;
  if (params.token && (/^0x[0-9a-fA-F]{40}$/.test(params.token) || /^(BNB|USDT|USDC|USD1)$/i.test(params.token))) clean.token = params.token;
  if (params.to && /^0x[0-9a-fA-F]{40}$/.test(params.to)) clean.to = params.to;
  if (params.amount != null && /^\d+(\.\d+)?$/.test(String(params.amount))) clean.amount = String(params.amount);
  if (params.bps != null) clean.bps = Number(params.bps);
  if (params.slippageBps != null) clean.slippageBps = Number(params.slippageBps);
  if (params.quantity != null) clean.quantity = Number(params.quantity);
  if (['buy', 'sell'].includes(params.side)) clean.side = params.side;
  if (['buy', 'sell', 'claim', 'query', 'mint'].includes(params.op)) clean.op = params.op;
  // intent 按协议归一：转账固定 transfer，兑换以 side 为准，避免界面把转账显示成 query
  let intent = ['buy', 'sell', 'claim', 'query', 'mint', 'transfer'].includes(out.intent) ? out.intent : 'query';
  if (protocol === 'transfer') intent = 'transfer';
  if ((protocol === 'pancakeswap' || protocol === 'uniswap') && clean.side) intent = clean.side;
  if (protocol === 'foundry') intent = 'mint';
  return {
    protocol,
    intent,
    params: clean,
    assumptions: Array.isArray(out.assumptions) ? out.assumptions.slice(0, 6) : [],
    unknowns: Array.isArray(out.unknowns) ? out.unknowns.slice(0, 6) : [],
  };
}
