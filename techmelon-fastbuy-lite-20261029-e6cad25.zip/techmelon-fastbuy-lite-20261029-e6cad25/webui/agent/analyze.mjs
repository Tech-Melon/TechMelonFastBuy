import { getConfig } from '../config.mjs';
import { extractConfig, validateConfig, inferByRules } from '../prompt.mjs';
import { planFlap } from '../flap.mjs';
import { detectKind, planMint } from '../tasks.mjs';
import { llmAnalyze } from './llm.mjs';
import { detectCustom, planCustom } from './custom.mjs';
import { planTransfer, planSwap } from './adapters.mjs';
import { detectGang, planGang } from './gang.mjs';
import { detectScripted, planScripted } from './scripted.mjs';
import { vetLlmParams, fillMissing, instructionOf } from './guard.mjs';

/**
 * 需要下载 / 安装 / 运行第三方 CLI 或 skill 的提示词（如 TRACE 的 trace-agent）：
 * 交易由第三方程序构造并用钱包会话发出，绕过本控制台的预览绑定与参数护栏。按用户决定一律拒绝，
 * 不调用模型、不生成计划、不访问提示词里的链接。
 */
const EXTERNAL_SKILL_SIGNALS = [
  [/https?:\/\/\S+\/skill\.md\b|\bSKILL\.md\b|\buse\s+the\s+\S+\s+skill\b|使用\s*\S+\s*(?:skill|技能)/i, '引用了外部 skill 文档'],
  [/\b(?:npm|pnpm|yarn)\s+(?:install|i|add)\b|\bnpx\s+\S+|\bpip3?\s+install\b|\buv\s+(?:tool\s+)?install\b|\bcurl\b[^\n|]*\|\s*(?:ba)?sh\b/i, '要求安装软件包'],
  [/\b(?:published|install(?:ed)?|upgrade|update)\s+(?:the\s+)?(?:\S+\s+){0,3}CLI\b|\bCLI\s*\(?\s*v?\d+\.\d+/i, '要求安装或升级第三方 CLI'],
  [/\b[a-z][\w-]*-(?:agent|cli)\s+(?:preflight|preview|execute|receipt|operations|config)\b/i, '要求运行第三方命令行工具'],
];

export function detectExternalSkill(text) {
  const hits = EXTERNAL_SKILL_SIGNALS.filter(([re]) => re.test(text)).map(([, why]) => why);
  return hits.length ? hits : null;
}

/** 要求使用 / 提供私钥或助记词的提示词（如 `cast send … --private-key $PRIVATE_KEY`）：Agentic Wallet 没有私钥，一律拒绝 */
const PRIVATE_KEY_RE = /--private-key\b|\$\{?PRIVATE_KEY\b|(?:提供|输入|导出|粘贴|填写)[^\n]{0,6}(?:私钥|助记词)|\b(?:enter|paste|export|provide)\s+(?:your\s+)?(?:private\s+key|seed\s+phrase|mnemonic)/i;

export async function analyzePrompt({ text, wallet }) {
  const started = Date.now();
  if (PRIVATE_KEY_RE.test(text)) {
    throw new Error('已拒绝：提示词要求使用私钥 / 助记词（例如 cast send --private-key）。Binance Agentic Wallet 没有可导出的私钥，'
      + '本控制台也绝不读取或传递私钥。请只保留「做什么」（如「在 Gang 买 0.05 BNB 的 0x…，滑点 5%」），由控制台生成交易并经币安预览确认。');
  }
  const external = detectExternalSkill(text);
  if (external) {
    throw new Error(`已拒绝：这是需要运行第三方 CLI / skill 的提示词（${external.join('、')}）。`
      + '这类操作由第三方程序代你构造并发出交易，绕过本控制台的预览与护栏，按你的设置不支持，也不会下载或执行其中的任何内容。'
      + '如果项目方提供了合约地址与函数，可以改写成「合约 0x… 调 函数(参数=值)，付 X BNB」再解析。');
  }
  const config = extractConfig(text) || null;
  const kind = detectKind(text);
  const ai = (await getConfig()).ai;
  // 「Contract + 1. 2. 3. 分步调用」：校验 → 读取 value → 调用，规则解析，不交给模型猜。
  // 编号脚本优先于单次调用：脚本最后一步也常写「sending X BNB」，会被单次调用误吞
  const scripted = config ? null : detectScripted(text);
  const custom = scripted ? null : detectCustom(text);
  const gang = custom || scripted ? null : detectGang(text);
  const swap = custom || gang || scripted ? null : detectSwap(text);
  // 转账只从用户指令里识别：手册正文里的「转给 0x…」不能成为收款人
  const transfer = custom || swap || gang || scripted ? null : detectTransfer(instructionOf(text));

  let spec = null;
  let source = 'rules';
  let llmError = null;
  let llmUsage = null;

  if (custom) {
    spec = {
      protocol: 'custom',
      intent: 'call',
      params: { contract: custom.contract, signature: custom.signature, valueBnb: custom.valueBnb },
      assumptions: [],
      unknowns: [],
    };
  } else if (scripted) {
    const last = scripted.steps[scripted.steps.length - 1];
    spec = {
      protocol: 'custom',
      intent: 'call',
      params: {
        contract: scripted.contract,
        mode: 'scripted',
        steps: scripted.steps.map((s) => `${s.n}. ${s.call[0]}`),
        call: last.call[0],
      },
      assumptions: [],
      unknowns: [],
    };
  } else if (gang) {
    spec = gang;
  } else if (swap) {
    spec = swap;
  } else if (config && config.MARKET) {
    const r = inferByRules(text);
    spec = {
      protocol: 'flap',
      intent: r.operation || 'query',
      params: {
        market: config.MARKET,
        // 规则没识别出操作时留空，允许模型补全；最终仍为空则按只读 query 处理
        op: r.operation || null,
        amount: r.amount || null,
        bps: r.percent ? Math.round(r.percent * 100) : null,
        slippageBps: r.slippageBps,
      },
      assumptions: [],
      unknowns: [],
    };
  } else if (kind === 'mint') {
    spec = inferMintSpec(text);
  } else if (transfer) {
    spec = transfer;
  }

  const guardWarnings = [];

  if (!custom && !scripted && !gang && !swap && !transfer && ai.apiKey) {
    try {
      const llm = await llmAnalyze({ text, wallet, local: { config } });
      if (llm) {
        llmUsage = llm.usage || null;
        // foundry 适配器写死了 Foundry ERC-1155 的接口（handleOf/mintOpen/quoteBnb）：
        // 模型把别的 mint 归到 foundry 会调用不存在的函数，必须有 ERC-1155 Foundry 特征才接受
        if (llm.protocol === 'foundry' && kind !== 'mint' && !/\bfoundry\b/i.test(text)) {
          guardWarnings.push('模型判断为 Foundry Mint，但提示词没有 Foundry ERC-1155 特征，已拒绝');
          llm.protocol = 'unknown';
          llm.unknowns = [...(llm.unknowns || []), '不是 Foundry ERC-1155 Mint；如果是「合约 + 1. 2. 3. 分步调用」，请写明 Contract: 0x… 与编号步骤'];
        }
        if (llm.protocol !== 'unknown') {
          // LLM 参数必须能在原文中字面找到，否则丢弃（防幻觉 / prompt injection）
          const vetted = vetLlmParams(llm.params, text, llm.protocol);
          if (vetted.rejected.length) {
            guardWarnings.push(`模型给出的 ${vetted.rejected.join('、')} 在用户指令中找不到原文，已丢弃`);
          }
          if (spec) {
            // 规则已确定协议与参数：规则优先，模型只补缺失字段
            if (spec.protocol === llm.protocol) {
              const { params, filled } = fillMissing(spec.params, vetted.params);
              spec.params = params;
              spec.assumptions = llm.assumptions;
              if (filled.length) {
                source = 'rules+llm';
                guardWarnings.push(`以下字段由模型补全，请核对：${filled.join('、')}`);
              }
            } else {
              guardWarnings.push(`模型判断为 ${llm.protocol}，与规则解析的 ${spec.protocol} 不一致，已以规则为准`);
            }
          } else {
            spec = {
              protocol: llm.protocol,
              intent: llm.intent,
              params: vetted.params,
              assumptions: llm.assumptions,
              unknowns: [...llm.unknowns, ...vetted.rejected],
            };
            source = 'llm';
          }
        } else if (!spec) {
          spec = {
            protocol: 'unknown',
            intent: llm.intent,
            params: {},
            assumptions: llm.assumptions,
            unknowns: llm.unknowns,
          };
          source = 'llm';
        }
      }
    } catch (err) {
      llmError = err.message;
    }
  }

  if (spec?.protocol === 'flap') {
    spec.params.op = spec.params.op || 'query';
    spec.intent = spec.params.op;
  }
  if (spec?.protocol === 'transfer' && source === 'llm') {
    guardWarnings.push('收款地址来自模型解析，请逐字核对');
  }
  // 转账计划固定在 BSC：用户写了别的链就拒绝，不能悄悄改成 BSC 上的同名代币
  const transferChain = spec?.protocol === 'transfer' ? otherChainMentioned(instructionOf(text)) : null;

  if (!spec) {
    throw new Error('无法识别该提示词。当前支持 Flap / Foundry Mint / 自定义合约调用 / 转账 / PancakeSwap / Uniswap；配置 AI Key 后可解析更口语化的指令。');
  }
  if (spec.protocol === 'unknown') {
    const unknowns = spec.unknowns?.length ? spec.unknowns.join('；') : '未识别到明确操作';
    throw new Error(`模型未能确定操作：${unknowns}`);
  }

  let plan = null;
  let planError = null;
  try {
    if (spec.protocol === 'flap') {
      plan = await buildFlapPlan(spec, config, wallet);
    } else if (spec.protocol === 'foundry') {
      plan = await planMint({ wallet, text, quantity: spec.params.quantity });
      plan.protocol = 'foundry';
    } else if (spec.protocol === 'custom') {
      plan = spec.params.mode === 'scripted' ? await planScripted({ wallet, text }) : await planCustom({ wallet, text });
    } else if (spec.protocol === 'transfer') {
      if (transferChain) throw new Error(`指令提到了 ${transferChain}，AI 转账目前只支持 BSC；其他链请用「转账」页手动选择链`);
      plan = await planTransfer({ wallet, spec });
    } else if (spec.protocol === 'gang') {
      plan = await planGang({ wallet, spec });
    } else if (spec.protocol === 'pancakeswap' || spec.protocol === 'uniswap') {
      plan = await planSwap({ wallet, spec });
    } else {
      throw new Error(`暂不支持协议：${spec.protocol}`);
    }
  } catch (err) {
    planError = err.message;
  }

  if (plan && guardWarnings.length) plan.warnings = [...guardWarnings, ...(plan.warnings || [])];

  return {
    source,
    spec,
    plan,
    planError,
    guardWarnings,
    checks: plan?.checks || [],
    warnings: plan?.warnings || guardWarnings,
    missing: spec.unknowns || [],
    configChecks: config ? validateConfig(config) : [],
    elapsedMs: Date.now() - started,
    llmError,
    llmUsage,
  };
}

async function buildFlapPlan(spec, config, wallet) {
  const market = spec.params.market || config?.MARKET;
  if (!market || !/^0x[0-9a-fA-F]{40}$/.test(market)) throw new Error('缺少合法的 MARKET 地址');

  const op = ['buy', 'sell', 'claim', 'query'].includes(spec.params.op)
    ? spec.params.op
    : (['buy', 'sell', 'claim', 'query'].includes(spec.intent) ? spec.intent : null);
  if (!op) throw new Error('无法确定 Flap 操作（buy/sell/claim/query）');

  if ((op === 'buy' || op === 'sell') && spec.params.slippageBps == null) {
    throw new Error('缺少滑点：提示词未指定，按规则不设默认值');
  }
  if (op === 'buy' && !spec.params.amount) throw new Error('缺少买入金额');
  if (op === 'sell' && !spec.params.bps) throw new Error('缺少卖出比例');

  const plan = await planFlap({
    wallet,
    market,
    op,
    amount: spec.params.amount || '0',
    bps: spec.params.bps || 0,
    slippageBps: Number(spec.params.slippageBps || 0),
    expect: {
      probe: config?.PROBE || '',
      quote: config?.QUOTE_TOKEN || '',
      decimals: config?.QUOTE_DECIMALS || '',
    },
  });
  plan.protocol = 'flap';
  return plan;
}

/** 滑点：中文「滑点 1%」或英文「slippage 1%」 */
const SLIPPAGE_RE = /(?:滑点|slippage)[^\d\n]{0,8}(\d+(?:\.\d+)?)\s*%/i;

/** 用户指令里提到的非 BSC 链（转账目前只在 BSC 上生成计划） */
function otherChainMentioned(ins) {
  const m = ins.match(/以太坊|ethereum|\bon\s+eth\b|\bbase\b|arbitrum|polygon|optimism|solana|avalanche/i);
  return m ? m[0] : null;
}

function detectSwap(text) {
  const protocol = /pancake/i.test(text) ? 'pancakeswap' : /uniswap/i.test(text) ? 'uniswap' : null;
  if (!protocol) return null;
  if (!/(swap|兑换|买入|卖出|buy|sell)/i.test(text)) return null;

  const skip = new Set([
    '0x10ed43c718714eb63d5aa57b78b54704e256024e',
    '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
    '0x7a250d5630b4cf539739df2c5dacb4c659f2488d',
    '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
  ]);
  // 方向 / 金额 / 滑点只看用户指令；代币地址优先取指令里的，其次才是全文
  const ins = instructionOf(text);
  const pick = (src) => [...src.matchAll(/0x[0-9a-fA-F]{40}/g)].map((m) => m[0]).find((a) => !skip.has(a.toLowerCase()));
  const token = pick(ins) || pick(text);
  const side = /(卖出|卖|sell)/i.test(ins) ? 'sell' : 'buy';
  const slip = (ins.match(SLIPPAGE_RE) || [])[1];
  // 取数量前先去掉滑点子句和地址：否则「50%」的滑点、「0x55…」开头的 0 会被当成数量
  const clean = ins.replace(new RegExp(SLIPPAGE_RE.source, 'gi'), ' ').replace(/0x[0-9a-fA-F]{40}/g, ' ADDR ');
  let amount = null;
  let percent = null;
  if (side === 'buy') {
    amount = (clean.match(/(\d+(?:\.\d+)?)\s*(BNB|ETH)\b/i) || [])[1] || null;
  } else {
    // 「卖出 50%」是按持仓比例，不能当成 50 个代币
    percent = (clean.match(/(?:卖出|卖|sell)[^\n%]{0,30}?(\d+(?:\.\d+)?)\s*%/i) || [])[1] || null;
    if (!percent) amount = (clean.match(/(?:卖出|卖|sell)\D{0,20}?(\d+(?:\.\d+)?)(?![\d.])/i) || [])[1] || null;
  }
  if (!token || (!amount && !percent)) return null;

  return {
    protocol,
    intent: side,
    params: {
      side,
      token,
      amount,
      ...(percent ? { percent } : {}),
      slippageBps: slip ? Math.round(Number(slip) * 100) : null,
      chainId: protocol === 'uniswap' ? 1 : 56,
    },
    assumptions: [],
    unknowns: slip ? [] : ['slippageBps'],
  };
}

function detectTransfer(text) {
  if (!/(转账|transfer|send|发送)/i.test(text)) return null;
  if (/Mint|NFT|ERC-1155/i.test(text)) return null;
  const to = (text.match(/(?:to|给|到|收款地址[:：]?)\s*(0x[0-9a-fA-F]{40})/i) || [])[1];
  const amount = (text.match(/([\d.]+)\s*(BNB|USDT|USDC|USD1)\b/i) || [])[1];
  const token = (text.match(/([\d.]+)\s*(BNB|USDT|USDC|USD1)\b/i) || [])[2];
  if (!to || !amount || !token) return null;
  return {
    protocol: 'transfer',
    intent: 'transfer',
    params: { token, to, amount, chainId: 56 },
    assumptions: [],
    unknowns: [],
  };
}

function inferMintSpec(text) {  const contract = (text.match(/Contract[^\n:：]*[:：]\s*(0x[0-9a-fA-F]{40})/i) || [])[1];
  const qty = Number((text.match(/Mint\s+(\d+)/i) || [])[1] || 0);
  return {
    protocol: 'foundry',
    intent: 'mint',
    params: { contract, quantity: qty || null },
    assumptions: [],
    unknowns: qty ? [] : ['quantity'],
  };
}
