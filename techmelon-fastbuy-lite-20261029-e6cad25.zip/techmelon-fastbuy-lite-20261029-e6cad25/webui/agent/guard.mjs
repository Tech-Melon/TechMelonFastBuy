/**
 * LLM 输出约束与通用交易参数护栏。
 *
 * 原则：规则解析出的确定性字段优先；LLM 只能补缺，且它给出的每个值都必须能在
 * 原文中「字面找到」——数值必须出现在用户指令尾部，地址必须出现在提示词里，
 * 收款地址必须出现在用户指令尾部（防止第三方手册里埋的地址被当成收款人）。
 */

const ADDR = /^0x[0-9a-fA-F]{40}$/;

/**
 * 单笔滑点硬上限（bps）：默认 50%（用户要求，与 Four 狙击的上限一致），环境变量 MAX_SLIPPAGE_BPS 只能往下调。
 * 滑点只决定「最少收到」：实际成交仍按当时价格；价格冲击 > 10% 的路由、实测损耗 > 20% 的疑似貔貅另有独立拦截。
 */
export const MAX_SLIPPAGE_BPS = (() => {
  const v = Number(process.env.MAX_SLIPPAGE_BPS || 5000);
  return Number.isInteger(v) && v > 0 && v <= 5000 ? v : 5000;
})();

/** 校验滑点：必须是 0..MAX_SLIPPAGE_BPS 的整数 */
export function assertSlippageBps(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) throw new Error(`滑点不合法：${value}`);
  if (n > MAX_SLIPPAGE_BPS) {
    throw new Error(`滑点 ${n / 100}% 超过安全上限 ${MAX_SLIPPAGE_BPS / 100}%（可通过 MAX_SLIPPAGE_BPS 调整）`);
  }
  return n;
}

/** 提示词的「用户指令」部分：最后 1200 字符里的最后 8 个非空行 */
export function instructionOf(text) {
  const tail = String(text || '').slice(-1200);
  const lines = tail.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  return lines.slice(-8).join('\n');
}

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** 数字是否以独立数字的形式出现在文本中（"0.1" 不会匹配 "10.1" 或 "0.15"） */
export function numberAppears(value, text) {
  const s = String(value ?? '').trim();
  if (!/^\d+(\.\d+)?$/.test(s)) return false;
  const variants = new Set([s, String(Number(s))]);
  return [...variants].some((v) => new RegExp(`(^|[^\\d.])${escapeRe(v)}(?![\\d])`).test(text));
}

export function addressAppears(value, text) {
  return ADDR.test(String(value || '')) && String(text || '').toLowerCase().includes(String(value).toLowerCase());
}

/** bps 值：用户写的通常是百分比（5%），也接受直接写 bps */
function bpsAppears(bps, text) {
  const n = Number(bps);
  if (!Number.isFinite(n)) return false;
  return numberAppears(String(n / 100), text) || numberAppears(String(n), text);
}

/**
 * 过滤 LLM 参数：不能在原文中字面找到的值一律丢弃，并记入 rejected。
 * @returns {{ params: object, rejected: string[] }}
 */
export function vetLlmParams(params, text, protocol) {
  const instruction = instructionOf(text);
  const out = {};
  const rejected = [];
  const keep = (key, ok) => {
    if (params[key] == null) return;
    if (ok) out[key] = params[key];
    else rejected.push(key);
  };

  keep('market', addressAppears(params.market, text));
  keep('contract', addressAppears(params.contract, text));
  keep('token', ADDR.test(String(params.token || ''))
    ? addressAppears(params.token, text)
    : new RegExp(`\\b${escapeRe(String(params.token || ''))}\\b`, 'i').test(instruction));
  // 收款地址必须出现在用户指令里，不能只出现在手册正文
  keep('to', addressAppears(params.to, instruction));
  keep('amount', numberAppears(params.amount, instruction));
  keep('quantity', numberAppears(params.quantity, instruction));
  keep('bps', bpsAppears(params.bps, instruction));
  keep('slippageBps', bpsAppears(params.slippageBps, instruction));
  if (params.side != null) out.side = params.side;
  if (params.op != null) out.op = params.op;

  void protocol;
  return { params: out, rejected };
}

/** 规则结果优先：只用 LLM 的值填补规则缺失（null/undefined）的字段 */
export function fillMissing(ruleParams, llmParams) {
  const merged = { ...ruleParams };
  const filled = [];
  for (const [k, v] of Object.entries(llmParams || {})) {
    if ((merged[k] == null || merged[k] === '') && v != null) {
      merged[k] = v;
      filled.push(k);
    }
  }
  return { params: merged, filled };
}
