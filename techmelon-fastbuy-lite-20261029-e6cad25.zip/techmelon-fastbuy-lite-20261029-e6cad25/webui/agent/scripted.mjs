/**
 * 「分步脚本」型提示词：合约 + 编号步骤，例如
 *
 *   Contract: 0x53c0…ae7d
 *   1. Call hasAgentId(myWallet) and stop if it is false.
 *   2. Call quote(myWallet) to get the BNB (in wei) to send.
 *   3. Call mint() sending exactly that BNB.
 *
 * 规则解析（不经过模型）：
 *   - 校验步骤：读 bool，按「stop if false / true」决定期望值，不满足就停；
 *   - 取值步骤：读 uint256（wei），作为最后一步的 value；
 *   - 最终调用：最后一个编号步骤，value 来自取值步骤或字面量「sending 0.01 BNB」。
 * 参数只接受 myWallet（替换为当前钱包）、地址、整数，其它一律拒绝，不猜。
 */
import { encodeFunctionData, decodeFunctionResult, parseAbi } from 'viem';
import { rpc } from '../config.mjs';

const ADDR = /^0x[0-9a-fA-F]{40}$/;
const MAX_VALUE_WEI = 10n ** 18n; // 单笔 value 上限 1 BNB，与 custom 一致
const GAS_RESERVE_WEI = 5n * 10n ** 14n; // 0.0005 BNB

const WALLET_TOKEN = /^(my\s*wallet|mywallet|wallet|my\s*address|me|msg\.sender|我的钱包|钱包|我的地址)$/i;
const FINAL_FROM_BOUND = /(sending|send|附带|发送|支付|转入)\s*(exactly\s*)?(that|this|the\s+quoted|上面的|该|这笔|这个|报价的?)/i;
const FINAL_LITERAL = /(sending|附带|发送|支付|with)\s*(exactly\s*)?(\d+(?:\.\d+)?)\s*BNB/i;
const STOP_IF_FALSE = /stop\s+if\s+(it\s+is\s+|it's\s+|the\s+result\s+is\s+)?false|false\s*(就|则)?\s*停止|必须(为|是)\s*true|must\s+be\s+true/i;
const STOP_IF_TRUE = /stop\s+if\s+(it\s+is\s+|it's\s+|the\s+result\s+is\s+)?true|true\s*(就|则)?\s*停止|必须(为|是)\s*false|must\s+be\s+false/i;
const BIND_HINT = /\b(wei|bnb|value|price|cost|fee)\b|金额|价格|费用|报价/i;

function parseArgsList(raw, label) {
  const parts = raw.split(',').map((s) => s.trim()).filter(Boolean);
  return parts.map((p) => {
    if (WALLET_TOKEN.test(p)) return { type: 'address', wallet: true, show: 'myWallet' };
    if (ADDR.test(p)) return { type: 'address', value: p.toLowerCase(), show: p };
    if (/^\d+$/.test(p)) return { type: 'uint256', value: BigInt(p), show: p };
    throw new Error(`${label} 的参数「${p}」无法识别（只支持 myWallet / 地址 / 整数）`);
  });
}

/** 识别分步脚本；不像脚本时返回 null（交给其它解析器） */
export function detectScripted(text) {
  const contract = (text.match(/(?:contract|合约)[^\n:：]{0,20}[:：]\s*(0x[0-9a-fA-F]{40})/i) || [])[1];
  if (!contract) return null;
  const lines = [...text.matchAll(/^\s*(\d{1,2})\s*[.)、]\s*(.+)$/gm)].map((m) => ({ n: Number(m[1]), text: m[2].trim() }));
  const steps = lines
    .map((l) => ({ ...l, call: l.text.match(/\b([A-Za-z_]\w*)\s*\(([^()]*)\)/) }))
    .filter((l) => l.call);
  if (steps.length < 2) return null;
  const last = steps[steps.length - 1];
  if (!FINAL_FROM_BOUND.test(last.text) && !FINAL_LITERAL.test(last.text) && !/^call\b|调用/i.test(last.text)) return null;
  return { contract, steps };
}

export function parseScripted(text) {
  const base = detectScripted(text);
  if (!base) return null;
  const { contract, steps } = base;

  const checks = [];
  let bind = null;
  const lastStep = steps[steps.length - 1];
  for (const s of steps.slice(0, -1)) {
    const fn = s.call[1];
    const args = parseArgsList(s.call[2], `${fn}()`);
    if (STOP_IF_FALSE.test(s.text)) checks.push({ fn, args, expect: true, line: s.text });
    else if (STOP_IF_TRUE.test(s.text)) checks.push({ fn, args, expect: false, line: s.text });
    else if (BIND_HINT.test(s.text)) {
      if (bind) throw new Error(`有两个取值步骤（${bind.fn}、${fn}），无法确定用哪个作为 value`);
      bind = { fn, args, line: s.text };
    } else {
      throw new Error(`第 ${s.n} 步「${s.text}」看不出是校验还是取值：请写明「stop if it is false」或「to get the BNB (in wei)」`);
    }
  }

  const fn = lastStep.call[1];
  const callArgs = parseArgsList(lastStep.call[2], `${fn}()`);
  let value = { kind: 'zero' };
  const literal = lastStep.text.match(FINAL_LITERAL);
  if (FINAL_FROM_BOUND.test(lastStep.text)) {
    if (!bind) throw new Error(`最后一步要求发送「那笔 BNB」，但前面没有取值步骤`);
    value = { kind: 'bound' };
  } else if (literal) {
    value = { kind: 'literal', bnb: literal[3] };
  } else if (bind) {
    throw new Error('前面读取了金额，但最后一步没写明要发送它（例如「sending exactly that BNB」）');
  }

  // 数量：只支持每次 1 个；「one per call」时要求 Mint 1
  const qty = Number((text.match(/\bmint\s+(\d+)\b/i) || [])[1] || 1);
  if (qty !== 1 && /one\s+per\s+call|每次\s*(只能)?\s*1/i.test(text)) {
    throw new Error(`提示词要求每次只能 mint 1 个，但写的是 ${qty} 个；请改成 1，需要多个就分多次运行`);
  }
  if (qty !== 1) throw new Error(`分步脚本每次只生成一笔调用，暂不支持一次 mint ${qty} 个`);
  const perWallet = Number((text.match(/up\s+to\s+(\d+)\s+per\s+wallet|每个钱包最多\s*(\d+)/i) || []).slice(1).find(Boolean) || 0);

  return { contract, checks, bind, call: { fn, args: callArgs }, value, perWallet };
}

const resolveArgs = (args, wallet) => args.map((a) => (a.wallet ? wallet.toLowerCase() : a.value));
const sigOf = (fn, args) => `${fn}(${args.map((a) => a.type).join(',')})`;
const showOf = (fn, args) => `${fn}(${args.map((a) => a.show).join(', ')})`;

async function readView(contract, fn, args, wallet, returns) {
  const abi = parseAbi([`function ${sigOf(fn, args)} view returns (${returns})`]);
  const data = encodeFunctionData({ abi, functionName: fn, args: resolveArgs(args, wallet) });
  let raw;
  try {
    raw = await rpc('eth_call', [{ to: contract, data, from: wallet }, 'latest']);
  } catch (err) {
    throw new Error(`读取 ${showOf(fn, args)} 失败（合约可能没有这个函数或参数不对）：${err.message}`);
  }
  return decodeFunctionResult({ abi, functionName: fn, data: raw });
}

const bnb = (wei) => {
  const s = wei.toString().padStart(19, '0');
  const frac = s.slice(-18).replace(/0+$/, '');
  return frac ? `${s.slice(0, -18)}.${frac}` : s.slice(0, -18);
};

export async function planScripted({ wallet, text }) {
  if (!ADDR.test(wallet)) throw new Error('wallet 地址不正确');
  const spec = parseScripted(text);
  if (!spec) throw new Error('不是可识别的分步脚本提示词');
  const checks = [];

  const code = await rpc('eth_getCode', [spec.contract, 'latest']);
  const size = code && code !== '0x' ? (code.length - 2) / 2 : 0;
  checks.push({ name: '合约已部署', ok: size > 0, detail: `${size} bytes` });
  if (!size) throw new Error('目标地址没有合约代码');

  for (const c of spec.checks) {
    const v = await readView(spec.contract, c.fn, c.args, wallet, 'bool');
    const ok = v === c.expect;
    checks.push({ name: `${showOf(c.fn, c.args)} == ${c.expect}`, ok, detail: String(v) });
    if (!ok) throw new Error(`${showOf(c.fn, c.args)} = ${v}，提示词要求为 ${c.expect}，已停止`);
  }

  if (spec.perWallet) {
    try {
      const held = await readView(spec.contract, 'balanceOf', [{ type: 'address', wallet: true, show: 'myWallet' }], wallet, 'uint256');
      const ok = held < BigInt(spec.perWallet);
      checks.push({ name: `balanceOf(myWallet) < ${spec.perWallet}`, ok, detail: String(held) });
      if (!ok) throw new Error(`该钱包已持有 ${held} 个，达到每钱包上限 ${spec.perWallet}`);
    } catch (err) {
      if (/上限/.test(err.message)) throw err;
      checks.push({ name: `每钱包上限 ${spec.perWallet}`, ok: true, detail: '合约无 balanceOf，未核对（以链上模拟为准）' });
    }
  }

  let valueWei = 0n;
  if (spec.value.kind === 'bound') {
    valueWei = await readView(spec.contract, spec.bind.fn, spec.bind.args, wallet, 'uint256');
    checks.push({ name: showOf(spec.bind.fn, spec.bind.args), ok: true, detail: `${valueWei} wei（${bnb(valueWei)} BNB${valueWei === 0n ? '，免费' : ''}）` });
  } else if (spec.value.kind === 'literal') {
    const [w, f = ''] = spec.value.bnb.split('.');
    if (f.length > 18) throw new Error('BNB 小数位超过 18');
    valueWei = BigInt(w) * 10n ** 18n + BigInt((f + '0'.repeat(18)).slice(0, 18) || '0');
  }
  if (valueWei > MAX_VALUE_WEI) throw new Error(`value ${bnb(valueWei)} BNB 超过单笔 1 BNB 安全上限`);

  const balance = BigInt(await rpc('eth_getBalance', [wallet, 'latest']));
  const enough = balance >= valueWei + GAS_RESERVE_WEI;
  checks.push({ name: 'BNB 余额（含 gas 预留）', ok: enough, detail: `${bnb(balance)} BNB` });
  if (!enough) throw new Error(`BNB 余额不足：需要 ${bnb(valueWei)} + gas`);

  const callAbi = parseAbi([`function ${sigOf(spec.call.fn, spec.call.args)}`]);
  const inputData = encodeFunctionData({ abi: callAbi, functionName: spec.call.fn, args: resolveArgs(spec.call.args, wallet) });

  // 生成计划前先 eth_call 模拟一次：售罄、未开放、限额等 revert 原因直接告诉用户，不用等到预览
  try {
    await rpc('eth_call', [{ from: wallet, to: spec.contract, value: `0x${valueWei.toString(16)}`, data: inputData }, 'latest']);
    checks.push({ name: `模拟 ${showOf(spec.call.fn, spec.call.args)}`, ok: true, detail: '不会 revert' });
  } catch (err) {
    // 节点会把 revert 原始数据拼在原因后面（": 0x08c379a0…"），只保留可读部分
    const reason = String(err.message || '')
      .replace(/^execution reverted:?\s*/i, '')
      .replace(/:?\s*0x[0-9a-fA-F]{8,}\s*$/, '')
      .trim() || 'revert（无原因）';
    checks.push({ name: `模拟 ${showOf(spec.call.fn, spec.call.args)}`, ok: false, detail: reason });
    throw new Error(`链上模拟失败，合约拒绝了这笔调用：${reason}`);
  }

  return {
    kind: 'custom',
    protocol: 'custom',
    spec: {
      contract: spec.contract,
      functionName: spec.call.fn,
      signature: sigOf(spec.call.fn, spec.call.args),
      valueBnb: bnb(valueWei),
      gasLimit: null,
      args: spec.call.args.map((a, i) => `${a.type} arg${i} = ${a.wallet ? `${wallet}（myWallet）` : a.show}`),
      mode: 'scripted',
    },
    checks,
    steps: [{
      label: `${showOf(spec.call.fn, spec.call.args)} → ${spec.contract}`,
      tx: { chainId: '56', to: spec.contract, value: valueWei.toString(), inputData },
    }],
    notes: [
      `value 由 ${spec.value.kind === 'bound' ? `链上 ${showOf(spec.bind.fn, spec.bind.args)}` : spec.value.kind === 'literal' ? '提示词字面量' : '默认 0'} 决定，已在链上模拟通过`,
    ],
    warnings: [],
  };
}
