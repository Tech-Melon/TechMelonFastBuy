import { encodeFunctionData, parseAbi, decodeFunctionResult } from 'viem';
import { rpcFor } from '../config.mjs';
import { assertSlippageBps, MAX_SLIPPAGE_BPS } from './guard.mjs';

const NATIVE = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';

export const BSC_TOKENS = {
  BNB: NATIVE,
  WBNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  USDT: '0x55d398326f99059fF775485246999027B3197955',
  USDC: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
  U: '0xcE24439F2D9C6a2289F741120FE202248B666666',
  USD1: '0x8d0D000Ee44948FC98c9B98A4FA4921476f08B0d',
};

export const ROUTERS = {
  pancakeswap: {
    chainId: 56,
    router: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
    wrapped: BSC_TOKENS.WBNB,
    // 多跳中转币：只用硬编码的主流稳定币（外盘 meme 常见的 USDT / USD1 / U 计价池）
    hubs: { USDT: BSC_TOKENS.USDT, USD1: BSC_TOKENS.USD1, USDC: BSC_TOKENS.USDC, U: BSC_TOKENS.U },
  },
  uniswap: {
    chainId: 1,
    router: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
    wrapped: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    hubs: {
      USDC: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    },
  },
};

// 多跳多一次 swap 的 gas：比直连多出的收益不到 0.2% 时仍走直连
const MULTIHOP_MIN_GAIN_BPS = 20n;
// 税率探测的精度（bps）：只在模拟失败时才二分，正常路径不增加延迟
const TAX_PROBE_STEP_BPS = 25;

const erc20Abi = parseAbi([
  'function transfer(address to,uint256 amount) returns (bool)',
  'function approve(address spender,uint256 amount) returns (bool)',
  'function allowance(address owner,address spender) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function balanceOf(address) view returns (uint256)',
]);

const routerAbi = parseAbi([
  'function getAmountsOut(uint256 amountIn,address[] path) view returns (uint256[])',
  // SupportingFeeOnTransferTokens 版本按「实际到账余额」校验 amountOutMin：
  // 普通代币结果相同，转账税 / 通缩币也不会因 K 校验或输出预期不符而 revert
  'function swapExactETHForTokensSupportingFeeOnTransferTokens(uint256 amountOutMin,address[] path,address to,uint256 deadline) payable',
  'function swapExactTokensForETHSupportingFeeOnTransferTokens(uint256 amountIn,uint256 amountOutMin,address[] path,address to,uint256 deadline)',
]);

const decimalsCache = new Map();

export function parseUnits(value, decimals = 18) {
  const s = String(value).trim();
  if (!/^\d+(\.\d*)?$/.test(s)) throw new Error(`金额格式不正确: ${value}`);
  const [whole, frac = ''] = s.split('.');
  if (frac.length > decimals) throw new Error(`小数位超过 ${decimals}，拒绝四舍五入`);
  const padded = (frac + '0'.repeat(decimals)).slice(0, decimals);
  return (BigInt(whole) * 10n ** BigInt(decimals) + BigInt(padded || '0')).toString();
}

export function human(raw, decimals = 18) {
  const s = BigInt(raw).toString().padStart(decimals + 1, '0');
  const whole = s.slice(0, -decimals);
  const frac = s.slice(-decimals).replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole;
}

export function resolveToken(input, chainId = 56) {
  if (!input) throw new Error('缺少代币');
  const key = String(input).toUpperCase();
  if (BSC_TOKENS[key] && chainId === 56) return BSC_TOKENS[key];
  if (/^0x[0-9a-fA-F]{40}$/.test(input)) return input;
  throw new Error(`未知代币：${input}（请给合约地址）`);
}

export async function tokenDecimals(token, chainId = 56) {
  if (token === NATIVE) return 18;
  if (decimalsCache.has(token)) return decimalsCache.get(token);
  const raw = await rpcFor(chainId, 'eth_call', [{ to: token, data: encodeFunctionData({ abi: erc20Abi, functionName: 'decimals' }) }, 'latest']);
  const decimals = Number(decodeFunctionResult({ abi: erc20Abi, functionName: 'decimals', data: raw }));
  decimalsCache.set(token, decimals);
  return decimals;
}

export async function planTransfer({ wallet, spec }) {
  const chainId = Number(spec.chainId || 56);
  const token = resolveToken(spec.params.token, chainId);
  const to = spec.params.to;
  const amount = spec.params.amount;
  if (!/^0x[0-9a-fA-F]{40}$/.test(to)) throw new Error('收款地址格式不正确');
  if (!amount || Number(amount) <= 0) throw new Error('缺少转账数量');

  const checks = [];
  const steps = [];

  if (token === NATIVE) {
    steps.push({
      label: `transfer ${amount} BNB → ${to}`,
      recipient: to,
      tx: { chainId: String(chainId), to, value: parseUnits(amount, 18), inputData: '0x' },
    });
  } else {
    const [decimals, code] = await Promise.all([
      tokenDecimals(token, chainId),
      rpcFor(chainId, 'eth_getCode', [token, 'latest']),
    ]);
    checks.push({ name: '代币合约', ok: code && code !== '0x', detail: `${(code.length - 2) / 2} bytes` });
    if (!code || code === '0x') throw new Error('代币地址没有合约代码');
    const raw = parseUnits(amount, decimals);
    steps.push({
      label: `transfer ${amount} → ${to}`,
      // ERC20 转账的 tx.to 是代币合约，真正收款人在 calldata 里，单独暴露给确认框
      recipient: to,
      tx: {
        chainId: String(chainId),
        to: token,
        value: '0',
        inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'transfer', args: [to, BigInt(raw)] }),
      },
    });
  }

  return {
    kind: 'transfer',
    protocol: 'transfer',
    spec: { ...spec, params: { ...spec.params, token, to, amount } },
    checks,
    steps,
    warnings: [],
  };
}

const toHex = (v) => `0x${BigInt(v).toString(16)}`;

/** revert（池子不存在 / 无储备 / 合约拒绝）与网络错误区分开：前者算「此路不通」，后者要报给用户 */
function isRevert(err) {
  return err?.code === 3 || err?.data != null || /revert|invalid opcode|out of gas/i.test(String(err?.message || ''));
}

/** 单条 V2 路径报价；不通返回 out=0n */
async function quotePath(chainId, router, amountIn, path) {
  let raw;
  try {
    raw = await rpcFor(chainId, 'eth_call', [{
      to: router,
      data: encodeFunctionData({ abi: routerAbi, functionName: 'getAmountsOut', args: [amountIn, path] }),
    }, 'latest']);
  } catch (err) {
    return { path, out: 0n, err: isRevert(err) ? null : err };
  }
  try {
    const amounts = decodeFunctionResult({ abi: routerAbi, functionName: 'getAmountsOut', data: raw });
    return { path, out: amounts[amounts.length - 1] };
  } catch {
    return { path, out: 0n }; // 空返回：pair 不存在
  }
}

/**
 * 在「直连」与「经稳定币中转一跳」的 V2 路径中并行报价，取输出最多的一条。
 * 中转币只用 ROUTERS 里硬编码的主流稳定币，不从链上发现，避免被假池子引导。
 */
export async function bestPath({ chainId, cfg, amountIn, from, to }) {
  const same = (a, b) => a.toLowerCase() === b.toLowerCase();
  const hubs = Object.entries(cfg.hubs || {}).filter(([, a]) => !same(a, from) && !same(a, to));
  const paths = [[from, to], ...hubs.map(([, a]) => [from, a, to])];
  const results = await Promise.all(paths.map((p) => quotePath(chainId, cfg.router, amountIn, p)));
  const live = results.filter((r) => r.out > 0n);
  if (!live.length) {
    const netErr = results.find((r) => r.err);
    if (netErr) throw new Error(`报价 RPC 失败：${netErr.err.message}`);
    throw new Error('报价为 0：该代币在 V2 直连和稳定币中转路径上都没有流动性（可能只在 V3 或其它 DEX）');
  }
  const direct = live.find((r) => r.path.length === 2) || null;
  let best = live.reduce((a, b) => (b.out > a.out ? b : a));
  if (direct && best !== direct && best.out * 10000n < direct.out * (10000n + MULTIHOP_MIN_GAIN_BPS)) best = direct;
  return { best, direct, results };
}

/** 路径展示：中转币用符号，目标代币显示为 token */
export function routeLabel(path, cfg, nativeSymbol) {
  const names = new Map(Object.entries(cfg.hubs || {}).map(([k, a]) => [a.toLowerCase(), k]));
  names.set(cfg.wrapped.toLowerCase(), nativeSymbol);
  return path.map((a) => names.get(a.toLowerCase()) || 'token').join(' → ');
}

/** 以钱包身份静态模拟一笔交易 */
async function simulate(chainId, from, tx) {
  try {
    await rpcFor(chainId, 'eth_call', [{ from, to: tx.to, value: toHex(tx.value || 0), data: tx.inputData }, 'latest']);
    return { ok: true };
  } catch (err) {
    if (!isRevert(err)) throw new Error(`模拟 RPC 失败：${err.message}`);
    // 去掉节点附带的原始 revert data（十六进制），只保留可读原因
    return { ok: false, reason: String(err.message || 'execution reverted').replace(/:\s*0x[0-9a-fA-F]*$/, '') };
  }
}

/**
 * 预检：按真实 minOut 和 minOut=0 并行模拟。
 * - 真实通过：放行
 * - 真实失败、下限为 0 通过：滑点不够覆盖转账税，二分探测实际损耗后报错（不让用户白烧 gas）
 * - 都失败：代币禁止该方向交易（黑名单 / 未开放 / 限额 / 貔貅），直接拒绝
 */
async function preflight({ chainId, wallet, out, slip, build, label, checks }) {
  const minAt = (bps) => (out * BigInt(10000 - bps)) / 10000n;
  const [real, zero] = await Promise.all([
    simulate(chainId, wallet, build(minAt(slip))),
    simulate(chainId, wallet, build(0n)),
  ]);
  if (real.ok) {
    checks.push({ name: `${label}模拟`, ok: true, detail: `按 ${slip / 100}% 滑点可成交` });
    return;
  }
  if (!zero.ok) {
    checks.push({ name: `${label}模拟`, ok: false, detail: zero.reason });
    throw new Error(`${label}模拟失败（不设下限也无法成交）：${zero.reason}。可能是代币限制交易 / 黑名单 / 限额 / 貔貅，已拒绝生成计划`);
  }
  // 先看安全上限滑点能否成交：不能就是恶意高税 / 貔貅，不再二分
  const cap = MAX_SLIPPAGE_BPS;
  if (slip >= cap || !(await simulate(chainId, wallet, build(minAt(cap)))).ok) {
    checks.push({ name: `${label}模拟`, ok: false, detail: `损耗超过 ${cap / 100}%` });
    throw new Error(`${label}模拟：实际到账比报价少 ${cap / 100}% 以上（滑点安全上限），疑似恶意高税 / 貔貅，已拒绝生成计划`);
  }
  let lo = slip;
  let hi = cap;
  while (hi - lo > TAX_PROBE_STEP_BPS) {
    const mid = Math.floor((lo + hi) / 2);
    if ((await simulate(chainId, wallet, build(minAt(mid)))).ok) hi = mid;
    else lo = mid;
  }
  checks.push({ name: `${label}模拟`, ok: false, detail: `实测比报价少约 ${hi / 100}%` });
  throw new Error(`${label}按 ${slip / 100}% 滑点会失败：实测到账比报价少约 ${hi / 100}%（疑似转账税 / 通缩）。如确认要交易，请把滑点设到高于 ${hi / 100}% 后重试`);
}

export async function planSwap({ wallet, spec }) {
  const protocol = spec.protocol;
  const cfg = ROUTERS[protocol];
  if (!cfg) throw new Error(`未知路由：${protocol}`);
  const chainId = Number(spec.chainId || cfg.chainId);
  const side = spec.params.side === 'sell' ? 'sell' : 'buy';
  const token = resolveToken(spec.params.token, chainId);
  let amount = spec.params.amount;
  const percent = spec.params.percent;
  const slipRaw = spec.params.slippageBps;
  if (side === 'buy' && percent) throw new Error('买入不支持按百分比，请写明 BNB/ETH 数量');
  if (!percent && (!amount || Number(amount) <= 0)) throw new Error('缺少数量');
  if (slipRaw == null || slipRaw === '') throw new Error('缺少滑点：不提供默认值');
  assertSlippageBps(slipRaw);
  const slip = Number(slipRaw); // 统一成数字：后面的二分探测要做算术
  if (token === NATIVE) throw new Error('交换目标不能是原生币');

  const checks = [];
  const steps = [];
  const warnings = [];
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 900);

  const [routerCode, tokenCode, tokenDecimalsValue] = await Promise.all([
    rpcFor(chainId, 'eth_getCode', [cfg.router, 'latest']),
    rpcFor(chainId, 'eth_getCode', [token, 'latest']),
    tokenDecimals(token, chainId),
  ]);
  checks.push({ name: 'Router 合约', ok: routerCode && routerCode !== '0x', detail: cfg.router });
  if (!routerCode || routerCode === '0x') throw new Error('Router 地址没有合约代码');
  checks.push({ name: 'Token 合约', ok: tokenCode && tokenCode !== '0x', detail: token });
  if (!tokenCode || tokenCode === '0x') throw new Error('代币地址没有合约代码');

  const wrapped = cfg.wrapped;
  const nativeSymbol = chainId === 1 ? 'ETH' : 'BNB';

  /** 路由选择结果写进 checks，让用户看到为什么走这条路 */
  const pushRoute = ({ best, direct, results }, outDecimals) => {
    const label = routeLabel(best.path, cfg, nativeSymbol);
    const gain = direct && best !== direct ? ` · 比直连多 ${Number(((best.out - direct.out) * 10000n) / direct.out) / 100}%` : '';
    checks.push({ name: '路由（V2 最优）', ok: true, detail: `${label}${gain}` });
    checks.push({
      name: '候选路径',
      ok: true,
      detail: results.map((r) => `${routeLabel(r.path, cfg, nativeSymbol)}：${r.out > 0n ? human(r.out, outDecimals) : '无池'}`).join(' ｜ '),
    });
    if (!direct) warnings.push('直连池不存在，已改走稳定币中转（多一跳 swap，会多付一次 LP 手续费）');
  };

  if (side === 'buy') {
    const amountIn = BigInt(parseUnits(amount, 18));
    const [route, balanceHex] = await Promise.all([
      bestPath({ chainId, cfg, amountIn, from: wrapped, to: token }),
      rpcFor(chainId, 'eth_getBalance', [wallet, 'latest']),
    ]);
    const { path, out } = route.best;
    pushRoute(route, tokenDecimalsValue);
    const minOut = (out * BigInt(10000 - slip)) / 10000n;
    checks.push({ name: '报价', ok: true, detail: `${human(out, tokenDecimalsValue)} tokens` });

    const build = (min) => ({
      chainId: String(chainId),
      to: cfg.router,
      value: amountIn.toString(),
      inputData: encodeFunctionData({
        abi: routerAbi,
        functionName: 'swapExactETHForTokensSupportingFeeOnTransferTokens',
        args: [min, path, wallet, deadline],
      }),
    });
    // 余额不够时 eth_call 会因 insufficient funds 失败，无法区分税和余额问题，跳过预检
    if (BigInt(balanceHex) >= amountIn) {
      await preflight({ chainId, wallet, out, slip, build, label: '买入', checks });
    } else {
      warnings.push(`钱包 ${nativeSymbol} 余额不足 ${amount}，未做买入模拟（税币 / 限购检测被跳过）`);
    }

    steps.push({ label: `swap ${amount} ${nativeSymbol} → token（${routeLabel(path, cfg, nativeSymbol)}）`, recipient: wallet, tx: build(minOut) });

    return {
      kind: 'swap', protocol, spec: { ...spec, chainId, params: { ...spec.params, token, side, amount } },
      checks, steps,
      quote: {
        side, amountIn: amount, inSymbol: nativeSymbol, amountOut: human(out, tokenDecimalsValue), outSymbol: 'token',
        minOut: minOut.toString(), minOutHuman: human(minOut, tokenDecimalsValue), slipBps: slip,
        route: routeLabel(path, cfg, nativeSymbol), path,
      },
      warnings,
    };
  }

  let amountIn;
  if (percent) {
    // 按持仓比例卖出：读链上余额后换算成具体数量，并在计划里展示
    const pctBps = Math.round(Number(percent) * 100);
    if (!(pctBps > 0 && pctBps <= 10000)) throw new Error(`卖出比例不合法：${percent}%`);
    const balRaw = await rpcFor(chainId, 'eth_call', [{
      to: token,
      data: encodeFunctionData({ abi: erc20Abi, functionName: 'balanceOf', args: [wallet] }),
    }, 'latest']);
    const balance = BigInt(decodeFunctionResult({ abi: erc20Abi, functionName: 'balanceOf', data: balRaw }));
    amountIn = (balance * BigInt(pctBps)) / 10000n;
    checks.push({ name: '持仓余额', ok: balance > 0n, detail: `${human(balance, tokenDecimalsValue)} → 卖出 ${percent}%` });
    if (amountIn === 0n) throw new Error('该钱包没有这个代币的持仓，无法按比例卖出');
    amount = human(amountIn, tokenDecimalsValue);
  } else {
    amountIn = BigInt(parseUnits(amount, tokenDecimalsValue));
    // 余额不足时卖出模拟必然失败，先单独拦下，避免被误判成「貔貅 / 禁止交易」
    const balRaw = await rpcFor(chainId, 'eth_call', [{
      to: token,
      data: encodeFunctionData({ abi: erc20Abi, functionName: 'balanceOf', args: [wallet] }),
    }, 'latest']);
    const balance = BigInt(decodeFunctionResult({ abi: erc20Abi, functionName: 'balanceOf', data: balRaw }));
    checks.push({ name: '持仓余额', ok: balance >= amountIn, detail: `${human(balance, tokenDecimalsValue)}，卖出 ${amount}` });
    if (balance < amountIn) {
      warnings.push(`持仓不足：持有 ${human(balance, tokenDecimalsValue)}，要卖 ${amount}；未做卖出模拟，执行会失败`);
    }
  }

  const [route, allowanceRaw] = await Promise.all([
    bestPath({ chainId, cfg, amountIn, from: token, to: wrapped }),
    rpcFor(chainId, 'eth_call', [{
      to: token,
      data: encodeFunctionData({ abi: erc20Abi, functionName: 'allowance', args: [wallet, cfg.router] }),
    }, 'latest']),
  ]);
  const { path, out } = route.best;
  pushRoute(route, 18);
  const minOut = (out * BigInt(10000 - slip)) / 10000n;
  checks.push({ name: '报价', ok: true, detail: `${human(out, 18)} ${nativeSymbol}` });

  const allowance = BigInt(allowanceRaw);
  checks.push({ name: 'allowance', ok: allowance >= amountIn, detail: allowance >= amountIn ? '足够' : '需要 approve' });

  const build = (min) => ({
    chainId: String(chainId),
    to: cfg.router,
    value: '0',
    inputData: encodeFunctionData({
      abi: routerAbi,
      functionName: 'swapExactTokensForETHSupportingFeeOnTransferTokens',
      args: [amountIn, min, path, wallet, deadline],
    }),
  });

  const enoughBalance = !checks.some((c) => c.name === '持仓余额' && !c.ok);
  if (allowance < amountIn) {
    steps.push({
      label: `approve ${amount} → Router`,
      tx: {
        chainId: String(chainId),
        to: token,
        value: '0',
        inputData: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [cfg.router, amountIn] }),
      },
    });
    warnings.push('需要先 approve，授权前无法模拟卖出（卖出税 / 貔貅检测被跳过）；授权后重新生成计划即可完成预检');
  } else if (enoughBalance) {
    await preflight({ chainId, wallet, out, slip, build, label: '卖出', checks });
  }
  steps.push({ label: `swap ${amount} token → ${nativeSymbol}（${routeLabel(path, cfg, nativeSymbol)}）`, recipient: wallet, tx: build(minOut) });

  return {
    kind: 'swap', protocol, spec: { ...spec, chainId, params: { ...spec.params, token, side, amount } },
    checks, steps,
    quote: {
      side, amountIn: amount, inSymbol: 'token', amountOut: human(out, 18), outSymbol: nativeSymbol,
      minOut: minOut.toString(), minOutHuman: human(minOut, 18), slipBps: slip, percent: percent || null,
      route: routeLabel(path, cfg, nativeSymbol), path,
    },
    warnings,
  };
}
