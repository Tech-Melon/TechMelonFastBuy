import { readFile, writeFile } from 'node:fs/promises';
import { AsyncLocalStorage } from 'node:async_hooks';
import { recordRpc } from './metrics.mjs';

const FILE = new URL('./config.json', import.meta.url);

const DEFAULTS = {
  rpcs: {},
  // WebSocket 节点（如 QuickNode wss），目前只用于 BSC 的 Four 狙击事件订阅
  wss: {},
  // 备用节点池：key 形如 'rpc:56' / 'wss:56'，值为候选 URL 列表（含当前启用的那条）
  pools: {},
  ai: { baseUrl: 'https://api.deepseek.com', model: 'deepseek-chat', apiKey: '' },
};

const DEFAULT_RPC = {
  56: 'https://bsc-rpc.publicnode.com',
  1: 'https://ethereum-rpc.publicnode.com',
  8453: 'https://base-rpc.publicnode.com',
  // Arbitrum / Polygon 只用于只读（代币核对、symbol 查询），设置页暂不提供自定义
  42161: 'https://arbitrum-one-rpc.publicnode.com',
  137: 'https://polygon-bor-rpc.publicnode.com',
  4663: '',
};

let cache = null;

export async function getConfig() {
  if (cache) return cache;
  try {
    const parsed = JSON.parse(await readFile(FILE, 'utf8'));
    const rpcs = { ...(parsed.rpcs || {}) };
    if (parsed.bscRpc && !rpcs['56']) rpcs['56'] = parsed.bscRpc;
    if (parsed.ethRpc && !rpcs['1']) rpcs['1'] = parsed.ethRpc;
    cache = {
      ...DEFAULTS,
      ...parsed,
      rpcs,
      wss: { ...(parsed.wss || {}) },
      pools: { ...(parsed.pools || {}) },
      ai: { ...DEFAULTS.ai, ...(parsed.ai || {}) },
    };
  } catch {
    cache = structuredClone(DEFAULTS);
  }
  return cache;
}

export async function saveConfig(patch) {
  const current = await getConfig();
  const next = {
    ...current,
    ...patch,
    rpcs: { ...current.rpcs, ...(patch.rpcs || {}) },
    wss: { ...(current.wss || {}), ...(patch.wss || {}) },
    pools: { ...(current.pools || {}), ...(patch.pools || {}) },
    ai: { ...current.ai, ...(patch.ai || {}) },
  };
  cache = next;
  await writeFile(FILE, JSON.stringify(next, null, 2), 'utf8');
  return next;
}

/** 只回传脱敏信息，密钥永不返回原文 */
export function publicConfig(config) {
  const chains = ['56', '1', '8453', '4663'];
  return {
    rpcs: Object.fromEntries(chains.map((id) => {
      const url = config.rpcs?.[id] || DEFAULT_RPC[id] || '';
      return [id, {
        set: Boolean(config.rpcs?.[id]),
        masked: maskUrl(url),
        custom: Boolean(config.rpcs?.[id]),
      }];
    })),
    wss: {
      56: { set: Boolean(config.wss?.['56']), masked: maskUrl(config.wss?.['56'] || '') },
    },
    wssDual: config.wssDual === true, // 双节点 WSS 订阅（主 + 备用同时订阅日志，先到先用），默认关
    wssBackup: maskUrl(nodeList(config, 'wss', '56').list.find((u) => u && u !== (config.wss?.['56'] || '')) || ''),
    // 备用节点池（脱敏）：固定遍历所有节点槽；每个槽始终含「当前启用（主）」+ 备用，标注哪条在用
    pools: Object.fromEntries(NODE_KEYS.map((key) => {
      const [kind, chainId] = key.split(':');
      const { list, active } = nodeList(config, kind, chainId);
      return [key, list.map((u, i) => ({ i, masked: maskUrl(u), active: u === active }))];
    })),
    ai: {
      baseUrl: config.ai.baseUrl,
      model: config.ai.model,
      hasKey: Boolean(config.ai.apiKey),
      keyHint: config.ai.apiKey ? `…${config.ai.apiKey.slice(-4)}` : '',
    },
  };
}

// 所有可管理的节点槽（RPC 各链 + BSC WSS）
export const NODE_KEYS = ['rpc:56', 'rpc:1', 'rpc:8453', 'rpc:4663', 'wss:56'];

/**
 * 节点槽的规范列表：当前启用（主）始终在列表内（旧配置里若缺则补到最前），其余为备用。
 * publicConfig 与节点管理共用它，保证前端看到的索引与服务端一致。
 */
export function nodeList(config, kind, chainId) {
  const key = `${kind}:${chainId}`;
  const stored = Array.isArray(config.pools?.[key]) ? [...config.pools[key]] : [];
  const active = kind === 'wss' ? (config.wss?.[chainId] || '') : (config.rpcs?.[chainId] || '');
  const list = [...stored];
  if (active && !list.includes(active)) list.unshift(active);
  return { key, list, active };
}

/** 节点主机名（统计用，不含路径里的令牌）：区分 QuickNode / NodeReal / 公共节点各承担了多少 */
const hostCache = new Map();
function hostOf(url) {
  if (!hostCache.has(url)) { let h = '?'; try { h = new URL(url).host; } catch { /* 无效 URL */ } hostCache.set(url, h); }
  return hostCache.get(url);
}

export function maskUrl(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}/••••`;
  } catch {
    return '（无效 URL）';
  }
}

const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]']);

/**
 * 外部服务 URL（RPC / AI Base URL）校验：
 * 只允许 https；明文 http 仅限本机回环（本地节点 / 本地模型），避免 Key 与交易数据走明文。
 */
export function assertServiceUrl(value, label = 'URL') {
  if (typeof value !== 'string' || value.length > 500) throw new Error(`${label} 过长`);
  if (/[\s"']/.test(value)) throw new Error(`${label} 不能包含空格或引号`);
  let u;
  try { u = new URL(value); } catch { throw new Error(`${label} 格式无效`); }
  if (!u.hostname) throw new Error(`${label} 缺少主机名`);
  if (u.username || u.password) throw new Error('不要在 URL 里内嵌账号密码，请用无凭据的地址');
  if (u.protocol === 'http:' && !LOOPBACK_HOSTS.has(u.hostname)) {
    throw new Error(`${label} 只支持 https（http 仅限 127.0.0.1 / localhost）`);
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error(`${label} 只支持 https`);
  return value;
}

export function assertRpcUrl(value) {
  if (!value) return '';
  return assertServiceUrl(value, 'RPC URL');
}

/**
 * WebSocket 节点 URL 校验：只允许 wss；明文 ws 仅限本机回环。
 * QuickNode 的令牌在路径里（wss://xxx.quiknode.pro/<token>/），maskUrl 只露出 host。
 */
export function assertWssUrl(value) {
  if (!value) return '';
  if (typeof value !== 'string' || value.length > 500) throw new Error('WSS URL 过长');
  if (/[\s"']/.test(value)) throw new Error('WSS URL 不能包含空格或引号');
  let u;
  try { u = new URL(value); } catch { throw new Error('WSS URL 格式无效'); }
  if (!u.hostname) throw new Error('WSS URL 缺少主机名');
  if (u.username || u.password) throw new Error('不要在 URL 里内嵌账号密码，请用无凭据的地址');
  if (u.protocol === 'ws:' && !LOOPBACK_HOSTS.has(u.hostname)) {
    throw new Error('WSS URL 只支持 wss（ws 仅限 127.0.0.1 / localhost）');
  }
  if (u.protocol !== 'wss:' && u.protocol !== 'ws:') throw new Error('WSS URL 必须以 wss:// 开头');
  return value;
}

/**
 * 双节点 WSS 订阅用的备用节点：config.wssDual 打开（默认关）且节点池里有一条不同于主节点的 wss 时返回它（取池里第一条），否则 ''。
 * 只用于「日志订阅双路接收、先到先用」，eth_call 等请求仍只走主节点。
 */
export function backupWssUrl(chainId, config) {
  if (config.wssDual !== true) return '';
  const main = chainWssUrl(chainId, config);
  if (!main) return '';
  return nodeList(config, 'wss', String(chainId)).list.find((u) => u && u !== main) || '';
}

export function chainWssUrl(chainId, config) {
  return config.wss?.[String(chainId)] || process.env[`WSS_${chainId}`] || '';
}

export function chainRpcUrl(chainId, config) {
  const id = String(chainId);
  return config.rpcs?.[id] || DEFAULT_RPC[id] || process.env[`RPC_${id}`] || '';
}

export async function rpcUrl(chainId = 56) {
  const config = await getConfig();
  const url = chainRpcUrl(chainId, config);
  if (!url) throw new Error(`未配置链 ${chainId} 的 RPC 节点`);
  return url;
}

/** 主节点 + 设置页里配置的备用节点（去重，主节点在前） */
async function rpcUrls(chainId) {
  const config = await getConfig();
  const primary = chainRpcUrl(chainId, config);
  if (!primary) throw new Error(`未配置链 ${chainId} 的 RPC 节点`);
  const { list } = nodeList(config, 'rpc', String(chainId));
  return [...new Set([primary, ...list])];
}

/** 网络层失败（连不上 / 超时 / 限流重试用尽）才切备用节点；RPC 业务错误（revert 等）不切 */
const isNodeFailure = (err) => err?.rateLimited || err?.name === 'AbortError' || err?.name === 'TypeError' || /fetch failed|ECONN|ETIMEDOUT|无法解析/.test(String(err?.message || ''));

async function rpcFailover(chainId, method, params) {
  const urls = await rpcUrls(chainId);
  let lastErr;
  for (let i = 0; i < urls.length; i += 1) {
    try {
      return await rpcAt(urls[i], method, params);
    } catch (err) {
      lastErr = err;
      if (!isNodeFailure(err) || i === urls.length - 1) throw err;
      console.warn(`[rpc] 节点 ${maskUrl(urls[i])} 失败（${err.message}），切到备用节点 ${maskUrl(urls[i + 1])}`);
    }
  }
  throw lastErr;
}

export async function rpcFor(chainId, method, params) {
  if (preferPublic(chainId)) return rpcPublic(chainId, method, params);
  return rpcFailover(chainId, method, params);
}

export async function rpc(method, params) {
  return rpcFor(56, method, params);
}

/*
 * 请求优先级：后台 / 非即时任务（WSS 补查、监控核验、预热、库存与持仓展示、图标、代币信息等）放进 runBackground() 里执行：
 * - BSC 读请求优先走免费公共节点（不消耗付费节点积分），公共节点都不可用时才回落到设置页的付费节点；
 * - 回落到付费节点时每秒最多用一半额度、最多占 3 个并发槽，限流时先让路，保证交易相关的读请求（模拟、回执、报价）不被饿死。
 * 狙击 / 下单 / 报价 / 等回执这类即时请求不要放进来。
 */
const bgContext = new AsyncLocalStorage();
/** label：是哪个后台任务发的（RPC 调用统计按它分组，查「后台节点被谁用掉了」）；嵌套时以最里层为准 */
export function runBackground(fn, label = '其它后台读取') { return bgContext.run({ label }, fn); }
const isBackground = () => Boolean(bgContext.getStore());
const backgroundLabel = () => bgContext.getStore()?.label || null;

/*
 * 免费公共节点（2026-10-28 服务器实测）：
 * - bnbchain / defibit / ninicoin dataseed：eth_call 10~15ms、不落后，但 eth_getLogs 一律 limit exceeded、不支持老区块状态；
 * - publicnode：eth_call ~50ms，eth_getLogs 必须带 address（5 万块约 1s），不带 address 拒绝；没有归档。
 * 环境变量 PUBLIC_RPC_56 / PUBLIC_LOGS_RPC_56 可覆盖（逗号分隔）。设为 off 时关闭公共节点分流。
 */
const envList = (name, def) => String(process.env[name] ?? def).split(',').map((s) => s.trim()).filter((s) => /^https:\/\//.test(s));
const PUBLIC_OFF = process.env.PUBLIC_RPC_56 === 'off';
const PUBLIC_READ = envList('PUBLIC_RPC_56', 'https://bsc-dataseed.bnbchain.org,https://bsc-dataseed1.defibit.io,https://bsc-dataseed1.ninicoin.io,https://bsc-rpc.publicnode.com');
const PUBLIC_LOGS = envList('PUBLIC_LOGS_RPC_56', 'https://bsc-rpc.publicnode.com');
const PUBLIC_COOLDOWN_MS = 30000;
const PUBLIC_MAX_CONCURRENCY = 6;
const pub = { cool: new Map(), active: 0, waiters: [], stats: { public: 0, fallback: 0, byReason: {} } };

const preferPublic = (chainId) => !PUBLIC_OFF && String(chainId) === '56' && isBackground();

/** 确定性的业务错误（revert 等）：换节点结果也一样，直接抛给调用方，不再浪费付费节点的请求 */
const isDeterministic = (err) => err?.data != null || /revert/i.test(String(err?.message || ''));

/** 公共节点偶尔不遵守过滤条件：本地按 address / topics 再筛一遍 */
function matchLogs(logs, filter = {}) {
  if (!Array.isArray(logs)) throw new Error('getLogs 返回的不是数组');
  const addrs = filter.address ? new Set([].concat(filter.address).map((a) => String(a).toLowerCase())) : null;
  const topics = Array.isArray(filter.topics) ? filter.topics : [];
  return logs.filter((l) => {
    if (addrs && !addrs.has(String(l.address).toLowerCase())) return false;
    return topics.every((t, i) => t == null || [].concat(t).map((x) => String(x).toLowerCase()).includes(String(l.topics?.[i] || '').toLowerCase()));
  });
}

async function pubSlot(fn) {
  while (pub.active >= PUBLIC_MAX_CONCURRENCY) await new Promise((r) => pub.waiters.push(r));
  pub.active += 1;
  try { return await fn(); } finally { pub.active -= 1; pub.waiters.shift()?.(); }
}

function fellBack(reason) {
  pub.stats.fallback += 1;
  pub.stats.byReason[reason] = (pub.stats.byReason[reason] || 0) + 1;
}

/*
 * ---- 后台节点（非即时请求专用，例如 NodeReal）----
 * 后台请求（runBackground）的顺序：后台节点 → 免费公共节点 → 交易用的主节点（最后兜底）。
 * 后台节点 = config.bgRpcs['56']；没填时自动用「备用节点池」里的 NodeReal 地址（用户已经配过的 NodeReal 不用再填一遍）。
 * 它有自己的每秒额度（config.bgRpcRate / 环境变量 BG_RPC_RATE_PER_SEC，默认 15）和并发上限，用满就让给公共节点，不排队、不占主节点额度。
 * 2026-10-28：公共节点（dataseed）每 IP 约 10000 次 / 5 分钟，预热高峰时 2 分钟打了 4000+ 次，有被封服务器 IP 的风险。
 */
// 每秒额度：config.json 的 bgRpcRate 优先，其次环境变量 BG_RPC_RATE_PER_SEC，默认 15（NodeReal 免费档 25/s 时报过 CUPS 超限）
const rateOf = (v) => (Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 500 ? Number(v) : 0);
const BG_RATE_DEFAULT = rateOf(process.env.BG_RPC_RATE_PER_SEC) || 15;
let BG_RATE_PER_SEC = BG_RATE_DEFAULT;
const BG_MAX_CONCURRENCY_NODE = 6;
const bgNode = { windowStart: 0, used: 0, active: 0, cool: 0, stats: { ok: 0, skipped: 0, errors: 0, lastError: null } };

/** 后台节点地址（没有则 ''） */
export async function backgroundNodeUrl(chainId = '56') {
  if (String(chainId) !== '56') return '';
  const cfg = await getConfig();
  BG_RATE_PER_SEC = rateOf(cfg.bgRpcRate) || BG_RATE_DEFAULT; // 改 config 后不用重启
  if (cfg.bgRpcs?.['56']) return cfg.bgRpcs['56'];
  return nodeList(cfg, 'rpc', '56').list.find((u) => /nodereal/i.test(u)) || '';
}

/** 后台节点这一秒还有没有额度（没有就直接让给公共节点，不等） */
function bgNodeTake(n = 1) {
  const now = Date.now();
  if (now - bgNode.windowStart >= 1000) { bgNode.windowStart = now; bgNode.used = 0; }
  if (bgNode.used + n > BG_RATE_PER_SEC || bgNode.active >= BG_MAX_CONCURRENCY_NODE || bgNode.cool > now) return false;
  bgNode.used += n;
  return true;
}

/** 走后台节点：成功返回 { ok:true, r }；额度满 / 冷却 / 网络失败返回 { ok:false }（调用方接着试公共节点）；revert 等确定性错误直接抛 */
async function tryBgNode(chainId, method, params) {
  const url = await backgroundNodeUrl(chainId);
  if (!url || !bgNodeTake(1)) { if (url) bgNode.stats.skipped += 1; return { ok: false }; }
  bgNode.active += 1;
  try {
    const r = await rpcFetch(url, method, params, 'bg');
    bgNode.stats.ok += 1;
    return { ok: true, r: method === 'eth_getLogs' ? matchLogs(r, params[0]) : r };
  } catch (err) {
    if (isDeterministic(err)) throw err;
    if (method === 'eth_getLogs' && /range|too many|block|limit/i.test(String(err.message))) { err.rangeTooLarge = true; throw err; }
    bgNode.stats.errors += 1;
    bgNode.stats.lastError = `${method}：${String(err.message).slice(0, 80)}`;
    if (err.rateLimited || isNodeFailure(err)) bgNode.cool = Date.now() + (err.rateLimited ? 2000 : PUBLIC_COOLDOWN_MS);
    return { ok: false };
  } finally {
    bgNode.active -= 1;
  }
}

async function rpcPublic(chainId, method, params) {
  const viaBg = await tryBgNode(chainId, method, params);
  if (viaBg.ok) return viaBg.r;
  // getLogs 只有 publicnode 支持，且必须带 address；不带地址的（不限地址的事件扫描）只能用付费节点
  const nodes = method === 'eth_getLogs' ? (params?.[0]?.address ? PUBLIC_LOGS : []) : PUBLIC_READ;
  for (const url of nodes) {
    if ((pub.cool.get(url) || 0) > Date.now()) continue;
    try {
      const r = await pubSlot(() => rpcFetch(url, method, params, 'public'));
      pub.stats.public += 1;
      return method === 'eth_getLogs' ? matchLogs(r, params[0]) : r;
    } catch (err) {
      if (isDeterministic(err)) throw err;
      // getLogs 区块跨度超出公共节点上限：交给调用方缩小跨度重试，不回落付费节点（付费节点一般上限更小，还耗积分）
      if (method === 'eth_getLogs' && /range|too many|block/i.test(String(err.message))) { err.rangeTooLarge = true; throw err; }
      pub.stats.lastError = `${maskUrl(url)} ${method}：${String(err.message).slice(0, 80)}`;
      // 限流 / 连不上：这个节点冷却一会；方法不支持、区块跨度超限、没有归档：换下一个
      if (err.rateLimited || isNodeFailure(err)) pub.cool.set(url, Date.now() + PUBLIC_COOLDOWN_MS);
    }
  }
  fellBack(method === 'eth_getLogs' && !params?.[0]?.address ? 'getLogs 不限地址' : `${method} 公共节点不可用`);
  return rpcFailover(chainId, method, params);
}

/** 公共节点分流统计（后台任务清单展示） */
export async function publicRpcStats() {
  const bgUrl = await backgroundNodeUrl('56').catch(() => '');
  return {
    enabled: !PUBLIC_OFF, read: PUBLIC_READ.map(maskUrl), logs: PUBLIC_LOGS.map(maskUrl), ...pub.stats,
    bgNode: { url: bgUrl ? maskUrl(bgUrl) : null, ratePerSec: BG_RATE_PER_SEC, ...bgNode.stats },
  };
}

const MAX_CONCURRENCY = Number(process.env.RPC_MAX_CONCURRENCY || 8);
const BG_MAX_CONCURRENCY = 3;
let active = 0;
let bgActive = 0;
const waiters = [];

/*
 * 全局 HTTP RPC 限速（所有模块共用）：节点按「每秒请求数」限流（QuickNode 当前套餐 50/s，batch 每项都算），
 * 超限返回 HTTP 429 且 body 没有标准 error 包装。按 Date.now() 整秒窗口计数，用满就等到窗口结束
 * （绝对时间对齐，不累计 sleep）。RPC_RATE_PER_SEC 可调，默认 45，留一点余量给 WSS 心跳等。
 */
const RATE_PER_SEC = (() => {
  const v = Number(process.env.RPC_RATE_PER_SEC || 45);
  return Number.isInteger(v) && v >= 5 ? v : 45;
})();
let windowStart = 0;
let windowUsed = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));

export async function rateTake(n = 1) {
  // 后台任务只能用到每秒额度的一半；前台（交易 / 界面）可以用满
  const cap = isBackground() ? Math.floor(RATE_PER_SEC / 2) : RATE_PER_SEC;
  for (;;) {
    const now = Date.now();
    if (now - windowStart >= 1000) { windowStart = now; windowUsed = 0; }
    // 空窗口总能放行（单批超过上限时独占这一秒）
    if (windowUsed === 0 || windowUsed + n <= cap) { windowUsed += n; return; }
    await sleep(windowStart + 1000 - now);
  }
}

const RATE_LIMIT_RETRIES = 3;

/** 节点限流响应：HTTP 429，或 body 为 {code:-32007,...}（没有 jsonrpc 包装） */
function rateLimitError(status, payload) {
  const code = payload?.error?.code ?? payload?.code;
  if (status === 429 || code === -32007 || code === 429) {
    const err = new Error(`RPC 限流：${payload?.error?.message || payload?.message || `HTTP ${status}`}`);
    err.code = -32007;
    err.rateLimited = true;
    return err;
  }
  return null;
}

async function withSlot(fn) {
  const bg = isBackground();
  // 前台请求排在后台前面；后台另有并发上限，避免慢请求（getLogs）占满槽位
  while (active >= MAX_CONCURRENCY || (bg && bgActive >= BG_MAX_CONCURRENCY)) {
    await new Promise((resolve) => (bg ? waiters.push(resolve) : waiters.unshift(resolve)));
  }
  active += 1;
  if (bg) bgActive += 1;
  try {
    return await fn();
  } finally {
    active -= 1;
    if (bg) bgActive -= 1;
    const next = waiters.shift();
    if (next) next();
  }
}

async function rpcAt(url, method, params) {
  for (let attempt = 0; ; attempt += 1) {
    try {
      return await rpcOnce(url, method, params);
    } catch (err) {
      // 限流：等到下一个整秒窗口再试（最多 3 次）；其它错误原样抛出
      if (!err.rateLimited || attempt >= RATE_LIMIT_RETRIES) throw err;
      windowUsed = RATE_PER_SEC; // 本窗口已被节点判满：后续请求也一起等
      await sleep(windowStart + 1000 - Date.now());
    }
  }
}

async function rpcOnce(url, method, params) {
  await rateTake(1);
  return withSlot(() => rpcFetch(url, method, params, 'paid'));
}

/**
 * 一次 HTTP JSON-RPC 请求。tier：paid = 交易用的主节点（计入 rpc.count / 延迟，占每秒额度）；
 * bg = 后台节点（NodeReal 等）；public = 免费公共节点。后两类只计入「节点分布」，不影响主节点的统计。
 */
async function rpcFetch(url, method, params, tier = 'paid') {
  const started = Date.now();
  const host = hostOf(url);
  const task = backgroundLabel();
  const rec = (ok) => recordRpc(method, Date.now() - started, ok, tier, { host, task });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method, params }),
      signal: controller.signal,
    });
    const payload = await res.json().catch(() => null);
    const limited = rateLimitError(res.status, payload);
    if (limited) { rec(false); throw limited; }
    if (!payload || typeof payload !== 'object') throw new Error(`RPC 返回了无法解析的内容（HTTP ${res.status}）`);
    rec(!payload.error || Boolean(payload.error.data));
    if (payload.error) {
      const err = new Error(payload.error.message || 'rpc error');
      err.data = payload.error.data;
      err.code = payload.error.code;
      throw err;
    }
    // 没有 result 字段的响应一律视为错误：不能把 undefined 当成功结果交给解码（曾导致 reading 'buffer'）
    if (!('result' in payload)) throw new Error(`RPC 响应缺少 result（HTTP ${res.status}）`);
    return payload.result;
  } catch (err) {
    if (!err.code) rec(false);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/** JSON-RPC batch：一次 HTTP 往返完成多个独立读调用（后台任务先试公共节点，整批失败再用付费节点） */
export async function rpcBatch(calls) {
  if (preferPublic(56)) {
    const bgUrl = await backgroundNodeUrl('56').catch(() => '');
    if (bgUrl && bgNodeTake(calls.length)) {
      bgNode.active += 1;
      try {
        const r = await batchAt(bgUrl, calls, 'bg');
        bgNode.stats.ok += calls.length;
        return r;
      } catch (err) {
        bgNode.stats.errors += 1;
        if (err.rateLimited || isNodeFailure(err)) bgNode.cool = Date.now() + (err.rateLimited ? 2000 : PUBLIC_COOLDOWN_MS);
      } finally { bgNode.active -= 1; }
    }
    for (const url of PUBLIC_READ) {
      if ((pub.cool.get(url) || 0) > Date.now()) continue;
      try {
        const r = await pubSlot(() => batchAt(url, calls, 'public'));
        pub.stats.public += calls.length;
        return r;
      } catch (err) {
        if (err.rateLimited || isNodeFailure(err)) pub.cool.set(url, Date.now() + PUBLIC_COOLDOWN_MS);
      }
    }
    fellBack('batch 公共节点不可用');
  }
  return batchAt(await rpcUrl(), calls, 'paid');
}

async function batchAt(url, calls, tier) {
  const metered = tier === 'paid';
  if (metered) await rateTake(calls.length);
  const started = Date.now();
  const payload = calls.map((c, i) => ({
    jsonrpc: '2.0', id: i, method: c.method, params: c.params,
  }));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    const list = await res.json().catch(() => null);
    const limited = rateLimitError(res.status, Array.isArray(list) ? null : list);
    if (limited) { if (metered) windowUsed = RATE_PER_SEC; throw limited; }
    if (!Array.isArray(list)) throw new Error(`RPC batch 返回的不是数组（HTTP ${res.status}）`);
    const results = new Array(calls.length);
    const errors = new Array(calls.length);
    for (const item of list) {
      if (item.error) errors[item.id] = item.error;
      else results[item.id] = item.result;
    }
    const per = Math.round((Date.now() - started) / Math.max(calls.length, 1));
    const tag = { host: hostOf(url), task: backgroundLabel() };
    calls.forEach((c, i) => recordRpc(c.method, per, !errors[i], tier, tag));
    return { results, errors, ms: Date.now() - started };
  } finally {
    clearTimeout(timer);
  }
}
