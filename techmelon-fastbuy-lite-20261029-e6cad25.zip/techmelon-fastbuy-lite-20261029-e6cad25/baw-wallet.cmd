@echo off
rem Usage: baw-wallet.cmd <wallet-dir-under-profiles> <baw subcommand...>
rem   e.g. baw-wallet.cmd wallet-1 wallet status --json
rem Each wallet uses its own BINANCE_BAW_DIR; never the global %USERPROFILE%\.baw
setlocal
if "%~1"=="" (
  echo Usage: %~nx0 ^<wallet-dir^> ^<baw command^>
  echo Wallet dirs:
  dir /b /ad "%~dp0profiles" 2>nul
  exit /b 1
)
if not exist "%~dp0profiles\%~1\" (
  echo Wallet dir not found: profiles\%~1
  exit /b 1
)
set "BINANCE_BAW_DIR=%~dp0profiles\%~1"
shift
set "ARGS="
:collect
if "%~1"=="" goto run
set ARGS=%ARGS% %1
shift
goto collect
:run
node "%~dp0.tmp\baw-cli\node_modules\@binance\agentic-wallet\dist\index.js"%ARGS%
