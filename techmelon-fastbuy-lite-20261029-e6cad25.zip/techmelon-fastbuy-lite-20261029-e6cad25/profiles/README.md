# profiles/

每个子目录 = 一个独立的 Agentic Wallet 登录会话（CLI 通过环境变量 `BINANCE_BAW_DIR` 选择目录）。

- 目录由控制台「钱包」页的「添加钱包」自动创建，登录后会话加密保存在其中；
- 会话文件是登录凭据：**不要复制、外发或提交**；不要让两个进程同时使用同一个目录；
- 手动调用 CLI：`baw-wallet.cmd <目录名> wallet status --json`。
