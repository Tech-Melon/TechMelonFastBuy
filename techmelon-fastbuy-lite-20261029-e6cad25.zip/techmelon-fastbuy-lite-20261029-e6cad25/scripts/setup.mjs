#!/usr/bin/env node
/**
 * 部署 / 修复脚本（只依赖 Node 18+ 与 npm）。
 *
 *   node scripts/setup.mjs
 *
 * 交互菜单：
 *   1. 完整安装：控制台依赖（npm ci）+ 币安 CLI（锁定版本，npm ci 校验完整性）+ 禁用 keytar + 环境检查
 *   2. 只重装币安 CLI 并禁用 keytar（升级 CLI 后必须执行）
 *   3. 只做环境检查
 * 无人值守：设置环境变量 SETUP_CHOICE=1|2|3 跳过菜单。
 *
 * 为什么要禁用 keytar：CLI 默认把登录凭据写进系统钥匙串的同一个全局槽位，多个钱包会互相覆盖（串号）。
 * 改名为 keytar.disabled 后，CLI 回退为把加密会话写进各自的 BINANCE_BAW_DIR 目录，钱包才真正隔离。
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, copyFileSync, renameSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import readline from 'node:readline/promises';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WEBUI = path.join(ROOT, 'webui');
const CLI_DIR = path.join(ROOT, '.tmp', 'baw-cli');
const CLI_LOCK_SRC = path.join(ROOT, 'deploy', 'baw-cli');
const KEYTAR = path.join(CLI_DIR, 'node_modules', '@github', 'keytar');
const CLI_ENTRY = path.join(CLI_DIR, 'node_modules', '@binance', 'agentic-wallet', 'dist', 'index.js');
const NPM = process.platform === 'win32' ? 'npm.cmd' : 'npm';

const ok = (m) => console.log(`  [OK]  ${m}`);
const bad = (m) => console.log(`  [!!]  ${m}`);
const step = (m) => console.log(`\n== ${m}`);

function run(cmd, args, cwd) {
  console.log(`  > ${cmd} ${args.join(' ')}   (目录: ${path.relative(ROOT, cwd) || '.'})`);
  // Windows 上 npm 是 .cmd，需要经 shell 启动；参数都是脚本内固定值，不含用户输入
  const r = spawnSync(cmd, args, { cwd, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) throw new Error(`命令失败（退出码 ${r.status}）：${cmd} ${args.join(' ')}`);
}

function checkNode() {
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 18) throw new Error(`需要 Node.js 18 或更高版本，当前 ${process.version}`);
  ok(`Node.js ${process.version}`);
}

function installWebui() {
  step('安装控制台依赖（webui，按 package-lock.json 精确安装）');
  run(NPM, ['ci', '--no-audit', '--no-fund'], WEBUI);
}

function installCli() {
  step('安装币安 Agentic Wallet CLI（锁定版本）');
  mkdirSync(CLI_DIR, { recursive: true });
  for (const f of ['package.json', 'package-lock.json']) {
    const src = path.join(CLI_LOCK_SRC, f);
    if (!existsSync(src)) throw new Error(`缺少 ${path.relative(ROOT, src)}，发布包不完整`);
    copyFileSync(src, path.join(CLI_DIR, f));
  }
  // npm ci 会删除旧 node_modules 并按锁文件里的 integrity 校验每个包
  run(NPM, ['ci', '--no-audit', '--no-fund'], CLI_DIR);
  disableKeytar();
}

function disableKeytar() {
  step('禁用 keytar（保证多钱包会话隔离）');
  const disabled = `${KEYTAR}.disabled`;
  if (existsSync(KEYTAR)) {
    if (existsSync(disabled)) throw new Error(`${disabled} 已存在，请手动删除旧目录后重试`);
    renameSync(KEYTAR, disabled);
    ok('已将 @github/keytar 改名为 keytar.disabled');
  } else if (existsSync(disabled)) {
    ok('keytar 已是禁用状态');
  } else {
    ok('当前 CLI 版本未携带 keytar，无需处理');
  }
}

function checkEnv() {
  step('环境检查');
  let problems = 0;
  try { checkNode(); } catch (e) { bad(e.message); problems += 1; }
  if (existsSync(path.join(WEBUI, 'node_modules', 'viem'))) ok('控制台依赖已安装'); else { bad('控制台依赖未安装（选 1）'); problems += 1; }
  if (existsSync(CLI_ENTRY)) {
    const v = JSON.parse(readFileSync(path.join(CLI_DIR, 'node_modules', '@binance', 'agentic-wallet', 'package.json'), 'utf8')).version;
    ok(`币安 CLI ${v}`);
  } else { bad('币安 CLI 未安装（选 1 或 2）'); problems += 1; }
  if (existsSync(KEYTAR)) { bad('keytar 未禁用：多个钱包会共用凭据槽位（选 2）'); problems += 1; } else ok('keytar 已禁用 / 不存在');
  mkdirSync(path.join(ROOT, 'profiles'), { recursive: true });
  ok('profiles/ 目录就绪（每个钱包的会话各自一个子目录）');
  if (existsSync(path.join(WEBUI, 'config.json'))) ok('已有 webui/config.json');
  else ok('未配置 webui/config.json：使用公共 RPC、不启用 AI（可在控制台「设置」页配置，或参考 config.example.json）');
  console.log(problems ? `\n存在 ${problems} 个问题，请按提示处理。` : '\n环境就绪。启动：webui\\start.cmd（或 node webui/server.mjs），打开 http://127.0.0.1:8790');
  return problems;
}

async function choose() {
  if (process.env.SETUP_CHOICE) return process.env.SETUP_CHOICE.trim();
  console.log('\nAgentic Wallet 控制台 · 部署脚本');
  console.log('  1. 完整安装（首次部署选这个）');
  console.log('  2. 只重装币安 CLI 并禁用 keytar（升级 CLI 后执行）');
  console.log('  3. 只做环境检查');
  console.log('  0. 退出');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    return (await rl.question('请选择 [1]: ')).trim() || '1';
  } finally {
    rl.close();
  }
}

async function main() {
  const c = await choose();
  if (c === '0') return 0;
  if (!['1', '2', '3'].includes(c)) { console.log(`无效选项：${c}`); return 1; }
  checkNode();
  if (c === '1') { installWebui(); installCli(); }
  if (c === '2') installCli();
  return checkEnv() ? 1 : 0;
}

main().then((code) => { process.exitCode = code; }).catch((err) => {
  console.error(`\n[失败] ${err.message}`);
  process.exitCode = 1;
});
