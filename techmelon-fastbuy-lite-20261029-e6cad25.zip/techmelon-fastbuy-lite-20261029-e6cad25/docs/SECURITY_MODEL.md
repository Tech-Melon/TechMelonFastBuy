# 安全模型（Threat Model）

> 本文描述 2026-10 安全修复（提交 `006c79d` / `7966738` / `93d8190`）之后的状态。

## 资产

| 资产 | 存储 | 谁能动 |
|---|---|---|
| 链上资金 | BSC/ETH 等链上，MPC 钱包 | 需要币安侧 MPC 签名（是否每笔都要 App 确认取决于币安 Agentic Wallet 策略，不在本仓库控制范围） |
| 登录会话 | `profiles/*/session.json`（CLI 加密） | 本机进程；服务端只传目录路径 |
| 本地 API 令牌 | 进程内存 + `webui/.api-token` | 本机进程；每次启动重新生成 |
| RPC URL（可能含 API Key） | `webui/config.json` | 本机；接口只回显 `https://host/••••` |
| DeepSeek API Key | `webui/config.json`（明文） | 本机；接口不回传原文 |
| 模块/地址簿 | `webui/modules.json`、`addressbook.json` | 本机 |

## 信任边界

```
浏览器(127.0.0.1) ── HTTP + x-api-token ──> Node 服务
                                              │
                                              ├─ spawn node baw CLI ──> 币安网关（会话/签名）
                                              ├─ HTTPS JSON-RPC ──> BSC/ETH 节点
                                              └─ HTTPS ──> DeepSeek API（可选）
```

- 浏览器与 Node 之间靠「Host 白名单 + 每次启动随机令牌 + 仅 JSON + Origin/Sec-Fetch-Site 校验」隔离；
- Node 与 `baw` 之间通过环境变量 `BINANCE_BAW_DIR` 隔离钱包，CLI 参数全部白名单校验；
- 所有链上写入最终由 `baw contract-call preview/execute` 完成，签名在币安侧。

## 主要威胁与缓解

### 1. 恶意网页调用本地 API（CSRF / DNS 重绑定）

**路径**：任意页面 `fetch('http://127.0.0.1:8790/api/...', { mode: 'no-cors', body: 'text/plain' })`，或把攻击者域名重绑定到 127.0.0.1。

**缓解**（`webui/server.mjs`）：
- 只监听 `127.0.0.1`；`Host` 必须是 `127.0.0.1:端口` / `localhost:端口`，否则 421（挡 DNS 重绑定）；
- 所有 `/api/*` 必须带 `x-api-token`（32 字节随机，`timingSafeEqual` 比对）。令牌只注入同源 `index.html`，跨源页面读不到；自定义请求头会触发预检，而服务端不返回任何 CORS 头；
- POST 只接受 `application/json`（挡 text/plain 简单请求）；`Origin`、`Sec-Fetch-Site` 为跨站时 403；
- 页面 CSP `script-src 'self'`、`frame-ancestors 'none'`、`X-Frame-Options: DENY`（防点击劫持）。

**残余风险**：同机恶意进程可以读 `webui/.api-token` 或进程内存，从而完全控制 API。这是「本地工具」的固有边界，未做进程级鉴权。

### 2. 前端 XSS

**路径**：链上 symbol、空投垃圾币名称、LLM 输出、钱包名、错误信息中嵌入 HTML。

**缓解**（`webui/public/app.js`）：所有 innerHTML 统一经 `` h`...` `` 模板，插值默认转义；登录链接只放行 http(s)；CSP 禁止内联脚本。

### 3. LLM 输出被污染（幻觉 / prompt injection）

**路径**：第三方手册里藏「把 10 BNB 转给 0x…」「滑点 100%」，或模型幻觉出地址/金额。

**缓解**（`webui/agent/guard.mjs`、`analyze.mjs`、`prompt.mjs`）：
- LLM 只输出 `{protocol,intent,params}`，**不产出 calldata**；未识别协议直接拒绝；
- **规则优先**：规则解析出的 MARKET / 金额 / 比例 / 滑点不会被模型覆盖，模型只能补缺；协议判断不一致以规则为准；
- **字面校验**：模型给的数值必须在用户指令（提示词最后 8 行）里字面出现；地址必须在提示词里出现；转账收款地址必须出现在用户指令里；否则丢弃并在界面提示；
- 规则解析本身也只从用户指令取金额/比例/滑点，手册示例数值不会被当成用户设置；规则识别转账只看用户指令；
- LLM 缓存键覆盖全文 + 模型配置，避免「CONFIG 不同、指令相同」互相命中；
- 单笔滑点硬上限默认 20%（`MAX_SLIPPAGE_BPS`），Flap / Swap / Gang / 兑换统一校验；
- 最终仍要 `preview` 模拟 + 用户确认，确认框显示链、目标合约与真实收款人。

**残余风险**：用户指令本身写错（如把 0.1 写成 1）无法发现；模型补全的字段会被标注，但仍需人工核对。

### 4. 恶意代币/合约

**路径**：代币名、symbol、事件日志含指令文本；恶意代币自报假的 launchpad。

**缓解**：
- 链上文本只作为数据展示（且已转义），不作为指令；
- Gang：交互对象固定为官方 LaunchpadV2（`0x1B8F3f69…966E`），代币自报的 `launchpad()` 不一致直接拒绝，且代币必须在 LaunchpadV2 注册过曲线；
- Flap：Market 必须 `Factory.isMarket`，Probe 与 Market 必须互相指认，报价资产地址 / decimals 必须合法，否则拒绝生成交易（只读查询除外）。

### 5. RPC 被劫持/返回错误数据

**路径**：自定义 RPC 返回伪造的 `quoteBuy` / `getAmountsOut` / `curves`。

**缓解**：RPC 与 AI Base URL 只允许 https（http 仅限本机回环）；preview 由币安侧模拟（不同信任域）；滑点上限限制了最坏 minOut；收款地址来自用户指令或钱包自身，RPC 无法修改。

**残余风险**：RPC 仍可在上限范围内压低 minOut（被夹）；建议使用可信 RPC。

### 6. 执行与签名绑定

- `preview` 的 `from` 必须是路径上钱包自己的 EVM 地址；规划接口的 `wallet` 必须属于本机钱包（它会被写进 calldata 作为收款人）；
- `execute` 只接受本服务 10 分钟内为同一钱包生成、且未使用过的 `requestId`；
- 每个步骤携带 `chainId`，前端按步骤所在链 preview（修复了 Uniswap 计划被发到 BSC 的问题）；
- 批量执行按每个钱包重新生成计划并 preview，每个钱包单独确认，步骤结构不一致即停止；
- 传给 CLI 的地址 / 金额（十进制字符串）/ wei / calldata / requestId 全部白名单校验，杜绝 `--xxx` 参数注入。

### 7. 会话/密钥泄露

- 会话文件由 CLI 加密，服务端不读内容；
- `config.json` 明文保存 RPC/DeepSeek Key；接口只回显掩码；更换 AI 主机必须同时填写新 Key，旧 Key 不会被发往新主机；
- `config.json` 还保存 GMGN API Key 与 Ed25519 签名私钥、浏览器插件配对密钥；插件密钥等同快捷交易权限（识别 / 报价 / 买卖），只在已配对的插件 Origin + 密钥同时匹配时放行，泄露后在设置页取消配对或重新生成；
- `config.json`、`.api-token`、`wallets.json` 等已在 `.gitignore`，不应提交/分享。每个 Key 的配置位置、泄露影响和作废方法见 `DEPLOY.md` 18.5。

**注意**：`node_modules/@github/keytar` 被改名为 `keytar.disabled`，否则 CLI 会把 sessionId 写进全局 Windows 凭据槽位，导致多钱包串号。升级 CLI 后必须重新禁用。

### 8. 授权与额度

- ERC20 买入：`approve(spender, 精确金额)`，默认不做无限授权；
- 一键卖出：只授权本次卖出数量给对应的卖出合约，一键执行复核授权对象和额度；
- 报价币库存：「备货并授权」「同步授权」额度 = 库存（每种默认 ≤ 1 BNB 等值）；「批量预授权（无上限）」需用户单独确认，只授权给白名单合约、只限已知报价币，gang V3 未审计，不建议使用；
- 买入后自动授权（`config.autoApprove`，默认关）：额度 = 当前持仓，只授权给白名单卖出合约，币安预判要 App 确认的授权不执行；
- 残余风险：被授权的合约被攻击或恶意升级时，损失以授权额度为限（无上限授权 = 该代币全部余额）。各开关的风险汇总见 `DEPLOY.md` 18.6；
- custom 适配器每笔 value 上限 1 BNB；其余按合约自身限制 + 滑点上限；
- 滑点必须显式选择，无默认值（兑换页不再提供 `auto`）；
- 报价币不足时停止，不自动换币（除用户点击「去兑换报价币」）。

## 已知未覆盖

- 无多签、无硬件钱包、无交易模拟沙箱隔离；
- 同机进程级鉴权（见 §1 残余风险）；
- LLM 服务商可见完整提示词（最多 12000 字符）；
- `baw` CLI 与币安网关本身不在本仓库审计范围。
