# 已知限制（评审时请视为范围外）

## 产品/部署

- **单用户、本机工具**：只监听 `127.0.0.1`，无账号体系、无 TLS（仅本地随机令牌）；不适合公网部署。
- **无多签/硬件钱包**：签名由币安 MPC + App 确认完成，本项目不托管私钥。
- **无 WSS**：只做 HTTPS 轮询；实时性依赖 6 秒刷新。
- **无移动端适配**：桌面布局优先。

## 协议支持

- DEX 只支持 PancakeSwap V2（BSC）与 Uniswap V2（ETH）；V3/其他路由未接入。
- Flap 支持 ERC20/原生 BNB 两种计价；`dex_exit`（发射后卖成 BNB）未做独立流程。
- Gang 只接官方 LaunchpadV2：内盘买入（报价币 WBNB 时 1:1 包装，其它报价币先走 Pancake）与内盘卖出
  （按比例/全部/数量，WBNB 所得按最少所得解包成 BNB）；发币（create）与分红 claim 未做，已毕业代币请走 PancakeSwap。
- 要求使用私钥 / 助记词的提示词（如 `cast send --private-key`）一律拒绝。
- Foundry 只支持 mint（空 data 转账）；其他 NFT 合约需加适配器。
- AI 转账与 `custom` 只支持 BSC（当前范围内刻意如此）；`custom` 不支持 tuple/struct 参数。
- 需要外部 CLI/skill 的项目（HashDroids PoW、Units、gang CLI、TRACE trace-agent）刻意不支持：
  AI 执行识别到「引用 skill.md / 要求 npm install / 安装或升级 CLI / 运行 xxx-agent 命令」会直接拒绝，
  不调用模型、不访问链接、不生成计划（`agent/analyze.mjs` 的 `detectExternalSkill`）。
- 没有 ABI 的合约无法安全生成调用，一律拒绝，不做“猜 calldata”。

## 安全边界

- 本地 API 有每次启动随机令牌，但同机进程可读取 `webui/.api-token`；不做进程级鉴权。`confirm` 字段只是防误触。
- LLM 补全字段受「字面出现」约束，但用户指令本身写错无法发现，只能靠预览与用户确认兜底。
- 只信任 Gang 官方 LaunchpadV2；Soft / U / S 等其他发射台的代币会被拒绝。
- `execute` 只认本服务生成的 preview：服务重启后旧 preview 全部失效；外部工具生成的 requestId 不能在本控制台执行。
- 已保存的历史 RPC 地址不会被重新校验（AI Base URL 会在每次调用前复查）。
- `config.json` 明文保存 RPC/DeepSeek Key；无 OS keychain 加密。
- 会话文件由第三方 CLI 加密，本项目不审计其实现。
- `keytar` 被手动禁用；升级 `@binance/agentic-wallet` 后需重新禁用，否则多钱包串号。

## 质量

- 只有一个 20 条的提示词回归集（`webui/eval`，需先启动服务，且 `WALLET` 必须是本机已加载的钱包地址），没有常驻的单元测试/集成测试。
- 批量执行要求每个钱包的步骤结构一致；需要额外 approve 的钱包会被停下，需单独执行。
- 没有压力测试；高频轮询可能触发上游限频。
- 报价与执行之间存在状态漂移，滑点保护只能降低、不能消除。
- 没有交易失败自动重试（刻意为之，避免重复下单）。

## 数据

- 指标按小时聚合，保留 35 天；最近明细不持久化。
- 模块保存的是原始提示词；若提示词含隐私信息，导出/分享前需自行脱敏。
- 地址簿/模块是本地 JSON，无加密、无同步。
