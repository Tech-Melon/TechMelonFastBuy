# 万能提示词 → 钱包操作 模块设计

目标：用户粘贴任意第三方交互提示词（Flap、Foundry、未来的新协议），DeepSeek API 解析后
生成**完整、可校验、可执行**的操作序列，而不是只支持两种模板。

现状（模板引擎）能覆盖已适配的协议，但每来一个新协议就要写适配器。
本设计把它改成「LLM 产出声明式 DSL → 编译器校验 → 通用执行器」的三段式。

---

## 1. 总体架构

```
用户提示词
   │
   ├─(A) 本地预抽取：CONFIG、地址、数量、函数名、预期值（毫秒级，不花 token）
   │
   ├─(B) DeepSeek API：只回答「用户要做什么 + 参数」，输出严格 JSON（DSL）
   │        失败/超时 → 回退规则解析或让用户手选
   │
   ├─(C) 校验器：schema、地址、数量上限、值上限、白名单、重复/冲突
   │
   ├─(D) 编译器：DSL → 具体 tx（to/value/data），ABI 只从注册表取
   │
   ├─(E) 预检：链上 view 调用 + 余额/授权检查 + 与提示词预期比对
   │
   ├─(F) 模拟：baw contract-call preview，展示人类可读摘要
   │
   ├─(G) 用户确认 → execute → 回执 → 事件解析 → 刷新
   │
   └─(H) 审计日志：原始提示词、DSL、每一步 tx、回执、结果
```

关键原则：**LLM 只产出「要做什么」的 JSON，不产出原始 calldata**。
calldata 由编译器用注册表里的 ABI 生成，LLM 无法直接指定任意字节。

---

## 2. 动作 DSL（核心）

```json
{
  "version": "1",
  "chainId": 56,
  "wallet": "0xYourWalletAddress000000000000000000000001",
  "protocol": "foundry",
  "intent": "mint",
  "params": { "quantity": 9 },
  "preflight": [
    { "call": "foundry.handleOf", "args": ["$wallet"], "expect": { "notEmpty": true } },
    { "call": "foundry.mintOpen", "args": [], "expect": { "eq": true } },
    { "call": "foundry.remaining", "args": [], "expect": { "gte": "$params.quantity" } },
    { "call": "foundry.quoteBnb", "args": ["$wallet", "$params.quantity"], "bind": "quote" }
  ],
  "steps": [
    {
      "id": "mint",
      "type": "transfer",
      "to": "0xa849300a3f97dBb2e6a8FBeb16F4f23189c27013",
      "value": "$quote",
      "data": "0x",
      "expect": { "valueEquals": "$quote" }
    }
  ],
  "postconditions": [
    { "type": "receiptStatus", "eq": "success" },
    { "type": "erc1155Received", "contract": "0xa849…7013", "to": "$wallet" }
  ],
  "assumptions": ["quantity from prompt", "price per part 0.00391 BNB"],
  "warnings": []
}
```

Flap 的例子：

```json
{
  "protocol": "flap",
  "intent": "buy",
  "params": { "amount": "0.01", "slippageBps": 500 },
  "preflight": [
    { "call": "flap.isMarket", "args": ["$market"], "expect": { "eq": true } },
    { "call": "flap.buyPlan", "args": ["$params.amount", "$params.slippageBps"], "bind": "plan" }
  ],
  "steps": [
    { "type": "call", "to": "$portal", "abi": "portal.buyWithQuote",
      "args": ["$market", "$params.amountRaw", "$plan.MIN_SHARES"], "value": "0" }
  ]
}
```

要点：

- `$变量` 只能引用 `wallet / params / preflight 绑定值 / config`，不能是 LLM 编造的地址；
- 每个 step 的 `to` 必须来自提示词文本或已知注册表，或通过 `preflight` 读回；
- `expect` 是硬断言，不满足就停，不做“就近调整”；
- `assumptions` 必须展示给用户。

---

## 3. DeepSeek API 接入

### 3.1 调用方式

```
POST {baseUrl}/chat/completions
model: deepseek-chat            # 解析任务不需要 reasoner
temperature: 0
response_format: { type: "json_object" }
max_tokens: 800
messages:
  system: 固定的 DSL 说明 + JSON Schema + 3 个 few-shot（flap / mint / transfer）
  user:   提示词（可精简）+ 本地预抽取结果 + 可用 ABI 注册表摘要
```

### 3.2 省 token 的关键：不要每次发整篇手册

提示词常 6–10k token，其中 90% 是重复的操作手册。做法：

1. 本地先抽 `CONFIG`、地址、函数名、数字——这些是确定性的，**不花 token**；
2. 只把「用户最后一段指令 + CONFIG + 可用操作清单」发给模型（约 300–800 token）；
3. 按提示词 hash 缓存解析结果（同一份 CONFIG 换个金额可以本地替换，不必重调）；
4. 长手册只在首次出现新协议时发一次做「协议画像」，之后复用。

这样单次成本从 ~1 分钱降到 ~0.1–0.3 分钱，延迟从 3–5s 降到 1–2s。

### 3.3 low / high

- `deepseek-chat`（非思考）+ temperature 0：解析任务足够，**推荐**；
- `deepseek-reasoner`：只在「提示词写得非常绕、结构化抽取失败」时兜底，慢 3–10 倍；
- 结论：默认 low，失败重试一次 high，仍失败就让用户确认参数。

### 3.4 结构化输出与修复

- 强制 JSON；解析失败 → 把错误信息 + 原输出回传一次，要求修复（最多 1 次）；
- 校验器拒绝时，把「哪条断言不满足」回传，让模型只改参数，不重写整份 DSL；
- 任何情况下模型输出都要过校验器，**不能直接执行**。

---

## 4. 校验器（安全核心）

| 检查 | 规则 |
|---|---|
| schema | 字段类型、必填、版本 |
| 地址 | 必须 40 位 hex；必须出现在提示词或注册表中，否则拒绝 |
| 数值 | 正数、精度不超 decimals、单笔 value ≤ 用户配置上限（默认 0.1 BNB） |
| 步骤 | 最多 N 步；approve 必须在对应 call 之前；不允许重复同一 nonce 语义 |
| 协议 | `protocol` 必须在注册表；未知协议进入「原始调用」模式，需显式勾选 |
| 断言 | preflight 的 expect 全部满足才放行 |
| 提示词一致性 | 提示词给出的数量/价格/上限与链上读值不一致 → 停 |
| 禁止项 | 不允许多签、代理升级、`delegatecall`、无限授权（除非用户显式要求且二次确认） |

---

## 5. 编译器与 ABI 注册表

```
registry/
  flap.json      # portal/factory/probe ABI + 语义
  foundry.json   # handleOf/mintOpen/remaining/quoteBnb + 空 data 转账规则
  erc20.json
  erc1155.json
```

每个协议一个 JSON：ABI、允许的函数、参数校验、人类可读摘要模板。
编译器只接受注册表里的 `abi` 名称，比如 `"portal.buyWithQuote"`，
然后 `encodeFunctionData` 生成 calldata。

对没有注册表的合约：

- 需要用户粘贴 ABI 或 BscScan 链接；
- 或走「原始调用」：LLM 给出 `to/value/data`，但 UI 必须显示解码摘要 + 高风险标记，
  且默认 0 value、需要输入合约地址二次确认。

---

## 6. 执行与回执

复用现有能力：

1. `contract-call preview` 模拟（余额变化、风险、requestId）；
2. 用户确认；
3. `contract-call execute`；
4. `eth_getTransactionReceipt` 轮询；
5. 按 `postconditions` 解码日志（ERC-1155 TransferSingle/Batch、ERC-20 Transfer、自定义事件）；
6. 刷新余额/额度/历史。

失败处理：原样回传错误；`NoBnbMintMatch` 这类明确错误按提示词要求最多重试一次，
且重试前必须重新报价；不自动改数量/路由。

---

## 7. 前端交互

1. 粘贴提示词 → 「解析」；
2. 展示：识别到的协议、操作、参数、假设、预检结果；
3. 若有 `unknowns` 或缺失参数 → 表单补全，不猜；
4. 「生成计划」→ 步骤列表（每步：人类可读摘要 + to/value + 模拟按钮）；
5. 逐步或一键「预览全部 → 全部确认 → 顺序执行」；
6. 执行后展示回执、事件、余额变化。

---

## 8. 开发排期（建议）

| 阶段 | 内容 | 工作量 |
|---|---|---|
| P0 | DSL schema + 校验器 + 编译器（flap/foundry 两个注册表） | 2–3 天 |
| P1 | DeepSeek adapter：JSON 模式、修复重试、缓存、降级 | 1–2 天 |
| P2 | 通用执行器接入现有 preview/execute/回执 | 1 天 |
| P3 | UI：解析结果、假设、步骤、批量确认 | 1–2 天 |
| P4 | 评估集：20 条真实提示词，逐条核对 DSL | 1–2 天 |
| P5 | 原始调用模式（无 ABI 的协议）+ 风控 | 2 天 |

总计约 **1.5–2 周**；P0–P2 做完就能跑通“提示词 → 可执行计划”，P3 之后才好用。

---

## 9. 成本与延迟估算

| 项 | 数值 |
|---|---|
| 精简后输入 | 300–800 tokens |
| 输出 | 200–500 tokens |
| deepseek-chat 单次 | 约 0.1–0.3 分钱 |
| 延迟 | 1–2s（low），3–6s（reasoner） |
| 本地预抽取 | <5ms |
| 链上预检 | 0.5–1.5s |
| 端到端（到可执行计划） | 约 2–3s |

---

## 10. 不可承诺的边界

- 没有 ABI 的合约无法安全生成调用，只能走原始调用 + 人工核对；
- 提示词本身有歧义（“买一点”）时，必须回问，不能猜；
- 任何“保证成功”的承诺都不成立：链上状态会变，只能保证**预检 + 模拟 + 回执**闭环；
- LLM 可能被提示词注入，因此提示词只作为数据，系统指令优先级最高，且 DSL 必须过校验器。
