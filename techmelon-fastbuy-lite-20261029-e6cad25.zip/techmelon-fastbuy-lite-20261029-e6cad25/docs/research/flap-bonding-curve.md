# Flap「ID AGENT CURVE」bonding curve 页面逆向技术报告

- 目标页面：<https://flap.sh/apps/agent-bonding-curve?lang=zh>
- 调研时间：2026-10-24（Asia/Shanghai），链上数据取自 BSC 主网 block ≈ 129,355,000
- 调研方式：**只读**。抓 HTML / JS，读链上 `eth_call` / `eth_getCode` / `eth_getStorageAt`，探 REST API。**全程未发送任何交易、未签名、未触碰私钥。**
- 结论置信度标注：`[已验证]` = 我用链上调用或实际 HTTP 抓包亲自核对；`[文档]` = 来自页面自身内置的 ABI/说明文本；`[推断]` = 由数据反推；`[未验证]` = 无法确认。

---

## 0. TL;DR（先看这 10 条）

1. 站点是 **Next.js App Router（RSC 流式渲染）+ Vercel + Cloudflare**，`Server: cloudflare`、`x-vercel-id`、`x-vercel-cache: MISS`。[已验证]
2. 但页面本体**不在 Next.js chunk 里**。`/apps/[slug]` 只是一个 shell，真正的业务代码是 `vault-ui` 产物：从 Vercel Blob 动态 `import()` 的 `component.mjs`（295 KB，esbuild 打包，sha256 `08545080…c83f`）。[已验证]
3. 该 `component.mjs` 里内嵌了**完整的人类可读 ABI**（`portalAbi` / `factoryAbi` / `readerAbi` / `marketAbi` / `marketProbeAbi`），是本报告最可靠的来源。[已验证]
4. **买入/卖出/领取全部走 Portal 合约 `0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062`**，签名 `buy(address market,uint256 minShares)`、`sellBps(address,uint256,uint256)`、`claim(address)`，selector 依次 `0xcce7ec13` / `0x2f9d7c27` / `0x1e83409a`（已在 Portal 实现合约 bytecode 的 dispatcher 里逐字匹配到）。[已验证]
5. **`msg.value` 只有 `buy` 用**（原生 BNB）；`sellBps` / `claim` / `buyWithQuote` 全部 `value = 0`。[已验证：模拟 `buy` 带 value 成功，`sellBps`/`claim` 带 0 才会进入业务校验]
6. 报价**没有后端 API**。价格与最小份额全部来自链上 view / 模拟：`portal.quoteBuy`、`portal.quoteSell`、以及 Probe 合约的 `*Probe()`（**故意 revert，把结果写在 `Error(string)` 里**）。[已验证]
7. 曲线是 `spot = k / (S + h)²`（S = 剩余可售份额）。我用该公式算出的 `5,767,376,245` 与链上事件里发出的 spot price **完全相等**。[已验证]
8. 费用：**买 1.00%、卖 1.00%**（16 个市场的 `flapBuyFeeBps / flapSellFeeBps / agentFeeBps` 全为 100；其中 10 个可报价市场实测扣费恒为 100 bps）。[已验证]
9. **页面本身不能发交易来买卖**。`manifest.json` 的 `walletContracts.allow` 只授权了 `createMarket*` 三个函数，且 `maxValueWei = 1 BNB`；买卖/领取/查询被做成「复制给 Binance AI（Bibi）的提示词」。真正落地的买卖要用钱包/CLI 自己发。[已验证]
10. 截图里那个 `0x70604C50309092fCa6d91f3C312039Aa261bcD9` **只有 39 位 hex，不是合法地址**（应为 40 位），大概率是截图/OCR 少了一位。本文改用链上真实市场做样例。[已验证]

---

## 1. 关键地址总表

| 角色 | 地址 | 说明 / 证据 | 置信度 |
|---|---|---|---|
| **Factory**（市场注册表） | `0xC55820f24015bE7c4f18949D9e1363A3609B300e` | ERC-1967 代理（130 B），实现 `0x39115a0a6dfd118a3c30835a2da74bbe7bde573b`；`marketCount()=59`；`isMarket(address)` 可用 | 已验证 |
| **Portal**（下单入口） | `0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062` | ERC-1967 代理（130 B），实现 `0x6b606f48443c1929f58e4e1e5a36516d6185b2c3`；实现 bytecode 内含 `cce7ec13 / 2f9d7c27 / 1e83409a / a7c893c4 / 34259b1b` | 已验证 |
| **Reader**（批量读） | `0x18Aa6C93f1887a243fdc348C9A77F5136555174a` | ERC-1967 代理，实现 `0xac82f3c8797975eb82a24d374d6692c9605febcd`；`marketCards / marketDetail / marketSettings / marketPage / holderPage / userPosition` | 已验证 |
| **Market Beacon** | `0xe6af4e69982821A48D2e759991B96f14Fbbc9a1F` | `implementation() = 0xbea6346198d5e65ddb1d063f854dd234e05b1b22`；每个 market 是 beacon proxy（291 B） | 已验证 |
| **Probe Beacon** | `0x8E6F34B590E825AeEb352aBc69e16051C4D28c00` | `implementation() = 0x09970c5b517e586c2e10151ec477c770d7307b99`；每市场一个 Probe | 已验证 |
| **Flap 上游 Portal** | `0xe2cE6ab80874Fa9Fa2aAE65D277Dd6B8e65C9De0` | `factory.flapPortal()`；`SALT_LOCK_FEE()`、`getSaltLock(bytes32)` | 已验证 |
| **Agent ID（ERC-721 式身份）** | `0x60B9262456dE011F7d15a54CdD8c48bAaa8B022F` | `handleOf(address)`；本机钱包 `0xYour…0001` → `"<your-handle>"`，`buyCapacityProbe` 返回 `ID=1` | 已验证 |
| **Quote Helper**（曲线参数快照） | `0x0f54c532bc2f5e85c9e97c20ac6b481103f74c40` | `factory.quoteHelper()`；`snapshot(flapPortal,quoteToken,projectBuyTaxBps)` 一次返回曲线全部参数 | 已验证 |
| **Curve Module** | `0x8371c500d0c28d8c87dfa663f249544fed3c108a` | 从 `quoteHelper.snapshot()` 的 `curveModule` 字段读到；曲线积分实际实现处 | 已验证（地址）/ 未验证（源码） |
| **Tax Token 实现** | `0x024f18294970b5c76c0691b87f138a0317156422` | `factory.taxTokenImplementation()`；launch 后按 45 B EIP-1167 clone 部署 | 已验证 |
| 报价资产 NVDAB | `0x02Fca66C1D1aFB4E2A7884261eB00F63598a7436` | `approvedQuoteToken = true` | 已验证 |
| 报价资产 QQQB | `0x205812CdBed920aFf76C6580abD681a46D11efc7` | 同上 | 已验证 |
| 报价资产 SPCXB | `0xbe9D156892E55e7154BcD3cB0FEA677F9D3103E1` | 同上 | 已验证 |
| 报价资产 BNCB | `0x4902C5ebc598265Ed2212b559B042De8a5Eeec3f` | 同上 | 已验证 |
| 原生 BNB | `address(0)` | `approvedQuoteToken(0) = false`，走单独分支；`quoteBuy` 里 `QUOTE=0x0` | 已验证 |
| 样例市场（原生 BNB，phase 1） | `0xbaa11e4717b35d4b4e4332c425d702221da60027` | probe `0x708ed2e71d2388c25e863412e2349b7c3b8f1695`，cap = 5 BNB | 已验证 |
| 样例市场（ERC20 报价 BNCB，phase 1） | `0x533e69fba93cc66569d8ea5bd4a12f7d40e84808` | probe `0x3a5282ab0520ebe3142208b6a5927c08684b7930`，cap = 666.5 BNCB | 已验证 |

> 拓扑：`Factory` 记录 `market → probe` 绑定；`Market` 是 `MarketBeacon` 的 beacon proxy，`Probe` 是 `ProbeBeacon` 的 beacon proxy。**所有可升级**（beacon 可换实现），地址稳定但逻辑可变 —— 长期脚本应在启动时 `Factory.isMarket()` + `probe.market() == market` 双向校验。

---

## 2. 页面结构（问题 1）

### 2.1 框架判定

- `<!DOCTYPE html><html class="dark" lang="zh">`，`/_next/static/*`，`self.__next_f.push([1,"..."])` 流式 RSC payload，`vary: rsc, next-router-state-tree, next-router-prefetch` → **Next.js App Router（RSC）**，不是 Pages Router（无 `__NEXT_DATA__`）。
- 静态路径模板：`x-matched-path: /apps/[slug]`，`x-pathname: /apps/agent-bonding-curve`。
- 托管：`Server: cloudflare` + `CF-RAY` + `x-vercel-id: sfo1::iad1::…` + `x-vercel-cache: MISS` → **Cloudflare 在前面，Vercel 做源站**。
- 语言切换靠 `flap_language` cookie + `localStorage["flap:language"]`；链选择靠 `localStorage["FLAP_SELECTED_CHAIN_ID"]`（`boardPaths` 里有 bnb/robinhood/base/xlayer/monad/morph）。

### 2.2 真正的业务代码：vault-ui artifact

RSC payload 里有一段 `registration`，把整个 app 的资产地址、哈希、版本都写死了：

```
appId      vaultui_agent-bonding-curve_01M5FK4RKTKXQ8GDT8ZMZMAYVD
version    v20261023134909522_agent-bonding-curve_8b26639fea52
surfaces   ["vault-ui"]
i18n       ["en","zh"]
walletChains [56]
endpoints  ["https://fsi.taxed.fun/fsi/v1",
            "https://api.dexscreener.com/tokens/v1/bsc"]
```

资产基址（Vercel Blob，公开可读、无鉴权）：
`https://lulxnvty7pwl9d1n.public.blob.vercel-storage.com/vault-ui/vaultui_agent-bonding-curve_01M5FK4RKTKXQ8GDT8ZMZMAYVD/v20261023134909522_agent-bonding-curve_8b26639fea52/`

| 文件 | 大小 | sha256（前 16 位） |
|---|---|---|
| `component.mjs` | 294,920 B | `08545080fdc1e4c8…` |
| `artifact.css` | 65,219 B | `d5b709ab4ea752b7…` |
| `metadata.json` | 3,597 B | `e71598144d565d5e…` |
| `manifest.json` | 8,775 B | `d2c4aabf6cfd3b39…` |
| `i18n.json` | 132,707 B | `e806ac409158bfa7…` |

`metadata.json` 关键点：`sdkVersion: @flapsdk/vault-runtime@0.1.39`，`buildTool: esbuild 0.25.12`，`runtimeExternals: [react, react-dom, wagmi, viem, @tanstack/react-query, @rainbow-me/rainbowkit]`。

**加载器**在 Next chunk `/_next/static/chunks/2353-cd11484390f914b2.js` 里：它读 `__FLAP_VAULT_ARTIFACT_COMPONENT_URL__`、校验 5 个 sha256、按 `assetTargets`（`flap-sh` / `flap-canary`）选 Blob 域名，然后 `import()` `component.mjs`。所以**只抓 Next chunk 是抓不到业务逻辑的** —— 这是本次调研最关键的弯路。

### 2.3 主要 `<script src>`（共 50 个，去重后）

页面级 / 框架级：

```
/_next/static/chunks/webpack-687394a4fdb9ebaa.js
/_next/static/chunks/polyfills-42372ed130431b0a.js
/_next/static/chunks/4bd1b696-100b9d70ed4e49c1.js
/_next/static/chunks/main-app-7f278ddf1055bc1a.js
/_next/static/chunks/1913-812f06c69e0a6f99.js
/_next/static/chunks/6585-be9a2634da20242b.js
/_next/static/chunks/app/layout-3a15c050efe81a30.js
/_next/static/chunks/app/apps/%5Bslug%5D/page-b3a8f94bda0ebe7b.js
/_next/static/chunks/app/apps/%5Bslug%5D/error-ffdee8a67fd30b46.js
/_next/static/chunks/app/apps/%5Bslug%5D/not-found-7bad4dd9868f559a.js
/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js   ← Cloudflare 注入
```

值得注意的三个 chunk：

| chunk | 作用 |
|---|---|
| `2353-cd11484390f914b2.js` (30.5 KB) | **artifact 加载器**：`surfaces: ["vault-ui","launch-config"]`、`component.mjs` 常量、sha256 校验、Blob target 选择 |
| `83-087e6b3bd8918d4c.js` (88 KB) | **运行时 SDK 的 RPC/FSI 层**：硬编码 `https://fsi.taxed.fun/fsi/v1` 与备份 `https://bsc-debug.butterfly.army/fsi/v1`，并做 origin 白名单校验 |
| `4354-6203779dfda296ff.js` / `326-7e849721b4cb96eb.js` | wagmi + RainbowKit 连接器；含 `wallet_sendCalls`、`eth_signTypedData_v4`、`capabilities`（EIP-5792 批量能力探测） |

其余 37 个为业务无关的 vendor chunk（`2544`、`7721`、`6711`、`4183`、`8766`、`8856`、`8930`、`920`、`753`… 含 viem/wagmi/ui 组件）。完整列表见附录 A。

---

## 3. 合约层面的买卖（问题 2）

### 3.1 两条独立交易路径

页面把市场分两类，ABI 与参数都不同：

| 报价资产 | 买入函数 | 卖出/领取 | `msg.value` |
|---|---|---|---|
| **原生 BNB**（`quoteToken == 0x0`） | `buy(address market, uint256 minShares)` | `sellBps` / `claim` | `buy` 的 value = 用户输入的 BNB(wei) |
| **ERC20**（NVDAB/QQQB/SPCXB/BNCB） | `buyWithQuote(address market, uint256 grossQuote, uint256 minShares)` | `sellBps` / `claim` | 恒 0；先 `approve` |

页面里区分逻辑（`component.mjs` → `aiActions()`）：`erc20 = market.quoteToken !== 0x0`。

### 3.2 Portal 合约完整签名表 `[文档 + 已验证 selector]`

```solidity
// ── 买入 ─────────────────────────────────────────────
function buy(address market, uint256 minShares) payable returns (uint256);
//   msg.value = grossWei（原生 BNB 毛额，含费，可含退款）
//   minShares = 滑点下限（由 buyPlanProbe 给出的 MIN_SHARES 原样填入）

function buyWithQuote(address market, uint256 grossQuote, uint256 minShares) returns (uint256);
//   value = 0；调用前 QUOTE_TOKEN.approve(market, grossQuote)  // spender 是 Market，不是 Portal
//   余额与授权必须覆盖「完整 grossRaw」，即使 ACCEPT_RAW 更小（Market 先全额 pull 再退差额）

// ── 卖出 ─────────────────────────────────────────────
function sellBps(address market, uint256 bps, uint256 minOut) returns (uint256);
//   bps     = 要卖出的持仓百分比，1..10000（5000 = 50%）
//   minOut  = 最小报价资产输出（由 sellPlanCustomProbe 的 MIN_WEI 原样填入）
//   value   = 0

function sell(address market, uint256 poolDebitWei, uint256 maxShares, uint256 minBnbOut) returns (uint256, uint256);
function sellAll(address market, uint256 minOut) returns (uint256);                                   // 旧版
function sellAll(address market, uint256 expectedShares, uint256 expectedRemainingPoolWei, uint256 minBnbOut) returns (uint256);

// ── 领取（launch 之后把内部份额换成真 token）──────────
function claim(address market) returns (uint256);
//   value = 0；不需要 Agent ID，不需要 approve

// ── 报价（view，纯 read）──────────────────────────────
function quoteBuy(address market, address wallet, uint256 grossWei)
    view returns (uint256 acceptedGross, uint256 fee, uint256 refund, uint256 shares);
function quoteSell(address market, address wallet, uint256 poolDebitWei)
    view returns (uint256 shares, uint256 curveWei, uint256 fee, uint256 bnbOut);
function quoteSellAll(address market, address wallet)
    view returns (uint256 shares, uint256 remainingPoolWei, uint256 fee, uint256 bnbOut);

// ── 建盘（本页面唯一被授权的写操作）────────────────────
function createMarket((string name,string symbol,string meta,bytes32 salt,address beneficiary,
                      uint16 buyTaxRate,uint16 sellTaxRate,uint16 mktBps,uint16 deflationBps,
                      uint16 dividendBps,uint16 lpBps,uint16 maxWalletBps) config) payable returns (address market);
function createMarketWithQuote(address quoteToken, (...同 config...) ) payable returns (address market);
function createMarketAndBuy((...同 config...), uint256 firstBuyWei, uint256 minShares)
    payable returns (address market, uint256 shares);
```

**已逐个核对 selector（自算 keccak，与页面内置表逐字一致）：**

| 函数 | selector |
|---|---|
| `buy(address,uint256)` | `0xcce7ec13` |
| `buyWithQuote(address,uint256,uint256)` | `0xa7c893c4` |
| `sellBps(address,uint256,uint256)` | `0x2f9d7c27` |
| `claim(address)` | `0x1e83409a` |
| `quoteBuy(address,address,uint256)` | `0x34259b1b` |
| `quoteSell(address,address,uint256)` | `0x9981d632` |
| `quoteSellAll(address,address)` | `0xae41aa61` |
| `sell(address,uint256,uint256,uint256)` | `0x92cdbac5` |
| `sellAll(address,uint256)` | `0xd69f8e66` |
| `sellAll(address,uint256,uint256,uint256)` | `0x93768068` |
| `approve(address,uint256)` | `0x095ea7b3` |

**链上直接证据**：`0x6b606f48…b2c3`（Portal 实现）的 dispatcher 字节码片段
`…9081631737a4bd…80631e83409a14611ebb5780632f9d7c2714611d8857806332ca2ee6…806334259b1b14611bb257…`
→ `claim`、`sellBps`、`quoteBuy` 三个 selector 都在 `if-else` 链里。`buy`/`buyWithQuote` 的 selector 也存在于同一份 bytecode。[已验证]

### 3.3 参数含义逐项说明

`buy`：

| 参数 | 含义 | 来源 |
|---|---|---|
| `market` | Market 合约地址（不是 token，不是 factory） | `marketCards[].market` / `marketPage` |
| `minShares` | 成交份额下限（18 位小数的 ledger 份额，**不是 ERC20 余额**） | `Probe.buyPlanProbe(grossWei, slippageBps)` 的 `MIN_SHARES`，**原样填入，不要自己算** |
| `msg.value` | 毛额 BNB（wei）。合约可能「只吃一部分 + 退款」：`acceptedGross ≤ msg.value`，差额进 `refund` | 用户输入 |

`buyWithQuote`：`grossQuote` 是 ERC20 毛额（用该 token 的 `decimals`），`minShares` 同上；`msg.value = 0`。
**注意**：Market 会先 `transferFrom` **完整 grossQuote** 再退差额，所以 `balanceOf` / `allowance` 必须 ≥ `grossQuote`，不能只按 `ACCEPT` 准备。

`sellBps`：`bps` 是「占自己当前份额的百分比」（整数，10000 = 100%），`minOut` 是最小报价资产输出。`value = 0`。
页面禁止擅自用 100% 或 5%：i18n 明确写 `Do not assume 50% or full sale`、`Only user-specified slippage`。

`claim`：只带 `market`，把「曲线内部份额」换成 launch 出来的真实 token。前置条件 `PHASE=3`、`CLAIM_OK=1`、`STATE=READY`、`CLAIM_RAW>0`。

### 3.4 「Market 地址」与「预测代币地址」到底是什么

页面在创建成功后的详情卡（`CreatedMarketDetail`）里显示两行：

```
{ label: t(launched ? "terminal.token" : "created.token"), value: token }   // 预测代币地址 / 已发行代币
{ label: t("created.market"), value: created.market }                      // Market 地址
```

- **Market 地址 = 一次「内部曲线市场」实例**（`MarketBeacon` 的 beacon proxy，291 B）。它持有：份额账本、池子余额、曲线参数、`predictedToken`、`creator`、`phase`、`maxWalletShares`。买卖的 `market` 参数就是它。它**不是** ERC20，**不是**交易对，**不**直接给你 token。
- **预测代币地址 = `market.predictedToken()`**，是用 CREATE2 + vanity `salt` 预算出来的地址，**必须以后缀 `7777` 结尾**（i18n：`The salt must predict an unused tax token ending in 7777`）。曲线打满（cap）后，Flap 在该地址 clone 出税币并在 PancakeSwap 建对。
  - 已核对：phase 3 的市场 `token() == predictedToken()`，且 `token` 的 code size = **45 B**（EIP-1167 minimal proxy）→ 预测地址在 launch 时被真正部署，**地址不变**。[已验证]
  - 样本：`0xaacb16af…4968` → token `0x7832c85c1910945d54494424f606e90c92cf7777`、pair `0x6e43f2662b9ee9065a0ca951552589b5a5313dbf`。
- 第三个地址 `pair` 只有 launch 后才有意义（`phase==3` 前是占位/预测地址，页面会显示 `null`）。

**所以你截图里那一对**：Market = `0x70604C50309092fCa6d91f3C312039Aa261bcD9`（39 位，**非法**，请回到页面重新复制完整地址），预测代币 = 该 market 的 `predictedToken()`，用 `Factory.probeOfMarket` + `Reader.marketCards([market])` 一查即可拿到。

---

## 4. 曲线 / 报价（问题 3）

### 4.1 前端不请求任何「报价 API」

`manifest.json` 的 `endpoints` 只有两个，且都与报价无关：

| endpoint | 用途 |
|---|---|
| `https://fsi.taxed.fun/fsi/v1` | 历史成交 / 价格点（图表、Trades 面板），**只读历史，不报价** |
| `https://api.dexscreener.com/tokens/v1/bsc` | 只把 `BNB / NVDAB / QQQB / SPCXB / BNCB` 折算成 USD 显示，**不参与成交定价** |

页面里 `fetch(` 只出现 2 次，都是 dexscreener。其余全部走 `sdk.readContract(...)` → JSON-RPC `eth_call`。[已验证]
备份 FSI 源：`https://bsc-debug.butterfly.army/fsi/v1`（运行时白名单里的第二个 origin）。

### 4.2 链上报价 = 唯一真源

**A. 正规 view（推荐给 CLI）**

```solidity
quoteBuy(market, wallet, grossWei)   → (acceptedGross, fee, refund, shares)
quoteSell(market, wallet, poolDebit) → (shares, curveWei, fee, bnbOut)
quoteSellAll(market, wallet)         → (shares, remainingPoolWei, fee, bnbOut)
```

实测（`0xbaa11e…0027`，原生 BNB，floor 0）：

| grossWei | acceptedGross | fee | refund | shares |
|---|---|---|---|---|
| 0.001 BNB `1e15` | 1e15 | 1e13 (1%) | 0 | `164763961506125483011425` |
| 0.01 BNB `1e16` | 1e16 | 1e14 (1%) | 0 | `1645392123416527945186430` |
| 0.1 BNB `1e17` | 1e17 | 1e15 (1%) | 0 | `16232498991563877315563814` |
| 1 BNB `1e18` | 1e18 | 1e16 (1%) | 0 | `143071675846688914734459816` |

**B. Probe 合约的「revert-string 读数」（页面/Agent 提示词主路径）**

每个 market 有一个 Probe（`Factory.probeOfMarket(market)`），所有 `*Probe()` 都是 **nonpayable、必然 revert**，把结果写进 `Error(string)`，格式 `KEY=VALUE;KEY=VALUE;…;END`。**只能 `eth_call` 模拟，绝对不能广播。**

| 方法 | selector | 返回字段（revert string） |
|---|---|---|
| `assetProbe()` | `0x80c8c302` | `MARKET;QUOTE;DECIMALS;END` |
| `marketProbe()` | `0x88c8da88` | `POOL_WEI;CAP_WEI;ROOM_WEI;PHASE;BLOCK;END` |
| `buyCapacityProbe()` | `0x593d2a74` | `ROOM_SHARES;HELD_SHARES;LIMIT_SHARES;ID;PHASE;END` |
| `positionProbe()` | `0x68036cac` | `HELD_SHARES;FULL_SELL_WEI;SELL_OK;PHASE;BLOCK;END` |
| `sharesProbe()` | `0x0ef4fec1` | `SHARES;END` |
| `actionStatusProbe()` | `0x331e21da` | `BUY_OK;CLAIM_OK;PHASE;TOKEN;END` |
| `claimableProbe()` | `0xfb0e3154` | `CLAIM_RAW;STATE;PHASE;END` |
| `launchRouteProbe()` | `0x766d6582` | `TOKEN;PAIR;PHASE;END` |
| `quoteBuyProbe(uint256 grossWei)` | `0xd620e44d` | `SHARES;ACCEPT_WEI;FEE_WEI;REFUND_WEI;BLOCK;END` |
| `buyPlanProbe(uint256 grossWei,uint256 slippageBps)` | `0x0f803438` | `MIN_SHARES;BUY_SHARES;RULES_OK;BLOCK;END` |
| **`sellPlanCustomProbe(uint256 bps,uint256 slippageBps)`** | `0xcceb5cad` | `SHARES;OUT_WEI;MIN_WEI;BLOCK;END` |
| `quoteSellBpsProbe(uint256 bps)` | `0xfe12dd21` | `SHARES;OUT_WEI;BLOCK;END` |
| `sellPlanProbe(uint256 bps)` | `0x309768d4` | 同上，**写死 5% 滑点** |
| `quoteSellSharesProbe(uint256 shares)` | `0x0717300a` | `SHARES;OUT_WEI;MIN_WEI;BLOCK;END`，写死 5% |
| `quoteFundingProbe(uint256 grossRaw)` | `0x5403449d` | `BALANCE_OK;ALLOWANCE_OK;BLOCK;END`（仅 ERC20） |
| `holderRegistryProbe()` | `0x07f691d0` | `COUNT;COMPLETE;TOTAL_SHARES;PHASE;BLOCK;END` |
| `holderAtProbe(uint256 i)` | `0x2d58b248` | `HOLDER;SHARES;IDX;COUNT;BLOCK;END` |
| `walletStatsProbe()` | `0x8be476a7` | `SPENT_WEI;RECEIVED_WEI;BUYS;SELLS;CLAIMS;END` |
| `walletShareStatsProbe()` | `0xbacf903d` | `BOUGHT;SOLD;CLAIMED;BALANCED;END` |

实测样例（from = `0xYourWalletAddress000000000000000000000001`，`0xbaa11e…0027`）：

```
buyCapacityProbe()            → ROOM_SHARES=20000000000000000000000000;HELD_SHARES=0;LIMIT_SHARES=20000000000000000000000000;ID=1;PHASE=1;END
actionStatusProbe()           → BUY_OK=1;CLAIM_OK=0;PHASE=1;TOKEN=0x000…000;END
marketProbe()                 → POOL_WEI=126201503727985483;CAP_WEI=5000000000000000000;ROOM_WEI=4873798496272014517;PHASE=1;BLOCK=129355002;END
quoteBuyProbe(1e16)           → SHARES=1645392123416527945186430;ACCEPT_WEI=10000000000000000;FEE_WEI=100000000000000;REFUND_WEI=0;BLOCK=129355000;END
buyPlanProbe(1e16,500)        → MIN_SHARES=1563122517245701547927108;BUY_SHARES=1645392123416527945186430;RULES_OK=1;BLOCK=129355001;END
positionProbe()               → HELD_SHARES=0;FULL_SELL_WEI=0;SELL_OK=0;PHASE=1;BLOCK=129354996;END
claimableProbe()              → CLAIM_RAW=0;STATE=PRELAUNCH;PHASE=1;END
launchRouteProbe()            → TOKEN=0x6fbf09a6207365655af0f4e149a8691ae4d67777;PAIR=0xf95cc286…;PHASE=1;END
```

> `MIN_SHARES = 1645392123416527945186430 × 95% = 1563122517245701547927108` → 滑点公式就是 `shares × (10000 - slippageBps) / 10000`，向下取整。[已验证]

### 4.3 曲线公式（已用链上数据逐位验证）

```
spot(S) = k · 1e18 / ( ((1e9·1e18 − totalShares) + h)² / 1e18 )
```

- `S = totalShares`（已售出的 18 位内部份额），`remaining = 1e9·1e18 − S`（总供应 10 亿 token，18 位）
- `h = curveH`、`k = curveK`，单位都是 1e18 定点
- 结果单位：**quote-wei / 1e18 份额**（原生市场即 wei/份额）

`component.mjs` 里的实现（`initialSpotPrice`，状态为 0 持仓时）：

```js
const TOTAL_TOKEN_SUPPLY = 1000000000000000000000000000n; // 1e9 * 1e18
function initialSpotPrice(settings) {
  if (settings.curveK <= 0n) return null;
  const remaining = TOTAL_TOKEN_SUPPLY + settings.curveH;
  const squared = remaining * remaining / 10n ** 18n;
  return squared > 0n ? settings.curveK * 10n ** 18n / squared : null;
}
```

**验证**：`0xbaa11e…0027` 上 `totalShares=21421183154473147021597812`、`h=107036752000000000000000000`、`k=6797205657280000000000000000`
→ 公式得 **`5767376245`**；
FSI `virtualBuy` 第 17 条（tx `0xc2569b3f…a6b77`）的 `extra` 正是 **`5767376245`** —— **完全相等**。[已验证]

各种曲线形态的实证区间（同一市场，价格随买入单调上升）：

| 区间（net BNB） | 隐含边际价（wei / 1e18 份额） |
|---|---|
| 0.0009–0.009 | 6.018e9 |
| 0.009–0.09 | 6.108e9 |
| 0.09–0.45 | 6.562e9 |
| 0.45–0.99 | 7.445e9 |

→ 曲率温和（1 BNB 内价格翻不到 1.3 倍），符合 `1/(S+h)²` 在 `S ≪ h` 时的近似线性。

**已知的曲线参数（`Reader.marketSettings`）**

| 字段 | 原生市场 `0xbaa11e…` | ERC20 市场 `0x533e…`（BNCB） |
|---|---|---|
| `curveType` | `20` | `50` |
| `curveR` | `6140000000000000000` (6.14 BNB) | `767400000000000000000` (767.4) |
| `curveH` | `107036752000000000000000000` | `107036751000000000000000000` |
| `curveK` | `6797205657280000000000000000` | `849540002717400000000000000000` |
| `capRaw` | `5000000000000000000` (5 BNB) | `666500017778002086793` (666.5) |
| `virtualReserveAtCap` | — | `646505017244662024191` |
| `maxWalletShares` | `20000000000000000000000000` | 同 |

`capRaw` 就是曲线打满阈值（`marketDetail.capRaw` / `marketProbe.CAP_WEI`）。原生市场一律 **5 BNB**；ERC20 市场按该 token 的 `quoteDecimals` 折算（约 666.5）。

> 曲线积分（`buy` 实际付多少拿多少）在 `curveModule = 0x8371c500d0c28d8c87dfa663f249544fed3c108a` 里，没开源，我**没有**复现闭式积分 —— 但 `spot` 公式、`cap`、`k/h/r` 全部已验证，且 `quoteBuy` 可随时取真值。`[未验证：积分闭式]`

### 4.4 FSI REST API（历史/图表，非报价）

```
GET https://fsi.taxed.fun/fsi/v1/{emitter}/G/{namespace}?sort=time_desc&limit=<n>[&cursor=<c>]
```

- `emitter`：Market 地址（小写）或 Factory 地址
- `namespace`：`virtualMarketCreated`（Factory 上新）、`virtualBuyFill` / `virtualSellFill`（逐笔成交）、`virtualBuy` / `virtualSell`（价格点）
- `template`：固定 `G`
- 响应：`{emitter, template, ns, items:[…], nextCursor}`

真实响应（裁剪）：

```json
{
  "emitter": "0xbaa11e4717b35d4b4e4332c425d702221da60027",
  "template": "G",
  "ns": "virtualBuyFill",
  "items": [{
    "id": "17",
    "actor": "0xc2ef3ef28549372b4fd19b4393fe97fc8c21e066",
    "related": "0x6fbf09a6207365655af0f4e149a8691ae4d67777",
    "amount": "10000000000000000",        // 曲线净额（quote wei / raw）
    "extra": "1650394901285658926280845", // 份额
    "blockNumber": 129354644, "logIndex": 410,
    "txHash": "0xc2569b3f9203361e5865e62ac984c086e81b48c8ca4c2e095e83a9150b0a6b77",
    "updatedAt": 1792773239, "confirmed": true, "trusted": false
  }],
  "nextCursor": "MAoxMjkzNDYwNTMKMjUx"
}
```

`virtualBuy` / `virtualSell` 的语义：`amount` = 该笔的曲线 quote 量，`extra` = **成交后的 spot price**（就是 4.3 的公式值）。页面用 `PRICE_RANGES`（1H/4H/1D/7D/ALL）翻页最多 10 页（100 条/页）。

---

## 5. 费用（问题 4）

### 5.1 内部曲线费

| 字段（`Reader.marketDetail`） | 含义 | 实测值（16 个市场全部一致） |
|---|---|---|
| `flapBuyFeeBps` | 买入平台费 | `100` = 1.00% |
| `flapSellFeeBps` | 卖出平台费 | `100` = 1.00% |
| `agentFeeBps` | Agent 分成 | `100` = 1.00% |
| `cumulativeBuyFeesRaw` | 累计买入费 | 与 `cumulativeAgentFeesRaw` **完全相等** |

**实测扣费**：扫了 16 个市场（其中 10 个 `PHASE=1` 可报价、6 个已 launch 报价 revert），三组 bps 字段**全部**是 `(100,100,100)`；10 个可报价市场逐个 `quoteBuy(market, 0x…01, 1e18)`，`fee / acceptedGross` **全部等于 100 bps**；`0x533e…` 的 `cumulativeBuyFeesRaw/cumulativeBuyGrossRaw = 13598851094788946/1359885109478894620 = 1.0000%`。[已验证]

前端**不拼接**费率：直接读 `marketDetail.cumulative*` 与 `quoteBuy().fee` 显示。契约里的 1% / 1% 已经由合约在 `acceptedGross` 里扣掉，`shares` 是按净额算的。

> **口径歧义（置信度：中）**：`flapBuyFeeBps` 与 `agentFeeBps` 都是 100，但实扣只有 100 bps，且 `cumulativeAgentFeesRaw == cumulativeBuyFeesRaw`。两种解释：(a) 总费 = `flapBuyFeeBps`，`agentFeeBps` 是「其中给 Agent 的份额」；(b) 总费 = max(两者)。样本里两者恒等，无法区分。**结论以实测 1.00% 为准。**

### 5.2 发布时设定的代币税（launch 之后生效，与曲线费无关）

建盘 `config` 里：

```
buyTaxRate   ∈ [100,1000] bps  (1%–10%，整百分点)
sellTaxRate  ∈ [100,1000] bps
mktBps + deflationBps + dividendBps + lpBps == 10000   (税的去向必须凑满 100%)
maxWalletBps  (单钱包上限，默认 100 bps)
beneficiary   (营销税收款地址)
salt          (CREATE2 vanity，预测地址必须以 7777 结尾)
```

页面默认：`buyTaxRate=100, sellTaxRate=100, mktBps=0, deflationBps=1000, dividendBps=0, lpBps=0, maxWalletBps=100`。
这是**税币**层面的税，只在该 token 上 PancakeSwap 交易时收，**不影响**内部曲线买卖的 1% 费。

---

## 6. 代币标准与授权（问题 5）

| 场景 | 要不要 approve | spender | 说明 |
|---|---|---|---|
| **原生 BNB 买入** | **不需要** | — | i18n：`No ERC20 allowance … is needed for native BNB purchases` / `Native BNB needs no token approval` |
| **ERC20 报价买入** | **需要** | **Market 地址**（不是 Portal） | `QUOTE_TOKEN.approve(market, grossQuote)`；i18n：`Approve Market, not Portal; never default to unlimited allowance`；`quoteFundingProbe` 专测 `BALANCE_OK` / `ALLOWANCE_OK` |
| **卖出（拿回 BNB/报价币）** | **不需要** | — | 份额是 Market 内部账本，不是 ERC20：`These are Market ledger shares, not an ERC20 token balance` / `Selling needs neither Agent ID nor share-token approval` |
| **claim（领真 token）** | **不需要** | — | `claim … needs no Agent ID or share-token approval` |
| **launch 后把 token 卖成 BNB**（dex_exit） | 视路由而定 | 由钱包/DEX 路由决定 | 页面**不**自己拼路由：`No external router ABI or price is inferred from Probe` |

- 份额精度恒 `1e18`（`Internal shares are 18-decimal ledger units`）。
- launch 出来的真 token 是 **45 B EIP-1167 clone**（实现 `0x024f18…6422`），带税（ERC20 + 税逻辑），`decimals` 需自行 `decimals()` 读。
- 报价币 `decimals`：NVDAB/QQQB/SPCXB/BNCB 实测 `18`（`assetProbe` 返回 `DECIMALS=18`）。

---

## 7. 可复现的调用示例（问题 6）

> 全部以 `market = 0xbaa11e4717b35d4b4e4332c425d702221da60027`（原生 BNB）、`portal = 0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062` 为例。

### 7.1 正确的执行顺序（缺一步就会失败或吃亏）

```
1) Factory.isMarket(market) == true
2) probe = Factory.probeOfMarket(market);  Probe.market() == market
3) Probe.assetProbe()          → QUOTE / DECIMALS 自检
4) Probe.buyCapacityProbe()    → 要求 PHASE=1, ID=1, 看 ROOM_SHARES
5) Probe.buyPlanProbe(grossWei, slippageBps) → 要求 RULES_OK=1，取 MIN_SHARES
6) （可选）Portal.quoteBuy(market, wallet, grossWei) → accepted/fee/refund/shares
7) Portal.buy(market, MIN_SHARES) with value = grossWei
8) 等 receipt → 复核 positionProbe()/sharesProbe()
```

卖出把 4–7 换成 `positionProbe()` → `sellPlanCustomProbe(bps, slippageBps)` → `Portal.sellBps(market, bps, MIN_WEI)`。

### 7.2 viem（推荐，最贴近页面 SDK）

```ts
import { createWalletClient, createPublicClient, http, parseAbi } from "viem";
import { bsc } from "viem/chains";

const PORTAL = "0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062" as const;
const PROBE  = "0x708ed2e71d2388c25e863412e2349b7c3b8f1695" as const; // Factory.probeOfMarket(market)
const MARKET = "0xbaa11e4717b35d4b4e4332c425d702221da60027" as const;

const portalAbi = parseAbi([
  "function buy(address market,uint256 minShares) payable returns (uint256)",
  "function sellBps(address market,uint256 bps,uint256 minOut) returns (uint256)",
  "function claim(address market) returns (uint256)",
  "function quoteBuy(address market,address wallet,uint256 grossWei) view returns (uint256 acceptedGross,uint256 fee,uint256 refund,uint256 shares)",
  "function quoteSell(address market,address wallet,uint256 poolDebitWei) view returns (uint256 shares,uint256 curveWei,uint256 fee,uint256 bnbOut)",
]);

// Probe 全部 nonpayable + 必然 revert，用 call 拿 revert data
const probeAbi = parseAbi([
  "function buyCapacityProbe()",
  "function buyPlanProbe(uint256 grossWei,uint256 slippageBps)",
  "function positionProbe()",
]);

function decodeErrString(data: `0x${string}`) {
  const d = data.slice(10);
  const off = Number(BigInt("0x" + d.slice(0, 64))) * 2;
  const len = Number(BigInt("0x" + d.slice(off, off + 64))) * 2;
  return Buffer.from(d.slice(off + 64, off + 64 + len), "hex").toString();
}
function parseFields(s: string) {
  const m = Object.fromEntries(
    s.replace(/;END;?$/, "").split(";").filter(Boolean)
      .map(kv => { const i = kv.indexOf("="); return [kv.slice(0, i), kv.slice(i + 1)]; })
  );
  if (!s.endsWith("END")) throw new Error("unreadable probe: " + s);
  return m;
}

const grossWei = 10_000_000_000_000_000n; // 0.01 BNB
const slippageBps = 500n;                 // 5%（必须由用户明确指定）

const client  = createPublicClient({ chain: bsc, transport: http("https://bsc-rpc.publicnode.com") });
const wallet  = createWalletClient({ chain: bsc, transport: http(), account });

// 1) 计划
let plan: Record<string,string>;
try { await client.call({ to: PROBE, data: encodeFunctionData({ abi: probeAbi, functionName: "buyPlanProbe", args: [grossWei, slippageBps] }) }); }
catch (e: any) { plan = parseFields(decodeErrString(e.data ?? e.cause?.data)); }
// plan.MIN_SHARES / plan.BUY_SHARES / plan.RULES_OK / plan.BLOCK

const minShares = BigInt(plan.MIN_SHARES);

// 2) 下单（value 就是毛额）
const hash = await wallet.writeContract({
  address: PORTAL, abi: portalAbi, functionName: "buy",
  args: [MARKET, minShares], value: grossWei,
});
```

### 7.3 ethers.js v6

```js
import { ethers } from "ethers";

const portal = new ethers.Contract(
  "0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062",
  [
    "function buy(address market,uint256 minShares) payable returns (uint256)",
    "function sellBps(address market,uint256 bps,uint256 minOut) returns (uint256)",
    "function claim(address market) returns (uint256)",
    "function quoteBuy(address market,address wallet,uint256 grossWei) view returns (uint256 acceptedGross,uint256 fee,uint256 refund,uint256 shares)",
    "function quoteSell(address market,address wallet,uint256 poolDebitWei) view returns (uint256 shares,uint256 curveWei,uint256 fee,uint256 bnbOut)",
  ],
  signer
);

const grossWei = ethers.parseEther("0.01");
const q = await portal.quoteBuy(MARKET, await signer.getAddress(), grossWei);
// minShares = q.shares * (10000 - slippageBps) / 10000，或直接取 buyPlanProbe 的 MIN_SHARES
const minShares = q.shares * 9500n / 10000n;

const tx = await portal.buy(MARKET, minShares, { value: grossWei });
await tx.wait();
```

### 7.4 原始 calldata（给 `contract-call --inputData` / `--value` 用）

`to = 0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062`（**所有 `to` 都是 Portal**）

| 操作 | value (wei) | data |
|---|---|---|
| **buy** 0.01 BNB，minShares=0 | `10000000000000000` | `0xcce7ec13000000000000000000000000baa11e4717b35d4b4e4332c425d702221da600270000000000000000000000000000000000000000000000000000000000000000` |
| **buy** 0.01 BNB，minShares=`1563122517245701547927108`（5% 滑点） | `10000000000000000` | `0xcce7ec13000000000000000000000000baa11e4717b35d4b4e4332c425d702221da60027000000000000000000000000000000000000000000014b010a9ca8ed9ee4a644` |
| **sellBps** 50%，minOut=0 | `0` | `0x2f9d7c27000000000000000000000000baa11e4717b35d4b4e4332c425d702221da6002700000000000000000000000000000000000000000000000000000000000013880000000000000000000000000000000000000000000000000000000000000000` |
| **claim** | `0` | `0x1e83409a000000000000000000000000baa11e4717b35d4b4e4332c425d702221da60027` |
| **buyWithQuote**（ERC20 市场 `0x533e…4808`，gross=1e18，minShares=0） | `0` | `0xa7c893c4000000000000000000000000533e69fba93cc66569d8ea5bd4a12f7d40e848080000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000` |
| **approve**（对 BNCB `0x4902…ec3f`，spender=市场，1e18） | `0` | `0x095ea7b3000000000000000000000000533e69fba93cc66569d8ea5bd4a12f7d40e848080000000000000000000000000000000000000000000000000de0b6b3a7640000` |

拼装规则（无例外）：`selector(4B) + 每个参数左补零到 32B`。地址参数按 20 字节右对齐补 12 字节零；`uint256` 直接大端 32 字节。

只读 view（同样形状，`eth_call`，不要广播）：

| 用途 | to | data |
|---|---|---|
| `quoteBuy` 0.01 BNB | Portal | `0x34259b1b000000000000000000000000baa11e4717b35d4b4e4332c425d702221da60027` + `00000000000000000000000000000000000000000000000000000000000000a1` + `000000000000000000000000000000000000000000000000002386f26fc10000` |
| `quoteSell` 0.01 | Portal | `0x9981d632` + 同上两个参数 |
| `buyPlanProbe(1e16,500)` | **Probe** `0x708ed2e7…1695` | `0x0f803438000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000001f4` |
| `quoteBuyProbe(1e16)` | Probe | `0xd620e44d000000000000000000000000000000000000000000000000002386f26fc10000` |
| `sellPlanCustomProbe(5000,500)` | Probe | `0xcceb5cad000000000000000000000000000000000000000000000000000000000000138800000000000000000000000000000000000000000000000000000000000001f4` |

### 7.5 用本仓库 `baw` CLI 落地

CLI 的两次式（`preview` → `execute`）签名（来自 `references/external-sign.md`）：

```powershell
# 0. 前置：Developer Mode 必须开启（contract-call 属于 external sign）
.\baw-wallet.cmd wallet-1 wallet settings --json     # 确认 devMode.enabled = true

# 1. 预览（强烈建议先跑第 2 步的只读 probe，再拼 minShares）
.\baw-wallet.cmd wallet-1 contract-call preview `
  --binanceChainId 56 `
  --from 0xYourWalletAddress000000000000000000000001 `
  --to   0x49387D2E6cbF8FefE856e3FBc3E98a01aC3af062 `
  --value 10000000000000000 `
  --inputData 0xcce7ec13000000000000000000000000baa11e4717b35d4b4e4332c425d702221da60027000000000000000000000000000000000000000000014b010a9ca8ed9ee4a644 `
  --json

# 2. 人工核对 parsedTx / risks / authorityChanges 后执行
.\baw-wallet.cmd wallet-1 contract-call execute --requestId <preview 返回的 requestId> --json
```

**`--value` 单位是 wei**（1 BNB = `1000000000000000000`），不是 `--amount` 那种人类可读值。
只读 probe 用任意 RPC 的 `eth_call` 即可（本报告用的是 `https://bsc-rpc.publicnode.com` 与 `https://bsc-dataseed.binance.org`），不必经过钱包。

> 注：`buy` 的 `minShares` 一定要用**刚刚**算出的 `MIN_SHARES`，不要复用旧值 —— i18n 明确要求 `Take MIN_SHARES/MIN_WEI/MIN_RAW exactly from the fresh plan; do not recompute, round or reuse an old minimum`。

---

## 8. 风控 / 限制（问题 7）

### 8.1 网络与反爬

| 项 | 实测 |
|---|---|
| CDN / WAF | `Server: cloudflare`、`CF-RAY: a4f22b0c…-SJC`、`cf-cache-status: DYNAMIC`；源站 Vercel（`x-vercel-id`、`x-vercel-cache: MISS`） |
| Cloudflare 挑战 | **没有**。裸 `curl`（普通 UA）直接 `HTTP 200`，无 `cf-mitigated`、无 JS challenge cookie |
| Turnstile / CAPTCHA | **没有**。页面 HTML 与 `component.mjs` 里 `turnstile` / `captcha` / `challenge` 命中数均为 0 |
| CSP | `frame-ancestors 'none'`；`connect-src 'self' https: wss:`（很宽，RPC 可任选） |
| 限流 | 页面自身无节流提示；FSI 建议 ≥5s 间隔轮询（仓库 `COMMANDS.md` 的通用建议） |
| FSI 鉴权 | **无**。裸 GET 直接 200，无 API key、无 cookie、无签名 |

### 8.2 钱包 / 签名

| 项 | 结论 |
|---|---|
| 必须连接钱包？ | **只读不需要**（`metadata.json` 的 e2e 覆盖 `guest` 阶段；市场列表走公共 RPC + FSI）。**任何写操作必须连**，用 RainbowKit + wagmi（页面里有 `data-rk` 注入的 `--rk-*` CSS 变量） |
| EIP-712 业务签名 | **没有**。`component.mjs` 里 `signTypedData` / `permit` / `deadline` 命中数全为 0；只有标准 `eth_sendTransaction` + 钱包弹窗确认 |
| 批量交易 | 运行时探测 EIP-5792 `wallet_sendCalls` / `capabilities`（连接器层），但本 app 未使用批处理 |
| 前端私钥 | 无。全部走注入式钱包 |
| 反机器人 | 链上层面有：**Agent ID（`0x60B926…022F`）是买入的硬门槛**（`ID=1` 才 `BUY_OK=1`）；无 CAPTCHA、无签名 nonce、无速率限制 |

### 8.3 交易层面的硬限制

| 限制 | 表现 | 证据 |
|---|---|---|
| **Agent ID 才能买** | `buyCapacityProbe` 返回 `ID=0` 时 `buy` 会拒；卖出/领取不要求 | i18n `Agent ID is required for buying only, not selling or claiming`；实测我们钱包 `handleOf = "<your-handle>"`、`ID=1` |
| **单钱包份额上限** | `maxWalletShares`（`buyCapacityProbe.LIMIT_SHARES`，样本 20,000,000e18） | `market.maxSharesPerWallet()` |
| **阶段闸门** | `PHASE=1` 才能买卖；`PHASE=3` 只能 claim / DEX 卖；`ROOM_WEI=0` 不等于已 launch（要看 `PHASE`） | `actionStatusProbe` / `launchRouteProbe` |
| **冷却时间** | **没发现**。`component.mjs` / ABI / i18n 里都没有 cooldown / 时间锁字段；`BLOCK=<n>` 只是「读数所在区块」的快照标记，不是限制 | `[未验证：不排除合约内部有 per-block 限制]` |
| **购买限额（金额）** | 曲线 `capRaw` 是市场总额上限；单笔无上限（`acceptedGross` 可被削减 + 退款） | `quoteBuy` 的 `refund` 字段 |
| **App 层金额上限** | `manifest.json` → portal `maxValueWei: "1000000000000000000"` = **1 BNB / 笔**；超出会 `launchValueLimitError` | `[文档]` + 页面 i18n |
| **App 层写权限** | `walletContracts.allow` 只列 `createMarket` / `createMarketAndBuy` / `createMarketWithQuote` → **页面无法发 buy/sell/claim** | 已验证 |
| **滑点** | 无默认值，必须用户给；`0..10000 bps`；`500` 只是示例 | i18n `500=5% is a conversion example, not a default` |
| **退款** | 接近 cap 时 `ACCEPT_WEI < grossWei`，差额退回；`MIN_SHARES` 仍按实际成交算 | `quoteBuy` 4 元组 |

### 8.4 页面实际做了什么（重要，避免误解）

这个 mini-app 是**「建盘 + 给 AI Agent 下指令」**的界面，不是自带买卖按钮的 DEX：

- 写：只有「创建市场」（`createMarket` / `createMarketAndBuy` / `createMarketWithQuote`）。
- 买卖/领取/查询：渲染成 5 个可复制的 **prompt**（`buy` / `sell` / `claim` / `query` / `dexExit`），由用户粘到 **Binance AI（Bibi）** 执行；prompt 里内嵌了 `CONFIG`（CHAIN_ID / FACTORY / PORTAL / READER / MARKET / QUOTE_TOKEN / QUOTE_DECIMALS / TOKEN / PREDICTED_TOKEN / PAIR / PROBE / WALLET）+ 完整 ABI + 执行规则 + 报告格式。
- 读：`Reader` 批量读 + Probe revert 读数 + FSI 历史 + dexscreener 折算 USD。
- 因此：**想用 CLI 直接买卖，完全可以**（ABI/参数/calldata 都在第 7 节），但别指望页面上点“买入” —— 它只会给你一段提示词。

---

## 9. 数据来源与「未验证」清单（问题 8）

### 9.1 用了哪些替代来源

`web_fetch` 直接抓 `https://flap.sh/...` 会失败（本机 DNS 被代理接管到 `198.18.x.x` 的 fake-ip 段，工具判定为内网地址而拒绝）。改用：

1. `curl.exe` 走系统代理抓 HTML → 解析 RSC payload；
2. 从 RSC 的 `registration` 提取 Vercel Blob 资产基址 → 下载 `component.mjs` / `manifest.json` / `metadata.json` ；
3. `curl` 下载 49 个 Next chunk，定位 artifact 加载器与 FSI/RPC 层；
4. 自写 keccak-256 + JSON-RPC 客户端（`research/_raw/chain.py`）做 `eth_call` / `eth_getCode` / `eth_getStorageAt`；
5. `fsi.taxed.fun` 裸 GET 取样；
6. 交叉验证：页面内置 ABI ↔ 自算 selector ↔ Portal 实现 bytecode dispatcher ↔ 实际 `eth_call` 返回值，四者一致才写进报告。

原始证据留在 `research/_raw/`（`page.html`、`component.mjs`、`i18n.json`、`manifest.json`、`metadata.json`、`probe*.out.txt`、`js/`）。

### 9.2 明确未验证 / 存疑

| # | 事项 | 状态 |
|---|---|---|
| 1 | 用户截图地址 `0x70604C50309092fCa6d91f3C312039Aa261bcD9` | **39 位 hex，非法地址**，无法查。请重新复制（`Reader.marketCards` 或页面 Copy 按钮） |
| 2 | 曲线积分闭式（`buy` 的 shares↔quote 解析式） | 未验证。实现于 `curveModule 0x8371c5…108a`，未开源；**用 `quoteBuy`/`quoteBuyProbe` 取真值即可** |
| 3 | `flapBuyFeeBps` 与 `agentFeeBps` 的关系（叠加 or 拆分） | 存疑。样本里两者恒等且实扣 1%，无法区分；以实扣 1.00% 为准 |
| 4 | 是否有 per-block / per-wallet 冷却 | 未验证（ABI 与提示词里都没有，但合约不可读源码） |
| 5 | `curveType=20`（原生）与 `50`（ERC20）的语义 | 未验证（推测与 reserve 缓冲倍数有关，`r/cap` 比值不同：6.14/5 vs 767.4/666.5） |
| 6 | `market.CAP()` 返回 `5e18` 而 `marketDetail.capRaw` 返回 `666.5e18`（ERC20 市场） | 语义不一致，未验证。取上限请用 **`capRaw` / `CAP_WEI`（probe）** |
| 7 | `sellAll` 两个同名重载 | 均存在（selector `0xd69f8e66` / `0x93768068`）；页面提示词只推荐 `sellBps`，建议跟进 `sellBps` |
| 8 | 页面用的 RPC 节点 | 未验证（由宿主钱包运行时注入，非硬编码） |
| 9 | 合约源码 / 是否开源验证 | 未验证。BscScan 无 API key，未逐一验证源码；本报告全部结论基于 **ABI + bytecode selector + 实际调用** |

---

## 附录 A：完整 `<script src>` 列表（50 条）

```
/_next/static/chunks/webpack-687394a4fdb9ebaa.js
/_next/static/chunks/polyfills-42372ed130431b0a.js
/_next/static/chunks/4bd1b696-100b9d70ed4e49c1.js
/_next/static/chunks/1913-812f06c69e0a6f99.js
/_next/static/chunks/main-app-7f278ddf1055bc1a.js
/_next/static/chunks/6585-be9a2634da20242b.js
/_next/static/chunks/420-c1e02a5dbd3f5184.js
/_next/static/chunks/4e88bc13-625632861c4fbe05.js
/_next/static/chunks/13b76428-c75990430d19f963.js
/_next/static/chunks/69b09407-f2257923662bb7a3.js
/_next/static/chunks/965f7cc4-59c29847c26c1d75.js
/_next/static/chunks/870fdd6f-d10ed0c664c8e3ba.js
/_next/static/chunks/83-087e6b3bd8918d4c.js
/_next/static/chunks/326-7e849721b4cb96eb.js
/_next/static/chunks/465-af8974bd6722b2dd.js
/_next/static/chunks/753-228226885070b22b.js
/_next/static/chunks/1557-21afcec37cc88ab7.js
/_next/static/chunks/2230-bf1c482c267d3573.js
/_next/static/chunks/2353-cd11484390f914b2.js
/_next/static/chunks/2544-c77cf766acab6360.js
/_next/static/chunks/2619-2513e7c69c182d93.js
/_next/static/chunks/2898-b7d07303b275b86d.js
/_next/static/chunks/3063-28593cf9656d5b0d.js
/_next/static/chunks/3925-411365fbe6f27a20.js
/_next/static/chunks/3955-09ffdfd7a69ce880.js
/_next/static/chunks/4183-d17730127041fdd6.js
/_next/static/chunks/4354-6203779dfda296ff.js
/_next/static/chunks/4481-7fecb9fd4599f774.js
/_next/static/chunks/5157-5a17a06ee7ed6eb3.js
/_next/static/chunks/5239-eafec49ba2198fe5.js
/_next/static/chunks/5490-3ea7f69ab44e48c2.js
/_next/static/chunks/5684-51b892cce24ac124.js
/_next/static/chunks/6711-1fe8726e48935690.js
/_next/static/chunks/7529-0f9f4b2707f2fa7b.js
/_next/static/chunks/7721-89b1e12ca6d53e41.js
/_next/static/chunks/8766-3c539a3b62e0461f.js
/_next/static/chunks/8856-a349b4f5bd81b1de.js
/_next/static/chunks/8930-6f69f6f877fb640f.js
/_next/static/chunks/8960-e9960ed542c71366.js
/_next/static/chunks/920-23f9938f064cb6cb.js
/_next/static/chunks/9382-5c5c2eae3de45763.js
/_next/static/chunks/9644-c3491dffa3e0ad5a.js
/_next/static/chunks/9759-06b1b0b2720f2c6e.js
/_next/static/chunks/app/layout-3a15c050efe81a30.js
/_next/static/chunks/app/error-ebd561520c0943ca.js
/_next/static/chunks/app/not-found-cbca39b47489bac7.js
/_next/static/chunks/app/apps/%5Bslug%5D/page-b3a8f94bda0ebe7b.js
/_next/static/chunks/app/apps/%5Bslug%5D/error-ffdee8a67fd30b46.js
/_next/static/chunks/app/apps/%5Bslug%5D/not-found-7bad4dd9868f559a.js
/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js
```

（真业务代码不在这 50 个里，而在 §2.2 的 `component.mjs`。）

## 附录 B：Reader / Market 常用只读签名

```solidity
// Reader 0x18Aa6C93f1887a243fdc348C9A77F5136555174a
function factory() view returns (address);
function marketPage(uint256 cursor, uint256 limit) view returns (address[] marketAddresses, uint256 nextCursor, uint256 total); // limit ≤ 16
function marketCards(address[] markets) view returns ((address market,address quoteToken,string name,string symbol,string meta,address predictedToken,address token,address pair,uint8 phase,uint256 poolRaw,uint256 capRaw,uint256 progressBps,uint256 buyCount,uint256 sellCount,uint256 curveH,uint256 curveK)[] cards);
function marketDetail(address market) view returns ((... 50 字段 ...) info);   // 含 flapBuyFeeBps / flapSellFeeBps / agentFeeBps / cumulative*
function marketSettings(address market) view returns ((... launch,curveType,curveR,curveH,curveK,capRaw,maxWalletShares ...) info);
function userPosition(address market, address wallet) view returns ((uint256 shares,uint256 claimableRaw,uint256 remainingWalletShares,(...) cumulative,bool statsComplete,bool eligibilityKnown,bool eligible,bool inventoryKnown,uint256 inventoryRaw,bool inventoryEnough) info);
function holderPage(address market, uint256 cursor, uint256 limit) view returns ((address wallet,uint256 shares)[] positions, uint256 nextCursor, uint256 indexedTotal, uint256 activeTotal, bool complete);
function probeOfMarket(address market) view returns (address);
function probeOfToken(address token) view returns (address);

// Market（beacon proxy）
function portal() view returns (address);
function phase() view returns (uint8);                 // 1=curve, 2=launching, 3=launched
function poolWei() view returns (uint256);
function totalShares() view returns (uint256);
function sharesOf(address wallet) view returns (uint256);
function predictedToken() view returns (address);
function token() view returns (address);               // phase 3 才非 0
function pair() view returns (address);
function creator() view returns (address);
function maxSharesPerWallet() view returns (uint256);
function CAP() view returns (uint256);
function launchConfig() view returns ((string,string,string,bytes32,address,uint16,uint16,uint16,uint16,uint16,uint16,uint16));
```

`marketDetail` 的 50 个字段顺序（本报告用于手工解码，可直接复用）：

```
0 market 1 creator 2 quoteToken 3 quoteDecimals 4 capRaw 5 poolRaw 6 remainingRaw 7 progressBps
8 phase 9 predictedToken 10 token 11 pair 12 curveReserveRaw 13 totalShares 14 claimedShares
15 maxWalletShares 16 predictedInitialBuyNetRaw 17 configHash 18 flapBuyFeeBps 19 flapSellFeeBps
20 agentFeeBps 21 buyCount 22 sellCount 23 cumulativeBuyGrossRaw 24 cumulativeBuySubmittedRaw
25 cumulativeBuyNetRaw 26 cumulativeBuyFeesRaw 27 cumulativeBuyRefundRaw 28 cumulativeBuyShares
29 cumulativeBuyCurveRaw 30 cumulativeSellDebitRaw 31 cumulativeSellPayoutRaw 32 cumulativeSellFeesRaw
33 cumulativeSellShares 34 cumulativeSellCurveRaw 35 cumulativeSellReserveRefundRaw 36 claimCount
37 uniqueBuyerCount 38 holderCount 39 virtualCurveVolumeRaw 40 cumulativeAgentFeesRaw 41 launchedAt
42 statsStartBlock 43 statsComplete 44 quoteBalanceKnown 45 quoteBalanceRaw 46 quoteBackingEnough
47 inventoryKnown 48 inventoryRaw 49 inventoryEnough
```

## 附录 C：Probe revert-string 解码（任意语言）

`eth_call` 返回的 `error.data` 形如 `0x08c379a0 + offset + len + utf8`。取出字符串后：

1. 必须以 `;END` 结尾，否则视为「不可读」，**不要当 0**；
2. 按 `;` 切分，每段按第一个 `=` 拆 `KEY` / `VALUE`；
3. 金额用 `QUOTE_DECIMALS` 格式化；份额恒 18 位小数；
4. 关键闸门字段：`PHASE`（1/3）、`BUY_OK`、`SELL_OK`、`CLAIM_OK`、`ID`、`RULES_OK`、`STATE`（`READY`/`PRELAUNCH`/`CLAIMED`/`NO_POSITION`）；
5. 只允许对 Probe 做 `eth_call`，**永远不要广播 Probe 调用**。
