# baw CLI 命令清单与脚本化用法

> 结论先行：**能脚本化，而且明显更快**。同一个 `wallet balance`，直接跑 CLI 约 1.4 秒；
> 走「和我对话」要经过推理 + 工具调用 + 确认，通常 10~60 秒。脚本化后延迟基本只剩网络。
> AI 适合做「发现、判断、一次性编排」，高频重复动作应该固化成脚本/别名。

## 调用约定

```powershell
# 钱包 1
.\baw-wallet.cmd wallet-1 <命令> --json
# 钱包 2
.\baw-wallet.cmd wallet-2 <命令> --json
```

- 所有命令都支持 `--json`，脚本里务必带上，便于 `ConvertFrom-Json`。
- 不要直接运行 `baw`：那是全局默认目录 `%USERPROFILE%\.baw`，和这两个钱包无关。
- 退出码 `0` 表示成功；业务错误在 JSON 的 `success:false` 里。

实测延迟（BSC，家用网络）：`wallet balance` ≈ 1.4s，`market-order quote` ≈ 0.5~1.1s。

## 命令总览

### auth — 登录
| 命令 | 说明 |
|---|---|
| `auth signin --json` | 生成 `urlForWeb` / `pairingCode` / `qrCodeId` |
| `auth verify --qrCodeId <id> --json` | 阻塞等待 App 确认（最长 5 分钟） |
| `auth signout --json` | 退出当前 profile 的会话 |

### wallet — 钱包（只读为主）
| 命令 | 说明 |
|---|---|
| `wallet status` | 连接状态 |
| `wallet address` | 各链地址 |
| `wallet balance [--symbol BNB] [--binanceChainId 56]` | 非零余额 + USD 估值 |
| `wallet settings` | 限额、会话到期、devMode |
| `wallet left-quota` | 今日额度用量 |
| `wallet chains` | 支持的链与 chainId |
| `wallet gas-price --binanceChainId 56` | 三档 gas |
| `wallet tx-history [--type pending] [--size 50]` | 交易历史/单笔详情 |
| `wallet tx-lock --binanceChainId 56` | 是否有待确认/锁定交易 |
| `wallet resolve-domain --domain alice.eth` | 域名解析 |
| `wallet send --binanceChainId 56 --amount 1 --tokenAddress 0x... --recipient 0x...` | 转账（变更） |
| `wallet cancel <txHash>` / `wallet speed-up <txHash>` | 取消/加速 |

### market-order — 市价兑换（变更）
| 命令 | 说明 |
|---|---|
| `market-order quote --binanceChainId 56 --fromTokenQty 1 --fromToken 0x... --toToken 0x...` | 只报价，不广播 |
| `market-order swap ... [--slippage auto|1] [--mev true] [--gasLevel MEDIUM]` | 执行兑换 |
| `market-order list` | 历史市价单 |
| `market-order list --orderId <id> --json` | 查单笔：`swap` 只返回 `orderId`，`txHash` / `status`（PENDING·FINISHED·FAILED）要靠这条查 |

### limit-order — 限价单（变更）
`limit-order buy` / `sell` / `list` / `cancel`（触发价单，不是立即成交）。

### prediction — 预测市场
`prediction category list`、`market list|detail|search|order-book|last-trade-price`、
`position list|token|settled-history|pnl|portfolio`、`order history`、
`trade quote|place-order|cancel|redeem`。

### defi — DeFi
`defi protocol-list|protocol-info|investment-list|investment-info|position`（只读）、
`defi deposit|redeem|lp-add|lp-remove|claim|preview`（变更）。

### approvals — 授权管理
`approvals list|detail|revoke`。

### 其他
- `contract-call preview|execute`：两步，先 preview 拿 `requestId` 再 execute。
- `sign-message preview|execute|result|history`：同上，签名消息。
- `x402-payment preview|sign`：HTTP 402 支付。
- `tracker token|tx|follow|group|address|ws`：地址/交易监控。
- `leaderboard query|analyze|alpha-radar|preset|alpha-radar-config`。
- `signal list|strategy|backtest|explore|credits|wallet-group`。
- `skill-check` / `cli-check`：版本检查。

## 脚本范式（PowerShell）

**1) 读取余额并格式化**

```powershell
$r = .\baw-wallet.cmd wallet-1 wallet balance --json | ConvertFrom-Json
$r.data | ForEach-Object { "{0,-6} {1,12}  ${2}" -f $_.symbol, $_.balance, $_.usdValue }
```

**2) 报价 → 判断 → 执行（带阈值保护）**

```powershell
$q = .\baw-wallet.cmd wallet-1 market-order quote --binanceChainId 56 `
      --fromTokenQty 10 --fromToken 0x55d398326f99059fF775485246999027B3197955 `
      --toToken 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee --json | ConvertFrom-Json

if ([double]$q.data.toCoinAmount -lt 0.013) { throw "报价低于阈值，放弃" }

.\baw-wallet.cmd wallet-1 market-order swap --binanceChainId 56 `
  --fromTokenQty 10 --fromToken 0x55d398326f99059fF775485246999027B3197955 `
  --toToken 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee --slippage 1 --json
```

**3) 轮询待处理交易**

```powershell
while ($true) {
  $p = .\baw-wallet.cmd wallet-1 wallet tx-history --type pending --json | ConvertFrom-Json
  if (-not $p.data.list) { "no pending"; break }
  Start-Sleep 5
}
```

**4) 循环监控价格/余额**

```powershell
while ($true) {
  $b = .\baw-wallet.cmd wallet-1 wallet balance --symbol USDT --json | ConvertFrom-Json
  "{0:HH:mm:ss} USDT={1}" -f (Get-Date), $b.data[0].balance
  Start-Sleep 30
}
```

**5) 批量/多钱包**

```powershell
foreach ($w in 'wallet-1','wallet-2') {
  $exe = ".\baw-wallet.cmd"
  $r = & $exe $w wallet balance --json | ConvertFrom-Json
  "$w total USD: " + (($r.data | Measure-Object usdValue -Sum).Sum)
}
```

## 注意事项

1. **变更类命令没有二次确认**：`send` / `swap` / `limit-order` / `defi` / `revoke` 直接执行，
   平台侧只受日限额与 `abnormalTxnHandling` 约束。脚本里请自己加阈值、白名单、`-DryRun` 开关。
2. **先 quote 再 swap**，不要把 quote 的返回值当成交结果；swap 才广播。
3. `contract-call` / `sign-message` 必须 preview → 人工核对 → execute（`requestId` 两段式）。
4. **RWA 缓存写在 `%USERPROFILE%\.baw\rwa-tokens.json`**（硬编码，不受 profile 影响），
   只是公共代币列表缓存，不含凭据；在受限沙箱里该写入会失败并导致 market-order 崩溃，
   普通终端无此问题。
5. 两个 profile 的会话独立，脚本里别混用目录；`--json` 输出可能含地址与余额，注意日志脱敏。
6. 高频轮询注意接口限频；读操作建议 ≥5s 间隔。
