/*
 * 工具栏弹窗：连接状态、当前网站停用 / 启用、显示 / 隐藏交易窗口、下单钱包与直接买入状态、两个常用开关。
 * 只读设置和调后台已有的接口（/api/wallets、/api/quick/arm），不新增任何下单路径。
 * 当前标签页的网址靠 activeTab 权限（用户点开弹窗时才授予，只对这一个标签页）。
 */
const $ = (s) => document.querySelector(s);
const DEFAULT_BLOCK = ['x.com', 'twitter.com'];
const matches = (host, d) => Boolean(d) && (host === d || host.endsWith(`.${d}`));

function setPill(el, text, cls = '') { el.textContent = text; el.className = `pill ${cls}`; }
const api = (path) => chrome.runtime.sendMessage({ type: 'api', path }).catch((err) => ({ ok: false, error: err.message }));

let tab = null;
let host = '';

async function blockList() {
  const { blockSites } = await chrome.storage.local.get('blockSites');
  return Array.isArray(blockSites) ? blockSites : DEFAULT_BLOCK;
}

/** 当前网站这一块：是否停用、页面里有没有插件脚本 */
async function renderSite() {
  const web = /^https?:$/.test((() => { try { return new URL(tab?.url || '').protocol; } catch { return ''; } })());
  $('#host').textContent = web ? host : '（浏览器页面）';
  if (!web) {
    setPill($('#siteState'), '不支持');
    $('#btnSite').disabled = true;
    $('#btnToggle').disabled = true;
    $('#pageHint').textContent = '浏览器自己的页面（设置页、扩展商店等）不能显示交易窗口。';
    return;
  }
  const list = await blockList();
  const hit = list.filter((d) => matches(host, d));
  $('#btnSite').disabled = false;
  $('#btnSite').textContent = hit.length ? '在此网站启用' : '在此网站停用';
  $('#btnSite').title = hit.length ? `从「不加载的网站」里移除：${hit.join('、')}` : `把 ${host}（含子域名）加进「不加载的网站」`;
  if (hit.length) {
    setPill($('#siteState'), '已停用', 'warn');
    $('#btnToggle').disabled = true;
    $('#pageHint').textContent = `命中「不加载的网站」：${hit.join('、')}`;
    return;
  }
  // 问一下页面里的脚本还在不在（装好 / 重新加载插件之前就打开的页面没有）
  const st = await chrome.tabs.sendMessage(tab.id, { type: 'panelState' }).catch(() => null);
  $('#btnToggle').disabled = !st;
  if (!st) {
    setPill($('#siteState'), '未加载', 'err');
    $('#pageHint').textContent = '这个页面还没加载插件（插件装好或重新加载之前就打开了）：刷新页面后可用。';
    $('#btnToggle').textContent = '刷新页面';
    $('#btnToggle').disabled = false;
    $('#btnToggle').onclick = () => { chrome.tabs.reload(tab.id); window.close(); };
    return;
  }
  setPill($('#siteState'), st.open ? '窗口已打开' : '正常', 'ok');
  $('#btnToggle').textContent = st.open ? '隐藏交易窗口' : '显示交易窗口';
  $('#pageHint').textContent = st.ca ? `当前 CA：${st.ca}` : '';
}

async function renderWallets() {
  const box = $('#wallets');
  const r = await api('/api/wallets');
  if (!r?.ok) {
    setPill($('#conn'), r?.needSetup ? '未配对' : '连不上', 'err');
    box.replaceChildren(Object.assign(document.createElement('span'), { className: 'hint', textContent: r?.error || '连不上控制台' }));
    return;
  }
  setPill($('#conn'), '已连接', 'ok');
  const { quickWallets } = await chrome.storage.local.get('quickWallets');
  const ids = (Array.isArray(quickWallets) ? quickWallets : []).filter((id) => r.data.some((w) => w.id === id));
  if (!ids.length) {
    box.replaceChildren(Object.assign(document.createElement('span'), { className: 'hint', textContent: '还没选钱包：在交易窗口标题栏勾选' }));
    return;
  }
  const arms = await Promise.all(ids.map((id) => api(`/api/quick/arm?walletId=${encodeURIComponent(id)}`)));
  box.replaceChildren(...ids.map((id, i) => {
    const w = r.data.find((x) => x.id === id);
    const a = arms[i]?.ok ? arms[i].data : null;
    const on = Boolean(a?.armed && Date.now() < Date.parse(a.expiresAt));
    const row = document.createElement('div');
    row.className = 'w';
    const name = Object.assign(document.createElement('span'), { className: 'name', textContent: w?.name || id });
    const pill = document.createElement('span');
    setPill(pill, on ? `免确认 ≤ ${a.maxBuyBnb} BNB` : '买入需确认', on ? 'ok' : 'warn');
    if (on) pill.title = `直接买入有效到 ${new Date(a.expiresAt).toLocaleString()}，滑点 ≤ ${a.maxSlippageBps / 100}%`;
    row.append(name, pill);
    return row;
  }));
}

async function init() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { host = new URL(tab?.url || '').hostname.toLowerCase(); } catch { host = ''; }

  const s = await chrome.storage.local.get(['autoOpen', 'sellNoConfirm']);
  $('#autoOpen').checked = s.autoOpen !== false;
  $('#sellNoConfirm').checked = s.sellNoConfirm !== false;
  $('#autoOpen').onchange = (e) => chrome.storage.local.set({ autoOpen: e.target.checked });
  $('#sellNoConfirm').onchange = (e) => chrome.storage.local.set({ sellNoConfirm: e.target.checked });

  $('#btnToggle').onclick = async () => {
    await chrome.tabs.sendMessage(tab.id, { type: 'togglePanel' }).catch(() => null);
    window.close();
  };
  $('#btnSite').onclick = async () => {
    const list = await blockList();
    const hit = list.filter((d) => matches(host, d));
    // 停用：加当前域名（去掉 www.，子域名一起停用）；启用：去掉所有命中这个网站的规则
    const next = hit.length ? list.filter((d) => !hit.includes(d)) : [...list, host.replace(/^www\./, '')];
    await chrome.storage.local.set({ blockSites: next }); // 已打开的网页通过 storage.onChanged 立即生效
    renderSite();
  };
  $('#btnOptions').onclick = () => { chrome.runtime.openOptionsPage(); window.close(); };

  const cmd = (await chrome.commands.getAll()).find((c) => c.name === 'toggle-panel');
  $('#shortcut').textContent = cmd?.shortcut ? `快捷键 ${cmd.shortcut}：显示 / 隐藏窗口` : '快捷键未设置（chrome://extensions/shortcuts）';

  renderSite();
  renderWallets();
}

init();
