// offscreen 文档：只做一件事——把剪贴板内容读出来交给后台（需要 clipboardRead 权限）
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen' || msg.type !== 'readClipboard') return false;
  const t = document.getElementById('t');
  t.value = '';
  t.focus();
  document.execCommand('paste');
  reply({ text: t.value });
  t.value = '';
  return false;
});
